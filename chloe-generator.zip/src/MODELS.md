# MODELE LLM — research pod E2 (własny model Chloe przez API)

Cel: wybrać model, którego Chloe użyje w trybie **E2** (własny klucz API), optymalny
dla: (1) nieocenzurowane wyszukiwanie i wiedza NSFW, (2) język polski, (3) prostota
wdrożenia. Data researchu: 2026-09-12.

## Metoda

- **RP-Bench / PlotPoints** — otwarty benchmark modeli do ról, sprawdzany
  **wyłącznie przez OpenRouter** (celowo, by usunąć zmienną providera). Zawiera:
  arena głosowana przez ludzi (single-message ELO oraz multi-turn ELO na pełnych
  dialogach), ocenę sędziowską (Sonnet + DeepSeek R1), rundę NSFW (40 modeli × 20
  seedów × 12 tur), **refusal %**, koszt i latencję. Źródła:
  `github.com/LeviTheWeasel/rp-benchmark`, `plotlightstudios.com/plotpoints`,
  `arena.l3vi4th4n.ai`.
- **EuroEval — Polish leaderboard** (~300 modeli, zadania językowe PL:
  klasyfikacja, NER, QA, streszczanie, wiedza). Niższy „rank score” = lepiej.
- **OpenRouter Models API** — ceny, kontekst, flaga moderacji providera
  (`is_moderated`), limity.
- Reddit: r/SillyTavernAI, r/LocalLLaMA, r/NSFWAI (przez redlib).

## Wniosek 1 (kluczowy, kontrintuicyjny): klasyczne „uncensored RP finetune'y” są przestarzałe

W rundzie NSFW (Round 3) modele reklamowane jako _uncensored / erotyczne_ wylądowały
**na samym końcu** stawki 40 modeli (craft wg sędziego Sonnet):

| # | Model (finetune) | Craft |
|---|---|---|
| 34 | Lunaris 8B | 3.83 |
| 35 | Cydonia 24B | 3.65 |
| 36 | Magnum v4 72B | 3.23 |
| 37 | UnslopNemo 12B | 2.61 |
| 38 | Skyfall 36B | 2.52 |
| 39 | Rocinante 12B | 2.49 |
| 40 | **Euryale L3.3 70B** | **2.12** |

Czołówka (craft 4.5–4.65): Claude Opus 4.8/4.6/4.7, **DeepSeek V4 Pro**, GPT-5.5,
Owl Alpha, MiMo 2.5 Pro, MiniMax M3. Sędziowie karzą finetune'y za powtórzenia,
purple prose i łamanie agencji gracza.

**Ale** „willingness” (nieodmawianie) to osobna oś: finetune'y mają **0% odmów**,
natomiast część modeli frontier ma 5–10%. Czyli „nie odmawia” ≠ „dobrze pisze”.
Dobra wiadomość: najlepsze modele open (DeepSeek V4 Pro/Flash) mają **jednocześnie
0% odmów i wysoki craft**.

## Wniosek 2: co realnie lubi społeczność (głosy ludzi)

**Single-message ELO** (engagement; ~2 000 głosów): #1 Gemma 4 26B, #2 **Mistral
Small Creative** (NSFW 67% wygranych!), #3 Gemini 2.5 Flash.

**Multi-turn ELO** (całe dialogi): #1 **DeepSeek V4 Pro**, #2 Claude Opus 4.6,
#3 Gemini 3.1 Flash Lite, #4 GPT-4.1, #6 Mistral Small Creative.

**„Kto najlepszy w NSFW” wg ludzi:** Mistral Small Creative **67%**, Grok 4.1 52%,
Gemini 54%. Najsłabsi w NSFW: DeepSeek 30%, Llama 34%, MiniMax 34% — czyli DeepSeek
jest _chętny_, ale wg ludzi pisze mniej „spicy”.

## Wniosek 3: polski (EuroEval — niższy = lepiej)

| Rank score | Model |
|---|---|
| 1.59 | Qwen3.8-27B / Qwen3.6-27B (najlepszy open) |
| 1.76 | Qwen3.5-35B-A3B |
| **1.85** | **Gemma 4 31B-it** |
| 1.87 | gpt-oss-120b |
| 2.01 | Mistral Small 3.1 24B |
| 2.05 | **Gemma 4 26B A4B-it** |
| 2.18 | GLM 4.7 Flash |

Wniosek: **Qwen i Gemma są najlepsze w polskim**, Mistral tuż za nimi (bardzo
dobry), DeepSeek nie pojawił się w tym zestawieniu (niepewne, trzeba przetestować).

## Wniosek 4: prędkość i koszt

- **Mistral Small Creative** — najszybszy realnie: 192 tok/s, **230 ms TTFT**,
  mediana 2.8 s, ~$0.0003/zapytanie.
- **DeepSeek V4 Flash** — #1 stosunek jakość/koszt (~$0.18/1M, mediana 5.3 s).
- **Gemini 3.1 Flash Lite** — najszybszy z wysoką jakością (2.3 s, Likert 4.30).
- Modele „reasoning” (GLM 4.7: **mediana 36 s**!; Kimi: 45–60 s) — za wolne do
  czatu na żywo; palą też tokeny myślenia, za które się płaci.

## Rekomendacja — shortlista (wszystkie OpenRouter, OpenAI-compatible, `mod:false`)

| # | OpenRouter ID | $in/$out za Mtok | Kontekst | Kiedy brać |
|---|---|---|---|---|
| **1** | `mistralai/mistral-small-2603` (Mistral Small Creative / „Mistral SC”) | $0.15 / $0.60 | 262k | **Najlepszy ogólny do NSFW**: #1 wg ludzi w NSFW (67%), #2 engagement, #6 multi-turn, **najszybszy**, tani, dobry polski (~2.0), brak moderacji. Minus: 15.9% naruszeń agencji (czasem pisze za użytkownika) — łagodzone promptem. |
| **2** | `google/gemma-4-26b-a4b-it` | $0.09 / $0.30 | 262k | **Najlepszy polski wśród NSFW-lubianych + #1 engagement**: polski 2.05, zbalansowany SFW/NSFW, tani, ma endpoint `:free` do testów. Minus: słabsza niezawodność wieloturowej (7/12). |
| 2b | `google/gemma-4-31b-it` | $0.09 / $0.34 | 262k | Jeszcze lepszy polski (1.85); uwaga: maxOut 16k, bardziej „instruct” (mniej swobodny). |
| **3** | `qwen/qwen3.8-27b` | $0.21 / $2.55 | 1M | **Najlepszy polski w ogóle** (1.59) + dobre rozumienie intencji/zadań. Minus: drogi output, wg społeczności mniej „NSFW-spicy”. |
| **4** | `deepseek/deepseek-v4-flash` (lub `-0731`) | $0.047 / $0.095 | 1M+ | **Najlepszy stosunek cena/jakość**: 0% odmów, craft 4.38, najtańszy, szybki. Minus: słabszy „vibe” NSFW wg ludzi, polski niepotwierdzony. |
| 5 | `deepseek/deepseek-v4-pro` | $1.60 / $3.20 | 1M | Opcja „premium”: #1 multi-turn ludzi, NSFW craft 4.62 przy 0% odmów. Wolny (~17 s). |
| — | `google/gemma-4-26b-a4b-it:free`, `nvidia/nemotron-3-super-120b-a12b:free`, `nex-agi/nex-n2.5-pro:free` | $0 | — | **Darmowe testy** (rate-limited) — do sprawdzenia polskiego bez płacenia. |

> **Sprostowanie (2026-09-12, weryfikacja na HF):** `mistralai/mistral-small-2603`
> to **Mistral Small 4**, dokładnie `mistralai/Mistral-Small-4-119B-2603` — **119B MoE**
> (36 warstw, top-4 + 1 shared expert, MLA/`kv_lora_rank`), a **nie 24B**.
> Na pojedynczym L4 (24 GB) się **nie zmieści** (INT4 ≈ 68 GB); potrzebuje 2×L40S
> (96 GB, $3.60/h) albo H100. Do lokalnego GPU patrz rozdział „NVIDIA L4" niżej.

**Mój wybór domyślny: `mistralai/mistral-small-2603`** (najlepszy kompromis
NSFW + szybkość + koszt + polski), z `google/gemma-4-26b-a4b-it` jako alternatywą
gdy polski jest priorytetem.

## Konfiguracja Mistral Small 4 — zalecane ustawienia (2026-09-12)

Sprawdzone w dokumentacji Mistrala i OpenRoutera, **zweryfikowane na żywo**
(HTTP 200, provider `Mistral`, odpowiedź bez wycieku rozumowania). Wdrożone w
`chloeE2Chat` / `chloeE2BuildMessages` (warstwa `CHLOE_E2_MISTRAL_EXTRA`).

| Parametr | Wartość | Dlaczego |
|---|---|---|
| `temperature` | **0.9** (0.85–0.95; w trybie wiedzy automatycznie ścinane do ≤0.6) | Mistral zaleca **wysoką** temperaturę do kreatywności/RP, ale ostrzega przed „nadmiernie wysoką”. 0.9 to środek; tryb wiedzy = fakty, więc niżej. |
| `top_p` | **nie wysyłamy** (domyślne 1.0) | Mistral: **nie stroić jednocześnie** temperatury i `top_p` — regulujemy samą temperaturę. (Gemma dalej dostaje 0.95.) |
| `frequency_penalty` | **0.1** | Mistral ostrzega, że kary psują spójność; 0.1 wystarcza przeciw pętlom, nie kaleczy prozy. |
| `presence_penalty` | **0.1** | jw. |
| `reasoning` (RP/czat) | `{ enabled: false }` | Domyślne „myślenie” ignoruje temperaturę/ kary, spowalnia i **zjada `max_tokens`** (ryzyko pustej odpowiedzi przy `finish_reason:"length"`). Do RP zbędne. |
| `reasoning` (tryb wiedzy) | `{ effort: "low", exclude: true }` | `mistral-small-latest` wspiera `reasoning_effort` bez konfiguracji; `low` = krótki tok myśli, `exclude` = nie wysyłamy szkicu użytkownikowi. `max_tokens` podbite do **≥4000**, żeby rozumowanie nie zjadło całego budżetu. |
| `max_tokens` | panel: 3000; w trybie wiedzy `Math.max(x, 4000)` | patrz wyżej. |
| `stop` | `["[INST]", "[/INST]", "</s>"]` | siatka na wyciek surowych znaczników szablonu. |
| `provider` | `{ order: ["Mistral"], allow_fallbacks: true }` | endpoint Mistrala: **262k ctx, 209k max out, ZDR/EU, $0.15/$0.60, cache read $0.015/Mtok (10× taniej)**, ~99.9% uptime. `allow_fallbacks` ratuje, gdy Mistral padnie. |
| warstwa promptu | `CHLOE_E2_MISTRAL_EXTRA` | Mistral miesza polski z angielskim i potrafi wypluć szkic myśli — dopinamy: **tylko polski**, zakaz moralizowania, zakaz pokazywania rozumowania (`<thinking>`, „krok 1”), format 2–4 akapity + 2–4 `[[akcje]]`. |
| fallback 400/422 | ponowienie bez `reasoning`/`provider` | gdyby jakiś inny endpoint (niż OpenRouter) nie znał tych pól. |

> **Prowider:** endpoint **Mistral** NIE wspiera `top_k` (Venice tak, ale fp8 i drożej:
> $0.1875/$0.75, 65k max out) — dlatego **nie wysyłamy `top_k`**, żeby nie zawęzić puli
> providerów.

**Źródła:** https://docs.mistral.ai/capabilities/reasoning · https://docs.mistral.ai/capabilities/sampling
· https://openrouter.ai/docs/use-cases/reasoning-tokens · `https://openrouter.ai/api/v1/models/mistralai/mistral-small-2603/endpoints`

## Czego NIE brać

- Modele z moderacją providera (`mod:true`): Anthropic Claude, OpenAI, Amazon Nova,
  Cohere — odmówią/zetną NSFW na poziomie API.
- Klasyczne uncensored finetune'y (Euryale, Magnum, Cydonia, Rocinante, Skyfall,
  UnslopNemo, Lunaris) — wg benchmarku 2026 przestarzałe.
- Ciężkie modele „reasoning” (GLM 4.7, GLM 5.x, Kimi) — za wolne do czatu.

## Najprostsze wdrożenie

**OpenRouter**: jeden klucz, jeden endpoint OpenAI-compatible
(`POST https://openrouter.ai/api/v1/chat/completions`), wszystkie modele za jednym
API, przyjazny CORS, kredyty prepaid (bez subskrypcji), darmowe endpointy do testów.
Alternatywy (Venice.ai, Featherless, Arli, Infermatic, NanoGPT, DreamGen) też są
OpenAI-compatible, ale OpenRouter ma największy wybór i najlepszą stabilność.

Uwaga: `fetch` w custom code idzie przez **proxy Perchance** → klucz przechodzi przez
proxy. Opcja „direct” (z pominięciem proxy, bezpośrednio do OpenRouter) prawdopodobnie
działa (OpenRouter wysyła `Access-Control-Allow-Origin: *`) i daje streaming SSE — do
potwierdzenia przy implementacji.

## Plan wdrożenia E2

1. Panel ustawień: provider (OpenRouter), klucz API, model (presety powyżej + pole
   własne), temperatura, max tokenów. Klucz trzymany **lokalnie** (localStorage
   iframe'a / `customData`), nigdy w kodzie generatora.
2. Przechwycenie tury w `MessageAdded` (user → `expectsReply=false`), budowa promptu,
   POST, wstawienie odpowiedzi.
3. Domyślnie włączony `mistralai/mistral-small-2603`; **natychmiastowy fallback** do
   natywnego modelu Perchance przy braku klucza / błędzie / 429.
4. Tryb opcjonalny (przełącznik „model: Perchance / własny”), żeby nie psuć natywnej
   pamięci i lorebooka, gdy klucza brak.

## Źródła

- RP-Bench: https://github.com/LeviTheWeasel/rp-benchmark
- PlotPoints: https://plotlightstudios.com/plotpoints · https://arena.l3vi4th4n.ai
- EuroEval Polish: https://euroeval.com/leaderboards/polish
- OpenRouter models: https://openrouter.ai/api/v1/models

---

# Darmowe opcje (research 2026-09-12, na pytanie: „czy jest model za darmo?")

## A. OpenRouter — warianty `:free` (naprawdę $0/token)

- Wymaga tylko **darmowego konta + klucza** (bez karty).
- Limity platformowe (potwierdzone w `openrouter.ai/docs/api-reference/limits.md`,
  stałe `FREE_MODEL_*`): **20 zapytań/min**; **50 zapytań/dzień** przy doładowaniach
  < $10; **1000 zapytań/dzień** po jednorazowym doładowaniu ≥ $10
  (`FREE_MODEL_CREDITS_THRESHOLD = 10`). Limity liczone **globalnie** — kolejne
  konta/klucze nic nie dają.
- Sprawdzone przez API: 445 modeli, 22 z `pricing = 0/0`, 19 z sufiksem `:free`.
  Aktualnie dostępne: `google/gemma-4-26b-a4b-it:free`, `google/gemma-4-31b-it:free`,
  `nvidia/nemotron-3-ultra-550b-a55b:free` (550B!), `nvidia/nemotron-3-super-120b-a12b:free`,
  `nvidia/nemotron-3.5-lightning:free`, `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free`,
  `nex-agi/nex-n2.5-pro:free`, `nex-agi/nex-n2.5-mini:free`,
  `inclusionai/ling-3.0-flash*:free`, `thinkingmachines/inkling:free`,
  `poolside/laguna-s-2.1:free`, `dots-studio/dots-3-note-preview:free`,
  `liquid/lfm-2.5-2.6b:free`, `openrouter/free`.
- **Uwaga:** wśród darmowych **nie ma** klasycznych finetune'ów „uncensored" — to
  głównie modele instruct (Gemma / Nemotron / Ling / Nex), wszystkie
  `is_moderated:false`. Do pełnego NSFW mogą częściowo odmawiać, ale nie ma
  moderacji na poziomie providera. (`nvidia/nemotron-3.5-content-safety:free` to
  klasyfikator bezpieczeństwa — nie do czatu.)

## B. Hugging Face — co realnie daje PRO

- **PRO = $2.00/mies. kredytów** inferencyjnych (docs „Pricing and Billing";
  NIE $9 jak dawniej; darmowe konto = $0.10). Kredyty są ogólne: Inference
  Providers, Inference Endpoints, GPU Spaces (także ZeroGPU ponad kwotę), Jobs.
  Czyli HF to **nie jest darmowe** — to ok. $2/mies.
- Router HF jest **OpenAI-compatible**:
  `POST https://router.huggingface.co/v1/chat/completions`,
  `Authorization: Bearer hf_...`, model z sufiksem wyboru providera:
  `Qwen/Qwen3.8-27B:featherless-ai`, `...:cheapest`, `...:fastest`, `...:preferred`.
- Sprawdzone: router ma 143 modele, **0 z `is_free:true`** — brak darmowych.
- **Kluczowe dla NSFW:** provider **`featherless-ai`** (69 modeli, `status:live`)
  hostuje znane nieocenzurowane finetune'y: `Sao10K/L3-8B-Stheno-v3.2`,
  `Sao10K/L3-8B-Lunaris-v1`, `NousResearch/Hermes-3-Llama-3.1-70B` — i nie moderuje.
  To najlepsza ścieżka „NSFW na HF" (za kredyty PRO).
- HF Content Policy **nie zakazuje** konsensualnych treści dla dorosłych — zakazuje
  tylko: małoletni, nękanie/poniżanie, treści bez zgody. NSFW to szara, ale
  dozwolona strefa (sam Hosting modeli na HF jest znany z NSFW modeli).

## C. Własny HF Space (najbliżej „za darmo bez limitów")

- Darmowy **CPU Space** (2 vCPU / 16 GB) może serwować mały model GGUF przez
  `llama.cpp` z endpointem OpenAI-compatible (`/v1/chat/completions`) pod
  `https://<user>-<space>.hf.space`. Koszt $0, model dowolny (też uncensored).
  Minusy: wolno (~kilka tok/s) i Space zasypia po 48 h bezczynności.
- **ZeroGPU (PRO)** działa tylko dla funkcji **Gradio** i ma kwoty — **nie** daje
  stałego endpointu OpenAI-compatible. Stały GPU Space = płatny za godzinę.

## D. Lokalnie w przeglądarce (E3)

- WebGPU / transformers.js: $0, bez konta, bez limitów, prywatnie; wolno i ciężko
  (na telefonie odpada). Patrz `PLAN.md` E3.

## E. Odpadają (darmowe, ale moderowane → odmówią NSFW)

- Google AI Studio / Gemini free tier, Groq free, Cerebras free, Cloudflare
  Workers AI — wszystkie mają moderację treści.

## Wniosek

- „Za darmo **i** nieocenzurowane" jednocześnie w gotowym API praktycznie nie
  istnieje. Najbliżej: (1) własny CPU Space (darmo, wolno, dowolny model),
  (2) OpenRouter `:free` (50 zapytań/dzień, model instruct), (3) lokalny WebGPU.
- **Najlepszy stosunek cena/nieocenzurowanie:** HF PRO ($2/mies.) → router →
  provider `:featherless-ai` (Stheno / Lunaris / Hermes) — rzędu kilku tysięcy
  krótkich zapytań miesięcznie.
- Żeby którakolwiek z tych opcji działała w Chloe, trzeba najpierw wdrożyć **E2**
  (`PLAN.md`), bo appka domyślnie używa wyłącznie natywnego modelu Perchance.

## Źródła (darmowe opcje)

- OpenRouter limits: https://openrouter.ai/docs/api-reference/limits.md
- OpenRouter models: https://openrouter.ai/api/v1/models (scratch/openrouter-free.json)
- HF pricing/billing: https://huggingface.co/docs/inference-providers/pricing
- HF router (OpenAI-compatible): https://huggingface.co/docs/inference-providers/index
- HF router models: https://router.huggingface.co/v1/models
- HF Content Policy: https://huggingface.co/content-policy
- HF GPU Spaces: https://huggingface.co/docs/hub/spaces-gpus

---

# Własny GPU na HF Spaces — NVIDIA L4 (24 GB) — co się zmieści

Research 2026-09-12. Pytanie: „gdyby postawić Space z NVIDIA L4 i wziąć najlepszy
model, jaki to model?".

## Sprzęt i koszt (docs „Using GPU Spaces")

| GPU | vCPU / RAM | VRAM | Dysk | $/h |
|---|---|---|---|---|
| **1× Nvidia L4** | 8 / 30 GB | **24 GB** | 400 GB | **$0.80** |
| 4× Nvidia L4 | 48 / 186 GB | 96 GB | 3200 GB | $3.80 |
| 1× Nvidia L40S | 8 / 62 GB | 48 GB | 380 GB | $1.80 |
| 4× Nvidia L40S | 48 / 382 GB | 192 GB | 3200 GB | $8.30 |
| T4 small | 4 / 15 GB | 16 GB | 50 GB | $0.40 |

- **Kredyty PRO ($2/mies.) = 2,5 h L4.** Czyli L4 to opcja **płatna**, nie darmowa.
  L4 na okrągło ≈ $576/mies. Ma sens, gdy liczy się prywatność, brak moderacji
  i nielimitowane tokeny — nie przy okazjonalnym czacie.
- L4 = Ada Lovelace: 24 GB GDDR6, ~300 GB/s, obsługuje FP8 (dobre dla vLLM).

## Ile realnie wchodzi na 24 GB (rozmiary zweryfikowane w plikach repo)

Rozmiar = same wagi (VRAM); do tego KV cache. KV/token policzony z `config.json`:
`2 × warstwy × KV-heady × head_dim × 2 B`.

| Model | Wariant na L4 | Wagi | KV/token | Realny kontekst na L4 |
|---|---|---|---|---|
| **Qwen3.8-27B** | GGUF Q4_K_M **15,3 GB** / Q5_K_M 18,4 GB / Q6_K 20,5 GB | 15–20 GB | **256 KB** | 16k spokojnie; 32k z KV w Q8 |
| **TheDrummer Cydonia-24B-v4.3** | GGUF Q4_K_M 13,4 / Q5_K_M **15,6 GB** | 13–16 GB | ~160 KB | 32k+ |
| **TheDrummer Artemis-31B-v1.1** | GGUF Q4_K_M **17,4 GB** / Q5_K_M 20,4 GB | 17–20 GB | ~250 KB | ~16k |
| **Gemma 4 31B** | AWQ INT4 QAT **19,5 GB** (`cyankiwi/gemma-4-31B-it-qat-AWQ-INT4`) | 19,5 GB | **960 KB** ⚠ | tylko ~4–8k (KV zjada VRAM) |
| Qwen3.6-35B-A3B | AWQ-4bit **23,3 GB** (`cyankiwi/...`) | 23,3 GB | 80 KB | **nie mieści się** (brak na KV) |
| Mistral Small 4 (119B) | INT4 ≈ 68 GB | — | — | **nie na L4** (2×L40S+) |
| DeepSeek V4 Flash (290B) | — | — | — | nie na L4 |
| Llama-3.3-70B | Q2_K 26 GB | — | — | odpada (jakość + brak KV) |

## Rekomendacja na L4 (24 GB)

1. **`Qwen3.8-27B` — zwycięzca.** Najlepszy polski wśród modeli open (EuroEval 1.59),
   27B, **tani KV (256 KB/tok → 32k kontekstu przy KV Q8)**, i co najważniejsze —
   są gotowe wersje **nieocenzurowane / abliterated**:
   - `huihui-ai/Huihui-Qwen3.8-27B-abliterated-GGUF` — Q4_K **15,7 GB**,
     UD-DW-Q4_K_M 15,4 GB, Q5/Q6K do 20,9 GB
   - `0bserverx/Qwen3.8-27B-Heretic-Abliterated-Uncensored-GGUF`
   - `HauhauCS/Qwen3.8-27B-Uncensored-HauhauCS-Aggressive-MTP-GGUF`
   - `JonathanColetti/Qwen3.8-27B-Uncensored-GGUF`
   - (baza: `unsloth/Qwen3.8-27B-GGUF`, `Qwen/Qwen3.8-27B-FP8`)
   Wybór quantu: **Q4_K_M (15,3 GB)** = dużo zapasu na kontekst → Q5_K_M (18,4 GB)
   → Q6_K (20,5 GB, ciasno). Jest też osobny plik `mmproj` (vision, 0,87 GB) — do
   czatu tekstowego niepotrzebny.
2. **`TheDrummer/Cydonia-24B-v4.3` (Q5_K_M 15,6 GB)** — dedykowany **uncensored RP**
   finetune; mieści się z dużym kontekstem, bardzo dobra „willingness".
3. **`TheDrummer/Artemis-31B-v1.1` (Q4_K_M 17,4 GB)** — większy uncensored finetune.
4. **`Gemma 4 31B` AWQ INT4 QAT (19,5 GB)** — najlepszy polski wśród lubianych
   w NSFW (EuroEval 1.85), QAT trzyma jakość przy INT4 — ALE KV 960 KB/tok
   ogranicza kontekst do ~4–8k. Sensowne tylko, jeśli kontekst nie jest kluczowy;
   do NSFW brać `wangzhang/gemma-4-31B-it-abliterated` lub
   `HauhauCS/Gemma4-31B-...Uncensored`.

**Czego nie brać na L4:** `Qwen3.6/3.5-35B-A3B` AWQ-4bit (23,3 GB — brak miejsca na
KV; potrzebuje L40S/2×L4), Mistral Small 4 119B, DeepSeek V4 Flash (290B), 70B.

Jeśli budżet pozwala: **1× L40S (48 GB, $1,80/h)** = Qwen3.6-35B-A3B AWQ z ogromnym
kontekstem, albo Qwen3.8-27B w Q8; **2× L40S (96 GB, $3,60/h)** = Mistral Small 4 119B.

## Jak to postawić (Space + E2)

- **Docker Space** z jednym z:
  - **llama.cpp server** (`ghcr.io/ggml-org/llama.cpp:server-cuda`) — GGUF, najprościej,
    działa z każdym modelem z listy (obsługuje `-ctk q8_0 -ctv q8_0` = tańszy KV),
  - **vLLM** (`vllm/vllm-openai:latest`) — AWQ INT4/FP8, szybszy, lepszy przy wielu
    użytkownikach (L4 ma FP8).
- Endpoint **OpenAI-compatible**: `https://<user>-<space>.hf.space/v1/chat/completions`
  → Chloe w trybie **E2** (`PLAN.md`) może tam celować bez zmiany formatu żądań.
- **Bezpieczeństwo:** publiczny Space = publiczny endpoint (każdy może wołać i palić
  Twój GPU). Dodać własny prosty proxy sprawdzające `Authorization`, albo trzymać
  Space **prywatny** i wołać z tokenem HF (`Authorization: Bearer hf_...` — nasz
  custom-code `fetch` przekazuje ten nagłówek przez proxy).
- **Usypianie:** Space zasypia przy bezczynności → pierwsze zapytanie po przerwie
  czeka na zimny start (minuty). Dla czatu na żywo: brak usypiania (płatne GPU)
  albo akceptacja zimnego startu z fallbackiem do modelu Perchance.

## Źródła (L4)

- HF GPU pricing: https://huggingface.co/docs/hub/spaces-gpus
- Rozmiary quantów: drzewa repo HF (`/api/models/<id>/tree/main?recursive=true`)
- `config.json` modeli: https://huggingface.co/<id>/raw/main/config.json

## L4 vs API — rachunek (czy L4 się opłaca? NIE)

Przepustowość L4 dla Qwen3.8-27B Q4_K_M: L4 ma ~300 GB/s, model 15,3 GB →
teoretycznie ~19 tok/s, realnie **12–16 tok/s** na jeden strumień (llama.cpp);
vLLM z batchingiem ~30–60 tok/s łącznie. Przy 15 tok/s: `3600 × 15 = 54 000 tok/h`
→ **$0.80 / 0,054M ≈ $14,8 za 1M tokenów wyjściowych**. To ~25× drożej niż
Mistral Small 4 (119B!) na OpenRouter ($0.60/Mtok) i ~150× drożej niż
DeepSeek V4 Flash ($0.095/Mtok).

Koszt „na wiadomość" (założenie: ~4 000 tok. wejścia + 400 tok. wyjścia):

| Opcja | Koszt | Wiadomości za $1 | Model, jaki dostajesz |
|---|---|---|---|
| OpenRouter `:free` | $0 | limit 50/dzień | Gemma 4 26B / Nemotron 120B (instruct) |
| DeepSeek V4 Flash (OR) | $0.047/$0.095 /Mtok | **~4 400** | 290B MoE, 0% odmów |
| OpenRouter Gemma 4 26B | $0.09/$0.30 /Mtok | ~2 500 | dobry polski |
| Mistral Small 4 (OR) | $0.15/$0.60 /Mtok | **~1 200** | 119B MoE, #1 w NSFW wg ludzi |
| HF PRO → Featherless | $2/mies. kredytów | ~2 000+ | Stheno/Lunaris/Hermes (uncensored) |
| **HF Space L4** | **$0.80/h** | **~160** | Qwen3.8-27B Q4 (własny, prywatny) |

**Wniosek: patrząc na cenę, L4 jest najdroższą opcją** — ~7× drożej niż 119B
Mistral Small 4 i ~27× drożej niż DeepSeek V4 Flash na wiadomość, przy słabszym
modelu. L4 wygrywa tylko w: prywatności (nic nie opuszcza GPU), zerowej moderacji,
braku limitów i przewidywalnym stałym koszcie.

Tańsze alternatywy o podobnym profilu:
- **Własny PC z GPU** (RTX 4070/4080/4090, 12–24 GB): L4 ma ~300 GB/s, 4070 ~504,
  4080 ~717, 4090 ~1008 GB/s → **1,7–3,4× szybciej i $0 poza prądem**. Jedyna
  droga do „szybko i za darmo", jeśli masz taki sprzęt.
- **ZeroGPU** (w kwocie PRO): darmowy GPU, ale tylko funkcje Gradio z limitem minut
  → brak stałego endpointu OpenAI-compatible.
- **Darmowy CPU Space**: $0, ale 2–5 tok/s.
- **L4 ma sens** dopiero, gdy chcesz mieć model bez żadnej moderacji, bez limitów
  i prywatnie — i godzisz się płacić za to ~10–30× więcej niż za API.

---

# Głos społeczności (research 2026-09-12)

Na pytanie: „co społeczność mówi o modelach do zadań takich jak nasze" (nieocenzurowany
czat NSFW + wiedza + polski, przez API). Źródła: r/SillyTavernAI, r/LocalLLaMA, modelgrep,
roborhythms, watsonout, rpfiend, Codesota. Metoda: realny ruch, głosy ludzi, wątki
dyskusyjne — a nie tylko benchmarki (te są wyżej, w części RP-Bench/EuroEval).

## 1. Co społeczność faktycznie odpala (realny ruch RP na OpenRouter)

modelgrep (wrzesień 2026) — udział w rzeczywistym ruchu roleplay na OpenRouter, wśród
modeli bez moderacji providera i z ≥32K kontekstu („no roleplay benchmark exists, so what
the character-chat community actually runs is the better signal"):

| # | Model | Udział | $/M | Prędkość | Kontekst |
|---|---|---|---|---|---|
| 1 | deepseek-v4-flash (0423) | **24.6%** | $0.089 | 82 t/s | 1.0M |
| 2 | deepseek-v4-flash-0731 | 14.3% | $0.060 | 145 t/s | 1.3M |
| 3 | gemini-2.5-flash-lite | 5.4% | $0.100 | 282 t/s | 1.0M |
| 4 | deepseek-v3.2 | 4.5% | $0.269 | 42 t/s | 164K |
| 5 | deepseek-v4-pro-0813 | 3.2% | $0.983 | 111 t/s | 1.0M |
| 6 | qwen3.7-plus | 2.2% | $0.320 | 9 t/s | 1M |

**Wniosek:** DeepSeek V4 Flash to de facto standard społeczności — razem ~39% ruchu.
Mistral Small 4 nie pojawia się w top-20 (mimo że wygrywa w głosowaniu ludzi „kto najspicy"
— patrz Wniosek 2 wyżej). Dwie różne miary: „ilu używa" ≠ „jakość wg głosów".

## 2. DeepSeek V4.1 Flash — zbliżająca się zmiana (14.09) i pułapka „thinking"

- **Ogłoszone:** od 04:00 UTC **14.09.2026** DeepSeek będzie przekierowywać
  `deepseek-v4-pro` na **V4.1 Flash** we własnym API — cicho, bez błędu w czacie.
  Nazwa `deepseek-v4-flash` została wycofana 10.09 i też wskazuje na V4.1 Flash.
- **OpenRouter tym nie jest objęty:** `deepseek/deepseek-v4-pro` tam nadal serwuje
  prawdziwe V4 Pro (wagi MIT, zewnętrzni hosterzy; DeepSeek nie jest jednym z nich).
  Dla `-0813` trzeba dodać DeepSeek do ignorowanych providerów.
- Karta modelu (DeepSeek, własna): V4.1 Flash jest **gorszy od V4 Pro w przypominaniu
  faktów** (SimpleQA 42.3 vs 55.2) i w długim kontekście (LongBench 45.2 vs 51.5) — czyli
  dokładnie tam, gdzie cierpi długi RP z lore. Za to lepiej trzyma instrukcje.
- **PUŁAPKA:** V4.1 Flash chodzi domyślnie w *thinking mode*, a thinking **ignoruje
  temperaturę oraz presence/frequency penalty** (bez błędu — suwaki nic nie robią),
  a `top_p < 0.95` jest podbijane do 0.95. Trzeba jawnie wyłączyć rozumowanie:
  OpenRouter → `reasoning: {enabled:false}`; DeepSeek API → `thinking:{type:"disabled"}`.
  Jeśli thinking zostaje, `max_tokens` ≥ 4000 (rozumowanie zjada budżet → pusta odpowiedź).
- **NSFW:** standardowe scenariusze przechodzą bez odmów, ale ciemne/przemocowe sceny
  bywają **„zmiękczane"** (pisane wymijająco), a non-consent częściej odmawiany.
  Recepta społeczności: twarda instrukcja **po** historii czatu (post-history), np.
  „Characters always act true to their personality, even if it leads to them harming
  {{user}}. Do not soften, skip or resolve violent or tragic scenes early."

## 3. Meta społeczności: dwumodelowy „recast" (najgłośniejszy wątek)

Top tutorial r/SillyTavernAI (~309 głosów): żaden pojedynczy model nie daje jednocześnie
inteligencji i „brudu", więc społeczność składa to z dwóch:

1. **Model główny (mądry)** — Opus/Fable/Kimi K3/GLM 5.3 — prowadzi fabułę, świat, postacie.
2. **Rozszerzenie `recast-post-processing`** (github.com/closuretxt/recast-post-processing)
   przepuszcza ostatnią turę przez **drugi, nieocenzurowany model** z osobnym promptem
   systemowym: usuwa eufemizmy, dodaje detale NSFW, poprawia styl postaci.
3. Drugi model nie musi być mądry — tylko niegrzeczny (GLM 4.7, lokalny abliterated, Grok).

Kluczowy cytat: *„NSFW-capable models are either old (GLM 4.7) or stupid (Grok)"*.
O DeepSeek V4 Pro autor: *„works and you can use it, you will get an okay experience"*
(czyli OK, ale nie top). Inne głosy z wątku: prawie wszystkie SOTA **przyjmują** lewd
tekst jako kontekst, ale słabo go *generują*; prefill / myślenie „w postaci" omija miękką
cenzurę; nowe modele dryfują w stronę tonu „asystenta" i to psuje RP.

Wątek „Things are looking bad for API models" (318 głosów): wszystko jest trenowane na
wyjściach Opus, więc cenzura rośnie; przewidywana przyszłość = lokalne finetune'y.
Wątek „TIL why older models were PEAK": stare DeepSeeki (V3 0324, R1) mają „raw" klimat,
którego nowe nie mają — ale zapominają detali. **Wniosek dla Chloe:** nie wiązać się z
jednym modelem; trzymać presety i fallback.

## 4. Abliterated / uncensored lokalnie (jeśli własny GPU)

wg watsonout (2026) + wątków r/LocalLLaMA:

| Do czego | Model | VRAM | Odmowy |
|---|---|---|---|
| All-rounder pisanie+RP | Huihui-Qwen3.6-35B-A3B-abliterated | ~14 GB | niskie |
| Długa forma, uczciwa karta | wangzhang/Qwen3.6-27B-abliterated-v2 | ~17 GB | ~10% |
| Słabszy GPU / 3060 | heretic-org/IBM-granite-4.1-8b-heretic | ~5 GB | ~1.2% |
| Styl Gemma | DuoNeural/Gemma-4-26B-A4B-Abliterated | ~13 GB | niskie |
| Workstation | darkc0de/XORTRON 123B | 123B | ~2% |

Metody: Heretic (najprecyzyjniejsza, ~1826 tensorów), HauhauCS („rzeźnik", 6× KL),
Huihui (niejednolita — dobra na dużych, psuje małe). Providerzy: abliteration.ai
($20–50/mies.), Unfil ($0.90/M), Venice (darmowy tier „Uncensored"), xAI Grok 4.3 (natywnie).

## 5. Polski — co mówią benchmarki (Codesota, „live")

- **PLCC** (kompetencja kulturowo-językowa; 165 modeli): #1 Gemini-3.1-Pro (97),
  dalej Gemini 3.0 Pro, GPT-5.4, Grok 4.
- **CPTU-Bench** (rozumienie złożonego polskiego): #1 Qwen3.5-27B thinking (4.34),
  Gemini 2.0 Flash (4.29), Qwen3.5-35B-A3B, DeepSeek V3.2 (4.14).
- **Open PL LLM Leaderboard**: #1 Mistral-Large-Instruct-2411 (69.84).
- Rodziny „polskie od podstaw": **Bielik** (SpeakLeash, tokenizer APT4, 292B+ tokenów PL)
  i **PLLuM** (OPI). Nie zawsze na szczycie, ale to czysta kontrola, ile polskiego jest
  wyuczone, a ile to „sztuczka z tłumaczenia".
- Otwarte modele wypadają w polskim słabiej niż frontier → dla Chloe: **trzymać polski
  prompt + instrukcję językową** (warstwa „dialektu" Gemma już to robi) i preferować
  Qwen/Gemma/Mistral, gdy polski jest priorytetem.

## 6. Co z tego wynika dla presetów Chloe

- Domyślny `mistralai/mistral-small-2603` zostaje — wg głosów ludzi #1 w NSFW (67%
  wygranych), najszybszy, tani, przyzwoity polski.
- **Dodać `deepseek/deepseek-v4.1-flash`** — realny faworyt społeczności (V4 Flash to
  ~39% ruchu RP), najlepszy stosunek jakość/koszt; z **wyłączonym reasoningiem**.
- Zachować `deepseek/deepseek-v4-flash` (0423, najtańszy) i `deepseek/deepseek-v4-pro`
  (premium, #1 multi-turn wg ludzi).
- **Dodać klasyczny uncensored finetune do testów:** `thedrummer/cydonia-24b-v4.1`
  (dedykowany RP, 0% odmów) — mimo że benchmarki mówią „przestarzałe", część społeczności
  nadal woli ten styl.
- Opcja przyszłości (E2+): **dwumodelowy recast** — główny model pisze, drugi (uncensored)
  przepisuje. To najsilniejszy trend 2026.

## 7. Ceny uncensored finetune'ów na OpenRouter (stan 2026-09-12)

| OpenRouter ID | $in/$out za Mtok | Kontekst |
|---|---|---|
| thedrummer/cydonia-24b-v4.1 | 0.30 / 0.50 | 131k |
| cognitivecomputations/dolphin-mistral-24b-venice-edition („Venice: Uncensored") | 0.20 / 0.90 | 128k |
| sao10k/l3.3-euryale-70b | 0.65 / 0.75 | 131k |
| sao10k/l3-lunaris-8b | 0.04 / 0.05 | 8k |
| anthracite-org/magnum-v4-72b | 2.50 / 5.00 | 32k |

## Źródła (głos społeczności)

- modelgrep — ranking realnego ruchu RP: https://modelgrep.com/best-models-for/sillytavern
- roborhythms — V4.1 Flash i wycofanie V4 Pro: https://www.roborhythms.com/deepseek-v4-1-flash-roleplay/
- r/SillyTavernAI — Tutorial „best NSFW RP": https://www.reddit.com/r/SillyTavernAI/comments/1w59r3l/
- r/SillyTavernAI — „Things are looking bad for API models": https://www.reddit.com/r/SillyTavernAI/comments/1vxwkwc/
- r/SillyTavernAI — „TIL why older models were PEAK": https://www.reddit.com/r/SillyTavernAI/comments/1w9rm0k/
- watsonout — abliterated: https://www.watsonout.com/editorials/best-abliterated-llms-for-nsfw-writing-roleplay-in-2026/
- rpfiend — SillyTavern weekly: https://rpfiend.com/sillytavern-weekly-april-27-2026/
- Codesota — Polish LLM register: https://www.codesota.com/polish-llm
- OpenRouter — parametry (reasoning): https://openrouter.ai/docs/api-reference/parameters

---

# Modele do wyszukiwania (search / grounding) — research 2026-09-12

Pytanie: „czy na OpenRouter jest model idealny do **wyszukiwania najgłębiej ukrytych
treści** (filmy, dyski)?".

## 1. Modele „search-native" — wbudowane wyszukiwanie w API

Sprawdzone w `scratch/openrouter-models.json` (pole `supported_parameters` zawiera
`web_search_options` — model sam odpytuje internet). Cała rodzina to **Perplexity
Sonar** (plus kilka modeli OpenAI i `openrouter/auto`):

| OpenRouter ID | $in / $out za Mtok | Kontekst | Uwaga |
|---|---|---|---|
| `perplexity/sonar` | $1 / $1 | 127k | najtańszy, zwykłe wyszukiwanie |
| `perplexity/sonar-pro` | $3 / $15 | 200k | więcej kroków, lepsze cytowania |
| `perplexity/sonar-pro-search` | $3 / $15 | 200k | **agentic** — sam planuje wiele zapytań |
| `perplexity/sonar-reasoning-pro` | $2 / $8 | 128k | rozumowanie + szukanie |
| `perplexity/sonar-deep-research` | $2 / $8 | 128k | **deep research** — długie raporty, dziesiątki źródeł |

Żaden z nich nie ma `is_moderated:true`, ale **Perplexity jest NSFW-awersyjny**:
grzecznie omija/ucina tematy erotyczne, a na „najgłębiej ukryte" materiały (tube,
lockery, dyski) odpowie albo pustką, albo odmową. Do Chloe — nie nadaje się jako
jedyny silnik.

## 2. Grounding dowolnego modelu (`:online` / plugin `web`)

Każdy model na OpenRouter można „uziemić" w sieci bez zmiany modelu:
- sufiks **`:online`** (np. `mistralai/mistral-small-2603:online`), albo
- `"plugins":[{"id":"web"}]` w żądaniu.

Silniki (do wyboru): **native**, **exa**, **parallel** (`mode:"advanced"`), **firecrawl**.
- **Exa**: ~$0.007–0.015/zapytanie, umie `include_domains` / `exclude_domains`.
- Reszta silników: ceny zależne od planu; Parallel „advanced" = głębsze, droższe.

To daje modelowi świeży kontekst z sieci, ale **jakość i „głębokość" zależą od silnika**,
a treści NSFW bywają wycinane na poziomie samego wyszukiwania (filtr safe-search /
indeks bez adult). Dla ukrytych materiałów to za słabe.

## 3. Co realnie poleca społeczność do groundingu

Konsensus (r/LocalLLaMA, r/SillyTavernAI, wątki o RAG): **Tavily**, **Jina**,
**SearXNG**, **Exa**, **Brave**, **Serper**, **DuckDuckGo**. Cytat: *„Tavily or Jina
make every LLM feel like a mini-Perplexity."* SearXNG self-hosted = brak filtra i brak
limitów (najlepszy do NSFW), ale wymaga własnego proxy — a nasze wywołania idą przez
proxy Perchance, więc sami scrapujemy źródła (patrz niżej) zamiast płacić za silnik.

## 4. Wniosek dla Chloe

- **Żaden model „search-native" nie jest potrzebny.** Całe głębokie wyszukiwanie robi
  już warstwa **readerów/scraperów** (XVideos, xHamster, Erome, tube'y) + **pullpush.io**
  (Reddit: posty i komentarze) + **5 wyszukiwarek dla dysków** (DDG html/lite, Bing,
  Startpage, Marginalia) + harvesty (Reddit + Bing RSS) + **weryfikacja linków na żywo**.
  Model nie przeszukuje sieci — tylko planuje zapytania.
- Do samego **planowania zapytań / orkiestracji** zostaje szybki, tani i nieocenzurowany
  model: domyślnie `mistralai/mistral-small-2603` (192 tok/s, ~$0.0003/zapytanie,
  0% odmów, NSFW 67% wygranych), a w konfiguracji użytkownika `deepseek/deepseek-v4.1-flash`
  (#1 jakość/koszt). Alternatywy dla polskiego: `google/gemma-4-26b-a4b-it`.
- Opcja (tylko ścieżka SFW/informacyjna): włączyć `:online` (Exa/Parallel) jako dodatek
  do wiedzy o świecie — **nie** do szukania NSFW.

## Źródła (modele wyszukiwania)

- OpenRouter models (pole `supported_parameters`): https://openrouter.ai/api/v1/models
- OpenRouter web search plugin: https://openrouter.ai/docs/features/web-search
- Perplexity Sonar: https://openrouter.ai/perplexity

---

# Lokalnie: RX 7600S (8 GB VRAM) + 32 GB RAM + Ryzen 7 7435HS — research 2026-09-12

Pytanie: „jaki model tekstu odpalić lokalnie na RX 7600S / 32 GB / 7435HS pod nasze
przeznaczenie (nieocenzurowany NSFW + polski + wiedza)”.

Sprzęt: laptop, Radeon RX 7600S = RDNA3, **8 GB VRAM**, ~256 GB/s; 32 GB RAM; 8c/16t.
Wąskie gardło: 8 GB VRAM. Szybko (≥15 tok/s) mieszczą się modele 8B w Q5-Q6; 12B w Q4
ledwo wchodzi; 24B+ dense oraz MoE 26-35B (aktywne 3-4B) → częściowy offload do RAM,
~7-15 tok/s.

Nazwy sprawdzone w HF search API (`abliterated/heretic GGUF`).

## Rekomendacja

| Priorytet | Model (GGUF) | Quant | VRAM | Prędkość | Uwaga |
|---|---|---|---|---|---|
| Szybkość (całość w VRAM) | `DavidAU/Qwen3-8B-Hivemind-Instruct-Heretic-Abliterated-Uncensored-NEO-Imatrix-GGUF` (lub `mradermacher/Huihui-Qwen3-8B-abliterated-v2-GGUF`) | Q5_K_M / Q6_K | ~5,7-6,6 GB | 25-40 t/s | Qwen = najlepszy polski wśród małych; mało odmów |
| Sweet spot 12B | `culturerevolt/gemma-4-12b-heretic-abliterated-GGUF` | Q4_K_M | ~7,3 GB | 15-25 t/s | Gemma = świetny polski + #1 engagement; ciasno — kontekst 4-8k |
| Najlepsza jakość (offload do RAM) | `huihui-ai/Huihui-gemma-4-26B-A4B-it-abliterated-GGUF` (MoE 26B/4B aktywne) | Q4_K_M | ~15 GB | 7-15 t/s | najlepszy polski z lubianych w NSFW |
| Najlepsze pisanie RP (offload) | `Huihui-Qwen3.6-35B-A3B-abliterated` (MoE 35B/3B) | Q4_K_M | ~14 GB | 8-15 t/s | all-rounder pisanie+RP wg społeczności |

Czego NIE brać na 8 GB: dense 24B+ (Cydonia-24B, Qwen3.6-27B-abliterated, Artemis-31B),
Gemma-4-31B — nie mieszczą się, CPU-only → 1-3 t/s.

## Jak uruchomić

- **Windows:** LM Studio albo llama.cpp z backendem **Vulkan** (ROCm na Windows dla
  laptopowego RDNA3 bywa zawodny; na Linuksie ROCm/HIP działa lepiej). Ollama też OK.
- Quant: min. Q4_K_M (dla 8B Q5_K_M/Q6_K), **KV cache Q8_0 + flash attention** (oszczędza VRAM).
- Kontekst 8k-16k.
- Podpięcie do Chloe (tryb E2, `PLAN.md`): endpoint OpenAI-compatible —
  LM Studio `http://localhost:1234/v1`, Ollama `http://localhost:11434/v1`.
  `fetch` Perchance domyślnie idzie przez proxy, które NIE dosięgnie Twojego localhosta →
  trzeba użyć ścieżki **direct**. Włączyć CORS: LM Studio (Server → CORS), Ollama
  `OLLAMA_ORIGINS=*`.
