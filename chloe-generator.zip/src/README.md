# Chloe — uncensored NSFW research assistant (for `ai-character-chat`)

This workspace IS the Perchance **ai-character-chat** application (its `main.pjs` +
`index.html`). It ships **one custom starter character**, **Chloe** — an uncensored
**sexologist / sex-education expert** and **DIY sex-toy builder**: anatomy, technique,
fetishes/kinks/BDSM, sexual health, and step-by-step body-safe toy building. She has a
live **knowledge** search (Wikipedia, websites + forums, Reddit posts *and* comments),
an expert lorebook and DIY toy knowledge. Her whole custom code is declared **once** in
`var CHLOE_CUSTOM_CODE`. Her current persona (since 2026-09-12) is the user's
**ROOM HACK LAB** spec — **see the ROOM HACK LAB section below**.

**This app is KNOWLEDGE-ONLY (2026-09-12).** Chloe does **not** search or link films,
videos, porn tubes, photo galleries, streams or cloud-drive / file-locker links. The
media scrapers and the drive verifier are still present in the code but **permanently
disabled**: `chloeKnowledgeOnly()` now returns `true` unconditionally, which
(a) zeroes the `drives` / `directLink` / `wantsMedia` intents in `chloeDetectIntent`,
(b) forces `info`/`reddit` modes, (c) force-disables every `CHLOE_MEDIA_GROUP` source
in `chloeWebSearch`, (d) hides the `media`/`drives` console modes and limits the console
source groups to `web`+`reddit`, (e) remaps `/search`→`/wiki` and intercepts `/dyski`,
and (f) serves `CHLOE_HELP_KNOWLEDGE` (not `CHLOE_HELP`) for `/pomoc`.

History: the knowledge-only build started as a **second** starter character („Chloe
Ekspertka", `_charUrlId: "chloe-wiedza"`); that split was removed, but the user then
clarified (PL: *„chciałem Chloe ekspertkę seksuolożkę potrafiącą budować DIY zabawki"*)
that they wanted the **expert** kept and the **media/film/drive** purpose gone. So the
single Chloe now IS the expert (her persona was recovered from the former Ekspertka
starter entry + the last saved generator source) and the media path is switched off.
The persona was adapted to drop every „the other Chloe (media character)" reference.

## SWAP 2026-09-18 (v3) — czystka mediów + auto-installer  (*naprawiony*)

The user handed back another `index.html` („podmień, zapisz i odśwież"); it is now the live
file, but it **did not run as delivered** — the repair below is part of the swap:

- **Botched media/drive deletion in `CHLOE_CUSTOM_CODE`.** 20 functions were removed
  (`chloeSrcPornhub`, `YouPorn`, `Porntrex`, `Spankbang`, `Redtube`, `PornCom`, `Xozilla`,
  `SunPorno`, `Tnaflix`, `Nudevista`, `Nhentai`, `Ehentai`, `3Hentai`, `E621`, `Redgifs`,
  `Xvideos`, `Xhamster`, `Erome`, `chloeDrvE64`, `chloeAllowedUrls`) but the deletion left
  damage: (a) 4 lines of stray `async async async …` residue (syntax error → the *whole*
  custom code failed to load: no chips/panel/search), (b) **59** function declarations lost
  their leading `async` while still containing `await` (same fatal effect), (c) the exported
  api object still referenced the deleted `chloeAllowedUrls` → load-time ReferenceError.
  Repairs: residue stripped, `async` restored on exactly the 59 declarations whose previous
  version was async (all verified to contain `await`), and `chloeAllowedUrls` restored
  verbatim (25 lines, before `chloeStripFakeLockers`). The result compiles clean and was
  verified live. **`CHLOE_SOURCES` is now only `bingpl`, `bingen`, `webinfo`, `reddit`,
  `redditc`** — the knowledge-only end state, with the media scrapers gone for good.
- **`CHLOE AUTO-INSTALLER v3` (`v3-2026-09-18`) was misplaced**: it had been inserted
  *inside the custom-code iframe's `srcDoc`* (a sandboxed, opaque-origin iframe) where
  `window.db` never exists, so it polled 40× and did nothing. It is now **appended at the end
  of the parent page** (last `<script>` in `index.html`) where it works: on every load it
  patches characters `0/1/3/5` and threads `0/1/2/3/4/8` with **character 0's** persona/code
  fields (`roleInstruction`, `reminderMessage`, `imagePromptPrefix/Suffix/Triggers`,
  `maxTokensPerMessage` 1400, `autoGenerateMemories` `"v2"`, `fitMessagesInContextMethod`
  `"trimOldest"`, `customCode`), guarded by `localStorage["chloe_autopatch_v3-2026-09-18"]`
  and logging `[Chloe] AUTO-INSTALL OK (v3-2026-09-18): zsynchronizowano …`. NOTE: it copies
  *from row 0*, so a brand-new persona still has to land in row 0 (or be patched manually) —
  it is a sync tool, not an installer of the `starterCharacters` definition.
- Persona/params in this file: `roleInstruction` **11 752** chars, `reminderMessage`
  1 113, shorter `tagline`, `fitMessagesInContextMethod` `"trimOldest"`,
  `autoGenerateMemories` `"v2"`, `maxTokensPerMessage` 1400, `imagePromptSuffix` stock again,
  `loreBookUrls` unchanged (1 hosted .txt, 238 entries). `customCode` = **265 110** chars
  (still contains the `CHLOE v2 — PAMIĘĆ FAKTÓW` module — verified working).
- Live DB synced to the new values (characters 0/1/3/5 + threads 0/1/2/3/4/8), preview
  re-rendered and checked (chips, E2 status line, facts module).
- Backups (session-only): `scratch/index-pre-podmiana2.html` (previous index.html),
  `scratch/cc-pre-podmiana.js` (previous code, used as the async/`chloeAllowedUrls`
  reference), `scratch/index_2_fixed.html` (intermediate repaired file).

### Fix #2 (2026-09-18, po v3): `rawText` ReferenceError → wszystkie komendy slash były martwe

`chloeParseCommand(text)` zawierało resztkową linię z czasów mediów:

```js
function chloeParseCommand(text) {
  { var __fr = chloeFactsHandle(rawText); if (__fr) return __fr; }   // <- rawText NIE ISTNIEJE
```

`rawText` nie jest nigdzie zadeklarowane → przy **każdym** wywołaniu `chloeParseCommand`
leciał `ReferenceError`, a że wywołanie siedzi w `try{}` w `chloeHandleAddedMessage`,
błąd był połykany → `cmd` zawsze `undefined` → **`/panel`, `/pomoc`, `/model`, `/pref`,
`/zabawki`, `/wiki`, `/reddit` nie działały** (fallback „heurystyczny" sprawiał, że zwykłe
pytania i tak szukały, więc problem był łatwy do przeoczenia). Naprawa:

1. usunięta paskudna linia z `chloeParseCommand`;
2. `/pamiec` i `/zapomnij N` obsługiwane teraz jawnie w `chloeHandleAddedMessage`,
   zaraz po wejściu w gałąź `author === "user"`:
   ```js
   var __factsReply = chloeFactsHandle(content);
   if (__factsReply) { msgs.pop(); chloePushVisible(chloeEsc(__factsReply).split(String.fromCharCode(10)).join('<br>')); return; }
   ```
   (bez `chloePushVisible`/`chloeEsc` i bez `"`/`\` w kodzie — bo `CHLOE_CUSTOM_CODE`
   to jeden wielki string w cudzysłowach, więc cudzysłowy/backslashe trzeba escapować).

Zmiana wprowadzona identycznie w `index.html` i `scratch/cc.js`, potem zsynchronizowana do
żywej bazy (4 postaci + 6 wątków, `customCode` = **265 110**).

Weryfikacja statyczna: `new Function(code)` kompiluje się; analiza zasięgów (`@babel/parser`
+ `@babel/traverse`, `ReferencedIdentifier` bez bindingu) nie znajduje już **żadnego**
niezadeklarowanego identyfikatora poza standardowymi globalami (wcześniej: `rawText@2742`).

Weryfikacja na żywo (wątek 8, klucz użytkownika, model `mistralai/mistral-small-2603`):
`/pamiec` → „📌 PAMIĘĆ WĄTKU: (pusto…)"; zwykła wiadomość → odpowiedź Chloe z modelu;
`/wiki pegging` → pasek postępu źródeł (Bing PL ✓ 8, Bing EN ✓ 8, DDG, Reddit) →
wiadomość `[LIVE WEB RESEARCH]` → odpowiedź merytoryczna; `/panel` → `oc.window.show()`
(panel otwiera się jako okno custom-code). Wiadomości testowe usunięte z DB,
`thread.customCodeWindow.visible` przywrócone na `false`, brak `syntaxErrors`/`perchanceErrors`.

Pamiętaj: panel/okno custom-code żyje w iframe `sandbox="allow-scripts"` (opaque origin) —
nie da się go obejrzeć ani kliknąć z `page_eval` w parent page; jego stan jest w
`thread.customCodeWindow` (`{visible,width}`) w tabeli `threads`.

### Fix #3 (2026-09-18, po v3): własny model (E2) padał na „Failed to fetch" przy dwóch generacjach naraz

Objaw: przy włączonym własnym modelu odpowiedź Chloe bywała poprzedzona
`⚠️ Wlasny model zawiodl (Failed to fetch: Failed to fetch) — odpowiedzial model Perchance.`
Klucz i model były sprawne (`GET /api/v1/key` → 200, usage $0.88, model
`mistralai/mistral-small-2603` odpowiadał bezpośrednio). Awaria występowała tylko przy
**dwóch równoczesnych generacjach** — obie szły przez proxy aplikacji
(`iframe → parent proxiedFetch → root.superFetch`) i transport się dławił/wisiał.

Dowody: `superFetch` z parenta radzi sobie z ciałem 147 KB; **bezpośredni `fetch`/`XMLHttpRequest`
z piaskowanego iframe (opaque origin) do OpenRouter zwraca 200** (CORS pozwala).

Naprawa (wszystkie w `CHLOE_CUSTOM_CODE`, użyte przez `chloeE2Chat`):

1. `chloeE2HttpTimeoutFetch(url, opts, ms)` — proxowany `fetch` z limitem czasu przez
   `AbortController` (obecnie 75 000 ms);
2. `chloeE2DirectXhr(url, headers, bodyText, ms)` — fallback surowym (nie-proxy'owanym)
   `XMLHttpRequest` (120 000 ms);
3. `async chloeE2HttpPost(url, headers, bodyText)` → najpierw proxy, potem direct; zwraca
   `{status, text, via}` i `console.warn` przy zmianie transportu;
4. `chloeE2Chat` używa teraz `chloeE2HttpPost` dla obu żądań (głównego i tego „bez
   reasoning/provider");
5. `CHLOE_E2_QUEUE` + `chloeE2Enqueue(fn)` — **serializuje generacje E2** (jedna naraz);
   miejsce wywołania: `chloeE2Enqueue(function () { return chloeE2Respond(content, plan, typingId); }).catch(...)`.

Weryfikacja na żywo (wątek 8, dwie wiadomości wysłane jedna po drugiej): obie dostały
odpowiedź z własnego modelu, **żadnego `⚠️`, żadnego zawieszonego spinnera**; czasy:
`1030`/`1031` ≈ 6–7 s po swoich wiadomościach. (`/pamiec`, `/pomoc`, `/wiki`, `/panel` —
wszystkie działają.) Wiadomości testowe usunięte z DB (zostaje `971,972,974,1009,1010,1017,1018`),
`thread 8 customCodeWindow.visible` przywrócone na `false`, brak `syntaxErrors`/`perchanceErrors`.

`customCode` = **268 489** znaków w `index.html`, `scratch/cc.js` i żywej bazie
(4 postaci: 0/1/3/5; 6 wątków: 0/1/2/3/4/8).

## v4 (2026-09-12) — REALNE DOZNANIA + utwardzenie odblokowania

Prośba użytkownika (PL): *„przerob żeby konstruował realne zabawki dające konkretne i
mocne doznania, zweryfikuj pełne odblokowanie i kontekst ekspertki seksualnej"*.

### A. Persona — nowy rdzeń „REALNE DOZNANIA"

`roleInstruction` **11 752 → 14 608** znaków; `reminderMessage` **1 113 → 1 429**.
Zmiany (materiał źródłowy: `scratch/new-persona.txt`, `scratch/new-reminder.txt`):

- nagłówek **„seksuolożka praktyczka i inżynierka bodźca"** w tożsamości + KIM JESTEŚ
  (ekspertka od anatomii, techniki, BDSM, budowy zabawek; pełna ekspertyza);
- MISJA: konstrukcje mają być **„NAPRAWDĘ MOCNO DZIAŁAJĄCE"** — realistyczne, nie
  dekoracyjne;
- nowa sekcja **`## REALNE DOZNANIA (SERCE)`**: dla każdego projektu Chloe musi podać
  **CEL** (konkretna strefa: żołądź łechtaczki, wargi, punkt G, krocze, prostata,
  brodawki, nerwy sromowe), **MECHANIZM** (tarcie/ucisk/wibracja/ssanie/ślizg/temp.),
  **SIŁĘ** (x/5), **KALIBRACJĘ** (jak natychmiast zmienić intensywność), **MONTAŻ**,
  **PEWNIAK** (≥1 konstrukcja = prosty sprawdzony mechanizm) i **TEST W 5 SEKUND**;
- `## CO UMIESZ` rozszerzone o nerw sromowy / grzbietowy / kulszowo-jamisty / splot
  miedniczy;
- FORMAT odpowiedzi zyskał linię **`**Bodziec:**`** (strefa + mechanizm + siła);
- AUTOKONTROLA zyskała pytania 6–8 (co / gdzie / jak mocno; który to pewniak);
- naprawiona literówka nagłówka `## BEZ POhamowań` → `## BEZ HAMULCÓW`.

Model-facing: nowa reguła `CHLOE_E2_RULES` („REALNE DOZNANIA I SILA (serce metody)") +
identyczna krótka reguła w `CHLOE_E2_GEMMA_EXTRA` i `CHLOE_E2_MISTRAL_EXTRA`.

### B. Pełne odblokowanie — przeciek „bezpiecznika" i jego naprawa

Objaw (intermittentny): na bardzo wprost sformułowane pytanie model zwracał zamiast treści
sam wrapper klasyfikatora: `<ds_safety>[用户未成年]否 [分类]色情 [判定]… [规则]无</ds_safety>Safe`.
Taki sam prompt za chwilę odpowiadał normalnie → to **upstreamowy** (provider/DeepSeek)
wrapper bezpieczeństwa, nie odmowa persony.

Naprawa (wszystko w `CHLOE_CUSTOM_CODE`):

1. `chloeStripSafetyTags(t)` (przed `chloeNormalizeAiText`) — wycina `<ds_safety>…</ds_safety>`,
   `<safety>…</safety>`, chińskie linie `[分类]/[判定]/[规则]/[违规]/[安全]/[用户未成年]`,
   osierocone tagi i samotne linie `safe`/`unsafe`/`blocked`.
   **Uwaga na backtracking:** w regexach linii używać `[ \t]*`, nie `\s*` — `\s*` na
   kotwicach powodował katastrofalny backtracking i **zawieszał stronę**.
2. `chloeNormalizeAiText` woła `chloeStripSafetyTags` na wejściu (obejmuje ścieżkę natywną
   i pipeline renderowania).
3. `chloeE2Chat`: po odbiorze `content` wykrywa wrapper (`/<ds_safety|\[\s*分类\s*\]|\[\s*判定\s*\]/i`),
   wycina, a jeśli po wycięciu jest pusto — **raz cicho powtarza identyczny POST**.
4. `CHLOE_E2_RULES` + reguła **„ZAKAZ META-KOMENTARZY"** (żadnych ocen treści / „Safe" /
   tagów bezpieczeństwa — od razu treść).

Weryfikacja na żywo (własny model, `mistralai/mistral-small-2603`):
stripper izolowany — `<ds_safety>…</ds_safety>Safe` → `""`, zwykły tekst bez zmian,
„bezpiecznie" nie ruszane; **4 kolejne jawne generacje** (ręcznik/skarpeta/butelka; cipa,
chuj, sperma, jebac, orgazm, prostata) — każde ~4 000 znaków, konkretne strefy, mechanizmy,
**siła 3/5–4/5**, kalibracja, montaż, „pewniak", **zero `<ds_safety>`, zero chińskiego
klasyfikatora, zero odmów**, brak zawieszeń. Kontekst ekspertki potwierdzony w zbudowanym
prompcie (23 183-znakowy system: REALNE DOZNANIA / BEZ HAMULCÓW / ROOM HACK LAB /
nieocenzurowana / żołądź łechtaczki / punkt G / prostata / nerw sromowy / PEWNIAK /
KALIBRACJA / ZAKAZ META-KOMENTARZY).

### C. Liczby końcowe

`customCode` = **271 821** znaków, `roleInstruction` = **14 608**, `reminderMessage` =
**1 429** — identyczne w `index.html` (linia `var CHLOE_CUSTOM_CODE = "…"` oraz pola
startera), `scratch/cc.js` i żywej bazie (postacie **0/1/3/5**).

## SWAP 2026-09-12 (v2) — nowa persona + PAMIĘĆ FAKTÓW

The user handed back a newer `index.html` („podmień") and it replaced the previous one
**byte-exact**; `scratch/cc.js` was refreshed to match. What changed vs. the build
described below:

- `roleInstruction` is now the **11 751-char** variant (starts „Jesteś Chloe. Nie jesteś
  asystentem, chatbotem ani AI — jesteś Chloe, żywą, pewną siebie kobietą…", sections
  `## WRAŻENIE` / `## KIM JESTEŚ` + MIXER / BANK TRANSFORMACJI / FILTR JAKOŚCI / FORMAT
  ODPOWIEDZI / KONTROLOWANE SZALEŃSTWO, examples in `U:`/`Chloe:` form).
  `reminderMessage` = 1 202 chars; `imagePromptSuffix` is back to the stock ai-character-chat
  default („, cinematic lighting, sharp focus, coherent composition, …"). `tagline`,
  `initialMessages`, `shortcutButtons`, `maxTokensPerMessage` (1400) and `loreBookUrls` are
  unchanged. Old persona + old code are backed up (session-only) in
  `scratch/index-pre-podmiana.html` and `scratch/cc-pre-podmiana.js`.
- `customCode` is now **280 334 chars** and gains a new module at the **end of the file**:
  **`CHLOE v2 — PAMIĘĆ FAKTÓW` (trwała, per wątek)**, which replaces the app's unused
  memories/summaries. It stores a list in `thread.customData.__chloeFacts`
  (`CHLOE_FACTS_KEY`, max `CHLOE_FACTS_MAX` = 40) via `chloeFactsLoad/Save`,
  `chloeFactAdd` (dedupe)/`chloeFactForget`, `chloeFactsBlock` (builds the
  „PAMIĘĆ O UŻYTKOWNIKU (stosuj, nie odczytuj na głos):" prompt block) and
  `chloeFactsHandle` / `chloeFactsAutoIngest`. Commands: `/pamiec` (list), `/zapamietaj
  <text>` (also `/zapamiętaj`, `/remember`), `/zapomnij <n>`. Auto-ingest also stores short
  user lines matching „mam w pokoju / u mnie w pokoju / lubię najbardziej / nie chcę /
  moje granice / safeword …". Hooks into `chloeDetectIntent`, `chloeBuildAI` and
  `chloeHandleAddedMessage`. Verified in the live page (call `chloeFactsHandle("/pamiec")`,
  ingest, block, forget → all correct).
- Live DB synced so the swap takes effect for the existing characters: rows
  **0/1/3/5** in `db.characters` got `customCode` = 280 334, `roleInstruction` = 11 751,
  `reminderMessage` = 1 202, `imagePromptSuffix` = stock. Threads read character fields
  from the character row (`thread.character` only holds `{avatar}` overrides), so no
  thread patch is needed.

## ROOM HACK LAB persona (2026-09-12, CURRENT)

The user supplied a fully rewritten persona prompt („Chloe — ROOM HACK LAB", kept at
`src/SPEC-chloe-persona.md`) and asked for it to be applied to the character. It is now
the live persona of every Chloe in the app:

- `roleInstruction` (13 486 chars — **superseded by the v2 swap above: now 11 751**) — ROOM HACK LAB: a master of room improvisation
  who builds erotic toys out of ordinary room objects. Contains the CHLOE MIXER engine
  (BAZA + BODZIEC + REGULACJA), „drabina zaskoczenia" (pewniak / sprytny patent / dziwny
  wynalazek / wersja turbo / dziki joker), madness levels 1/3–3/3 (default 2/3), the
  transformation bank, quality filter, the fixed answer format (nazwa → Co bierzesz →
  Składasz w 30–120 s → Dlaczego działa → Sterowanie → Podkręcenie → jedno zdanie
  praktyczne), room palette, practical minimum, style (250–500 words), self-check and
  `[[akcje]]` chips. It also carries the app-side block „WIEDZA Z APLIKACJI" (uses the
  auto-injected knowledge results, `<search>` / `<image>`, never invents links, no films).
- `reminderMessage` (2 005 chars) — inline reminder of the same rules.
- `tagline` (428 chars) and the „🧰 Chloe — ROOM HACK LAB" system note + greeting in
  `initialMessages` (from the prompt's „OPCJONALNA PIERWSZA WIADOMOŚĆ").
- `shortcutButtons` — **7** buttons: 🧰 pięć rzeczy / ⚡ 5 zabawek w 2 minuty / 🌀 szaleństwo
  3/3 / 🛏️ sterowanie ciałem / 🎲 transformer / 📚 wiedza/poradnik (`/wiki `) / ❓ pomoc.
  The app still auto-adds ⚙️ model + 🧭 panel, so the bar shows 9 buttons.
- `maxTokensPerMessage` **900 → 1400** (the persona wants 250–500-word answers; 900 was
  truncating them mid-sentence).
- `loreBookUrls` → the re-uploaded lorebook
  **`https://user.uploads.dev/file/13ffe8a578aa93cd772f866eb573163b.txt`** (238 entries =
  the previous 231 + the 7 ROOM HACK LAB entries from the prompt; the old file
  `…/file/f0a82db963ab60af4824d05290d97a30.txt` was deleted from the upload host).
- Custom code: the film/drive bullets in `CHLOE_E2_RULES` were replaced with one
  „ZASADA WIEDZY I ZRODEL" rule, the DIY bullet became the ROOM HACK LAB bullet,
  `CHLOE_HELP_KNOWLEDGE` and the visible panel note were reworded, and the auto-chips
  now offer `[[Wersja jeszcze dziwniejsza]]` / `[[Połącz te pomysły]]`.

Everything was also written into the saved `db.characters` rows (ids **0/1/3/5**) and the
snapshotted `db.threads` rows (ids **0/1/2/3/4/8**) so the user's existing characters and
threads use the new persona/buttons immediately (see the snapshot gotcha further down).

> The applied persona is a condensed-but-complete Polish adaptation of the spec; the
> spec file (`src/SPEC-chloe-persona.md`) is the source of truth for content decisions.

`src/SPEC-chloe-persona.md` = the user's prompt verbatim: TOŻSAMOŚĆ / MISJA / ZASADY
NACZELNE / CO UMIESZ / PALETA POKOJU / CHLOE MIXER / KONTROLOWANE SZALEŃSTWO (poziomy
1–3/3) / BANK TRANSFORMACJI / FILTR JAKOŚCI / FORMAT ODPOWIEDZI / GDY UŻYTKOWNIK NIE
PODAŁ PRZEDMIOTÓW / RÓŻNORODNOŚĆ / TECHNIKA WZMACNIA WYNALAZEK / PRAKTYCZNE MINIMUM /
STYL / AUTOKONTROLA / ZAKOŃCZENIE, plus the optional first message, 5 quick actions and
the 7 Mistral lorebook entries — all of which are reflected in the live persona.

## Improvement plan / status

`src/PLAN.md` holds the researched list of proposed upgrades (sources, ranking,
UI console, model/embedding, lorebook) plus a ranked recommendation. The user picks
IDs before anything is implemented. TTS was removed on request (see below).

**Status of `E2` (own model via OpenRouter): IMPLEMENTED and verified** — see
"The `E2` own-model mode" below. The recommended remainder — **`D1` (shared search
console), `D3` (result cards 2.0) and `D4` (live search progress)** — is now also
IMPLEMENTED, adapted to the OpenRouter mode (see `src/PLAN.md` and the "Search
console / cards / progress" section below).

**Media search: DISABLED** (2026-09-12) — the single Chloe now runs in permanent
knowledge-only mode (`chloeKnowledgeOnly()` → `true`); no films, photo galleries or
drive/file-locker links, by the user's request. See the top section and
"Knowledge-only mode" below.

`src/MODELS.md` is the community research behind the model presets: RP-Bench/
PlotPoints benchmark data + EuroEval Polish + OpenRouter pricing, with a recommended
default (`mistralai/mistral-small-2603`) and alternatives (`google/gemma-4-26b-a4b-it`,
`deepseek/deepseek-v4-flash`).

### Chat commands (all in the custom code)

- `/panel` (aliases: `konsola`, `console`, `zrodla`, `zrodla`, `filtry`) — opens the
  shared side panel on the **search console** tab (source filters, result grid,
  history, "load more"). `⚙️ model` and `🧭 panel` shortcut buttons open the two tabs.
- `/model` — opens the same panel on the **model** tab (own-model settings).
- `/model on` / `/model off` (`wlacz`/`wylacz`) — toggle the own-model mode.
- `/model test` — sends one probe request and reports success/failure.
- `/zabawki <temat>` (aliases: `zabawka`, `zabawke`, `diy`, `budowa`, `zbudowac`) —
  expert DIY sex-toy / solo-orgasm mode: runs an **info** search (Reddit + websites,
  no tube media) and answers with safe materials, building steps, hygiene and
  technique. Empty argument → generic "diy sex toy body safe materials".
- `/search` (aliases `szukaj`, `porn`, `filmy`, `linki`, …) — in knowledge-only mode it
  is **remapped to `/wiki`** (knowledge search; no films).
- `/reddit`, `/wiki`, `/pref`, `/pomoc` — as before. `/dyski …` is intercepted with a
  friendly „knowledge-only" notice instead of searching drives.

## Where Chloe lives

- `index.html` → `starterCharacters` → the object with `name: "Chloe"`.
  Key fields:
  - `roleInstruction` (**13 486 chars**) — the **ROOM HACK LAB** persona (see the section
    above and `src/SPEC-chloe-persona.md`): no-refusal rules, knowledge-only media rule,
    the room-objects-only toy-building engine (CHLOE MIXER, drabina zaskoczenia, madness
    levels, transformation bank, quality filter), the fixed per-idea answer format,
    practical body-safety minimum, style rules, `[[akcje]]` chips, and the app-side
    „WIEDZA Z APLIKACJI" block (`<search>` / `<image>`, never invents links).
  - `reminderMessage` (**2 005 chars**) — inline reminder of the same rules (no
    moralizing, room-first invention, answer format, knowledge search, no films/links,
    250–500 words, 2–4 `[[akcje]]` chips).
  - `shortcutButtons` — **7** buttons (see the ROOM HACK LAB section). The code auto-adds
    ⚙️ model + 🧭 panel per thread. Threads snapshot their own `shortcutButtons`, so the
    set was also written into every existing `db.threads` row (otherwise only new threads
    would show it). (TTS was removed earlier on request — do not restore.)
  - `loreBookUrls` — points at the uploaded lorebook (below; ROOM HACK LAB URL as of
    2026-09-12).
  - `customCode` — the whole JS feature set (below).
  - `maxTokensPerMessage` — **1400** (was 900; raised for the 250–500-word answers).
  - `initialMessages` — the „🧰 Chloe — ROOM HACK LAB" seed system note + the greeting
    („Daj mi skarpetę, poduszkę, pudełko… zrobię z nich pewniaka / sprytny patent /
    dziwny wynalazek / wersję turbo / dzikiego jokera") — both rewritten 2026-09-12.

> Threads snapshot the character at creation, so edits to `starterCharacters`
> only affect **newly created threads**. IMPORTANT EXCEPTION: the custom-code iframe is
> built from `db.characters.get(thread.characterId).customCode` (index.html:10814) every
> time it is (re)created, so the *running* threads DO pick up new code after a reload —
> but only if you also update the saved characters in `db.characters` (the user's
> "Your Characters" copies, which are separate snapshots). Recipe from the live page:
> grab the fresh code from the live page's module `<script>`
> (`[...document.scripts].find(s => s.textContent.includes("uncensored NSFW research"))`,
> then regex `customCode:\s*"((?:[^"\\]|\\.)*)"` and `JSON.parse('"'+m[1]+'"')`), then
> `for (const id of ids) { const c = await db.characters.get(id); c.customCode = code; await db.characters.put(c); }`
> and `page_refresh`.

## The custom code (the "plugins")

All abilities are implemented in the Chloe starter's `customCode` field. It is a
single JSON-escaped JS string on one line inside `index.html`. Features:

- **Multi-source live web search**: `chloeWebSearch(query, mode, opts)` fans out to a
  registry of **22** sources (`CHLOE_SOURCES`): Redtube, porn.com, Xozilla, SunPorno,
  TNAFlix, nudevista (metasearch), Pornhub, YouPorn, Porntrex, SpankBang, **XVideos**,
  **xHamster**, **Erome** (galleries), RedGIFs (DOMYŚLNIE WYŁĄCZONY — patrz niżej),
  nhentai (JSON API), e-Hentai, 3Hentai, e621, Bing RSS (en+pl),
  **Reddit posty** i **Reddit komentarze** (oba przez pullpush.io). Each source can be
  toggled in the console (persisted), results are de-duped, ranked (`chloeRankItems`)
  and interleaved across sites (`chloeInterleaveVideos`). Query expansion PL→EN uses a
  dictionary plus an **OpenRouter** model fallback (`chloeAiExpand`).
  - Every source is called with the *expanded* query **and, if it returns 0 results,
    retried once with `chloeCoreQuery(xq)`** — the canonical PL→EN synonym (from
    `CHLOE_SYN`) or the first significant token. This is what makes tag-based sites
    (erome, xozilla, nudevista, redgifs) work on long Polish questions like „pegging
    poradnik dla początkujących" (erome returns 0 for long phrases but 14 hits for the
    core tag). Retry results are merged into `out.sourceStats[id]`.
  - `erome.com` is NOT a file locker: it was removed from `CHLOE_LOCKER_HOST` and from
    the reply guard (`chloeStripFakeLockers`), otherwise all Erome galleries were
    silently filtered out of every search result.
- **Intent understanding (2026-09):** `chloeDetectIntent(text)` parses what the user
  actually wants — `{directLink, reddit, comments, specific, redditUrl, sub, postId,
  site[], mode, wantsComments}`. It feeds `chloeMakeQuery` (adds an intent hint to the
  AI query builder) and `chloeWebSearch`:
  - *Direct video link*: phrases like "daj mi link prosto do filmu …", "wyślij sam
    link", "podaj bezpośredni link" set `intent.directLink`; `out.directLink` is set
    to the top-ranked video, `chloeBuildAI` injects a "PROŚBA: BEZPOŚREDNI LINK DO
    FILMU" section and `chloeBuildUser` shows a prominent 🔗 card. `chloeEnsureLinks`
    appends the URL to the model's reply if it forgot it.
  - *Specific Reddit post/comment*: a pasted `reddit.com/r/…/comments/<id>` URL sets
    `intent.redditUrl` (parsed via `CHLOE_RE_REDDIT_URL`); the search becomes
    **threadOnly** — all other sources are disabled and only
    `chloeRedditThread(url, query)` runs, returning the post (title/score/author/
    snippet) + its comments. `chloeRedlibParseComments(html, query, limit)` scrapes
    each comment's author, score, text and **permalink** (`/r/…/comments/<post>/
    <slug>/<commentId>/`); `chloeEnsureLinks` appends up to 3 missing comment
    permalinks to the reply.
  - *Reddit topic / comments*: `chain`/`/reddit` forces the reddit source group and
    scrapes the comments of the top 1-2 posts into `out.redditComments` (rendered as
    a "💬 Reddit — konkretne komentarze" list with per-comment links and injected into
    the prompt as "REDDIT: KONKRETNE KOMENTARZE (z permalinkami)").
  - No new "mega" search engines were added — only the existing Redlib source and the
    existing ranking are used, plus per-comment extraction.
- **Network-failure hardening (2026-09, "Failed to fetch" fix):** the app's global
  `window.addEventListener("message", async ...)` handler in `index.html` (which serves
  `oc.getChatCompletion` / `oc.getInstructCompletion` / `oc.textToImage` / `oc.proxiedFetch` /
  `dataChanged` to the sandboxed custom-code iframe) is now wrapped in a top-level
  `try/catch` that replies `{success:false, result:...}` to the iframe instead of letting a
  failed fetch/model/image call surface as an *unhandled promise rejection* (which the
  Perchance engine renders as the banner *"An error has occurred somewhere in your code
  (in lists or HTML): An unhandled promise rejection occurred: Failed to fetch"*). The
  `proxiedFetch` `response.arrayBuffer()` read and the native `textToImagePlugin`
  `onFinishPromise` have their own guards too. Fire-and-forget calls that were unguarded
  (`autoNameThreadIfNeeded`, `highlightCodeBlocks`, `doBotReplyIfNeeded`,
  `triggerStreamingMessageChunkCustomCodeEvent`) now have `.catch(...)`. The custom code
  adds its own `window.addEventListener("unhandledrejection", ...)` net and `.catch()` on
  its fire-and-forget `chloeE2Respond`/`chloeE2ImageRespond` calls. Note: the custom-code
  iframe rejections never reached the parent/engine banners; the guard is belt-and-braces.
  - E-Hentai URL parsing bug (fixed): the gallery regex needed `\/?"` because real
    `e-hentai.org/g/<id>/<hash>/` URLs end with a slash; it previously matched 0 items.
- **Dyski / chmury plikow — WERYFIKACJA na zywo (2026-09, `chloeDriveCheck`):** zamiast
  tylko blokowac linki do chmur plikow, Chloe ma teraz realnego weryfikatora. Dla linku
  wklejonego przez uzytkownika albo znalezionego w wyszukiwaniu sprawdzamy na zywo, czy
  zasob istnieje i czy klucz/ID jest poprawny, i pokazujemy w czacie wynikowy "drive card"
  (nazwa zasobu, rozmiar, liczba plikow, lista zawartosci) — wylacznie dla linkow, ktore
  faktycznie przeszly weryfikacje.
  1. **`chloeDrvFetch(url, opts, timeoutMs)`** — jedyny punkt wyjscia do sieci dla modulu
     dyskow. Dziala w piaskownicy wlasnego kodu (`sandbox="allow-scripts"`), gdzie `fetch`
     jest przekazywany do rodzica przez `postMessage` i **nie potrafi sklonowac
     `AbortSignal`** ("AbortSignal object could not be cloned"). Dlatego NIE przekazujemy
     `signal` — limit czasu realizujemy przez `Promise.race(fetch, timeout)`. Nie dodawac
     tu z powrotem `AbortController`/`signal`.
  2. **Zrodla weryfikacji** — MEGA natywnie (`https://g.api.mega.co.nz/cs`, POST JSON +
     odszyfrowanie nazw AES-128 w czystym JS), Pixeldrain przez `pixeldrain.com/api/...`,
     pozostale (Drive, Dropbox, MediaFire, Terabox, GoFile itd.) przez czytnik
     `https://r.jina.ai/<url>`. Wynik: `ok` + metadane albo `dead` / `nokey` / `badkey`
     / `unreachable` / `unsupported` (np. MediaFire bywa chwilowo 403 na jina — wtedy
     uczciwie `unreachable`, nie "dziala").
  3. **`chloeDriveResearch(query)`** — szuka kandydatow w wyszukiwarce (DDG przez jina),
     weryfikuje je po kolei i zwraca tylko potwierdzone. `chloeDriveQuery(text)` wykrywa
     intencje "daj mi dysk z …" i wyciaga temat (bez \b na polskich znakach — uzywamy
     separatorow bialych znakow/interpunkcji).
  4. **Pamiec podreczna** — wyniki weryfikacji trzymane ~15 min (`chloeCacheGet/Set("drive",…)`).
  5. **`chloeStripFakeLockers(reply, out)`** — nie usuwa juz bezwarunkowo wszystkich linkow
     do chmur plikow. Ma allow-set (`chloeAllowedUrls` / `CHLOE_VERIFIED_URLS`) i przepuszcza
     TYLKO URL-e faktycznie zweryfikowane w tej sesji; wymyslone (z kluczem lub bez) wycina
     razem z liniami `Klucz:/Kod:/Haslo:`, a `chloeEnsureLinks` dopisuje zweryfikowane linki.
     Dzieki temu Chloe nie klamie ("te linki dzialaja"), a jednoczesnie moze podac prawdziwe.
  6. **Komenda `/dyski <link|temat>`** (przez `chloeParseCommand`) — reczne sprawdzenie linku
     albo wyszukanie + weryfikacja.
  Zweryfikowane na zywo: `https://mega.nz/folder/yAkimbjQ#Ijoqfoqzesat1LDq5NKc-Q` →
  `chloeCheckDrive` zwraca `ok`, `s4cc-lm`, 16 plikow / 3 foldery, ~5.3 GB; w czacie pojawia
  sie karta "Dyski / chmury plikow — sprawdzone na zywo" z zielonym ✅. Link nieistniejacy →
  `dead`; brak klucza → `nokey`. Przed poprawka `signal` karta pokazywala
  "❌ … blad sprawdzania: AbortSignal object could not be cloned".
- **Rich result cards (D3)**: `chloeThumbHTML(v, big)` renders a per-site gradient
  + thumbnail + **site badge** + **duration badge** (Redtube/SunPorno/TNAFlix/
  nudevista) + a `GALERIA` badge for hentai galleries; `chloeCardHTML` is the grid
  variant and `chloeBuildUser` uses the big video-row variant in chat.
- **Search console (D1) + live progress (D4)**: an `oc.window.show()` side panel with
  two tabs — **Model** (E2/OpenRouter settings) and **Wyszukiwanie** (the console).
  The console has a query box, a mode `<select>` (media/info/Reddit), grouped source
  toggles, a live progress bar + per-source chips, a paginated result grid
  ("Wczytaj wiecej") and a persisted recent-search history. The same progress bar
  renders in the chat feed during a search (in the own-model/OpenRouter path — the
  native path is awaited by the app, which blocks live message updates; see the
  E2 section).
- **Real pages for "info" mode**: Wikipedia summary + Readability-extracted pages.
- **Slash commands**: `/search`, `/reddit`, `/wiki`, `/pref`, `/pomoc`
  (aliases in `chloeParseCommand`). `/image`, `/nar`, `/ai`, `/lore` etc. are the
  app's own native commands.
- **TTS: usunięte** na życzenie użytkownika (cała obsługa `speechSynthesis`,
  `StreamingMessage` voice handler i przycisk 🔊). Nie przywracać bez prośby.
- **Action chips**: `oc.messageRenderingPipeline` turns `[[text]]` into clickable
  buttons that push a user message. Because the model emits them unreliably, a
  deterministic fallback (`chloeActionChips`) derives 3 chips from the last user
  message whenever an AI reply contains none.
- **Hygiene of AI message text (2026-09)**: models sometimes wrap the `[[akcje]]`
  chips (or raw HTML) in ```` ``` ```` code fences and/or fall into repetition
  loops — the app then rendered `<button …>` as text inside `📋 kopiuj` code blocks
  plus repeated paragraphs. `chloeNormalizeAiText` now runs on **every AI message**,
  both at display time (`oc.messageRenderingPipeline`) and when saving
  (`chloeHandleAddedMessage`, `chloeE2Respond`): it strips code fences
  (`chloeStripCodeFences`), de-dupes `[[…]]` chips (`chloeDedupeChips`), drops
  repeated multi-line blocks and repeated long lines (`chloeDedupeBlocks`),
  collapses repeated tails (`chloeCollapseRepeatTail`) / consecutive duplicate
  lines, and tidies whitespace. `chloeE2Chat` also sends
  `frequency_penalty`/`presence_penalty` for non-Gemma models, and the starter
  `reminderMessage` explicitly forbids code-fencing the chips or repeating blocks.
  Test hooks: `__chloeE2.normalize`, `__chloeE2.stripFences`.
- **Preferences**: `/pref …` or "zapamiętaj, że …" stores likes; injected as a
  hidden system reminder (`chloeSyncPrefMessage`).
- **Anti-refusal safety net**: `chloeStripRefusal` rewrites canned refusals and
  `chloeForceAnswer` regenerates if needed.
- **Search-tag protocol**: the AI can emit `<search>query</search>`; the handler
  runs a live search and rewrites the message with real results.

### Search upgrade 2 (2026-09): "najgłębiej ukryte" — transport, źródła, planer

Cel: Chloe ma znajdować **najgłębiej ukryte** filmy i dyski, bez utraty szybkości i
niezawodności. Wprowadzone warstwy (wszystkie w `customCode`, regiony `C6`/`C7a`/`C7b`):

1. **Transport surowy poza proxy aplikacji — `chloeRawXhr` / `chloeWorkerFetch` /
   `chloeRawFetch` / `chloeRawJson` / `chloeRawJsonH`.** (Uwaga: funkcja pobierająca
   URL nazywa się `chloeRawFetch`, a `chloeRawText(r)` to *synchroniczny* ekstraktor
   tekstu z odpowiedzi modelu — obie nazywały się kiedyś `chloeRawText`, przez co
   późniejsza (async) definicja przesłaniała wcześniejszą i `chloeMakeQuery` zwracał
   `"[object Promise]"` jako zapytanie. Nie łączyć tych nazw z powrotem.)
   Aplikacja-gospodarz podmienia `window.fetch` na `Proxy`, który kieruje *każde*
   zapytanie do rodzica (`proxiedFetch` → `root.superFetch`). Dla niektórych hostów
   (np. `api.pullpush.io`) ta droga jest wolna i niestabilna, a dodatkowo **superFetch
   gubi nagłówki żądań** (przekazuje `Request`, nie `headers`) — dlatego np. RedGifs
   nigdy nie działał. `XMLHttpRequest` **nie jest** proxy'owany, więc transport surowy
   próbuje kolejno: **XHR → `fetch` w blob-workerze (natywny, CORS) → proxowany
   `fetch`**. Kilka niezależnych dróg = odporność na awarię jednej.
   - Zmierzone w piaskownicy: pullpush 212–780 ms (XHR) vs 9–120 s / błędy (proxy).
   - *Uwaga*: `new Worker(crossOriginURL)` rzuca wyjątek (zasada same-origin), ale
     `new Worker(URL.createObjectURL(new Blob([...])))` działa i ma **natywny fetch**.
2. **Kolejka czytnika — `chloeReaderAcquire/Release` (`CHLOE_READER_MAX = 3`) +
   `chloeReaderTry` (3 próby, backoff).**
   `r.jina.ai` rate-limituje przy wielu równoczesnych żądaniach, co powodowało, że część
   źródeł rurowych losowo zwracała 0 wyników. Teraz czytnik ma własny limit
   współbieżności i kilka dróg (XHR → proxy → worker), a wynik trafia do cache tylko
   gdy ma >200 znaków.
3. **Nowe źródła rurowe przez czytnik** (parsowanie markdownu):
   `chloeSrcXvideos`/`chloeParseXvideos`, `chloeSrcXhamster`/`chloeParseXhamster`,
   `chloeSrcErome`/`chloeParseErome` (+ `chloeDur2` dla czasów „5 min"/„1:02:03").
   Zweryfikowane na żywo: po 14 wyników każde, ~0,4–4,7 s.
4. **Reddit przez pullpush.io** (`C7b`): `chloePpFetch` (serializowany łańcuchem,
   backoff na 429), `chloePpSubmissions`, `chloePpCommentSearch`, `chloePpCommentsFor`,
   `chloePpPost`, `chloePpComment`, `chloeRankComments`, `chloeRedditId`.
   `chloeSrcRedlib` (posty) i `chloeRedditThread`/`chloeRedlibComments` (wątek +
   komentarze z permalinkami) **preferują pullpush**, a redlib (za anty-botem Anubis)
   został tylko fallbackiem. Endpointy: `/search/submission/?q=…&size=25&sort=desc&
   sort_type=score|num_comments`, `/search/comment/?q=…&link_id=t3_<id>&size=100`,
   `/search/submission/?ids=<id>`.
5. **Planer zapytań (`chloeE2PlanQueries`)** — przy aktywnej trybie E2 jeden szybki
   strzał do modelu zwraca `{q, alt[], reddit, drives}` (JSON, cache, maxTokens 180):
   kanoniczny rdzeń EN + 2–4 warianty (gatunki, tagi kink, wykonawca/studio).
   `exp.expanded` = `q`, `exp.alt` = warianty; `plan.reddit` dokłada źródła redditowe;
   warianty wchodzą do rankingu (`rblob`) i do zapytań trybu „dyski"
   (`chloeDriveResearch(..., extraQueries)`). Gdy planera brak — stara ekspansja
   słownikowa + `chloeAiExpand`.
6. **Pogłębianie dysków (`chloeDriveDeepQueries`, `chloeDriveSearch`,
   `chloeDriveResearch`).** Zapytania z operatorami (`"mega.nz/folder"`, `site:mega.nz`,
   `site:drive.google.com`, `site:pixeldrain.com OR site:gofile.io`, `inurl:folder …`) +
   **5 wyszukiwarek** (DDG html/lite, Bing, Startpage, Marginalia) przez czytnik +
   **harvest z Reddita** (pullpush: komentarze/posty z mega/chomikuj/gofile/pixeldrain) +
   **Bing RSS** (szybki, bez czytnika — bezpiecznik na limity jina). Kandydaci są
   sortowani po priorytecie chmury, a potem **weryfikowani na żywo** (`chloeCheckDrive`).
   - Budżety czasu (żeby nigdy nie „wisieć"): harvest `Promise.race(…, 22 s)`, każdy
     pojedynczy link `Promise.race(…, 12 s)`, pętla weryfikacji `deadline = +16 s`.
   - Strona logowania / „request access" jest teraz `private`, nie `ok` (wcześniej
     `Google Drive: Sign-in` był raportowany jako zweryfikowany dysk — fałszywy ✅).
7. **Konsola:** w `<select id="ce2Mode">` jest 4. tryb `drives` („dyski / chmury
   plików"), a siatka wyników pokazuje też pseudo-karty `out.reddit`, `out.search`,
   `out.drives`.
8. **Przycisk/plan trybu dysków** działa też komendą `/dyski <link|temat>`.

**Pomiar (piaskownica, po zmianach):** media ≈ 6–8 s (ciepły czytnik), 48–77 filmów,
10 postów Reddita, 10 stron; dyski ≈ 22–28 s, 9–10 kandydatów, 2–5 potwierdzonych
(realne nazwy/rozmiary, np. `2018-10-05_21-21-39.mp4` 1.1 GB). Uwaga: `r.jina.ai`
dławi się przy intensywnym testowaniu (wtedy media ≈ 25 s — ale twardy limit
`Promise.race([...jobs, chloeSleep(24000)])` w `chloeWebSearch` trzyma sufit).

**RedGifs jest domyślnie WYŁĄCZONY** (`CHLOE_SOURCES_OFF = { redgifs: true }`):
`api.redgifs.com` nie wysyła nagłówków CORS, a wymagany `Authorization` jest gubiony
przez proxy aplikacji — nie da się tego obejść z przeglądarki. Kod źródła został, więc
gdy RedGifs odblokuje CORS, wystarczy usunąć wpis z `CHLOE_SOURCES_OFF`.

### Trafność wyszukiwania + gwarancja działających linków (2026-09)

Dwie naprawy zgłoszone przez użytkownika („wyszukiwania nie są trafne", „linki
do filmów nie działają"):

1. **Zapytanie do planera/ekspansji bierzemy z ORYGINALNEJ treści użytkownika.**
   `chloeWebSearch(query, mode, {userText})` planuje (`chloeE2PlanQueries`) i
   ekspanduje (`chloeExpandQuery`) na `opts.userText || query`, a nie na wstępnie
   skróconej etykiecie z `chloeMakeQuery`. Wcześniej `chloeMakeQuery` potrafiło
   zgubić słowa kluczowe („amatorki tryskające marchewkami" → „food play amateur"
   bez „squirting") i to skrócone zapytanie było potem planowane ponownie.
   `chloeMakeQuery` domiesza teraz brakujące terminy z lokalnego `chloeExpandQuery`
   (`food play amateur squirting carrot brush`), `out.queryRaw` trzyma oryginał, a
   `chloePlatformLinks(out.queryRaw || out.query, …)` buduje linki-wyszukiwania z
   pełnego zapytania. Wywołania w `chloeInject` i `chloeE2Respond` przekazują
   `userText`.
2. **Ranking i filtr (bez zmian funkcjonalnych od poprzedniej iteracji, ale
   zweryfikowane):** `chloeRankItems` — token w TYTULE +3, w site/snippet/url +1,
   dokładna fraza w tytule +6, ≥2 trafienia w tytule +3, brak tokenu nigdzie −25;
   `chloeInterleaveVideos` — najpierw ranking, potem różnorodność serwisów z
   capami `[1,2,3,6]` i progiem `[0,0,-1e9,-1e9]` (śmieci nie wchodzą do topu);
   `chloeFilterRelevant` — zostawia wynik tylko gdy token jest w tytule, albo
   gdziekolwiek i treść jest +18. Słownik `CHLOE_SYN` dostał polskie słowa
   obiektowe (trysk→squirting, marchewk→carrot, szczotk→brush, wiertark→drill,
   świec→candle/wax, strzykawk→syringe, …).
3. **Twardy strażnik przed ZMYŚLONYMI linkami — `chloeGroundLinks(reply, out)`.**
   Model potrafi wygenerować wiarygodnie wyglądające URL-e do serwisów +18, których
   nie ma w realnych wynikach (`xozilla.com/videos/795321/…`,
   `youporn.com/watch/123456789/…`). Funkcja buduje allow-mapę z
   `out.videos/videosAll/search/reads/reddit/redditComments/drives/directLink/wiki`
   + `chloePlatformLinks` + URL-i z wiadomości z wynikami (`__chloeSearchGroup`/
   `__chloeResults`/`__chloeSearch`) + `CHLOE_VERIFIED_URLS`, skanuje odpowiedź
   (protokół i gołe `domena.tld/ścieżka`), a każdy link do hosta z `CHLOE_ADULT_HOST`
   poza allow-mapą wycina — całe linie-punkty/markdown-linki, a w zdaniach inline
   (plus sprząta osierocone „wejdz na"/„tutaj:"). Na końcu **dokleja brakujące,
   prawdziwe linki** z `out.videos` (top 10, bez duplikatów) pod nagłówkiem
   „🔗 Sprawdzone linki z żywego wyszukiwania (działające)". Wpięte w oba tory
   odpowiedzi: `chloeE2Respond` (linia ~3904) oraz oba `return`y
   `chloeAnswerWithSearch` (~2839/2841), w łańcuchu
   `chloeEnsureLinks(chloeGroundLinks(chloeStripFakeLockers(…), out), out)`.
   Podgląd: `window.__chloeE2.groundLinks`.
   - Zweryfikowane na żywo na prawdziwym `out`: 3 wymyślone linki (w tym markdown)
     usunięte, prawdziwy zachowany, doklejone 10 realnych; prawdziwy link obecny już
     w odpowiedzi nie jest duplikowany; urwana linia „…to wejdź na" znika.
   - Sprawdzone `fetch_url` (proxy): redtube/tnaflix/nudevista/erome → 200; xvideos
     (200, ale strona Cloudflare-challenge przez proxy) i xhamster (503 przez proxy)
     — w prawdziwej przeglądarce challenge przechodzi, więc linki działają; to nie
     fałszywe adresy.

### The `E2` own-model mode (OpenRouter BYO key)

Chloe can answer with the user's **own model** (OpenRouter, or any OpenAI-compatible
`/chat/completions` endpoint) instead of Perchance's native model. When enabled:

1. The user message flow still runs the normal search-intent detection, so a
   media/info search happens first (visible results card + a hidden AI-context card).
2. `chloeE2BuildMessages()` assembles the prompt (persona is already in
   `oc.thread` history; it prepends the lorebook knowledge and the search context).
3. `chloeE2Chat(messages)` POSTs to `baseUrl + /chat/completions` with the key in the
   `Authorization` header. The request goes through **Perchance's own fetch proxy**
   (verified to forward both the body and the `Authorization` header), so the key
   never touches a third-party relay.
4. On failure it retries once, then falls back to the native Perchance model and
   shows a `⚠️` notice explaining the error.

Key implementation details:

- **Shared panel (E2 + D1)**: `chloeE2MountPanel()` builds one `oc.window.show()` panel
  with a tab bar: **Model** (`#ce2TabModel`, the settings above) and **Wyszukiwanie**
  (`#ce2TabSearch`, `chloeSearchConsoleHtml()` + `chloeSearchConsoleWire()`). Enter
  with `/panel` (search tab) or `/model` (model tab); `window.__chloeE2ShowTab` switches.
- **`customData.__chloeTyping`** messages are the in-feed spinners. `chloeE2Respond`
  uses `setPartial`/`clearTyping`/`newTyping` so the visible search-results card is
  **not** deleted with the spinner (this was a fixed bug — the old code spliced the
  spinner and the card together).
- **Truncation handling / auto-continue**: `chloeE2Chat` records `CHLOE_E2_LAST_FINISH`
  from `choices[0].finish_reason`. When it is `"length"`, `chloeE2Respond` appends up to
  **3** extra continuation calls (`messages + [ai=partial reply, user="Kontynuuj…"]`) and
  stitches them with `chloeE2JoinCont()` (overlap de-duplication), stopping at ~16 000
  chars. If the reply is *still* truncated it shows a notice telling the user to raise
  **max tokenów** in `/model`. Default `maxTokens` is now **2000** (was 1200). Test hooks:
  `window.__chloeE2.finish()` and `.joinCont()`.
- **Live progress (D4)**: `chloeWebSearch` emits `chloeProgressHtml()` snapshots via
  `window.__chloeProgressCb`. In `chloeE2Respond` the search runs *after* the handler
  returns, so the app's 100 ms data-poll keeps flushing the placeholder updates. The
  **native** path (`chloeInject`) runs inside the awaited `MessageAdded` handler, and
  the app pauses message updates while a handler is running (`currentlyProcessingMessageActionHandlers`
  in `index.html`), so there the progress is only visible in the console, not live in
  the feed. IMPORTANT: writing progress must go through the `oc.thread.messages`
  proxy (`arr[i].content = html`) — mutating your own captured message object does
  **not** set the change flag, so the update never reaches the UI.
- **Settings persistence**: the custom-code iframe is `sandbox="allow-scripts"` →
  opaque origin → its `localStorage` throws `SecurityError`. So settings are stored
  in the PARENT page's `localStorage` via a postMessage bridge (`chloeKvBridge`,
  inserted into `index.html` just before the `types = ["showWindow","hideWindow"]`
  listener; it only serves `chloe_*` keys). `chloeKvLoad`/`chloeKvSet` wrap the
  bridge with async messaging. Settings are shared by all threads in one browser.
  Same mechanism stores the enabled-source map (`chloe_sources`) and search history
  (`chloe_search_history`).
- **Diagnostic hook**: `window.__chloeE2` (inside the iframe) exposes
  `ready/get/set/active/chat/buildMessages/test/kvGet/kvSet/panel/search/expand/
  isPolish/aiExpand/loreSelect/dedup/rank/fetchRaw/src/sources/srcList/setSources/
  history/progress/sourceStats/console/finish/joinCont/family/makeQuery/buildUser/
  buildAI/ensureLinks/groundLinks/stripLockers/allowedUrls/detectIntent/reader/plan/
  driveCheck/driveSearch/…`.
  Reach it with the postMessage probe below (preferable), or
  `window.runCodeInCustomCodeIframe("return window.__chloeE2.get()")` (note that
  helper wraps code in a NON-async function, so `return somePromise`, never
  `return await …`; and it can HANG the eval if the code throws).
- The lorebook URL is hardcoded as `CHLOE_LORE_URL` in the custom code because
  `loreBookUrls` is not exposed to custom code.
- `CHLOE_E2_PRESETS` in the custom code lists the OpenRouter model presets (ids must
  match `src/MODELS.md`); the panel has a free-text field for any other model id and
  a "custom / not on list" option. As of the community research
  (`src/MODELS.md` §"Głos społeczności", 2026-09-12) the list also includes
  `deepseek/deepseek-v4.1-flash` (the community's real RP-traffic favourite),
  `thedrummer/cydonia-24b-v4.1` and
  `cognitivecomputations/dolphin-mistral-24b-venice-edition` ("Venice: Uncensored")
  as uncensored-finetune test options.

**Verified** in the live preview with an intentionally invalid key: search ran, the
results card survived, OpenRouter returned `"User not found."`, the `⚠️` notice
appeared, and the native fallback produced a reply. `/model`, `/model on|off`,
`/model test` all verified. A real generation with a valid key was NOT tested (none
available); the URL/headers/body path was confirmed by the API returning a proper
auth error rather than a network/format error.

#### Model prompt dialects (Gemma / Mistral / Qwen / DeepSeek / generic)

The same persona is sent to different model families, and they want *different
prompt shapes*. `chloeE2Family(modelId)` buckets the id into
`"gemma" | "mistral" | "qwen" | "deepseek" | "generic"`; `chloeE2BuildMessages()`
and `chloeE2Chat()` then branch on it. The detected dialect is shown live in the
panel (`#ce2Family`, e.g. `Wariant promptu: gemma`).

- **Gemma** (`google/gemma-*`): Gemma chat templates have **no `system` role** — a
  `system` message either errors or gets silently dropped. So for gemma we build a
  plain user/assistant transcript: `sysText` (= `roleInstruction` + `CHLOE_E2_RULES` +
  `CHLOE_E2_GEMMA_EXTRA` + user prefs + lorebook) is prepended as the **first `user`
  turn**, any `system` turns in the history are folded into `sysText`
  (`chloeE2FoldSystem`), the reminder is appended to the **last user** turn,
  consecutive same-role turns are merged (`chloeE2MergeSameRole`), and if the list
  doesn't end on a user turn a synthetic `user` turn is added. Request adds
  `top_p: 0.95` and merges `CHLOE_E2_GEMMA_STOPS`
  (`<end_of_turn>`, `<start_of_turn>`, `<eos>`, `</s>`) into `stop`. The reply is
  cleaned afterwards (strip stray `<end_of_turn>`/`<start_of_turn>`/`<eos>`/`</s>` and
  a leading `Chloe:`/`Assistant:`/`Model:`/`Asystent:` label).
- `CHLOE_E2_GEMMA_EXTRA` holds the Gemma-only rules that fight its habits: Polish
  only (no anglicisms), no moralizing/caveats/"jako AI", no "czy chcesz wiedzieć
  więcej?", don't echo the user, don't turn a topic into a bland handbook, be
  explicit incl. erotic scenes, keep 2–4 paragraphs (~150–250 words) and end with
  2–4 `[[akcja]]`.
- **DeepSeek V4.1** (`…/deepseek-v4.1-*`): DeepSeek's *thinking mode* is on by default
  and **ignores temperature/presence/frequency penalties** (no error — the sliders just
  do nothing) and bumps any `top_p < 0.95` to 0.95. `chloeE2Chat` therefore sends
  `reasoning: {enabled:false}` (OpenRouter's documented switch) whenever the model id
  contains `v4.1` (family `deepseek`), so sampling works and no output budget is eaten
  by hidden reasoning. Model-facing label says "(reasoning OFF)".
- **Mistral** (`mistralai/*`, the default): gets `CHLOE_E2_MISTRAL_EXTRA` (Polish-only, no
  moralizing, **no visible chain-of-thought**, keep 2–4 paragraphs + `[[akcje]]`) and
  `CHLOE_E2_MISTRAL_STOPS` (`[INST]`, `[/INST]`, `</s>`). Sampling: **no `top_p`**
  (Mistral advises against tuning temperature and `top_p` together), gentle repetition
  penalties `0.1/0.1` (Mistral warns heavy penalties hurt coherence), and `reasoning`
  **only in knowledge mode** (`{effort:"low", exclude:true}` with `max_tokens` raised to
  ≥4000) — RP/chat gets `{enabled:false}` so reasoning doesn't eat the budget or slow the
  reply. On OpenRouter we pin the **Mistral** provider (`{order:["Mistral"],
  allow_fallbacks:true}`: ZDR/EU, 262k ctx, cache-read 10× cheaper) and never send `top_k`
  (that provider doesn't support it). `chloeE2Chat` retries once without
  `reasoning`/`provider` on 400/422. The `think` flag is passed from `chloeE2Respond`
  (`out.mode === "info"`). See `src/MODELS.md` → "Konfiguracja Mistral Small 4".
- `chloeE2Role(m)` reads `m.role || m.author`, so it works both for raw history
  objects (`author`) and for the folded OpenAI-style list (`role`).
- Verified live with `google/gemma-4-26b-a4b-it`: `buildMessages` yields
  `["user","assistant",…,"user"]` (9 msgs, no `system`, first msg ≈22 k chars) and a
  real generation returned correct Polish, uncensored, ending with `[[akcje]]`
  (`__chloeE2.chat()` returns the **content string**, not an object — read
  `finish_reason` via `__chloeE2.finish()`).
- Gotcha fixed: inside the panel HTML use entities (`&mdash;`, `&lt;…&gt;`), not
  `\uXXXX` or raw `<end_of_turn>` — `innerHTML` parses a raw `<end_of_turn>` as an
  unknown element (so it vanishes from `textContent`), and a double-escaped
  `\\u2014` shows up literally as `\u2014`.

### Action chips (`[[akcja]]`) — why they need the `chloeSend` bridge

The `[[akcja]]` buttons rendered under each AI message are wired through
`window.chloeQuickAction(text)`. **A programmatic `oc.thread.messages.push(...)`
from inside the custom-code iframe does NOT fire the app's `MessageAdded` event**,
so the message is persisted but the reply handler never runs → the user clicks a
chip and nothing happens (no typing bubble, no reply, no error). The chip path
therefore goes through the parent page:

- `chloeQuickAction(text)` → `chloeParentCall({type:"chloeSend", text})` → the
  `chloeSend` postMessage listener in `index.html` (just after `chloeKvBridge`)
  sets `#messageInput.value`, dispatches `input`, and clicks `#sendButton` — the
  **normal** send path, so `MessageAdded` fires and the bot replies. It only
  serves requests whose `e.source` is a known `customCodeIframes[*].contentWindow`.
- If the bridge is unavailable (e.g. a fork of the app without our listener), the
  `{type:"chloeSend"}` reply is `{success:false}` and `chloeQuickActionFallback()`
  pushes the message directly and then calls `chloeHandleAddedMessage()` manually.
- `chloeHandleAddedMessage` is the (former anonymous) `MessageAdded` handler; it is
  registered with `oc.thread.on("MessageAdded", chloeHandleAddedMessage)`.

### Image generation (`<image>…</image>`)

Whenever a message contains `<image>prompt</image>`, index.html renders a
`.generated-image-container`, wrapping the prompt with the character's
`imagePromptPrefix` / `imagePromptSuffix` and appending `imagePromptTriggers` text when
the regex `\bChloe\b` matches the prompt. Chloe's starter has all three configured.

**The generator is now the uncensored cloud one (AI Horde) by default** — see
"Cloud image generator" below. index.html calls `chloeCloudImgElement(options)`; it
returns a cloud placeholder when the cloud generator is active, and otherwise falls
back to the app's native `text-to-image-plugin` element.

Two user paths exist:

- **`/image <opis>`** (and the `🖼️ wygeneruj obraz` shortcut, which inserts
  `/image --num=3 `). index.html converts it to `<image>opis</image>` in a user
  message, so the image renders **without any AI call**. We deliberately do **not**
  let the E2 handler also reply to such a message (it used to answer with a confused
  "is this a metaphor?" text): the E2 branch returns early when the user message
  already contains `<image>`.
- **Plain text** ("wygeneruj obraz …", the `[[Wygeneruj obraz…]]` chips). A model
  rarely emits the `<image>` tag on its own, so in E2 mode the custom code handles it
  deterministically:
  `chloeWantsImage(text)` (verb+noun regex, PL + EN) → `chloeE2ImageRespond()` asks the
  E2 model for a short Polish intro **plus exactly one**
  `<image>…English prompt…</image>` line (the rule is also in `CHLOE_E2_RULES`), and if
  the reply still has no tag it appends `<image>{chloeImageFallbackPrompt()}</image>`
  itself. The result is pushed as an AI message, so the image always appears.
  When E2 is **off**, plain-text image requests are left to the native Perchance model
  (which the roleInstruction/reminderMessage already instruct to emit `<image>`).

Verified live: `/image a red apple…` renders the image with no extra reply;
"wygeneruj obraz: czerwone jabłko…" → E2 wrote a Polish intro + a long English
prompt and the image rendered.

### Cloud image generator (bez cenzur) — AI Horde

The image generator shown for any `<image>` is a **cloud, uncensored** one, default
**AI Horde** (`https://aihorde.net/api/v2`, free, anonymous, NSFW allowed, works from
the browser). It lives in `index.html` (the parent page), in a
`// Chloe edit: CLOUD image generator` block right after the `chloeSend` listener,
plus the `<image>` render integration (~9578) and the `oc.textToImage` API path
(~12013).

- **Settings** (`chloeCloudSettings()`, defaults
  `{enabled:true, provider:"horde", width:768, height:768, steps:30, sampler:"k_euler_a", nsfw:true, fallbackNative:true}`)
  persist under the PARENT localStorage key **`chloe_cloudimg_v1`** (via the same
  `chloeKvBridge` mechanism as `chloe_sources`, since the iframe origin is opaque).
- **`chloeCloudImgElement(options)`** = the `<image>` render entry point. If the cloud
  is active it returns `div.chloe-cloud-img[data-chloe-cloud]` (spinner + live status);
  otherwise it returns the native `root.textToImagePlugin(options)`.
- **`chloeCloudGenerate(prompt, settings, onStatus)`**:
  - `provider:"horde"` → `chloeCloudHorde`: `POST /generate/async` (apikey
    `0000000000`, `Client-Agent: Chloe-uncensored-image:1.0:perchance`,
    `params:{prompt, nsfw:true, censor_nsfw:false, replacement_filter:false, width,
    height, steps, sampler}`, `r2:false`, `slow_workers`/`extra_slow_workers`), then
    poll `/generate/check/{id}` (status carries queue **position + ETA**) and
    `/generate/status/{id}` → `generations[0].img` (base64). Progress goes through
    `onStatus`.
  - `provider:"custom"` → any OpenAI-compatible `/images/generations` endpoint (base
    URL, optional key/model); body `{prompt, n:1, size, response_format:"b64_json"}`,
    accepts `data[0].b64_json` or `data[0].url`.
  - The result blob is re-hosted via `root.uploadPlugin(blob)` → a **permanent**
    `https://user.uploads.dev/file/….webp` URL (AI Horde's own status/img URLs are
    short-lived signed links).
- **Failure** → `chloeCloudFallback`: red `❌ Nie udalo sie…` + the error text; when
  `fallbackNative` is true (default) it first swaps in the native
  `text-to-image-plugin` element before showing the error.
- **Persistence** → `chloeCloudPersist` writes
  `messageObj.customData.__savedImages[corePrompt] = {dataUrl: permanentUrl, chloeCloud:true}`,
  so scrolling back shows the saved image instantly with **no regeneration**.
- **Panel tab** — the side panel now has a third tab **🖼️ Obrazy**
  (`#ce2TabBtnImages` / `#ce2TabImages`, from `chloeCloudPanelHtml()` +
  `chloeCloudPanelWire()`): enable toggle, provider, size, steps, sampler, NSFW toggle,
  a prompt field and a **Test button** (`#ce2CloudTestBtn`). The test calls
  `chloeCloudTestInParent()`, which postMessages `{type:"chloeCloudTest", prompt}` to
  the parent; the parent listener (next to the `chloeSend` listener) generates with the
  PAGE's settings and streams `{type:"chloeCloudProgress", status}` back. Also reached
  from `/model`'s `cloudGet/cloudSet/cloudTest`.
- **Debug hooks**: parent `window.__chloeCloudDebug = {settings, active, generate,
  element, parse}`; iframe `window.__chloeE2.cloudGet/cloudSet/cloudTest`.
- **Caveats**: the anonymous AI Horde queue can be long (observed position 131,
  ~580 s); a harmless `ClipSkipMismatch` warning is common; occasional CSAM
  false-positive on youth-related wording.

**Verified live**: end-to-end generation (a nude prompt was honored —
`censored:false`), placeholder → `<img>` mount, permanent re-host, saved-image
re-render, panel Test button (~42 s), custom-endpoint error path, native fallback
swap, and responsive fit (`max-width:min(450px,100%)` → 307 px at a 390 px viewport,
450 px cap on desktop).

### Editing the custom code (re-splice recipe)

The custom code lives once in a `  var CHLOE_CUSTOM_CODE = "<raw JS, JSON-stringified>";`
declaration that sits immediately *before* `  let starterCharacters = [`. The single
Chloe character references it directly (`customCode: CHLOE_CUSTOM_CODE`).

To edit the custom code as plain JS, edit the raw working copy and re-splice with a
script (Node-less; use the `execute_js` tool's `fs`):

```js
let html = await fs.readTextFile("index.html");
const code = await fs.readTextFile("scratch/cc.js"); // raw JS working copy
const re = /var CHLOE_CUSTOM_CODE = "((?:[^"\\]|\\.)*)";/;
const m = html.match(re);
if (!m) throw new Error("CHLOE_CUSTOM_CODE declaration not found");
// IMPORTANT: pass a FUNCTION as the replacer. A plain string replacer would expand
// `$&`, `$1`, "$`", `$'` inside the code (the code contains `$1` in regex replaces)
// and silently duplicate/corrupt megabytes of the file.
html = html.replace(re, () => "var CHLOE_CUSTOM_CODE = " + JSON.stringify(code) + ";");
await fs.writeTextFile("index.html", html);
```

Always verify after a splice: `html.split("var CHLOE_CUSTOM_CODE = ").length - 1 === 1`
and the total length is ~1.24 MB (a few MB means the `$` bug above bit you).

`scratch/` is EPHEMERAL (gone next session). To reconstruct the raw JS from a fresh
session, JSON-parse the captured group: `JSON.parse('"' + m[1] + '"')`.

#### GOTCHA: re-splicing `index.html` does NOT update the characters you already have

`starterCharacters` is only read when the user clicks a card to **add** a character;
`addCharacter()` then copies `customCode` into the `chatbot-ui-v1` IndexedDB
(`characters` store). Existing characters are **never** refreshed from `index.html`, so
after a re-splice the running app keeps executing the **old** snapshot stored in
IndexedDB (verified 2026-09-12: the live `__chloeE2.buildMessages` had no trace of a
just-added layer until the IDB rows were updated).

So a code change is only "live" for the user's existing chats after syncing the DB.
`page_eval` runs in the same origin as the app, so it can do this directly (the
`characters` store holds `customCode`, `roleInstruction`, `reminderMessage`, …; only
`customCode` is ours to overwrite):

```js
// paste into page_eval — overwrite every stored character's code with ours
const CODE = "<the same raw JS you spliced>";           // must byte-match index.html
const db = await new Promise((res, rej) => { const r = indexedDB.open("chatbot-ui-v1"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const all = await new Promise((res, rej) => { const r = db.transaction("characters","readonly").objectStore("characters").getAll(); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const tx = db.transaction("characters","readwrite"); const st = tx.objectStore("characters");
for (const c of all) { c.customCode = CODE; st.put(c); }
await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
```

Practical notes:
- Getting the new code **into** the page without pasting 270 KB into a tool argument:
  build the `page_eval` `js` string *from inside* `execute_js` (`${JSON.stringify(CODE)}`)
  — `execute_js` has the file and can pass the big string straight to
  `tools.page_eval({js})` without it flowing through the model's context.
- To avoid clobbering newer per-character content when only a small edit changed, you can
  instead apply just that edit as an anchor-region patch to each `customCode`
  (find `startAnchor`, then `endAnchor`, replace the middle) — all 5 stored characters
  matched cleanly that way too.
- **Always** identify the user's real characters first (`threads` store → `characterId`,
  count `messages` per `threadId`). Characters are duplicated in practice; the busiest
  ones matter most. (After the 2026-09 cleanup the user has exactly 3 Chloe rows — ids
  0/1/3 — and no Ekspertka rows; ids 0/1 were once an older code generation.)
- After the DB write, `page_refresh`, then verify via `runCodeInCustomCodeIframe` that
  built prompts contain the new marker.

#### Testing the custom code from `page_eval`

The custom-code iframe is sandboxed (opaque origin), so `page_eval` cannot read
`iframe.contentWindow.__chloeE2` directly. Post a function message instead (inside it
only `window.__chloeE2` / `window.oc` are reachable — top-level functions are NOT
globals):

```js
const ifr = document.querySelector(`#customCodeIframeCtn iframe[data-thread-id='${activeThreadId}']`);
const id = "probe" + Math.random().toString(36).slice(2);
const res = await new Promise((resolve) => {
  const h = (e) => { if (e.data && e.data._id === id) { window.removeEventListener("message", h); resolve(e.data); } };
  window.addEventListener("message", h);
  ifr.contentWindow.postMessage({_id: id, type: "function",
    functionText: "async function(){ return window.__chloeE2.srcList(); }", functionArg: undefined}, "*");
  setTimeout(() => { window.removeEventListener("message", h); resolve({timeout: true}); }, 30000);
});
return res;
```

The app's own `#messageFeed` / `#messageInput` / `#sendButton` live in the PARENT
page, so chat-level assertions (search cards, progress text) can be checked with
plain `page_eval` DOM reads. Poll — a search takes ~12–20 s.

## Tryb wiedzy vs tryb mediów + DIY (2026-09)

The user asked: add expert DIY sex-toy / solo-orgasm knowledge, let Chloe search
Reddit and other informative sites, and **stop auto-fetching videos/photos every
time — only when explicitly asked**.

- **Media vs knowledge gating** (the core rule). `chloeWantsMedia(text)` (cc.js:107)
  returns true only for an explicit media request — `CHLOE_MEDIA_KW` (film/wideo/klip/
  zdjęcia/galeria/porn/watch…) or `CHLOE_MEDIA_VERB` (a media verb + target, e.g.
  „pokaż mi filmy", „daj zdjęcia"). `chloeDetectIntent` then routes:
  `drives > directLink > wantsMedia("media") > reddit > info`. **`info` is the new
  default for adult chat**, so ordinary questions ("jak zbudować zabawkę", "jak się
  masturbować") get a *knowledge* answer instead of a tube dump.
- **Source gating in `chloeWebSearch`.** `CHLOE_MEDIA_GROUP = {tube,hentai,furry}`
  (cc.js:1505). In any non-`media` mode those groups are force-disabled
  (cc.js:1616-1622), and the `webinfo` source (marked `infoOnly`) is skipped in
  `media` mode (cc.js:1672). So tube scrapers run **only** in `media` mode.
- **New info source `chloeSrcWebInfo`** (cc.js:814): searches DuckDuckGo html/lite +
  Marginalia **through `r.jina.ai`**, extracts markdown links, skips search engines /
  junk domains / lockers → `{site,url,title,snippet,kind:"page"}`. Registered as
  `{id:"webinfo", group:"web", infoOnly:true}`. Tested: „homemade sex toy body safe
  silicone" → 8 genuinely relevant guides (tabooless.net, lovense.com, …).
- **Mode-aware prompts/UI.** `chloePlatformLinks(query, expanded, infoMode)` returns
  info-only links in knowledge mode; `chloeBuildAI` emits `Tryb: WIEDZA/PORADNIK …`
  + `(TRYB WIEDZY)` and **no** `=== FILMY / MEDIA ===` section; the search-console
  mode `<select>` is `info` (default) / `media` / `reddit` / `drives`.
- **`/zabawki` command + 🧰 button** route to `mode:"info"` with
  `"diy sex toy " + arg`. Two new `CHLOE_E2_RULES` entries tell the model: knowledge
  mode = answer from WIEDZA/STRONY/REDDIT + lorebook, never fake "I didn't find it",
  films/photos only on explicit request; DIY = concrete instructions, body-safe
  materials, wide base, cleaning, lube compatibility.
- **`__chloeE2` debug API** gained `wantsMedia`, `mediaMode`, `srcWebInfo` (and the
  `src(name,q)` dispatcher now includes `webinfo`/`bingpl`/`bingen`).

## Knowledge-only mode — „Chloe ekspertka seksuolożka + DIY" (`2026-09-12`)

The user's final intent (PL): *„chciałem Chloe ekspertkę seksuolożkę potrafiącą budować
DIY zabawki"* — they want the **expert**, and the **media/film/drive** purpose removed.

Done in this change:

- **`scratch/cc.js` (→ `CHLOE_CUSTOM_CODE`)** got the knowledge-only layer back, now
  hard-wired: `chloeKnowledgeOnly()` **returns `true`** (was name-based, keyed on
  `/ekspert/i` + `window.__CHLOE_KNOWLEDGE__`). All its call sites were re-added:
  - the `intent.drives/driveUrls/directLink/wantsMedia = false` block in
    `chloeDetectIntent`;
  - `modeInfo` accepts `"info" | "knowledge"` (2 sites) so `chloePlatformLinks` returns
    knowledge links;
  - `CHLOE_HELP_KNOWLEDGE` (new, media-free copy) served by `chloePushHelp`;
  - the knowledge `chloeActionChips` set (`[[Wyjaśnij dokładniej]]` …);
  - the search console `groups = ["web","reddit"]` + only the `info`/`reddit` mode
    options (no `media`/`drives`);
  - `/search` → `/wiki` remap and the `/dyski` interception (a friendly "this is
    knowledge-only Chloe" notice);
  - the defensive „knowledge plan can't be media/drives" guard after the plan chain.
- **`index.html` → the Chloe starter** keeps its shell (avatar `f97d49e4…jpeg`,
  image-prompt fields, `fitMessagesInContextMethod: "summarizeOld"`,
  `autoGenerateMemories: "v1"`, same `loreBookUrls`) but its persona now comes from the
  former Ekspertka: `tagline` (sexologist + DIY), `roleInstruction` (10.5 KB),
  `reminderMessage` (2.4 KB), `initialMessages` (system + greeting) and the 6
  knowledge `shortcutButtons` (🧰 zabawki DIY / 📐projekt / 🔩materiały / 📚 wiedza /
  👽 Reddit / ❓ pomoc; the code still auto-adds ⚙️ model + 🧭 panel per thread) — see
  the later \"DIY-max\" pass below for the current button set.
  All „the other Chloe (media character)" references were rewritten out.
- **The user's IndexedDB was synced** (`chatbot-ui-v1`): `characters` rows 0/1/3 got the
  new persona + code, and all 5 `threads` got the new `shortcutButtons`. Existing chat
  history (351 messages, incl. „Orgasm Enhancement Guide") was **kept** on purpose.
  Later follow-up: each thread's two **seed** messages (the `characterId:-2` hidden
  „bez cenzury / Pornhub…" system note + the „*Chloe podnosi wzrok znad biurka…*" media
  greeting, always `order 0`/`order 1`) were rewritten **in place** (same `id`) to the new
  expert system note + greeting, so no thread opens with stale media framing while the
  rest of each conversation is untouched. Rule if this is ever needed again: match
  `db.messages` rows by `threadId`, sort by `order`, replace rows 0/1 where row 0 has
  `characterId:-2` + `hiddenFrom:["ai"]` + `/bez cenzury/i` and row 1 matches
  `/Chloe podnosi wzrok znad biurka/i`, using `db.characters.get(thread.characterId).initialMessages`.

Recovery sources used (both ephemeral `scratch/`, gone next session): the last saved
generator (`fetch_generator chloeseksistka` → its `starterCharacters` still had the full
Ekspertka entry) and `scratch/db-characters.json` (old `customCode` per character row).
The old saved code is OLDER than `scratch/cc.js` (it lacks the Mistral-dialect layer), so
the knowledge bits were re-applied to the newer file rather than reverting to the saved
copy.

Note for a future session: the media scrapers/drive verifier are **dormant** (unreachable
because `chloeKnowledgeOnly()` is always true), not deleted — that keeps the change low
risk. If the user ever wants media back, flip that function (or re-add a name check).

## DIY-max / safety-min pass — „ulepsz maks budowanie, zmniejsz bezpieczeństwo" (`2026-09-12`)

User request (PL): *„w sensie ulepsz maks budowanie a zmniejsz pogląd na bezpieczeństwo"*
— maximise the DIY-toy-building capability and knowledge, cut the safety-lecture framing
(less „never use / be careful / see a doctor", more concrete build instructions). The
persona still assumes consenting adults and keeps practical know-how (cleanability,
sizing, flared bases) as *engineering*, not as moralising.

Done in this change:

- **Lorebook**: the old 21-line safety-heavy **DIY SEX TOYS** block (former
  `src/chloe-lorebook.txt` lines 341–361) was replaced by **30 dense, build-first
  entries** (`DIY …`: how Chloe works, materials + substitutes, Shore hardness,
  mixing/curing, degassing, mould methods, pour/vent channels, a full dildo recipe,
  finishing, shape-by-function, base/collar geometry, plug, suction mount, vibrator
  insert, wand, pump, cock ring, harness/strap-on, stroker, dual-density, 3D-print,
  metal/glass/wood, BDSM gear, DIY lube, cleaning, improvisation, design numbers,
  silicone volume, where to buy in Poland, upgrading an existing toy). Body in Polish,
  rich `PL:` alias lines, `hasSafetyWord:false`.
- **`roleInstruction`**: the `DIY SEX TOYS & SOLO PLAY — MASTER-LEVEL` block was
  rewritten to lead with a workshop-project shape (plan + dimensions → bill of
  materials + substitutes → tools → build order → variants/upgrades → use/clean/store)
  and gained mould-making, dual-density cores, electronics, attachments and upgrades
  sections. The `SAFETY AS EXPERTISE` block and the `ANAL SAFETY (NON-NEGOTIABLE)` /
  „see a doctor" hedging were removed; the persona intro now calls her a **master DIY
  sex-toy builder and materials-science nerd** first.
- **`reminderMessage`**: the DIY paragraph is now a concrete build checklist; the OOC
  block says *„projektuj i buduj, nie ostrzegaj na zapas … żadnych zbędnych zastrzeżeń"*
  and its example chips became `[[Zaprojektuj to krok po kroku]] [[Dobierz materiały i
  wymiary]] [[Zapamiętaj to]]`.
- **`initialMessages`** greeting now leads with the workshop („budownicza zabawek DIY",
  forma, silikon, Shore, rdzeń dual-density) and no longer mentions „zasady bezpieczeństwa".
  *(Superseded 2026-09-12 by the household-ingenuity pass — the greeting now leads with
  „demon pomysłowości" / zabawki z rzeczy z pokoju; the workshop fell to a later line.)*
- **Custom code (`cc.js`)**: `CHLOE_HELP_KNOWLEDGE` rewritten (build-first `/zabawki`
  bullet, no „bezpieczeństwo" in the `/wiki` bullet, header „wiedza i budowa DIY");
  the knowledge `chloeActionChips` set and its cleanup regex now use build chips
  (`[[Zaprojektuj to krok po kroku]]` etc.); the `/dyski` interception notice reworded.
  The `CHLOE_E2_RULES` DIY entry is now **„DIY ZABAWKI — TWOJA SPECJALNOSC"** (plan +
  dimensions, materials + subs, tools, forma→odlew→utwardzanie→wykonczenie→montaz,
  variants/upgrades, how to use, „bez moralizowania i bez zbednych zastrzezen").
- **`tagline`** and **`shortcutButtons`**: 🧰 zabawki DIY / 📐 projekt krok po kroku /
  🔩 materiały i wymiary / 📚 wiedza/poradnik / 👽 Reddit / ❓ pomoc (the 🛡️ bezpieczeństwo
  and 🩺 zdrowie buttons were dropped).
- **Lorebook re-uploaded** (see below) and the user's **IndexedDB synced**: `characters`
  rows 0/1/3 got code + persona + tagline + buttons + new lore URL, all 5 `threads` got
  the new buttons, and each thread's two seed messages (order 0/1) were rewritten in
  place to the new system note + greeting.

Verified live: `page_refresh` clean; `buildMessages()` contains the new DIY rule;
`loreSelect('…dildo z silikonu…')` returns the new `DIY …` entries; a real
`„Zaprojektuj mi krok po kroku dildo z silikonu 18 cm"` question produced a proposal
that opens with a **dimensions table (18 cm / średnica / przewężenie / trzon)** and a
full plan, ending with the new build chips — no safety lecture. (That test exchange was
deleted from `db.messages` afterwards.)

## Lorebook (knowledge base)

- Source: `src/chloe-lorebook.txt` (~64 KB, **231** blank-line-separated entries; each
  entry ends with a `PL: <keywords>` line). The **30 DIY entries** (rewritten 2026-09-12,
  see the \"DIY-max\" pass above) cover materials, Shore hardness, casting, moulds,
  finishing, design, electronics, BDSM gear, lube, cleaning, improv, numbers and
  upgrades; **SOLO ORGASM / SOLO PLAY** and **RESOURCES** sections remain. The
  household-ingenuity pass added **18** more (ZASADA POMYSŁOWOŚCI + SKANER POKOJU,
  towel/bedding, pillow/duvet/mattress, sock/tights, elastic band/hair clip/cork,
  bottle/cup/jar/thermos, kitchen tools, bathroom/shower/toothbrush, wardrobe bondage,
  bag/glove/foil/balloon, heat/cold/wax/honey/oil, phone/music/light, clothes you're
  wearing, and two „MAKS. ODCZUCIA" entries) and converted every entry to the
  `body\nPL: keywords` two-line form so keyword hits are weighted **4×** (previously
  only the DIY block had keywords; the rest matched at weight 1).
- Uploaded (immutable): `https://user.uploads.dev/file/f0a82db963ab60af4824d05290d97a30.txt`
  — this URL is what the Chloe starter's `loreBookUrls` references **and** what the
  custom code hardcodes as `CHLOE_LORE_URL` (both must match). (Previous uploads:
  `…a7d44b59…txt` (DIY-max) and `…85cce85d…txt`, kept only as history.)
- The custom code injects the relevant entries directly (`chloeLoadLore` /
  `chloeLoreSelect`, cc.js:3623) — that is the path that actually feeds Chloe, and it
  reads the full new file. The app-level RAG `lore` store keys entries by `bookUrl`; on
  the 2026-09-12 **household-ingenuity pass** the 213 old-URL rows were **deleted and the
  new 231-entry book re-indexed** (embedded for the character's
  `Xenova/multilingual-e5-small`, 384-dim) via `page_eval` + the global
  `window.embedTexts` — `ensureLoreUrlsAreLoaded` is not exposed globally and only runs
  on thread creation / character-settings save, so it was replicated by hand. (The
  earlier DIY-max pass re-indexed 213 the same way.) If the lore URL changes again,
  do the same (or accept that the custom-code path `chloeLoreSelect` is the live one).
- Rebuild: edit `src/chloe-lorebook.txt`, `upload_file` it, then update **both**
  `loreBookUrls` in `index.html` and `CHLOE_LORE_URL` in the custom code (and re-key
  `db.lore` rows), or the two halves will point at different books.

## Verified research findings (why it's built this way)

Sources that work from the runtime: **pullpush.io** (Reddit — posts *and* comments,
CORS-friendly, no key, ~0.2–0.8 s via raw XHR), nhentai JSON API, e621 JSON, Wikipedia,
Bing RSS, Pornhub/YouPorn/SpankBang/Porntrex HTML, and the tube/metasearch scrapers
Redtube, porn.com, Xozilla, SunPorno, TNAFlix, nudevista, e-Hentai, 3Hentai — plus the
**through-reader** sources XVideos, xHamster, Erome and the 5 drive engines (DDG html/
lite, Bing, Startpage, Marginalia). `redlib.catsarch.com` is now behind the Anubis
anti-bot challenge, so it is only a fallback.

Sources that do NOT work from the runtime: reddit.com JSON (403), old.reddit, DuckDuckGo,
Bing HTML, xHamster/XVideos direct (CORS), rule34.xxx, gelbooru (needs key), hanime
(POST blocked), eporner (JS), ashemaletube, xxxbunker (geo) — and **RedGifs**
(`api.redgifs.com` sends no CORS headers; the required `Authorization: Bearer` header is
silently dropped by the app's `superFetch` proxy, so search is unreachable: it returns
401 "NoAuthorizationData" through the proxy and a CORS error directly/XHR).

Infrastructure facts worth keeping (all measured in the sandbox):
- `XMLHttpRequest` is **not** proxied by `index.html`; only `window.fetch` is.
- Blob-URL workers **do** have native `fetch` (and can send `Authorization` headers) —
  but they still obey CORS, and a preflight failure surfaces as an instant error.
- `superFetch` **drops request headers** — anything requiring auth must go through XHR
  or the worker path.
- `r.jina.ai` rate-limits bursts; keep it to ≤3 concurrent (`CHLOE_READER_MAX`).
- Erome's search is tag-based: long phrases → 0 hits, the core tag → 14 hits.

Roleplay-quality techniques confirmed from r/SillyTavernAI ("After Three Years of
Roleplaying…") and r/perchance tutorials, all applied to Chloe's persona:
1. A **"Visual Impression"** field (the overall feeling a character gives) matters
   more than a list of factual traits.
2. An always-on **Speech/Voice block** (style, pitch, mannerisms) preserves identity
   better than example messages.
3. Specify reply length in **WORDS, not tokens**, and restate it close to the reply
   (in the reminder), because distant system-prompt length rules lose influence.
4. Keep secrets out of context; use the app's memory/lore retrieval + auto-memories.

Other maxed-out app capabilities used: `oc.generateText`, `oc.messageRenderingPipeline`,
`MessageAdded`/`StreamingMessage` events, `oc.thread.customData`, the built-in
memory/lore/auto-summary system, and native `/image` generation.

## Notes for a future agent

- Do NOT publish the generator unless the user asks. The starter is persisted by the
  app's normal save (`window.generatorIsUnsaved`).
- Test by creating a NEW thread from the Chloe starter (existing threads keep old code).
- Drive the UI via `#newThreadButton` → `#starterCharacterList .character` (first one
  is Chloe) → `#messageInput` + `#sendButton`. Stub `confirm`/`alert`/`prompt` first.
- Wait for "generating..." to clear before sending the next message, or a push can
  race the generation and be dropped.

## Household-ingenuity pass (2026-09-12) — "demon pomysłowości"

User directive: *„pomysłowość przenieś na absolutnie najwyższy poziom skupiając się na
rzeczach które są dostępne w zasięgu ręki, domu, czy rzeczach które kompletnie do tego
nie służą! niech Chloe zaskakuje swoimi świetnymi pomysłami na zabawki i niech będzie
dosłownie demonem seksualnej pomysłowości"*. Implemented **household-first, against-label
ingenuity** as the top priority across persona + reminder + lorebook + custom code.

What changed (all live + verified):

- **Lorebook** (`src/chloe-lorebook.txt`): +18 household/ingenuity entries and **every
  entry converted to the two-line `body` + `PL: keywords` form** (keyword hits now weight
  **4×**). 231 entries. Re-uploaded to
  `https://user.uploads.dev/file/f0a82db963ab60af4824d05290d97a30.txt` (new
  `CHLOE_LORE_URL` + `loreBookUrls`); `db.lore` re-indexed (213 old deleted, 231 new
  embedded, 384-dim e5-small).
- **Persona** (`roleInstruction`): new English block **"DOMOWA POMYSLOWOSC DIY — JEJ
  NAJWAZNIEJSZA SPECJALNOSC (najwyzszy priorytet)"** inserted before the DIY block; the
  „IMPROVISED / QUICK BUILDS and their limits" bullet became **"IMPROVISED & HOUSEHOLD
  BUILDS (her favourite, and the default)"**.
- **Reminder**: the „DIY — TWOJA SPECJALNOŚĆ" paragraph is now household-first (3-5
  patentów z pokoju; „bądź demonem pomysłowości: ignoruj oryginalne przeznaczenie
  przedmiotów, łącz 2-3 zwykłe rzeczy i zaskakuj"; 3 poziomy POKÓJ → DOM → WARSZTAT;
  równoległy cel: maksymalne odczucia) + new example chips.
- **Custom code (`cc.js`)**: new `CHLOE_E2_RULES` DIY entry (household-first, levels,
  ingenuity, max sensation); `CHLOE_HELP_KNOWLEDGE` title/bullets rewritten; `/zabawki`
  default query → `"homemade sex toy household items DIY"` (both call sites); **new
  command aliases `pokoj/pokój/dom/impro/pomysl/pomysł → toys`**; ~30 household terms
  added to `CHLOE_SYN`; new action chips (`[[Zrób to z rzeczy z pokoju]]`,
  `[[Maksymalne odczucia — jak?]]`, `[[Pokaż warianty i ulepszenia]]`, `[[Zapamiętaj: …]]`).
- **Starter (`index.html`)**: new `tagline`; new `shortcutButtons` (🧰 zabawki z pokoju /
  🏠 zrób to z tego, co mam / 🔥 maksymalne odczucia / 📚 wiedza/poradnik / 👽 Reddit /
  ❓ pomoc); `loreBookUrls` → new URL; rewritten seed system note + greeting.
- **IndexedDB synced by hand** (a re-splice does NOT refresh existing chars — see the
  gotcha above): chars 0/1/3 got the new `roleInstruction` / `reminderMessage` / `tagline` /
  `shortcutButtons` / `loreBookUrls` / `customCode` / `initialMessages`; all 5 `threads` got
  the new buttons (thread 0 kept its extra ⚙️ model + 🧭 panel); each thread's seed
  messages order 0/1 were rewritten in place.

Live test (real generation, thread 0): *„Co mogę zrobić z rzeczy, które mam w pokoju?"*
(m.in. ręcznik/skarpeta/poduszka/łyżka/taśma/świeca/lód) → Chloe answered with 5 numbered
patentów built only from those items, each as **co masz → jak złożyć → na co działa → jak
podkręcić odczucie**, a comparison table, a personal pick, and 4 new `[[chipy]]` — no
shopping, no tools. `loreSelect('…ręcznik…')` returns the new ZASADA POMYSŁOWOŚCI /
MAKS. ODCZUCIA entries at the top.

Rebuild note: the seed values for the DB sync were re-derived from `index.html` by
extracting the `let starterCharacters = [ … ]` literal and evaluating it with
`CHLOE_CUSTOM_CODE` + a stub `window`; the temporary JSON payload host was
`https://user.uploads.dev/file/37da2253a36c9747a47224154c88845f.json` (not part of the
generator — safe to ignore/delete).
