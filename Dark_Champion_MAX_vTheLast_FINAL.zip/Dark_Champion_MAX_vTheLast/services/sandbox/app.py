import subprocess, tempfile
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="Dark Code Sandbox")
class Run(BaseModel):
    code: str = Field(max_length=50000)
    timeout: int = Field(default=10, ge=1, le=30)

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/execute")
def execute(req: Run):
    with tempfile.TemporaryDirectory(dir="/tmp") as d:
        try:
            p = subprocess.run(
                ["python","-I","-c",req.code],
                cwd=d, capture_output=True, text=True,
                timeout=req.timeout, env={"PATH":"/usr/local/bin:/usr/bin:/bin"},
            )
            return {"exit_code":p.returncode,"stdout":p.stdout[-20000:],"stderr":p.stderr[-20000:]}
        except subprocess.TimeoutExpired as e:
            return {"exit_code":124,"stdout":(e.stdout or "")[-20000:],"stderr":"Execution timed out"}
