# MODELE LLM — research pod E2 (własny model Chloe przez API)

Cel: wybrać model, którego Chloe użyje w trybie **E2** (własny klucz API), optymalny
dla: (1) nieocenzurowane wyszukiwanie i wiedza NSFW, (2) język polski, (3) prostota
wdrożenia. Data researchu: 2026-09-12.

## Metoda

- **RP-Bench / PlotPoints** — otwarty benchmark modeli do ról, sprawdzany
  **wyłącznie przez OpenRouter** (celowo, by usunąć zmienną providera). Zawiera:
  arena głosowana przez ludzi (single-message ELO oraz multi-turn ELO na pełnych
  dialogach), ocenę sędziowską (Sonnet + DeepSeek R1), rundę NSFW (40 modeli × 20
  seedów × 12 tur), **refusal %**, koszt i latencję. Źródła:
  `github.com/LeviTheWeasel/rp-benchmark`, `plotlightstudios.com/plotpoints`,
  `arena.l3vi4th4n.ai`.
- **EuroEval — Polish leaderboard** (~300 modeli, zadania językowe PL:
  klasyfikacja, NER, QA, streszczanie, wiedza). Niższy „rank score” = lepiej.
- **OpenRouter Models API** — ceny, kontekst, flaga moderacji providera
  (`is_moderated`), limity.
- Reddit: r/SillyTavernAI, r/LocalLLaMA, r/NSFWAI (przez redlib).

## Wniosek 1 (kluczowy, kontrintuicyjny): klasyczne „uncensored RP finetune'y” są przestarzałe

W rundzie NSFW (Round 3) modele reklamowane jako _uncensored / erotyczne_ wylądowały
**na samym końcu** stawki 40 modeli (craft wg sędziego Sonnet):

| # | Model (finetune) | Craft |
|---|---|---|
| 34 | Lunaris 8B | 3.83 |
| 35 | Cydonia 24B | 3.65 |
| 36 | Magnum v4 72B | 3.23 |
| 37 | UnslopNemo 12B | 2.61 |
| 38 | Skyfall 36B | 2.52 |
| 39 | Rocinante 12B | 2.49 |
| 40 | **Euryale L3.3 70B** | **2.12** |

Czołówka (craft 4.5–4.65): Claude Opus 4.8/4.6/4.7, **DeepSeek V4 Pro**, GPT-5.5,
Owl Alpha, MiMo 2.5 Pro, MiniMax M3. Sędziowie karzą finetune'y za powtórzenia,
purple prose i łamanie agencji gracza.

**Ale** „willingness” (nieodmawianie) to osobna oś: finetune'y mają **0% odmów**,
natomiast część modeli frontier ma 5–10%. Czyli „nie odmawia” ≠ „dobrze pisze”.
Dobra wiadomość: najlepsze modele open (DeepSeek V4 Pro/Flash) mają **jednocześnie
0% odmów i wysoki craft**.

## Wniosek 2: co realnie lubi społeczność (głosy ludzi)

**Single-message ELO** (engagement; ~2 000 głosów): #1 Gemma 4 26B, #2 **Mistral
Small Creative** (NSFW 67% wygranych!), #3 Gemini 2.5 Flash.

**Multi-turn ELO** (całe dialogi): #1 **DeepSeek V4 Pro**, #2 Claude Opus 4.6,
#3 Gemini 3.1 Flash Lite, #4 GPT-4.1, #6 Mistral Small Creative.

**„Kto najlepszy w NSFW” wg ludzi:** Mistral Small Creative **67%**, Grok 4.1 52%,
Gemini 54%. Najsłabsi w NSFW: DeepSeek 30%, Llama 34%, MiniMax 34% — czyli DeepSeek
jest _chętny_, ale wg ludzi pisze mniej „spicy”.

## Wniosek 3: polski (EuroEval — niższy = lepiej)

| Rank score | Model |
|---|---|
| 1.59 | Qwen3.8-27B / Qwen3.6-27B (najlepszy open) |
| 1.76 | Qwen3.5-35B-A3B |
| **1.85** | **Gemma 4 31B-it** |
| 1.87 | gpt-oss-120b |
| 2.01 | Mistral Small 3.1 24B |
| 2.05 | **Gemma 4 26B A4B-it** |
| 2.18 | GLM 4.7 Flash |

Wniosek: **Qwen i Gemma są najlepsze w polskim**, Mistral tuż za nimi (bardzo
dobry), DeepSeek nie pojawił się w tym zestawieniu (niepewne, trzeba przetestować).

## Wniosek 4: prędkość i koszt

- **Mistral Small Creative** — najszybszy realnie: 192 tok/s, **230 ms TTFT**,
  mediana 2.8 s, ~$0.0003/zapytanie.
- **DeepSeek V4 Flash** — #1 stosunek jakość/koszt (~$0.18/1M, mediana 5.3 s).
- **Gemini 3.1 Flash Lite** — najszybszy z wysoką jakością (2.3 s, Likert 4.30).
- Modele „reasoning” (GLM 4.7: **mediana 36 s**!; Kimi: 45–60 s) — za wolne do
  czatu na żywo; palą też tokeny myślenia, za które się płaci.

## Rekomendacja — shortlista (wszystkie OpenRouter, OpenAI-compatible, `mod:false`)

| # | OpenRouter ID | $in/$out za Mtok | Kontekst | Kiedy brać |
|---|---|---|---|---|
| **1** | `mistralai/mistral-small-2603` (Mistral Small Creative / „Mistral SC”) | $0.15 / $0.60 | 262k | **Najlepszy ogólny do NSFW**: #1 wg ludzi w NSFW (67%), #2 engagement, #6 multi-turn, **najszybszy**, tani, dobry polski (~2.0), brak moderacji. Minus: 15.9% naruszeń agencji (czasem pisze za użytkownika) — łagodzone promptem. |
| **2** | `google/gemma-4-26b-a4b-it` | $0.09 / $0.30 | 262k | **Najlepszy polski wśród NSFW-lubianych + #1 engagement**: polski 2.05, zbalansowany SFW/NSFW, tani, ma endpoint `:free` do testów. Minus: słabsza niezawodność wieloturowej (7/12). |
| 2b | `google/gemma-4-31b-it` | $0.09 / $0.34 | 262k | Jeszcze lepszy polski (1.85); uwaga: maxOut 16k, bardziej „instruct” (mniej swobodny). |
| **3** | `qwen/qwen3.8-27b` | $0.21 / $2.55 | 1M | **Najlepszy polski w ogóle** (1.59) + dobre rozumienie intencji/zadań. Minus: drogi output, wg społeczności mniej „NSFW-spicy”. |
| **4** | `deepseek/deepseek-v4-flash` (lub `-0731`) | $0.047 / $0.095 | 1M+ | **Najlepszy stosunek cena/jakość**: 0% odmów, craft 4.38, najtańszy, szybki. Minus: słabszy „vibe” NSFW wg ludzi, polski niepotwierdzony. |
| 5 | `deepseek/deepseek-v4-pro` | $1.60 / $3.20 | 1M | Opcja „premium”: #1 multi-turn ludzi, NSFW craft 4.62 przy 0% odmów. Wolny (~17 s). |
| 6 | `nousresearch/hermes-3-llama-3.1-70b` | $0.70 / $0.70 | 131k | Klasyczny nieocenzurowany finetune RP (Llama 3.1, 0% odmów) — dodany na życzenie. Wg benchmarku 2026 takie finetune'y wypadają słabiej na „craft" (powtórzenia, purple prose), ale są niezawodne i mają bardzo duży kontekst. Siostrzane: `…-405b` ($1/$1), `nousresearch/hermes-4-405b` ($1/$3). |
| — | `google/gemma-4-26b-a4b-it:free`, `nvidia/nemotron-3-super-120b-a12b:free`, `nex-agi/nex-n2.5-pro:free` | $0 | — | **Darmowe testy** (rate-limited) — do sprawdzenia polskiego bez płacenia. |

> **Sprostowanie (2026-09-12, weryfikacja na HF):** `mistralai/mistral-small-2603`
> to **Mistral Small 4**, dokładnie `mistralai/Mistral-Small-4-119B-2603` — **119B MoE**
> (36 warstw, top-4 + 1 shared expert, MLA/`kv_lora_rank`), a **nie 24B**.
> Na pojedynczym L4 (24 GB) się **nie zmieści** (INT4 ≈ 68 GB); potrzebuje 2×L40S
> (96 GB, $3.60/h) albo H100. Do lokalnego GPU patrz rozdział „NVIDIA L4" niżej.

**Mój wybór domyślny: `mistralai/mistral-small-2603`** (najlepszy kompromis
NSFW + szybkość + koszt + polski), z `google/gemma-4-26b-a4b-it` jako alternatywą
gdy polski jest priorytetem.

## Czego NIE brać

- Modele z moderacją providera (`mod:true`): Anthropic Claude, OpenAI, Amazon Nova,
  Cohere — odmówią/zetną NSFW na poziomie API.
- Klasyczne uncensored finetune'y (Euryale, Magnum, Cydonia, Rocinante, Skyfall,
  UnslopNemo, Lunaris) — wg benchmarku 2026 przestarzałe.
- Ciężkie modele „reasoning” (GLM 4.7, GLM 5.x, Kimi) — za wolne do czatu.

## Najprostsze wdrożenie

**OpenRouter**: jeden klucz, jeden endpoint OpenAI-compatible
(`POST https://openrouter.ai/api/v1/chat/completions`), wszystkie modele za jednym
API, przyjazny CORS, kredyty prepaid (bez subskrypcji), darmowe endpointy do testów.
Alternatywy (Venice.ai, Featherless, Arli, Infermatic, NanoGPT, DreamGen) też są
OpenAI-compatible, ale OpenRouter ma największy wybór i najlepszą stabilność.

Uwaga: `fetch` w custom code idzie przez **proxy Perchance** → klucz przechodzi przez
proxy. Opcja „direct” (z pominięciem proxy, bezpośrednio do OpenRouter) prawdopodobnie
działa (OpenRouter wysyła `Access-Control-Allow-Origin: *`) i daje streaming SSE — do
potwierdzenia przy implementacji.

## Plan wdrożenia E2

1. Panel ustawień: provider (OpenRouter), klucz API, model (presety powyżej + pole
   własne), temperatura, max tokenów. Klucz trzymany **lokalnie** (localStorage
   iframe'a / `customData`), nigdy w kodzie generatora.
2. Przechwycenie tury w `MessageAdded` (user → `expectsReply=false`), budowa promptu,
   POST, wstawienie odpowiedzi.
3. Domyślnie włączony `mistralai/mistral-small-2603`; **natychmiastowy fallback** do
   natywnego modelu Perchance przy braku klucza / błędzie / 429.
4. Tryb opcjonalny (przełącznik „model: Perchance / własny”), żeby nie psuć natywnej
   pamięci i lorebooka, gdy klucza brak.

## Źródła

- RP-Bench: https://github.com/LeviTheWeasel/rp-benchmark
- PlotPoints: https://plotlightstudios.com/plotpoints · https://arena.l3vi4th4n.ai
- EuroEval Polish: https://euroeval.com/leaderboards/polish
- OpenRouter models: https://openrouter.ai/api/v1/models

---

# Darmowe opcje (research 2026-09-12, na pytanie: „czy jest model za darmo?")

## A. OpenRouter — warianty `:free` (naprawdę $0/token)

- Wymaga tylko **darmowego konta + klucza** (bez karty).
- Limity platformowe (potwierdzone w `openrouter.ai/docs/api-reference/limits.md`,
  stałe `FREE_MODEL_*`): **20 zapytań/min**; **50 zapytań/dzień** przy doładowaniach
  < $10; **1000 zapytań/dzień** po jednorazowym doładowaniu ≥ $10
  (`FREE_MODEL_CREDITS_THRESHOLD = 10`). Limity liczone **globalnie** — kolejne
  konta/klucze nic nie dają.
- Sprawdzone przez API: 445 modeli, 22 z `pricing = 0/0`, 19 z sufiksem `:free`.
  Aktualnie dostępne: `google/gemma-4-26b-a4b-it:free`, `google/gemma-4-31b-it:free`,
  `nvidia/nemotron-3-ultra-550b-a55b:free` (550B!), `nvidia/nemotron-3-super-120b-a12b:free`,
  `nvidia/nemotron-3.5-lightning:free`, `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free`,
  `nex-agi/nex-n2.5-pro:free`, `nex-agi/nex-n2.5-mini:free`,
  `inclusionai/ling-3.0-flash*:free`, `thinkingmachines/inkling:free`,
  `poolside/laguna-s-2.1:free`, `dots-studio/dots-3-note-preview:free`,
  `liquid/lfm-2.5-2.6b:free`, `openrouter/free`.
- **Uwaga:** wśród darmowych **nie ma** klasycznych finetune'ów „uncensored" — to
  głównie modele instruct (Gemma / Nemotron / Ling / Nex), wszystkie
  `is_moderated:false`. Do pełnego NSFW mogą częściowo odmawiać, ale nie ma
  moderacji na poziomie providera. (`nvidia/nemotron-3.5-content-safety:free` to
  klasyfikator bezpieczeństwa — nie do czatu.)

## B. Hugging Face — co realnie daje PRO

- **PRO = $2.00/mies. kredytów** inferencyjnych (docs „Pricing and Billing";
  NIE $9 jak dawniej; darmowe konto = $0.10). Kredyty są ogólne: Inference
  Providers, Inference Endpoints, GPU Spaces (także ZeroGPU ponad kwotę), Jobs.
  Czyli HF to **nie jest darmowe** — to ok. $2/mies.
- Router HF jest **OpenAI-compatible**:
  `POST https://router.huggingface.co/v1/chat/completions`,
  `Authorization: Bearer hf_...`, model z sufiksem wyboru providera:
  `Qwen/Qwen3.8-27B:featherless-ai`, `...:cheapest`, `...:fastest`, `...:preferred`.
- Sprawdzone: router ma 143 modele, **0 z `is_free:true`** — brak darmowych.
- **Kluczowe dla NSFW:** provider **`featherless-ai`** (69 modeli, `status:live`)
  hostuje znane nieocenzurowane finetune'y: `Sao10K/L3-8B-Stheno-v3.2`,
  `Sao10K/L3-8B-Lunaris-v1`, `NousResearch/Hermes-3-Llama-3.1-70B` — i nie moderuje.
  To najlepsza ścieżka „NSFW na HF" (za kredyty PRO).
- HF Content Policy **nie zakazuje** konsensualnych treści dla dorosłych — zakazuje
  tylko: małoletni, nękanie/poniżanie, treści bez zgody. NSFW to szara, ale
  dozwolona strefa (sam Hosting modeli na HF jest znany z NSFW modeli).

## C. Własny HF Space (najbliżej „za darmo bez limitów")

- Darmowy **CPU Space** (2 vCPU / 16 GB) może serwować mały model GGUF przez
  `llama.cpp` z endpointem OpenAI-compatible (`/v1/chat/completions`) pod
  `https://<user>-<space>.hf.space`. Koszt $0, model dowolny (też uncensored).
  Minusy: wolno (~kilka tok/s) i Space zasypia po 48 h bezczynności.
- **ZeroGPU (PRO)** działa tylko dla funkcji **Gradio** i ma kwoty — **nie** daje
  stałego endpointu OpenAI-compatible. Stały GPU Space = płatny za godzinę.

## D. Lokalnie w przeglądarce (E3)

- WebGPU / transformers.js: $0, bez konta, bez limitów, prywatnie; wolno i ciężko
  (na telefonie odpada). Patrz `PLAN.md` E3.

## E. Odpadają (darmowe, ale moderowane → odmówią NSFW)

- Google AI Studio / Gemini free tier, Groq free, Cerebras free, Cloudflare
  Workers AI — wszystkie mają moderację treści.

## Wniosek

- „Za darmo **i** nieocenzurowane" jednocześnie w gotowym API praktycznie nie
  istnieje. Najbliżej: (1) własny CPU Space (darmo, wolno, dowolny model),
  (2) OpenRouter `:free` (50 zapytań/dzień, model instruct), (3) lokalny WebGPU.
- **Najlepszy stosunek cena/nieocenzurowanie:** HF PRO ($2/mies.) → router →
  provider `:featherless-ai` (Stheno / Lunaris / Hermes) — rzędu kilku tysięcy
  krótkich zapytań miesięcznie.
- Żeby którakolwiek z tych opcji działała w Chloe, trzeba najpierw wdrożyć **E2**
  (`PLAN.md`), bo appka domyślnie używa wyłącznie natywnego modelu Perchance.

## Źródła (darmowe opcje)

- OpenRouter limits: https://openrouter.ai/docs/api-reference/limits.md
- OpenRouter models: https://openrouter.ai/api/v1/models (scratch/openrouter-free.json)
- HF pricing/billing: https://huggingface.co/docs/inference-providers/pricing
- HF router (OpenAI-compatible): https://huggingface.co/docs/inference-providers/index
- HF router models: https://router.huggingface.co/v1/models
- HF Content Policy: https://huggingface.co/content-policy
- HF GPU Spaces: https://huggingface.co/docs/hub/spaces-gpus

---

# Własny GPU na HF Spaces — NVIDIA L4 (24 GB) — co się zmieści

Research 2026-09-12. Pytanie: „gdyby postawić Space z NVIDIA L4 i wziąć najlepszy
model, jaki to model?".

## Sprzęt i koszt (docs „Using GPU Spaces")

| GPU | vCPU / RAM | VRAM | Dysk | $/h |
|---|---|---|---|---|
| **1× Nvidia L4** | 8 / 30 GB | **24 GB** | 400 GB | **$0.80** |
| 4× Nvidia L4 | 48 / 186 GB | 96 GB | 3200 GB | $3.80 |
| 1× Nvidia L40S | 8 / 62 GB | 48 GB | 380 GB | $1.80 |
| 4× Nvidia L40S | 48 / 382 GB | 192 GB | 3200 GB | $8.30 |
| T4 small | 4 / 15 GB | 16 GB | 50 GB | $0.40 |

- **Kredyty PRO ($2/mies.) = 2,5 h L4.** Czyli L4 to opcja **płatna**, nie darmowa.
  L4 na okrągło ≈ $576/mies. Ma sens, gdy liczy się prywatność, brak moderacji
  i nielimitowane tokeny — nie przy okazjonalnym czacie.
- L4 = Ada Lovelace: 24 GB GDDR6, ~300 GB/s, obsługuje FP8 (dobre dla vLLM).

## Ile realnie wchodzi na 24 GB (rozmiary zweryfikowane w plikach repo)

Rozmiar = same wagi (VRAM); do tego KV cache. KV/token policzony z `config.json`:
`2 × warstwy × KV-heady × head_dim × 2 B`.

| Model | Wariant na L4 | Wagi | KV/token | Realny kontekst na L4 |
|---|---|---|---|---|
| **Qwen3.8-27B** | GGUF Q4_K_M **15,3 GB** / Q5_K_M 18,4 GB / Q6_K 20,5 GB | 15–20 GB | **256 KB** | 16k spokojnie; 32k z KV w Q8 |
| **TheDrummer Cydonia-24B-v4.3** | GGUF Q4_K_M 13,4 / Q5_K_M **15,6 GB** | 13–16 GB | ~160 KB | 32k+ |
| **TheDrummer Artemis-31B-v1.1** | GGUF Q4_K_M **17,4 GB** / Q5_K_M 20,4 GB | 17–20 GB | ~250 KB | ~16k |
| **Gemma 4 31B** | AWQ INT4 QAT **19,5 GB** (`cyankiwi/gemma-4-31B-it-qat-AWQ-INT4`) | 19,5 GB | **960 KB** ⚠ | tylko ~4–8k (KV zjada VRAM) |
| Qwen3.6-35B-A3B | AWQ-4bit **23,3 GB** (`cyankiwi/...`) | 23,3 GB | 80 KB | **nie mieści się** (brak na KV) |
| Mistral Small 4 (119B) | INT4 ≈ 68 GB | — | — | **nie na L4** (2×L40S+) |
| DeepSeek V4 Flash (290B) | — | — | — | nie na L4 |
| Llama-3.3-70B | Q2_K 26 GB | — | — | odpada (jakość + brak KV) |

## Rekomendacja na L4 (24 GB)

1. **`Qwen3.8-27B` — zwycięzca.** Najlepszy polski wśród modeli open (EuroEval 1.59),
   27B, **tani KV (256 KB/tok → 32k kontekstu przy KV Q8)**, i co najważniejsze —
   są gotowe wersje **nieocenzurowane / abliterated**:
   - `huihui-ai/Huihui-Qwen3.8-27B-abliterated-GGUF` — Q4_K **15,7 GB**,
     UD-DW-Q4_K_M 15,4 GB, Q5/Q6K do 20,9 GB
   - `0bserverx/Qwen3.8-27B-Heretic-Abliterated-Uncensored-GGUF`
   - `HauhauCS/Qwen3.8-27B-Uncensored-HauhauCS-Aggressive-MTP-GGUF`
   - `JonathanColetti/Qwen3.8-27B-Uncensored-GGUF`
   - (baza: `unsloth/Qwen3.8-27B-GGUF`, `Qwen/Qwen3.8-27B-FP8`)
   Wybór quantu: **Q4_K_M (15,3 GB)** = dużo zapasu na kontekst → Q5_K_M (18,4 GB)
   → Q6_K (20,5 GB, ciasno). Jest też osobny plik `mmproj` (vision, 0,87 GB) — do
   czatu tekstowego niepotrzebny.
2. **`TheDrummer/Cydonia-24B-v4.3` (Q5_K_M 15,6 GB)** — dedykowany **uncensored RP**
   finetune; mieści się z dużym kontekstem, bardzo dobra „willingness".
3. **`TheDrummer/Artemis-31B-v1.1` (Q4_K_M 17,4 GB)** — większy uncensored finetune.
4. **`Gemma 4 31B` AWQ INT4 QAT (19,5 GB)** — najlepszy polski wśród lubianych
   w NSFW (EuroEval 1.85), QAT trzyma jakość przy INT4 — ALE KV 960 KB/tok
   ogranicza kontekst do ~4–8k. Sensowne tylko, jeśli kontekst nie jest kluczowy;
   do NSFW brać `wangzhang/gemma-4-31B-it-abliterated` lub
   `HauhauCS/Gemma4-31B-...Uncensored`.

**Czego nie brać na L4:** `Qwen3.6/3.5-35B-A3B` AWQ-4bit (23,3 GB — brak miejsca na
KV; potrzebuje L40S/2×L4), Mistral Small 4 119B, DeepSeek V4 Flash (290B), 70B.

Jeśli budżet pozwala: **1× L40S (48 GB, $1,80/h)** = Qwen3.6-35B-A3B AWQ z ogromnym
kontekstem, albo Qwen3.8-27B w Q8; **2× L40S (96 GB, $3,60/h)** = Mistral Small 4 119B.

## Jak to postawić (Space + E2)

- **Docker Space** z jednym z:
  - **llama.cpp server** (`ghcr.io/ggml-org/llama.cpp:server-cuda`) — GGUF, najprościej,
    działa z każdym modelem z listy (obsługuje `-ctk q8_0 -ctv q8_0` = tańszy KV),
  - **vLLM** (`vllm/vllm-openai:latest`) — AWQ INT4/FP8, szybszy, lepszy przy wielu
    użytkownikach (L4 ma FP8).
- Endpoint **OpenAI-compatible**: `https://<user>-<space>.hf.space/v1/chat/completions`
  → Chloe w trybie **E2** (`PLAN.md`) może tam celować bez zmiany formatu żądań.
- **Bezpieczeństwo:** publiczny Space = publiczny endpoint (każdy może wołać i palić
  Twój GPU). Dodać własny prosty proxy sprawdzające `Authorization`, albo trzymać
  Space **prywatny** i wołać z tokenem HF (`Authorization: Bearer hf_...` — nasz
  custom-code `fetch` przekazuje ten nagłówek przez proxy).
- **Usypianie:** Space zasypia przy bezczynności → pierwsze zapytanie po przerwie
  czeka na zimny start (minuty). Dla czatu na żywo: brak usypiania (płatne GPU)
  albo akceptacja zimnego startu z fallbackiem do modelu Perchance.

## Źródła (L4)

- HF GPU pricing: https://huggingface.co/docs/hub/spaces-gpus
- Rozmiary quantów: drzewa repo HF (`/api/models/<id>/tree/main?recursive=true`)
- `config.json` modeli: https://huggingface.co/<id>/raw/main/config.json

## L4 vs API — rachunek (czy L4 się opłaca? NIE)

Przepustowość L4 dla Qwen3.8-27B Q4_K_M: L4 ma ~300 GB/s, model 15,3 GB →
teoretycznie ~19 tok/s, realnie **12–16 tok/s** na jeden strumień (llama.cpp);
vLLM z batchingiem ~30–60 tok/s łącznie. Przy 15 tok/s: `3600 × 15 = 54 000 tok/h`
→ **$0.80 / 0,054M ≈ $14,8 za 1M tokenów wyjściowych**. To ~25× drożej niż
Mistral Small 4 (119B!) na OpenRouter ($0.60/Mtok) i ~150× drożej niż
DeepSeek V4 Flash ($0.095/Mtok).

Koszt „na wiadomość" (założenie: ~4 000 tok. wejścia + 400 tok. wyjścia):

| Opcja | Koszt | Wiadomości za $1 | Model, jaki dostajesz |
|---|---|---|---|
| OpenRouter `:free` | $0 | limit 50/dzień | Gemma 4 26B / Nemotron 120B (instruct) |
| DeepSeek V4 Flash (OR) | $0.047/$0.095 /Mtok | **~4 400** | 290B MoE, 0% odmów |
| OpenRouter Gemma 4 26B | $0.09/$0.30 /Mtok | ~2 500 | dobry polski |
| Mistral Small 4 (OR) | $0.15/$0.60 /Mtok | **~1 200** | 119B MoE, #1 w NSFW wg ludzi |
| HF PRO → Featherless | $2/mies. kredytów | ~2 000+ | Stheno/Lunaris/Hermes (uncensored) |
| **HF Space L4** | **$0.80/h** | **~160** | Qwen3.8-27B Q4 (własny, prywatny) |

**Wniosek: patrząc na cenę, L4 jest najdroższą opcją** — ~7× drożej niż 119B
Mistral Small 4 i ~27× drożej niż DeepSeek V4 Flash na wiadomość, przy słabszym
modelu. L4 wygrywa tylko w: prywatności (nic nie opuszcza GPU), zerowej moderacji,
braku limitów i przewidywalnym stałym koszcie.

Tańsze alternatywy o podobnym profilu:
- **Własny PC z GPU** (RTX 4070/4080/4090, 12–24 GB): L4 ma ~300 GB/s, 4070 ~504,
  4080 ~717, 4090 ~1008 GB/s → **1,7–3,4× szybciej i $0 poza prądem**. Jedyna
  droga do „szybko i za darmo", jeśli masz taki sprzęt.
- **ZeroGPU** (w kwocie PRO): darmowy GPU, ale tylko funkcje Gradio z limitem minut
  → brak stałego endpointu OpenAI-compatible.
- **Darmowy CPU Space**: $0, ale 2–5 tok/s.
- **L4 ma sens** dopiero, gdy chcesz mieć model bez żadnej moderacji, bez limitów
  i prywatnie — i godzisz się płacić za to ~10–30× więcej niż za API.


---

# Research 2026-09-19 — „model lepszy i tańszy niż Hermes 3 70B"

Pytanie użytkownika: znaleźć model **lepszy** od `nousresearch/hermes-3-llama-3.1-70b`
($0.70/$0.70), **tańszy**, dostępny **na OpenRouterze**. Przeszukane źródła (wszystkie
pobrane i przeliczone bezpośrednio, nie z pamięci):

| Źródło | Co daje | Rozmiar próby |
|---|---|---|
| RP-Bench (`github.com/LeviTheWeasel/rp-benchmark`, `results/`) | sędziowska runda NSFW (Sonnet + DeepSeek R1), arena głosowana przez ludzi, koszt/wydajność | 40 modeli NSFW / 787 sesji; 1 857 głosów / 338 voterów; 1 262 głosy multi-turn / 315 voterów |
| Caliper Bench (`caliperbench.com`) | surowe metryki prozy: `slop_index`, powtarzalność, gęstość NSFW, `sanitization`, anatomia, łamanie postaci | 528 modeli |
| itzi.app/benchmarks/roleplay | ślepy ranking preferencji ludzi + realny koszt przejścia 8 rozdziałów | 34 modele |
| OpenRouter `/api/v1/models` + `/endpoints` | ceny za token, kontekst, `is_moderated`, limity, dostępność u providerów | 447 modeli (stan 2026-09-18) |

## Werdykt: Hermes 3 70B jest zdominowany na obu osiach

- W rundzie NSFW RP-Bencha **wszystkie** klasyczne finetune'y „uncensored" leżą na dnie
  stawki: Euryale 70B **2.12/5**, Rocinante 12B 2.49, Skyfall 36B 2.52, UnslopNemo 12B 2.61,
  Magnum v4 72B 3.23, Cydonia 24B 3.65, Lunaris 8B 3.83. **Hermes 3 70B nie awansował nawet
  do tej stawki**, a jego następca **Hermes 4 70B w Caliper Bench jest na 526/528 miejscu**
  (slop 50.1/100 — najgorszy wynik w całym zestawie).
- Za te same lub niższe pieniądze modele **ogólne** (nie finetune'y) biją go i jakością,
  i ceną — przy 0% odmów i `is_moderated: false`.

## Shortlista: lepsze I tańsze (wszystkie `is_moderated: false`)

| Model (OpenRouter) | $/1M in / out | NSFW RP-Bench /5 | Dodatkowe dane | Po co |
|---|---|---|---|---|
| `deepseek/deepseek-v4-flash-0731` | **0.04 / 0.08** | 4.45 | #1 w cost-efficiency (Likert 4.38, flaw-hunter 50.6), 1.3M ctx, 943k maxOutput | domyślny „tani i dobry"; 7-17× taniej od Hermesa |
| `deepseek/deepseek-v3.2` | 0.269 / 0.400 | **4.50** | F13 (długie sesje) #2, 164k ctx, reasoning **domyślnie OFF**, 0% odmów | najwyższy zmierzony NSFW, który jest tańszy z OBU stron |
| `google/gemma-4-31b-it` | 0.09 / 0.34 | 4.46 | EuroEval PL 1.85, maxOutput 16k | gdy polski jest priorytetem |
| `z-ai/glm-5.3-flash` | 0.09 / 0.30 | — (za nowy) | **slop 16.7/100 = najniższy z 528 modeli**; reasoning obowiązkowy → itzi: mediana 93 s | najczystsza proza, gdy nie zależy na czasie |
| `qwen/qwen3.5-flash-02-23` | 0.065 / 0.26 | 4.37 | 1M ctx, brak domyślnego reasoningu | budżetowo + polski |
| `mistralai/mistral-small-2603` | 0.15 / 0.60 | 4.24 | **67% wygranych w NSFW u ludzi** (arena), 192 tok/s, 230 ms TTFT, 0% odmów | najostrzejszy seks wg ludzi (obecny domyślny) |
| `deepseek/deepseek-v4-pro-0813` | 0.578 / 1.734 | **4.62** | 4. miejsce na 40 w NSFW, #1 w multi-turn arena ludzi | gdy cena outputu nie gra roli |
| `minimax/minimax-m3` | 0.30 / 1.20 | 4.58 | itzi: 4.4 s/odpowiedź | jakość + szybkość |
| `nvidia/nemotron-3-super-120b-a12b` | 0.08 / 0.45 | — | 120B MoE, 262k ctx | eksperyment |

## Pułapki tanich modeli

- **Reasoning** to ukryty koszt: `deepseek-v4-flash-0731` ma go domyślnie włączonego
  („high"), a `glm-5.3-flash` ma **obowiązkowy**. To dodatkowe tokeny wyjścia i sekundy
  opóźnienia (itzi: DeepSeek V4 Flash 7 s, GLM 5.3 Flash 93 s mediany na rozdział).
- **Gemini / Claude / GPT** wygrywają w rankingach (itzi: Gemini 3.8 Flash 91.9/100), ale
  mają moderację providera i są 5–100× droższe — realne ryzyko zacięcia się na ERP.
- **Caliper Bench** mierzy `sanitization` (niższe = mniej ugrzecznione) i `slop_index`.
  Gemma ma najlepszy polski, ale najgorszy slop w stawce (50.1/100) — dlatego nie jest
  domyślnym wyborem do długiego RP.
- **Uczciwa uwaga metodologiczna**: autor RP-Bencha pisze wprost, że sygnały
  sędziów-LLM „disagree with real users about half the time" (korelacja z arena ludzi
  rho ≈ 0.50). Dlatego wybór domyślny (Mistral Small Creative) stoi na **głosach ludzi**
  (67% NSFW), a nie na ocenach sędziów.

## Efekt w kodzie

`CHLOE_E2_PRESETS` + `CHLOE_E2_PRICES` w custom code (14 presetów, każdy z ceną).
Hermes 3 70B został na liście, ale opisany jako „dla porównania".
