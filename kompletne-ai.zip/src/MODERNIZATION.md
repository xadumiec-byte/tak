# Chloe Enhanced — modernizacja 2.0

## Zakres ukończony

- zachowano zgodność z Perchance, dane `state/`, istniejące komendy i funkcje;
- zachowano dotychczasowy routing treści NSFW i istniejące zabezpieczenia;
- RP Engine, Image Engine, Memory Engine i Model Router są składane deterministycznie do jednego `customCode`;
- `index.html` otrzymuje podczas buildu dokładnie ten sam bundle co `src/chloe-customcode.js`;
- Memory Engine v2 automatycznie migruje wpisy v1 bez kasowania danych;
- pamięć zapisuje datę aktualizacji, ostatnie użycie i licznik użyć;
- dodano komendę `/pamięć edytuj ID nowa treść`;
- dodano testy regresyjne bundle, osadzenia w HTML, pamięci i routingu;
- dodano kontrolę składni wszystkich modułów JavaScript.

## Weryfikacja

W katalogu projektu uruchom:

```text
npm run verify
```

Polecenie składa moduły, aktualizuje `index.html`, sprawdza składnię i uruchamia testy.

## Najważniejsze pliki

- `src/chloe-customcode.js` — gotowy bundle do Perchance;
- `index.html` — aplikacja z osadzonym aktualnym bundle;
- `src/memory-engine.js` — Memory Engine v2;
- `src/rp-engine.js` — RP Engine;
- `src/img-engine.js` — Image Engine;
- `src/model-router.js` — routing modeli, w tym zachowana trasa NSFW;
- `tools/build.mjs` — powtarzalny build;
- `tests/regression.mjs` — testy regresyjne.
