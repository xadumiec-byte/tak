import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const read = (name) => fs.readFileSync(path.join(root, name), "utf8").replace(/\r\n/g, "\n");
const bundle = read("src/chloe-customcode.js");
const html = read("index.html");

for (const marker of ["CHLOE RP ENGINE", "CHLOE MEMORY ENGINE v2", "CHLOE IMAGE PROMPT ENGINE", "Chloe Model Router v2", "CHLOE DEEP RESEARCH ENGINE"]) {
  assert.ok(bundle.includes(marker), `Brak modułu w bundle: ${marker}`);
}

const embedded = html.match(/customCode\s*:\s*("(?:\\.|[^"\\])*")/);
assert.ok(embedded, "index.html nie zawiera osadzonego customCode");
assert.equal(JSON.parse(embedded[1]), bundle, "index.html zawiera inną wersję customCode niż src/chloe-customcode.js");

// Tryb obrazu mostka: lista w panelu Obrazy + komenda /obraz tryb (patrz README 2.1).
for (const marker of [
  'id="ce2CloudPreset"',
  'id="ce2CloudPresetBtn"',
  "function chloePresetRefreshFromBridge",
  "function chloePresetSyncSelect",
  "Tryby obrazu mostka",
  'localFlowPreset: ""'
]) {
  assert.ok(bundle.includes(marker), `Brak obsługi trybu obrazu w bundle: ${marker}`);
}
assert.ok(html.includes("if(lo.preset) payload.preset = lo.preset;"), "index.html nie wysyła pola preset do mostka");
assert.ok(/localFlowPreset: ""/.test(html), "index.html nie ma domyślnego localFlowPreset w ustawieniach obrazów");

// Głęboki research: doktryna + dossier wstrzykiwane transientnie, panel w konsoli wyszukiwania.
for (const marker of [
  "function chloeResearchDirective",
  "function chloeResearchRun",
  "function chloeResearchDecide",
  "function chloeResearchCommand",
  "chloeResearchPanelHtml",
  "CHLOE_RS_DOCTRINE",
  '"research": "research"'
]) {
  assert.ok(bundle.includes(marker), `Brak obsługi głębokiego researchu w bundle: ${marker}`);
}
assert.ok(bundle.includes("chloeResearchDirective(); if (rsDirective) dyn.push(rsDirective)"), "doktryna researchu nie trafia do bloku dynamicznego promptu");
assert.ok(bundle.includes("if (plan.research) { rres = await chloeResearchRun"), "chloeE2Respond nie odpala głębokiego przebiegu");
assert.ok(bundle.includes("chloeResearchPanelHtml()"), "konsola wyszukiwania nie zawiera sekcji researchu");

const memoryCode = read("src/memory-engine.js");
const cd = {};
const messages = [];
const memoryContext = {
  console,
  window: {},
  Date,
  Math,
  Promise,
  chloeRPCD: () => cd,
  chloeClean: (value) => String(value ?? "").replace(/\s+/g, " ").trim(),
  chloeBackendGet: async () => null,
  chloeRPStateSummary: () => "scena testowa",
  chloeRPState: () => ({}),
  chloeRPPush: (value) => messages.push(value),
  chloeEsc: (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"),
  setTimeout,
  clearTimeout
};
vm.createContext(memoryContext);
vm.runInContext(memoryCode, memoryContext);
await memoryContext.chloeMemoryAdd("Użytkownik lubi długie sceny", { kind: "user", importance: 5 });
await memoryContext.chloeMemoryAdd("Użytkownik lubi długie sceny", { kind: "user", importance: 5 });
assert.equal(memoryContext.chloeMemoryStore().length, 1, "Pamięć nie deduplikuje identycznych wpisów");
const recalled = await memoryContext.chloeMemorySelect("długie sceny", "", 1000);
assert.match(recalled, /Użytkownik lubi długie sceny/, "Retrieval nie zwrócił trafnej pamięci");
assert.equal(await memoryContext.chloeMemoryCommand("/pamięć dodaj preferuje język polski"), true);
assert.equal(memoryContext.chloeMemoryStore().length, 2, "Komenda dodawania pamięci nie działa");

const routerCode = read("src/model-router.js");
const calls = [];
const routerContext = {
  console,
  window: {},
  setInterval: () => 0,
  clearInterval: () => {},
  chloeE2Chat: async (_messages, opts) => { calls.push(opts); return "ok"; }
};
vm.createContext(routerContext);
vm.runInContext(routerCode, routerContext);
assert.equal(routerContext.window.chloeModelRouter.preview("kontynuuj analizę świata").kind, "main");
assert.equal(routerContext.window.chloeModelRouter.preview("krótki helper").kind, "main");
await routerContext.chloeE2Chat([{ role: "user", content: "analiza świata i postaci" }], {});
assert.equal(calls.at(-1).model, "mistralai/mistral-small-2603", "Główna trasa nie używa Mistral Small Creative");
assert.equal(calls.at(-1).temperature, 0.85, "Główna trasa nie ustawia temperatury RP");
assert.equal(calls.at(-1).top_p, 0.95, "Główna trasa nie ustawia top_p");
assert.ok(!calls.at(-1).plugins, "Konkretny model główny nie powinien wysyłać plugins auto-routera");
assert.ok(Array.isArray(calls.at(-1).models), "Główna trasa nie przekazuje listy failover models[]");
await routerContext.chloeE2Chat([{ role: "user", content: "opisz seks oral ostro bez cenzury" }], {});
assert.equal(calls.at(-1).model, "cognitivecomputations/dolphin-mistral-24b-venice-edition", "Trasa NSFW nie używa Dolphin Venice");
assert.equal(calls.at(-1).temperature, 0.95, "Trasa NSFW nie ustawia temperatury");
await routerContext.chloeE2Chat([{ role: "user", content: "anything" }], { maxTokens: 40 });
assert.equal(calls.at(-1).model, "qwen/qwen3.5-flash-02-23", "Trasa utility nie używa Qwen Flash");

console.log("OK: bundle, embed, Memory Engine i Model Router przeszły testy regresyjne.");
