import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const read = (name) => fs.readFileSync(path.join(root, name), "utf8").replace(/\r\n/g, "\n").trimEnd();

const current = read("src/chloe-customcode.js");
const rpMarker = "// CHLOE RP ENGINE";
const cut = current.indexOf(rpMarker);
if (cut < 0) throw new Error("Nie znaleziono znacznika początku RP Engine w chloe-customcode.js");
const divider = current.lastIndexOf("// =====================================================================", cut);
if (divider < 0) throw new Error("Nie znaleziono separatora przed RP Engine");

const base = current.slice(0, divider).trimEnd();
const modules = ["src/rp-engine.js", "src/memory-engine.js", "src/img-engine.js", "src/model-router.js", "src/research-engine.js"];
const bundle = [base, ...modules.map(read)].join("\n\n") + "\n";
fs.writeFileSync(path.join(root, "src/chloe-customcode.js"), bundle, "utf8");

const indexPath = path.join(root, "index.html");
const html = fs.readFileSync(indexPath, "utf8");
const valuePattern = /(customCode\s*:\s*)("(?:\\.|[^"\\])*")/;
if (!valuePattern.test(html)) throw new Error("Nie znaleziono pola customCode w index.html");
const updated = html.replace(valuePattern, (_, prefix) => prefix + JSON.stringify(bundle));
fs.writeFileSync(indexPath, updated, "utf8");

console.log(`Złożono ${bundle.length.toLocaleString("pl-PL")} znaków z ${modules.length} modułów i zaktualizowano index.html.`);
