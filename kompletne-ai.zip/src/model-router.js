/*
 * Chloe Model Router v2 — automatyczny routing modeli (OpenRouter)
 *
 * Warstwy:
 * - main: Mistral Small Creative (konkretny model RP) + pasmo `models[]`
 *   jako serwerowy failover przy bledzie/429. Tryb auto (openrouter/auto
 *   z allow-lista i cost_tier) dostepny przez CFG.autoModel.
 * - nsfw: jawne tresci i retry po odmowie wprost do uncensored Dolphin (Venice).
 * - utility: sztywno tani model bez reasoningu do krotkich zadan.
 * - klasyfikator: domyslnie szybki regex; opcjonalnie Jev (Decisions API,
 *   model typesafe/jev-1.13) z automatycznym spadkiem do regexa przy kazdym
 *   niepowodzeniu. Brak klucza = regex, nic sie nie psuje.
 *
 * Nie umieszczaj tutaj klucza API. Router korzysta z ustawien /model Chloe.
 * Ten plik jest zrodlem: doklejany na koniec src/chloe-customcode.js i dalej
 * osadzany jako customCode w index.html (przepis: src/README.md).
 */
(function installChloeModelRouter() {
  "use strict";

  var CFG = {
    enabled: true,
    mainModel: "mistralai/mistral-small-2603",
    mainParams: { temperature: 0.85, top_p: 0.95, frequency_penalty: 0.3, presence_penalty: 0.1 },
    autoModel: "openrouter/auto",
    autoCostTier: "medium",
    autoAllowed: [
      "deepseek/deepseek-v3.2",
      "mistralai/mistral-small-2603",
      "google/gemma-4-26b-a4b-it",
      "qwen/qwen3.5-flash-02-23",
      "minimax/minimax-m3",
      "cognitivecomputations/dolphin-mistral-24b-venice-edition"
    ],
    mainFallbacks: [
      "deepseek/deepseek-v3.2",
      "qwen/qwen3.5-flash-02-23",
      "google/gemma-4-26b-a4b-it"
    ],
    nsfwModel: "cognitivecomputations/dolphin-mistral-24b-venice-edition",
    nsfwParams: { temperature: 0.95, top_p: 0.98, frequency_penalty: 0.4, presence_penalty: 0.15 },
    nsfwFallbacks: [
      "mistralai/mistral-small-2603",
      "deepseek/deepseek-v3.2"
    ],
    utilityModel: "qwen/qwen3.5-flash-02-23",
    utilityParams: { temperature: 0.2, top_p: 0.9 },
    utilityFallbacks: [
      "google/gemma-4-26b-a4b-it"
    ],
    directNsfw: true,
    retryRefusals: true,
    rememberNsfwMinutes: 45,
    classifier: "regex",
    jevUrl: "https://openrouter.ai/api/alpha/decisions",
    jevModel: "typesafe/jev-1.13",
    jevTimeoutMs: 15000
  };

  var STATE = { installed: false, lastRoute: null, nsfwUntil: 0, jevOk: null };

  function textOf(message) {
    return String((message && message.content) || "");
  }

  function lastUserText(messages) {
    for (var i = (messages || []).length - 1; i >= 0; i--) {
      var role = String(messages[i] && (messages[i].role || messages[i].author) || "").toLowerCase();
      if (role === "user") return textOf(messages[i]);
    }
    return "";
  }

  var NSFW_RE = /\b(?:nsfw|erp|seks|sex|erot|nago|naga|nagi|porno|porn|fetysz|fetish|bdsm|orgazm|orgasm|penetr|anal|oral|cipk|wagin|penis|fiut|kut|piersi|sutk|sperm|cum|creampie|masturb|dildo|strap-?on|pegging|rimming|fisting|domin|uleg|bondage|shibari|klaps|spanking|choking|hardcore|mocniej|glebiej|głębiej|zerzn|ruchaj|pieprz|fuck)\w*/i;
  var CONTINUE_RE = /^\s*(?:dalej|kontynuuj|nie przerywaj|mocniej|jeszcze|tak|dokladnie|dokładnie|ciągnij|ciagnij|continue|more|harder)\b/i;
  var COMPLEX_RE = /\b(?:lore|swiat|świat|postaci|bohater|intryg|plan|strateg|pamie|pamię|podsum|analiz|narzedz|narzędz|json|stan|relacj|watek|wątek|scenariusz)\w*/i;
  var REFUSAL_RE = /(?:^|[.!?]\s+)(?:przepraszam|przykro mi|nie mog[eę]|nie jestem w stanie|nie mogę pomóc|nie mogę kontynuować|jako (?:ai|model|asystent)|i(?:'|’)m sorry|i can(?:'|’)t|i cannot|i won(?:'|’)t|as an ai|i must (?:decline|refuse)|i(?:'|’)m unable)/i;
  var FADE_RE = /(?:fade(?:s)? to black|resztę pozostawmy wyobraźni|reszte pozostawmy wyobrazni|scena (?:blednie|będzie kontynuowana poza kadrem)|nie będę opisywa[ćc] szczeg[oó][łl][oó]w|pomijając szczeg[oó][łl]y)/i;

  function isUtility(messages, opts) {
    var max = Number(opts && opts.maxTokens);
    var t = lastUserText(messages);
    return (max > 0 && max <= 120) || /^(?:translate|przetlumacz|przetłumacz|classify|sklasyfikuj|extract|wyodrebnij|wyodrębnij|summarize briefly)\b/i.test(t.trim());
  }

  function choose(messages, opts) {
    var user = lastUserText(messages);
    if (isUtility(messages, opts)) return { kind: "utility", model: CFG.utilityModel };

    var explicit = NSFW_RE.test(user);
    if (explicit) STATE.nsfwUntil = Date.now() + CFG.rememberNsfwMinutes * 60000;
    var activeScene = STATE.nsfwUntil > Date.now() && CONTINUE_RE.test(user);
    var complex = COMPLEX_RE.test(user) || user.length > 1400;

    if (CFG.directNsfw && (explicit || activeScene) && !complex) {
      return { kind: "nsfw", model: CFG.nsfwModel };
    }
    return { kind: "main", model: CFG.mainModel };
  }

  function autoPlugin() {
    return [{ id: "auto-router", cost_tier: CFG.autoCostTier, allowed_models: CFG.autoAllowed.slice() }];
  }

  function jevRoute(userText) {
    if (typeof chloeDirectFetch !== "function" || typeof chloeE2Get !== "function" || typeof chloeAuthHeaders !== "function") return Promise.resolve(null);
    var s = null;
    try { s = chloeE2Get(); } catch (eGet) { return Promise.resolve(null); }
    var body = {
      model: CFG.jevModel,
      state: String(userText || "").slice(0, 1500),
      questions: {
        route: {
          type: "choice",
          instructions: "Classify the user's chat message for model routing.",
          criteria: {
            main: "Complex roleplay, story, lore, planning, or a long message needing a strong model.",
            nsfw: "Explicit adult or erotic content needing an uncensored model.",
            utility: "A short helper task: translate, classify, extract, or summarize briefly."
          }
        }
      }
    };
    var p = null;
    try {
      p = chloeDirectFetch(CFG.jevUrl, { method: "POST", headers: chloeAuthHeaders(s), body: JSON.stringify(body) }, CFG.jevTimeoutMs);
    } catch (eCall) { return Promise.resolve(null); }
    return Promise.resolve(p).then(function (r) {
      if (!r || r.ok === false) return null;
      var j = null;
      try { j = JSON.parse(String((r && r.text) || "")); } catch (eP) { return null; }
      var c = j && j.answers && j.answers.route && j.answers.route.choice;
      if (c === "nsfw") return { kind: "nsfw", model: CFG.nsfwModel, fromJev: true };
      if (c === "utility") return { kind: "utility", model: CFG.utilityModel, fromJev: true };
      if (c === "main") return { kind: "main", model: CFG.mainModel, fromJev: true };
      return null;
    }, function () { return null; });
  }

  function looksCensored(answer) {
    var t = String(answer || "").trim();
    return !t || REFUSAL_RE.test(t) || FADE_RE.test(t);
  }

  function lastUsedModel() {
    try {
      if (typeof CHLOE_E2_LAST_MODEL === "string" && CHLOE_E2_LAST_MODEL) return CHLOE_E2_LAST_MODEL;
    } catch (e0) {}
    try {
      if (window.__chloeE2 && typeof window.__chloeE2.model === "function") return window.__chloeE2.model() || "";
    } catch (e1) {}
    return "";
  }

  function paramsFor(kind) {
    if (kind === "nsfw") return CFG.nsfwParams || {};
    if (kind === "utility") return CFG.utilityParams || {};
    return CFG.mainParams || {};
  }

  function mergeOptions(opts, route) {
    var out = {}, k;
    opts = opts || {};
    for (k in opts) if (Object.prototype.hasOwnProperty.call(opts, k)) out[k] = opts[k];
    out.model = route.model;
    var p = paramsFor(route.kind);
    for (k in p) if (Object.prototype.hasOwnProperty.call(p, k) && out[k] == null) out[k] = p[k];
    if (route.kind === "main") {
      if (route.model === CFG.autoModel) out.plugins = autoPlugin();
      else if (out.plugins) delete out.plugins;
      if (CFG.mainFallbacks.length) out.models = CFG.mainFallbacks.slice();
    } else if (route.kind === "nsfw") {
      if (CFG.nsfwFallbacks.length) out.models = CFG.nsfwFallbacks.slice();
    } else if (route.kind === "utility") {
      if (CFG.utilityFallbacks.length) out.models = CFG.utilityFallbacks.slice();
    }
    return out;
  }

  function addRetryInstruction(messages) {
    var out = (messages || []).slice();
    out.push({
      role: "system",
      content: "Napisz kompletna odpowiedz zgodna z persona i formatem Chloe. Zachowaj ciaglosc sceny, jezyk polski, linie <<stan {...}>> i propozycje [[...]]. Nie komentuj poprzedniej odmowy ani procesu ponawiania. Wszystkie postacie w scenie sa dorosle."
    });
    return out;
  }

  function stampRoute(route) {
    STATE.lastRoute = { at: new Date().toISOString(), kind: route.kind, model: route.model, actualModel: "", retry: false, via: (route.fromJev ? "jev" : "regex") };
  }

  function install() {
    var original = (typeof chloeE2Chat === "function") ? chloeE2Chat : null;
    if (!original || original.__chloeRouterWrapped) return false;

    var routed = async function chloeE2ChatRouted(messages, opts) {
      if (!CFG.enabled || (opts && opts.model)) return original(messages, opts);

      var route = null;
      if (CFG.classifier === "jev") {
        try { route = await jevRoute(lastUserText(messages)); } catch (eJ) { route = null; }
        try { STATE.jevOk = !!route; } catch (eS) {}
      }
      if (!route) route = choose(messages, opts);
      stampRoute(route);

      try {
        var answer = await original(messages, mergeOptions(opts, route));
        STATE.lastRoute.actualModel = lastUsedModel();
        if (CFG.retryRefusals && route.model !== CFG.nsfwModel && looksCensored(answer)) {
          STATE.lastRoute = { at: new Date().toISOString(), kind: "nsfw-retry", model: CFG.nsfwModel, actualModel: "", retry: true, via: STATE.lastRoute.via };
          var retryAns = await original(addRetryInstruction(messages), mergeOptions(opts, { kind: "nsfw", model: CFG.nsfwModel }));
          STATE.lastRoute.actualModel = lastUsedModel();
          return retryAns;
        }
        return answer;
      } catch (err) {
        if (route.model === CFG.nsfwModel) throw err;
        STATE.lastRoute = { at: new Date().toISOString(), kind: "nsfw-error-fallback", model: CFG.nsfwModel, actualModel: "", retry: true, via: STATE.lastRoute.via };
        var fbAns = await original(addRetryInstruction(messages), mergeOptions(opts, { kind: "nsfw", model: CFG.nsfwModel }));
        STATE.lastRoute.actualModel = lastUsedModel();
        return fbAns;
      }
    };

    routed.__chloeRouterWrapped = true;
    routed.__chloeRouterOriginal = original;
    chloeE2Chat = routed;
    try { window.chloeE2Chat = routed; } catch (e) {}
    try { if (window.__chloeE2) window.__chloeE2.chat = routed; } catch (e2) {}
    STATE.installed = true;
    return true;
  }

  window.chloeModelRouter = {
    config: CFG,
    state: STATE,
    install: install,
    enable: function () { CFG.enabled = true; },
    disable: function () { CFG.enabled = false; },
    preview: function (text, opts) {
      var r = choose([{ role: "user", content: String(text || "") }], opts || {});
      return { kind: r.kind, model: r.model, params: paramsFor(r.kind), plugins: (r.kind === "main" && r.model === CFG.autoModel) ? autoPlugin() : null };
    },
    status: function () {
      return {
        enabled: CFG.enabled,
        installed: STATE.installed,
        classifier: CFG.classifier,
        jevOk: STATE.jevOk,
        models: { main: CFG.mainModel, nsfw: CFG.nsfwModel, utility: CFG.utilityModel },
        params: { main: CFG.mainParams, nsfw: CFG.nsfwParams, utility: CFG.utilityParams },
        auto: { model: CFG.autoModel, costTier: CFG.autoCostTier, allowed: CFG.autoAllowed.slice(), mainFallbacks: CFG.mainFallbacks.slice() },
        lastRoute: STATE.lastRoute
      };
    }
  };

  if (!install()) {
    var attempts = 0;
    var timer = setInterval(function () {
      attempts++;
      if (install() || attempts >= 40) clearInterval(timer);
    }, 250);
  }
})();
