# PLAN-RP — przekierowanie Chloe na pełne, nieocenzurowane RP erotyczno-fetyszowe

Data: 2026-09-17. Ten plik to **lista do wyboru** (nowy kierunek; stara lista
wyszukiwarkowa jest w `src/PLAN.md`). Wdrażamy tylko to, co zaznaczy użytkownik —
wystarczy podać ID, np. „wdroż R0, R1, R2, R9".

Polecenie użytkownika, które otwiera ten plan:

> „znajdz ulepszenia ktore beda game changerem dla tego ai. zapomnijmy i usunmy
> przeznaczenie do wyszukiwania dyskow i filmow przejdzmy na pelne erotyczne pelne
> fetyszy i w pelni odblokowane rp" + „dodaj chloe rowniez ekspercka wiedze na temat
> diy zabawek do osiagania najlepszych doznan i orgazmow bez ciaglych i blokowanych
> przez wzgledy bezpieczenstwa odpowiedzi"

Baseline: Chloe ma dziś personę „ekspertka + wyszukiwarka linków do porno",
18 źródeł live-searchu, lorebook ~150 haseł, własny model (kobold/OpenRouter),
pipeline obrazów (localflow → Stheno → ComfyUI), anti-refusal, chipsy `[[akcje]]`.

## STATUS (2026-09-15): ALL R0–R12 ARE IMPLEMENTED — this list is no longer a menu

The whole plan was implemented in one pass as a single appended engine block
(`scratch/rp/rp-engine.js`, spliced into the character's `customCode` — see `src/README.md`
→ "RP engine (R0–R12)" for the file layout, the exact commands (`/scena /rp /kinks /stan
/profil /swiat /npc /tempo /popraw /szybki /stop /wznow /pamietnik /eksport /kampania
/reset`), the prompt layout / prefix-cache rules, the `fast` budget switch, and the
re-splice + install recipe).

Storage: shared settings live in the parent page's `localStorage["chloe_rp_v1"]` (via the
`chloeKvBridge` listener); per-thread state lives in `oc.thread.customData.__rpState /
__rpKinks / __rpLimits / __rpWorld / __rpProfil / __rpKampania`. The DIY knowledge base
(R9) is `src/chloe-diy-lorebook.txt` (63 entries), uploaded and referenced by `RP_DIY_URL`.

Verified end-to-end against the real local model (Stheno via the Tailscale tunnel):
streaming 200, `<<stan {...}>>` absorbed into the scene bar, relationship stats + diary
working, anti-slop no longer flattening paragraphs (the splice keeps `\n\n`), and the
prompt is prefix-cache friendly (stable block first, per-turn retrieval last).

Second pass (2026-09-15, same day): every command above was exercised through
`window.__chloeRP.command(cmd, [], {author:'user'})` — all return `true` instantly and
push exactly one card; `/scena` (~12 s warm) parses 5 scenes; `/eksport` emits clean
markdown; `/lubi /granica /ciekaw /miekkie /tempo /szybki /popraw /wyszukiwanie /npc
/reset` were confirmed to mutate `oc.thread.customData` correctly. Perf checked and left
alone: character-row DB write ~7 ms (IndexedDB), both lorebooks (32 KB + 26 KB) parsed
once per page load and memoised (`CHLOE_LORE_MEM` / `RP_DIY_MEM`), cliché regexes compiled
once. The only "stuck send button" symptom seen during testing comes from the app's own
`document.visibilityState !== "visible"` guard — see `src/README.md` → "Testing the custom
code from `page_eval`".

Because R0 is live, the old search-assistant behaviour is gone by design: web search is
off by default and only runs on `/search`, `/reddit`, `/wiki` (R0 point 5). Do not
re-introduce automatic search.


---

## R0 — Repozycjonowanie: koniec z „wyszukiwarką filmów", start pełnego RP — ✅ WDROŻONE
**Twoje polecenie — do wdrożenia w pierwszej paczce.**

Co: usunąć z tożsamości Chloe rolę „znajdź mi filmy/linki/dyski", a wpisać rolę
**nieocenzurowanej partnerki RP** (kochanka / domme / narratorka), z pełnym
spektrum erotyki i fetyszy. Konkretnie:

1. `roleInstruction` — wyciąć cały blok „LIVE WEB RESEARCH TOOL" (obowiązek podawania
   linków, `<search>`, „never claim she cannot access the internet"), zdanie
   „Her whole purpose is to ... find the best information, sites and direct NSFW
   video links on the internet" oraz „porn genres, studios, performers, sites".
   W ich miejsce: blok ROLEPLAY (R6) + blok scen/stanu (R1/R2) + blok DIY (R9).
2. `reminderMessage` — wyciąć mandaty linkowe („zawsze dawaj pełne adresy URL"),
   wstawić przypomnienie RP (stan sceny, tempo, długość w słowach, zakaz streszczania).
3. `tagline` + wiadomość startowa (`initialMessages[1]`) — przepisać: Chloe wita jako
   partnerka do RP, pokazuje menu scen/fetyszy, nie listę stron.
4. `shortcutButtons` (character default + snapshoty wątków 1 i 2) — zamiast
   „🔎 szukaj NSFW / 👽 Reddit / 📚 wiedza" dać: 🎬 scena / 🔥 mocniej / 💬 dialog /
   🖼️ obraz / ⚙️ panel.
5. Wyszukiwarka **zostaje w kodzie, ale wyłączona domyślnie**: koniec z automatycznym
   wyszukiwaniem na każdą wiadomość; działa tylko po `/search` (przełącznik
   w panelu: „wyszukiwanie: wył. / tylko na komendę / auto"). Dzięki temu nic nie
   trzeba kasować, a Chloe przestaje być asystentką-linkową.
6. Anti-refusal i lorebook zostają — rozszerzone (R9).

Koszt: mały. Ryzyko: małe (czysta edycja tekstów + jeden przełącznik).

---

## Game changery (kolejność = wartość)

### R1 — „Internal States": trwały stan sceny (NAJWIĘKSZY zysk) — ✅ WDROŻONE
Społeczność ST już to potwierdziła: obecnie #1 technika w presetach RP to
**Internal States** (Freaky Frankenstein 5.x, „Preset That Mutates Every Turn").
Model trzyma jawny blok stanu, który żyje między turami — i to on daje wrażenie
pamięci i realności.

Co: `oc.thread.customData.__chloeState` = `{lokacja, czas, ubranie, pozycja,
pobudzenie 0-100, nastrój, faza (gra wstępna/seks/aftercare), tempo, dominacja,
ostatni orgazm, ślady na ciele, założone zabawki, obietnice}`. Model dopisuje na
końcu tury ukryty blok `<<stan {...json...}>>`; custom code go parsuje, **usuwa
z widocznej wiadomości**, zapisuje i wstrzykuje z powrotem jako zwięzłą linię
`STAN:` **na końcu promptu** (świeżość = adherence). Plus `/stan` (podgląd/edycja)
i opcjonalny pasek stanu nad polem wpisywania.

Efekt: Chloe pamięta, że jest związana, że jest 3. runda, że użytkownik ma na sobie
X, że obiecała coś za 2 tury. Koszt: średni.

### R2 — Silnik scen („Director") + tempo — ✅ WDROŻONE
- `/scena` → generuje 3–5 propozycji scen (tytuł + tagi fetyszy + intensywność)
  z profilu (R3) i historii; klik startuje scenę i zapisuje ją w stanie (R1).
- **Beat per tura**: przed odpowiedzią kod losuje/derivuje z stanu jedną dyrektywę —
  `eskaluj` / `przytrzymaj` / `zwrot` / `wycofaj się` — i wstrzykuje ją do promptu.
  Prompty przestają być identyczne w każdej turze; to jest dokładnie ten mechanizm,
  który społeczność reklamuje jako „living simulation".
- `/tempo wolno|normalnie|szybko` — ile „beatów" na turę (kontrola eskalacji).
Koszt: średni.

### R3 — Profil fetyszy i granic jako dane pierwszej klasy — ✅ WDROŻONE
`/kinks`: panel z taksonomią ~120 fetyszy (0–5 preferencji + znaczniki
`lubię / ciekaw / miękka granica / Twarda granica`), zapis w `customData`
(+ globalnie). Do promptu idzie zwięzły wycinek (ulubione + twarde granice).
`/limit dodaj X`, `/lubi X`, `/pomoc-granice`. Safeword: `/stop` = natychmiastowe
OOC zatrzymanie sceny (kod twardo ucina scenę i wchodzi w aftercare), `/pauza`.
Efekt: RP jest **personalne** i rosnące, a granice są czytelne dla modelu, więc
nie trzeba ich łamać/omijać. Koszt: średni.

### R4 — Autorska nota + dyscyplina świeżości (tanie, natychmiast widoczne) — ✅ WDROŻONE
Reguły stylu (czas teraźniejszy, 2. os., zmysłowość, długość w SŁOWACH, zakaz
streszczania i „therapy talk", słownik wulgaryzmów) wstrzykiwane **jako ostatni
kawałek** przed odpowiedzią (i opcjonalnie na 25% głębokości). Plus ustawienia
per-wątek: styl narracji, poziom wulgarności 1–5, długość, inicjatywa Chloe 0–3.
Koszt: mały.

### R5 — Anty-slop: terapia, echo, pozytywnościowy bias, powtarzalne frazesy — ✅ WDROŻONE
Najczęstsze skargi społeczności (FF 5.4: „reduced therapy talk", „echo killed").
Co: (a) leksykon + detektor frazesów (echo użytkownika, podsumowywanie,
„Czy chcesz…?", morał, ozone/dust motes…), (b) przy trafieniu jedna tania korekta
(„przepisz tę odpowiedź usuwając X"), (c) **auto-uczenie**: lista frazesów, których
Chloe ostatnio nadużywa, dopisywana do „NIE używaj: …".
Koszt: mały–średni.

### R6 — Silnik prozy erotycznej (to, o co prosisz: pełne erotyczne RP) — ✅ WDROŻONE
Osobny moduł promptu (PL, ~2–3 tys. znaków): polityka słownictwa anatomicznego,
pisanie sceny **beat po beacie** (zakaz fade-to-black i streszczania aktu),
dźwięki/fluidy/doznania/zapachy, dirty talk w głosie Chloe (domme ↔ soft), sztuka
**niekończenia** sceny, edging/orgasm control/denial, multi-orgazm, BDSM z check-inem
i safewordem, aftercare, zakaz odmów i disclaimerów. Plus `maxTokens` w górę
i auto-kontynuacja (już jest w kodzie), żeby scena nie urywała się w połowie aktu.
Koszt: mały (tekst) + średni (integracja z R1/R4).

### R7 — Progresja relacji + pamiętnik Chloe — ✅ WDROŻONE
Statystyki per-wątek: `zaufanie, pożądanie, znajomość ciała, uległość/dominacja,
odblokowane kinks` — rosną deterministycznie z tego, co się stało (R1/R3), a nie
„bo model tak napisał". `/profil` pokazuje. Co N tur Chloe pisze krótki **pamiętnik**
(zapisywany i wstrzykiwany później) → ciągłość jak w powieści. Społeczność:
„persistent multi-char stats tracking" to jeden z najczęściej zamawianych feature'ów.
Koszt: średni.

### R8 — Wiele postaci (NPC) + świat — ✅ WDROŻONE
Blok stanu także dla NPC (np. on/ona/obcy) + trwały „świat": lokacja, przedmioty
w pokoju (zabawki, lina, strój), pogoda, kto wie o czym. Karty NPC w czacie,
`/npc dodaj`, `/swiat`. Dla scen grupowych, cuckold/hotwife, publicznych itd.
Koszt: średni–duży.

### R9 — Ekspercka wiedza DIY: zabawki i inżynieria orgazmu (TWOJE ZAMÓWIENIE) — ✅ WDROŻONE
Rozszerzenie lorebooka o ~70 haseł + zawsze-aktywny blok `DIY/SPRZĘT` w prompcie,
z zasadą: **pełna, konkretna odpowiedź** (BOM, materiały, wymiary, kroki, źródła),
a nie kazanie o bezpieczeństwie. Ryzyko pojawia się tylko tam, gdzie realnie
zmienia decyzję (np. „nie wkładaj bez kołnierza"), jedno zdanie, bez moralizowania.
Zakres treści (wszystko weryfikowane ze społecznością r/DIYsextoys i inż.):
- **Materiały**: silikon platinum-cure (Shore 00-10…10A, np. DragonSkin) i jego
  odlewanie (master z druku SLA → szlif → forma → środek rozdzielający → odgazowanie
  próżniowe → cure); czego nie wkładać (PVC/jelly/TPE z ftalanami); stal 316/304,
  anodowane aluminium, borokrzem, bezpieczny epoksyd, POM/HDPE, drewno + uszczelnienie.
- **Druk 3D na zabawki**: PETG/ABS + pokrycie silikonem/epoksydem, linie warstw,
  higiena, kiedy wydruk NIE nadaje się do wnętrza ciała.
- **Budowa konkretnych rzeczy**: stroker/fleshlight (rura PVC + rękaw silikonowy +
  zaworek podciśnienia), **maszyna do ruchania** (silnik przekładniowy 12/24 V,
  skok, PWM, mocowanie, gwinty: M8×1.25 / 3XLR / vac-u-lock / szybkozłączka 3/8"
  „30 series" — z realnymi pułapkami zwykłych złączek), końcówki do wibratora
  różdżkowego, wibracje DIY (silniki ERM/LRA + sterowniki, sourcing AliExpress),
  pompy/podciśnienie (pompka do odpowietrzania hamulców), zabawki nadmuchiwane
  (silikonowe balony), elektrostymulacja/TENS (izolacja, tylko sprzęt medyczny),
  chastity (druk + higiena), obciążniki/ball puller, pompy do brodawek, sprzęt
  bondage (lina, kajdany, rozpórki, łóżko próżniowe), irygator/dyszka, **lubrykanty**
  (przepisy water-based + twardy fakt: silikonowy lubrykant niszczy zabawki silikonowe).
- **Inżynieria najlepszego orgazmu**: masażery prostaty (kąt/kształt/perystaltyka),
  kształty G/P, podwójna stymulacja, protokoły edging/denial, „rumbly vs buzzy"
  (niskie częstotliwości = głębsze doznanie), zabawki na podciśnienie i air-pulse,
  zabawy temperaturą, hands-free (mocowanie/ujazd), multi-orgazm i refrakcja,
  dobór rozmiaru do anatomii, ile i jakiego żelu, techniki oddechowe.
- **Bezpieczeństwo, ale praktyczne**: matryca materiałów, czyszczenie/sterylizacja
  (wrzątek, rozcieńczony wybielacz, IPA, UV), objawy infekcji, nerwy przy
  długotrwałym nacisku, izolacja elektryczna w maszynach DIY, narzędzia do
  sondowania, limity obciążników, „jak przetestować nową zabawkę".
- **Sourcing po polsku**: nazwy części + gotowe frazy do AliExpress/Amazon.pl.

Wdrożenie: nowe wpisy w `src/chloe-lorebook.txt` (PL/EN keywords) **albo osobny
lorebook** (drugi URL w `loreBookUrls`) + blok promptu. Osobny plik = nie zaśmieca
retrievalu wiedzy erotycznej i ładuje się tylko, gdy temat dotyczy sprzętu.
Koszt: średni (głównie pisanie treści), zerowe ryzyko techniczne.

### R10 — Tempo i koszt (realna bolączka lokalnego modelu) — ✅ WDROŻONE
Prefill 8B na obecnym sprzęcie to ~200 s na odpowiedź. Game changer użytkowy:
(a) agresywna kompresja promptu (stan zamiast pełnej historii — R1 to już daje),
(b) struktura promptu **przyjazna cache** (stały prefiks → zmienny stan na końcu;
społeczność mierzy do 90%+ trafień cache), (c) „szybki preset" do zwykłych scen
vs „pełny" do kluczowych, (d) `--gpulayers 99` po stronie PC.
Koszt: mały–średni.

### R11 — Eksport sceny + immersja — ✅ WDROŻONE
`/eksport` → cała scena jako sformatowane opowiadanie (Markdown/HTML, upload-plugin),
karta sceny (lokacja/czas/strój/stan) nad czatem, obraz do sceny generowany
w odpowiednim momencie (pipeline już jest). **TTS pozostaje usunięty** — nie
przywracać bez prośby.
Koszt: mały.

### R12 — Ekstra: tryb „scenariusz" (długi łuk fabularny) — ✅ WDROŻONE
`/kampania start` → Chloe planuje wielotygodniowy łuk (rozdziały, punkty zwrotne,
odblokowania), zapisuje plan w stanie i realizuje go beat po beat (R2). Daje „coś
do roboty" na dziesiątki tur. Koszt: średni.

---

## Rekomendowana pierwsza paczka

`R0` (Twoje polecenie) + `R9` (Twoje polecenie) + `R1` + `R6` + `R4`.

Powód: R0 i R9 są zamówione; R1 daje skok „pamięci/realności" natychmiast i jest
fundamentem R2/R7/R12; R6 to esencja „pełnego erotycznego RP"; R4 jest tanie,
a poprawia adherencję wszystkich pozostałych. Druga paczka: `R3` + `R2` + `R5`
(personalizacja i jakość), trzecia: `R7` + `R12` + `R8` (długi łuk, wiele postaci).

---

## Źródła (research społeczności)

- r/SillyTavernAI — top wszech czasów i wyszukiwania: „Freaky Frankenstein 5.0 —
  Internal States!" (presety z jawnym stanem), „FF 5.2/5.4 — cache hits, mniej
  therapy talk, echo killed", „Hawthorne — The Living Simulation Preset ... mutates
  every turn", „MVU Game Maker — Persistent Multi-Char Stats tracking",
  „8 prose dials", „Waidrin / DRY / XTC", „Guided Generations".
- r/DIYsextoys — „I successfully cast a Platinum Silicone balloon" (części 1–2:
  druk SLA, forma, odlew), „Fuck stool", „DIY: Fleshlight, a drill, PVC and some
  wood", „My fuck machine", „Suction+Contraction", motory/łączniki do maszyn
  (M8×1.25, 3XLR, vac-u-lock, złączka 3/8" „30 series"), „3d printed chastity
  design", „Safety concerns on DIY plug", mody strokerów (rura + rękaw) i
  wibratorów, „modifying this dirt cheap stroker... xToys app".
- Metody ST potwierdzone wcześniej w `src/README.md` (Visual Impression, blok
  Speech/Voice, długość w słowach blisko odpowiedzi, sekrety poza kontekstem).
