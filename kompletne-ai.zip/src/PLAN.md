# PLAN ulepszeń — Chloe (asystentka do wyszukiwania treści NSFW)

Data: 2026-09-12. Ten plik to **lista do wyboru**. Wdrażamy dopiero to, co
zaznaczy użytkownik. Każda pozycja ma ID (np. `B3`), opis, uzasadnienie i koszt.

Baseline (co już działa): multi-source live search z rejestrem **18 źródeł**
(tube: Redtube, porn.com, Xozilla, SunPorno, TNAFlix, Pornhub, YouPorn, Porntrex,
SpankBang, RedGIFs; metasearch: nudevista; hentai: nhentai API, e-Hentai, 3Hentai;
furry: e621; web: Bing RSS en+pl; społeczność: Reddit przez redlib.catsarch.com),
Wikipedia + czytanie stron, karty wyników 2.0 (miniatury/badge/czas trwania),
konsola wyszukiwania + live pasek postępu (D1/D3/D4), własny model przez OpenRouter
(E2), ekspansja zapytań PL→EN (słownik + model), komendy `/panel`, `/search`,
`/reddit`, `/wiki`, `/pref`, `/pomoc`, lorebook (~150 haseł), anti-refusal, chipsy
akcji. TTS: **usunięty** (patrz A1).

---

## A. Sprzątanie / decyzje podjęte

- **A1 — Usunięcie TTS. ✅ WYKONANE.** Z custom code usunięto: `chloeVoiceEnabled`,
  `chloeSetVoice`, `chloePickVoice`, `chloeSpeak`, `chloeHandleVoice`,
  `CHLOE_SPEECH_VOICE`, handler `oc.thread.on("StreamingMessage")`, komendę
  `/voice`, wpis w help i przycisk `🔊 głos`. Zweryfikowane w podglądzie (help
  bez wzmianki o głosie, brak błędów).

---

## B. Rozbudowa źródeł wyszukiwania

Wszystkie poniższe przetestowane na żywo (przez `root.superFetch`, realny proxy
perchance). Podział na paczki do wyboru.

### Zweryfikowane i DZIAŁA (HTTP 200 + treść)
| Kategoria | Źródła |
|---|---|
| Tube video | Redtube, porn.com, xozilla, SunPorno, TNAFlix, SxyPrn, Txxx, Sextb, Porn300, AlohaTube, HQporner (+ już: Pornhub, YouPorn, SpankBang, Porntrex) |
| Hentai / doujin | **nhentai API v2 (JSON)**, e-hentai, 3hentai (+ już: e621) |
| Booru / JSON API | danbooru (`posts.json`), (+ już: e621) |
| Galerie zdjęć | pornpics (już) |
| Metasearch | **nudevista** (jedno zapytanie = wiele tube'ów), Brave Search, Mojeek, Searx |
| Opowiadania / forum | Literotica, AdultDVDTalk |
| Społeczność | Reddit przez redlib (już) |

### Martwe / niestabilne (do pominięcia lub usunięcia)
xvideos, xnxx, xhamster, google, 4chan, missav, motherless, pornkai, rule34.xxx,
gelbooru (wymaga klucza), realbooru, safebooru, fapello (JS-cloak), letsjerk,
hanime (POST blokowany), ashemaletube, xxxbunker (geo), eporner (JS), coomer.

### Paczki
- **B1 — Tube video tier-1 (6 źródeł).** Redtube, porn.com, xozilla, SunPorno,
  TNAFlix, SxyPrn. Duże, szybkie, dobrze parsowalne listy z miniaturami.
- **B2 — Tube video tier-2 (5 źródeł).** Txxx, Sextb, Porn300, AlohaTube, HQporner.
- **B3 — Hentai / doujin (3 źródła).** nhentai API v2 (JSON, najpewniejsze),
  e-hentai, 3hentai. Uzupełnia e621 o mangi/doujinshi.
- **B4 — Booru / galerie zdjęć.** danbooru (JSON), pornpics (rozbudowane tagi),
  opcjonalnie hypnohub / konachan / imagefap.
- **B5 — Metasearch (duży zysk).** nudevista (agreguje wiele tube'ów jednym
  zapytaniem — świetne dla nisz/rzadkich fraz) + Brave/Mojeek jako ogólny fallback.
- **B6 — Opowiadania / fora.** Literotica (erotyka tekstowa), AdultDVDTalk (forum).
- **B7 — Nisze (opcjonalnie).** erome (albumy), thothub (leaki/OF), heavy-r,
  boundhub (BDSM), pornone/iceporn/anysex/porndig.
- **B8 — Sprzątanie źródeł.** Usunąć/oznaczyć niestabilne wpisy z obecnego kodu.

---

## C. Jakość i niezawodność wyszukiwania

- **C1 — Ekspansja zapytań PL→EN + synonimy/tagi.** Np. „pegging" → `strap-on`,
  `femdom`, `anal`, `prostate`; hentai → tagi. Generator wariantów (słownik +
  fallback AI). *Dlaczego:* polskie frazy dają słabe wyniki w angielskich bazach.
- **C2 — Re-ranking trafności.** Scoring tytuł+tagi (ważone dopasowanie, TF-IDF),
  zamiast kolejności źródła. Ewentualnie semantycznie (embeddingi).
- **C3 — Deduplikacja cross-source.** Po znormalizowanym URL + podobieństwie tytułu.
- **C4 — Cache wyników (TTL).** Mniej zapytań, szybsze powtórki, obchodzi
  rate-limit proxy.
- **C5 — Kolejka + retry/backoff + wyniki częściowe.** Koniec z „Failed to fetch"
  po ~15 zapytaniach; throttling i jitter.
- **C6 — Paginacja / „więcej wyników".** `/more` + licznik per źródło.
- **C7 — Routing wg intencji.** Dobór źródeł do typu: video / zdjęcia / opowiadanie
  / poradnik / dyskusja.
- **C8 — Niezawodne miniatury.** Cache/dataURL + fallbacki (koniec z 403 CDN).
- **C9 — Lepsze linki.** Bezpośrednie URL-e do filmów + „szukaj na stronie"
  fallback + linki embed.
- **C10 — Region/język i filtry.** pl/en, długość, HD, data.

---

## D. Interfejs (custom-code panel)

- **D1 — Konsola wyszukiwania (`oc.window.show()`). ✅ WYKONANE.** Wspólny panel
  (zakładki **Model** + **Wyszukiwanie**): filtry/przełączniki źródeł (18 źródeł,
  stan zapisany w `chloe_sources`), siatka wyników z miniaturami, historia
  (`chloe_search_history`), „Wczytaj wiecej". Wejście: `/panel`.
- **D2 — Historia + ulubione.** Historia wyszukiwań zrobiona (D1); ulubione — nie.
- **D3 — Karty wyników 2.0. ✅ WYKONANE.** Duże miniatury (150×84), badge źródła,
  czas trwania (Redtube/SunPorno/TNAFlix/nudevista), badge `GALERIA` dla hentai.
- **D4 — Pasek postępu wyszukiwania. ✅ WYKONANE.** Live pasek + chipy per źródło
  (✓/✗/…). W czacie działa w trybie własnego modelu (OpenRouter); w trybie natywnym
  appka blokuje aktualizacje wiadomości w trakcie handlera, więc tam pasek widać
  w konsoli, a nie w feedzie.
- **D5 — Żetony szybkich filtrów.** Kategorie/fetysze jednym kliknięciem.
- **D6 — Kopiuj wszystkie linki / eksport.** JSON/Markdown.
- **D7 — Zapisane wyszukiwania + link share.**
- **D8 — Tryb „deep dive".** Pobierz top strony, streszczaj, wyciągnij fakty + linki.

---

## E. Model / platforma (realia)

- **E1 — FAKT:** modelu czatu Perchance **nie da się zmienić** — API
  `text-generation.perchance.org` nie przyjmuje parametru modelu; `modelName` w
  kodzie jest niefunkcjonalny. (Nie jest to opcja, tylko ograniczenie.)
- **E2 — BYO klucz API (własny model przez OpenRouter / innego dostawcę).**
  Największy skok jakości: podmiana modelu czatu na nieocenzurowany. Szczegóły
  techniczne i warianty — patrz rozdział „E2 — rozbudowa" niżej.
- **E3 — Lokalny mały model w przeglądarce (WebGPU / transformers.js).** Prywatny,
  bez klucza, ale wolny/ciężki; na telefonie słabo.
- **E4 — Wymiana modelu embeddingów (realny, tani zysk).** Domyślny
  `Xenova/bge-base-en-v1.5` obsługuje **tylko angielski**, więc polskie lore/pamięć
  dopasowują się słabo. Zmiana na `Xenova/multilingual-e5-base` (lub `bge-m3`) +
  poprawka prefiksu zapytań (`index.html` ~7870) → dużo lepsza trafność wiedzy.

---

## F. Wiedza / kontekst

- **F1 — Rozbudowa lorebooka.** Więcej haseł + aliasy PL/EN (encyklopedia fetyszy).
- **F2 — Źródła wiedzy praktycznej/bezpieczeństwa** obok pornografii (Wikipedia,
  Scarleteen, Planned Parenthood…). Realna wartość jakościowa.
- **F3 — Auto-notatki.** Zapamiętywanie linków i upodobań z rozmowy.
- **F4 — Prompt wyszukiwarki.** Lepsze instrukcje doboru i opisu wyników.

---

## G. Pluginy — ustalenie

Perchance **nie ma** pluginu wyszukiwania (sprawdzono oficjalny katalog `plugins`,
80 pozycji — tylko super-fetch / ai-text / text-to-image). Nie ma więc czego
adoptować; wyszukiwanie musi zostać custom code. Opcjonalnie można dodać do
projektu: `kv-plugin` (historia/ulubione), `upload-plugin` (hosting miniatur/
eksportów) — ale to kosmetyka.

---

## Rekomendacja (moja, ranking wg realnej wartości)

1. **C5 + C4 — niezawodność (najwyższy priorytet).** Dziś wyszukiwanie sypie się
   („Failed to fetch”) po ~15 zapytaniach przez rate-limit proxy. Kolejka +
   retry/backoff + wyniki częściowe + cache TTL = koniec tego problemu. Bez tego
   reszta ulepszeń ma mały sens, bo funkcja po prostu bywa niedostępna.
2. **C1 — ekspansja zapytań PL→EN + synonimy.** Aplikacja jest używana po polsku,
   a bazy są angielskie — bez tego wyniki są słabe. Największy skok jakości za
   najmniejsze pieniądze (słownik + fallback AI). Świetnie łączy się z `C7`.
3. **B5 + B1 + B3 — pokrycie źródeł.** `B5` (nudevista — jedno zapytanie agreguje
   wiele tube'ów) to najlepszy pojedynczy zakup; `B1` dodaje duże tube'y, `B3`
   hentai/doujin. Efekt widoczny od razu.
4. **C3 + C2 — jakość listy.** Deduplikacja cross-source i re-ranking trafności:
   mniej śmieci, lepsza kolejność.
5. **E4 — multilingual embeddingi.** Tanie, realne: polskie lore/pamięć zaczną się
   dobrze dopasowywać (obecny model obsługuje tylko angielski).
6. **E2 — własny model (największy sufit).** Patrz `src/MODELS.md`. Największy skok
   jakości czatu, ale też największa praca/ryzyko (traci natywną pamięć/lore,
   brak streamingu przez proxy) → wdrażać jako tryb **opcjonalny** z fallbackiem,
   najlepiej razem z `E4`.
7. **D1 + D3 + D4 — konsola/UX.** Miłe, ale obecne karty działają; robić po
   powyższych, jeśli zależy na wygodzie.
8. `B6`, `B7`, `F1`, `F2`, `C6`–`C10`, `D2`, `D5`–`D8` — wypełniacze na później.

**Proponowana paczka na teraz:** `C5`, `C4`, `C1`, `C3`, `B5`, `B1`, `B3`, `E4`.
`E2` jest już zrobione (patrz status wyżej). `D1` + `D3` + `D4` też są już zrobione
(patrz rozdział D) — dostosowane do trybu własnego modelu (OpenRouter).

Aby zlecić wdrożenie — wystarczy podać ID, np.: „wdroż C4, C5, C1, B5, B1, B3, E4".

---

# E2 — rozbudowa: własny, nieocenzurowany model przez API użytkownika

> **STATUS: ZAIMPLEMENTOWANE** (patrz `src/README.md` → „The `E2` own-model mode").
> Zrobione jako tryb opcjonalny, domyślnie wyłączony: panel `/model`, komendy
> `/model on|off|test`, obsługa klucza OpenRouter (lub dowolnego endpointu
> OpenAI-compatible), wstrzykiwanie lorebooka, fallback natywny + powiadomienie,
> mostek postMessage do localStorage (sandbox = opaque origin), hook diagnostyczny
> `window.__chloeE2`. Zweryfikowane w live preview (ścieżka błędu + fallback).
> Niewdrożone z tego rozdziału: streaming przez proxy, profile per-wątek, licznik
> kosztów per model, integracja z `E4` (multilingual embeddingi).

Cel: podmienić model, który pisze odpowiedzi Chloe, na zewnętrzny LLM wybrany
przez użytkownika (nieocenzurowany, lepszy w polskim, konfigurowalny). Poniżej
wszystko sprawdzone w kodzie tej aplikacji.

## Dlaczego to w ogóle możliwe (mechanika appki)

1. **Modelu Perchance nie da się zmienić** — `getChatCompletion` (index.html:8290)
   woła `root.aiTextPlugin(...)`, a `getBotReply` (index.html:7377) nie przekazuje
   `modelName` do API. Parametr `modelName` jest martwy.
2. **Custom code `fetch` jest automatycznie proxowany** (index.html:10872 →
   `root.superFetch`) i **przekazuje POST, ciało JSON oraz nagłówek
   `Authorization`** — potwierdzone testem (`postman-echo` odesłał z powrotem i
   ciało, i `Authorization: Bearer ...`). To znaczy, że z custom code możemy wołać
   zewnętrzne API LLM bez problemów CORS.
3. **Można wyłączyć natywną odpowiedź i wstawić własną.** Przepływ wysyłania
   (index.html:10665) najpierw `await`-uje handlery custom code (`MessageAdded`),
   a dopiero potem woła `doBotReplyIfNeeded()`, które **nie odpowiada, jeśli
   ostatnia wiadomość ma `expectsReply === false`** (index.html:8494). Czyli:
   w handlerze `MessageAdded` ustawiamy user-message `expectsReply = false`,
   odpalamy własne API i po otrzymaniu tekstu wstawiamy
   `oc.thread.messages.push({author:"ai", content})`.
4. **Custom code widzi wszystko, co potrzebne do zbudowania promptu**
   (index.html:10745): `oc.character.roleInstruction`, `reminderMessage`,
   `initialMessages`, `stopSequences`, `maxTokensPerMessage`, `streamingResponse`,
   `customData`, `userCharacter` oraz pełną historię w `oc.thread.messages`.
   (Uwaga: `temperature`/`topP` postaci NIE są udostępniane — ale my i tak
   podajemy własne do zewnętrznego API.)
5. **Fallback jest darmowy**: `oc.getChatCompletion` / `oc.getInstructCompletion`
   (index.html:10969) to natywny model Perchance — jeśli zewnętrzne API zawiedzie
   (brak klucza, 429, limit), odpowiadamy natywnie, żeby czat nigdy nie „milczał".

## Jak to będzie działać (przepływ)

1. **Ustawienia**: panel (E2 + D1) — pole na klucz API, bazowy URL, nazwa modelu,
   temperatura, max tokenów. Zapis w `oc.thread.customData` (per-wątek) lub w
   `localStorage` iframe'a (per-przeglądarka, trwałe). Domyślnie OpenRouter.
2. **Przechwycenie tury**: w `MessageAdded` (gałąź user) ustawiamy
   `expectsReply = false`, pokazujemy wskaźnik „pisze…", i uruchamiamy wywołanie
   **bez await** (żeby nie blokować przepływu appki).
3. **Budowa promptu po naszej stronie**:
   - `messages[0]` = system: `roleInstruction` + lore/preferencje + info o userze.
   - historia: mapowanie `oc.thread.messages` → `[{role, content}]`
     (z pominięciem `hiddenFrom:"ai"`).
   - na końcu `reminderMessage` + wstrzyknięte preferencje.
4. **Wywołanie**: `POST {baseUrl}/chat/completions` z
   `{model, messages, temperature, max_tokens}` (format OpenAI-compatible).
5. **Wstawienie odpowiedzi**: `oc.thread.messages.push({author:"ai", content})` —
   appka sama zapisuje i renderuje; nasz `messageRenderingPipeline` (chipsy),
   `<search>`/`<image>` i tak dalej działają dalej.
6. **Błędy**: retry/backoff → fallback do `oc.getChatCompletion` (natywny model).

## Co zyskujemy, a co tracimy

- **Zysk:** wolny wybór modelu (nieocenzurowany, mocniejszy instrukcyjnie, lepszy
  polski), własna temperatura/długość, możliwość tanich providerów.
- **Strata (jeśli nie odtworzymy):** automatyczne **pamięci + retrieval lorebooka
  + auto-streszczenia** dzieją się wewnątrz `getBotReply`, które omijamy. Dla
  asystentki-wyszukiwarki to istotne (lorebook!), więc E2 wymaga:
  - MVP: wstrzyknięcie lorebooka do system-promptu (mamy go z `loreBookUrls`,
    ~32 KB — trzeba przyciąć / wyszukać trafne hasła),
  - docelowo: własny retrieval (słownikowy/embeddingowy) po hasłach lorebooka.
- Bez tego E2 najlepiej wdrożyć jako **tryb opcjonalny** (przełącznik
  „model: Perchance / własny"), żeby nie psuć natywnej pamięci, gdy klucz nie jest
  podany.

## Streaming — ograniczenie

Proxy zwraca **całą odpowiedź naraz** (`transferrableStreamsSupported = false`,
index.html:11585), więc prawdziwy streaming przez proxy nie działa. Opcje:
- **MVP:** brak streamingu + wskaźnik „pisze…" (najprostsze, niezawodne).
- **Pseudo-streaming:** pobierz całość, potem odsłaniaj tekst progresywnie (efekt UX).
- **Direct fetch:** bezpośrednio do providera (z pominięciem proxy), jeśli wysyła
  `Access-Control-Allow-Origin: *` (OpenRouter tak) — wtedy możliwy SSE streaming,
  ale trzeba to potwierdzić dla konkretnego providera.

## Prywatność / bezpieczeństwo klucza

- Klucz jest wpisywany przez użytkownika w runtime i trzymany lokalnie — **nie**
  trafia do publicznego źródła generatora.
- UWAGA: skoro `fetch` custom code idzie przez proxy Perchance, to **klucz
  przechodzi przez serwer proxy**. Jeśli to problem — tryb „direct” (bez proxy) do
  providera obsługującego CORS.
- Niektóre providery/upstreamy i tak moderują treści — wybrać takie bez moderacji.

## Providerzy (OpenAI-compatible, nadają się z przeglądarki)

- **OpenRouter** — ogromny wybór, w tym nieocenzurowane modele RP; pay-per-token;
  przyjazny CORS. Domyślny wybór.
- **Featherless.ai**, **Infermatic**, **Arli AI**, **Mancer**, **NanoGPT**,
  **DreamGen** — zorientowane na RP/NSFW.
- **Lokalnie (Ollama / LM Studio)**: OpenAI-compatible na `localhost` — ale w tej
  appce praktycznie odpada (https → http://localhost = mixed content; proxy nie
  dosięgnie komputera użytkownika). Chyba że przez https-tunel (ngrok itp.).

## Szacunek pracy / ryzyko

- **MVP** (ustawienia + przechwycenie tury + POST + fallback, bez streamingu,
  lorebook wstrzyknięty skrótowo): średnio-duży.
- **Pełne E2** (streaming, własny retrieval lore/pamięci, profile per-wątek,
  wielu providerów, licznik kosztów): duży.
- Ryzyko: średnie — głównie „obcięcie” natywnej pamięci/lore oraz zmienność
  providerów. Dlatego: tryb opcjonalny + fallback natywny.

## Rekomendacja dla E2

Wdrożyć jako **opcjonalny tryb** „własny model (OpenRouter)" z natychmiastowym
fallbackiem do modelu Perchance, domyślnie wyłączony. Najlepiej łącznie z `E4`
(multilingual embeddingi) dla natywnej ścieżki oraz z `D1`/`D2` (panel + historia)
jako wspólną konsolą ustawień.

**Wybór modelu → `src/MODELS.md`** (pełny research społeczności: RP-Bench/PlotPoints,
EuroEval Polish, OpenRouter API). Skrót: domyślnie `mistralai/mistral-small-2603`
(Mistral Small Creative — najlubiany w NSFW, najszybszy, tani), alternatywy:
`google/gemma-4-26b-a4b-it` (najlepszy polski wśród NSFW-lubianych, #1 engagement)
oraz `deepseek/deepseek-v4-flash` (najtańszy, 0% odmów).

**Opcje darmowe / HF PRO →** patrz `src/MODELS.md`, rozdział „Darmowe opcje":
OpenRouter `:free` ($0, limit 50/dzień), HF router z providerem `:featherless-ai`
($2/mies. kredytów PRO, nieocenzurowane finetune'y), własny CPU Space (darmo, wolno),
lokalny WebGPU. Uwaga: HF PRO daje $2/mies., nie $9.
