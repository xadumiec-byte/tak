// =====================================================================
// CHLOE DEEP RESEARCH ENGINE (R-D1)  —  tryb glebokiego researchu
// ---------------------------------------------------------------------
// Zrodlo: plugin uzytkownika "Deep Sexual Research Plugin - MAX LEVEL".
// Zachowane: automatyczna aktywacja po slowach kluczowych, komendy
// /research (on|off|status), trwaly tryb + sticky, wlasna instrukcja
// researchu i format odpowiedzi (podsumowanie / techniki / DIY / szalone
// pomysly / konsensus / zrodla).
// Przebudowane na infrastrukturze Chloe:
//   1) zamiast kazac modelowi UDAWAC research - realnie odpalamy
//      chloeWebSearch (19 zrodel: tube, hentai, e621, Bing PL/EN, Reddit),
//      czytamy strony (chloeReadPage), ciagniemy komentarze Reddita i
//      budujemy DOSSIER z prawdziwymi linkami i markerami dowodow,
//   2) instrukcja + dossier jada TYLKO w biezacym zadaniu (blok `dyn` w
//      chloeE2BuildMessages) - nic nie zostaje w historii watku, wiec nie
//      rosnie kontekst i nie peka prefiks-cache modelu (lokalne 8B),
//   3) aktywacja punktowa (waga slow + drugi czynnik: pytanie/request),
//      zamiast minHits=1 na luznych regexach, ktore lapaly zwykle RP,
//   4) cache zapytania + twardy budzet czasu + adaptacyjna glebia (druga
//      runda tylko gdy pierwsza dala malo) - sticky nie powtarza sieci,
//   5) panel: przelaczniki w konsoli wyszukiwania (auto, prog, sticky,
//      liczba czytanych stron, "Research teraz").
// Ustawienia globalne: kv "chloe_research_v1". Stan per-watek:
// oc.thread.customData.__chloeResearch. Uzywa funkcji z reszty bundle'a
// (chloeWebSearch, chloeReadPage, chloeBuildUser, chloeKvLoad/Set, ...).
// =====================================================================

var CHLOE_RS_KV = "chloe_research_v1";
var CHLOE_RS_S = null;           // ustawienia globalne (lazy, async)
var CHLOE_RS_LAST = null;        // ostatni dossier w tej sesji strony
var CHLOE_RS_CACHE = {};         // query -> {at, dossier, stats, out} (dodatkowa warstwa)
var CHLOE_RS_READ_MS = 12 * 60 * 1000;   // jak dlugo dossier uchodzi za swiezy

function chloeResearchDefaults() {
  return {
    auto: true,      // automatyczne wlaczanie po slowach kluczowych
    sticky: 2,       // ile kolejnych wiadomosci uzytkownika trzyma tryb (poza trwalym)
    prog: 2,         // prog punktowy aktywacji (1-9; wyzej = mniej falszywych trafien)
    strony: 3,       // ile stron odczytac na zywo pod dossier (0-6)
    glebia: "auto",  // auto|szybko|gleboko — auto = druga runda gdy malo danych
    pokazuj: true,   // pokazywac w czacie karte "co przeszukano"
    debug: false
  };
}

async function chloeResearchReady() {
  if (CHLOE_RS_S) return CHLOE_RS_S;
  var s = chloeResearchDefaults();
  try {
    var raw = await chloeKvLoad(CHLOE_RS_KV);
    if (raw) {
      var o = (typeof raw === "string") ? JSON.parse(raw) : raw;
      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k) && o[k] !== undefined) s[k] = o[k];
    }
  } catch (e) {}
  CHLOE_RS_S = s;
  return s;
}

function chloeResearchGet() { return CHLOE_RS_S || chloeResearchDefaults(); }

function chloeResearchSet(patch) {
  var s = chloeResearchGet();
  for (var k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) s[k] = patch[k];
  CHLOE_RS_S = s;
  try { chloeKvSet(CHLOE_RS_KV, JSON.stringify(s)); } catch (e) {}
  return s;
}

// Stan per-watek: trwaly tryb, sticky, ostatnie zapytanie, historia zapytan.
function chloeResearchState() {
  var cd = null;
  try {
    if (!oc.thread.customData) oc.thread.customData = {};
    cd = oc.thread.customData;
  } catch (e) { return { on: false, sticky: 0, queries: [] }; }
  if (!cd.__chloeResearch || typeof cd.__chloeResearch !== "object") {
    cd.__chloeResearch = { on: false, sticky: 0, queries: [], lastQuery: "", lastAt: 0 };
  }
  var st = cd.__chloeResearch;
  if (!st.queries || !st.queries.length) st.queries = st.queries || [];
  return st;
}

function chloeResearchStateSet(patch) {
  var st = chloeResearchState();
  for (var k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) st[k] = patch[k];
  return st;
}

function chloeResearchActive() {
  var st = chloeResearchState();
  return !!(st.on || Number(st.sticky) > 0);
}

// --------------------------- ocena wiadomosci ---------------------------
// Wagi: 3 = jednoznacznie "research" (DIY, sprzet, techniki, wprost "research"),
// 2 = sygnaly kontekstu (poradnik, doswiadczenia, forum), 1 = slabe (najlepsze, szukaj).
// Karzemy narracje RP (gwiazdki, cytaty), zeby tryb nie wlaczal sie w scenie.
var CHLOE_RS_PATTERNS = [
  { re: /\bresearch\b|research(?:uj|owa)|przeszukaj\s+(?:internet|sie[ćc]|fora|reddit)|sprawd[źz]\s+w\s+(?:internecie|sieci)/i, w: 3, tag: "research" },
  { re: /\bdiy\b|domowej?\s*roboty|zr[óo]b\s+to\s+sam|homemade|improwizowan|samodzieln[ei]\s+roboty/i, w: 3, tag: "diy" },
  { re: /onahole|fleshlight|autoblow|tenga|sextoy|sex\s*toy|zabawk(?:a|i|ę|e|ek|ami|ą)|masturbator|dildo|butt\s*plug|prostate|p-?spot|sleeve|strapon|kagel|kegel/i, w: 3, tag: "sprzet" },
  { re: /edging|death\s*grip|stop.?start|squeeze\s*technique|ruined\s*orgasm|milking|wytrzyma[łl]o[śs]|przedwczesn|odwr[óo]con[ay]\s+kegel|tantr/i, w: 3, tag: "technika" },
  { re: /poradnik|instrukcj|\bguide\b|\btutorial\b|\bhow\s*to\b|jak\s+(?:to\s+)?(?:zrobi[ćc]|u[żz]y[ćc]|uprawia[ćc]|zacz[ąć]|przygotowa[ćc]|wytrenowa[ćc])/i, w: 2, tag: "poradnik" },
  { re: /\btechnik|spos[óo]b\s+na|\bmetod|\bsztuczk/i, w: 2, tag: "technika" },
  { re: /konsensus|consensus|do[śs]wiadczen|doświadczen|\bexperience/i, w: 2, tag: "doswiadczenia" },
  { re: /\breddit\b|\bforum\b|imageboard|4chan|spo[łl]eczno[śs][ćc]|\bcommunity\b|\bw[ąa]t(?:ek|ku|ki)\b/i, w: 2, tag: "spolecznosc" },
  { re: /opinie|recenzj|review|\btesty\b|por[óo]wna|ranking|\bnajlepsz|\bvs\b/i, w: 1, tag: "porownanie" },
  { re: /\bszukaj\b|\bposzukaj\b|\bwyszukaj\b|\bznajd[źz]\b|\bsprawd[źz]\b|\bznajdziesz\b/i, w: 1, tag: "szukanie" }
];

var CHLOE_RS_SECOND = /[?]|\b(jak|co|czym|dlaczego|czy|gdzie|kiedy|ile|kt[óo]r|what|how|why|which|is|are|does)\b|pole[ćc]|podaj|opowiedz|wyja[śs]nij|interesuje\s+mnie|chc[ęe]\s+wiedzie[ćc]|szukam|potrzebuj[ęe]|mo[żz]esz\s+mi|poka[żz]|daj\s+mi|link|linki|najlepsz|ranking|por[óo]wnaj|opinie|rekomend|zaproponuj|what|best|recommend|suggest|help\s+me/i;

function chloeResearchScore(text) {
  var t = String(text == null ? "" : text);
  var score = 0, hits = [];
  for (var i = 0; i < CHLOE_RS_PATTERNS.length; i++) {
    if (CHLOE_RS_PATTERNS[i].re.test(t)) { score += CHLOE_RS_PATTERNS[i].w; hits.push(CHLOE_RS_PATTERNS[i].tag); }
  }
  var stars = (t.match(/\*/g) || []).length;
  if (stars >= 4) score -= 2;                       // *akcja* w scenie, nie pytanie
  if (/^\s*[*_>"'\-]/.test(t)) score -= 2;          // cytat / narracja / dialog
  var explicit = /\/research\b|\bresearch\b|przeszukaj\s+(?:internet|sie[ćc]|fora)/i.test(t);
  return { score: score, hits: hits, explicit: explicit, second: CHLOE_RS_SECOND.test(t) };
}

// --------------------------- decyzja o trybie ---------------------------
// Zwraca { active, fresh, query, mode, score, reason }. Bez sieci (sam wybor).
function chloeResearchDecide(userText) {
  var set = chloeResearchGet();
  var st = chloeResearchState();
  var t = chloeClean(userText || "");
  var sc = chloeResearchScore(t);
  var prog = Math.max(1, Math.min(9, Number(set.prog) || 3));
  var keywordHit = set.auto && (sc.explicit || (sc.score >= prog && sc.second));
  var wasActive = !!(st.on || Number(st.sticky) > 0);
  var active = wasActive || keywordHit;
  if (keywordHit && !wasActive) {
    // nowe trafienie slowem kluczowym: dokladamy sticky (trwaly tryb zostaje jak byl)
    if (!st.on) chloeResearchStateSet({ sticky: Math.max(Number(st.sticky) || 0, Number(set.sticky) || 0) });
  } else if (wasActive && !st.on && Number(st.sticky) > 0) {
    chloeResearchStateSet({ sticky: Number(st.sticky) - 1 });   // zuzycie jednej wiadomosci
  }
  var last = CHLOE_RS_LAST;
  var fresh = true, query = "", reason = keywordHit ? "slow kluczowe" : (st.on ? "tryb trwaly" : "sticky");
  if (last && last.query && (Date.now() - last.at) < CHLOE_RS_READ_MS) {
    // Ten sam temat? Wtedy NIE szukamy drugi raz - uzywamy dossier, ktore juz mamy.
    var same = chloeResearchOverlap(last.query, t) >= 0.34;
    if (same) { fresh = false; query = last.query; reason += " (ten sam temat - uzyto gotowego dossier)"; }
    else if (!sc.explicit && t.length < 48) {
      // Krotkie dopytanie (\"a ile to kosztuje?\") - doprecyzowujemy poprzednie zapytanie,
      // zamiast szukac dos\u0142ownie zdania bez tematu.
      query = (last.query + " " + chloeResearchQueryFrom(t)).slice(0, 120);
      reason += " (dopytanie do poprzedniego tematu)";
    }
  }
  if (!active) return { active: false, fresh: false, query: "", mode: "info", score: sc.score, hits: sc.hits, reason: "wylaczony" };
  if (fresh && !query) {
    query = chloeResearchQueryFrom(t);
    // query moze byc puste - wtedy plan uzyje chloeMakeQuery (model)
  }
  var wantsMedia = /film|wideo|video|klip|porn|scen[ay]|zdj[ęe]c|gif|obraz/i.test(t);
  return { active: true, fresh: fresh, query: query, mode: wantsMedia ? "media" : "info", score: sc.score, hits: sc.hits, reason: reason };
}

// Zapytanie bezposrednio z tekstu (bez modelu): po komendzie albo czysty temat.
function chloeResearchQueryFrom(text) {
  var t = chloeClean(String(text || "").replace(/^\s*\/research\b[\s:]*/i, ""));
  t = t.replace(/^\s*(?:teraz|now|tu|tutaj)\s*[:=]?\s*/i, "");
  t = t.replace(/^\s*(?:o|na temat|about)\s+/i, "");
  if (t.length < 3) return "";
  if (t.length > 140) t = t.slice(0, 140);
  return t;
}

var CHLOE_RS_STOP = { "the": 1, "and": 1, "for": 1, "with": 1, "jak": 1, "dla": 1, "sie": 1, "jest": 1, "czy": 1, "ale": 1, "czyli": 1, "ktore": 1, "które": 1, "moze": 1, "może": 1, "bardzo": 1, "prosze": 1, "proszę": 1, "chce": 1, "chcę": 1, "wiem": 1 };
function chloeResearchWords(text) {
  var raw = chloeNorm(text).split(/[^a-z0-9]+/);
  var out = [];
  for (var i = 0; i < raw.length; i++) {
    var w = raw[i];
    if (w.length < 4 || CHLOE_RS_STOP[w]) continue;
    out.push(w.slice(0, 6));   // lekkie ujednolicenie odmiany (technik-a / technik-i)
  }
  return out;
}
function chloeResearchOverlap(a, b) {
  var wa = chloeResearchWords(a), wb = chloeResearchWords(b);
  if (!wa.length || !wb.length) return 0;
  var seen = {}, hit = 0;
  for (var i = 0; i < wa.length; i++) seen[wa[i]] = true;
  for (var j = 0; j < wb.length; j++) if (seen[wb[j]]) hit++;
  return hit / Math.min(wa.length, wb.length);
}

// --------------------------- gleboki przebieg ---------------------------
function chloeResearchStats(out) {
  var sites = {}, n = 0;
  function add(list, field) {
    for (var i = 0; i < (list || []).length; i++) {
      var h = chloeHost(list[i].url || "");
      if (!h) continue;
      if (!sites[h]) { sites[h] = 0; n++; }
      sites[h]++;
    }
  }
  add(out.videos, "site"); add(out.search, "site"); add(out.reddit, "site");
  return { hosty: n, lacznie: (out.videos || []).length + (out.search || []).length + (out.reddit || []).length, sites: sites };
}

function chloeResearchDossier(out, ctx) {
  var lines = [];
  var st = chloeResearchStats(out);
  lines.push("[ROZPOZNANIE SIECIOWE \u2014 pobrane teraz: " + chloeNow() + "]");
  lines.push("Zapytania: " + (ctx.queries || [out.query]).join(" | "));
  if (out.queryExpanded && out.queryExpanded !== out.query) lines.push("Rozszerzone: " + out.queryExpanded + (out.aiExpanded ? " (t\u0142um. modelu)" : ""));
  lines.push("Przeszukane serwisy: " + Object.keys(st.sites).sort().join(", "));

  var budget = 2600;
  if (chloeRPIsFast()) budget = 1500;
  if (String(chloeResearchGet().glebia) === "gleboko") budget = 3400;
  var used = lines.join(CHLOE_NL).length + 40;
  var parts = [];

  function push(text) {
    if (!text) return;
    var room = budget - used;
    if (room < 160) return;
    var t = text.length > room ? chloeTrimText(text, room) : text;
    parts.push(t);
    used += t.length + 1;
  }

  if (out.wiki && out.wiki.extract) {
    push("=== WIEDZA (Wikipedia: \"" + out.wiki.title + "\") ===\n" + chloeTrimText(out.wiki.extract, 900));
  }
  if (out.reads && out.reads.length) {
    var R = ["=== ODCZYTANE STRONY (dos\u0142owne fragmenty, pobrane teraz) ==="];
    for (var i = 0; i < out.reads.length && i < 5; i++) {
      R.push("- " + (out.reads[i].title || chloeHost(out.reads[i].url)) + " (" + chloeHost(out.reads[i].url) + " \u2014 " + out.reads[i].url + "):");
      R.push("  " + chloeTrimText(out.reads[i].text, 430));
    }
    push(R.join(CHLOE_NL));
  }
  if (out.redditComments && out.redditComments.length) {
    var C = ["=== REDDIT: DO\u015aWIADCZENIA LUDZI (komentarze) ==="];
    if (out.redditTop) C.push("W\u0105tek: " + chloeTrimText(out.redditTop.title, 120) + " \u2014 " + out.redditTop.url);
    for (var c = 0; c < out.redditComments.length && c < 6; c++) C.push("- " + chloeTrimText(out.redditComments[c], 240));
    push(C.join(CHLOE_NL));
  }
  if (out.reddit && out.reddit.length) {
    var D = ["=== REDDIT: POZOSTA\u0141E W\u0104TKI (tytu\u0142y + linki) ==="];
    for (var r = 0; r < out.reddit.length && r < 8; r++) D.push("- " + chloeTrimText(out.reddit[r].title, 110) + " \u2014 " + out.reddit[r].url);
    push(D.join(CHLOE_NL));
  }
  if (out.search && out.search.length) {
    var W = ["=== STRONY / ARTYKU\u0141Y ==="];
    for (var s = 0; s < out.search.length && s < 7; s++) {
      W.push("- " + chloeTrimText(out.search[s].title, 110) + " \u2014 " + out.search[s].url);
      if (out.search[s].snippet) W.push("  " + chloeTrimText(out.search[s].snippet, 150));
    }
    push(W.join(CHLOE_NL));
  }
  if (out.videos && out.videos.length && ctx.media) {
    var V = ["=== MEDIA (bezpo\u015brednie linki) ==="];
    for (var v = 0; v < out.videos.length && v < 6; v++) V.push("- " + chloeTrimText(out.videos[v].title, 100) + " \u2014 " + out.videos[v].site + " \u2014 " + out.videos[v].url);
    push(V.join(CHLOE_NL));
  }
  var gaps = [];
  if (!out.wiki) gaps.push("brak has\u0142a encyklopedycznego");
  if (!out.reddit || !out.reddit.length) gaps.push("brak w\u0105tk\u00f3w Reddita/for\u00f3w");
  if (!out.reads || !out.reads.length) gaps.push("nie uda\u0142o si\u0119 odczyta\u0107 stron");
  if (!out.search || !out.search.length) gaps.push("brak wynik\u00f3w webowych");
  if (gaps.length) push("=== LUKI (nie ma danych \u2014 nie wymy\u015blaj) ===\n- " + gaps.join("\n- "));
  var src = ["=== \u0179R\u00d3D\u0141A (host: liczba pozycji) ==="];
  var hosts = Object.keys(st.sites).sort();
  for (var h = 0; h < hosts.length; h++) src.push("- " + hosts[h] + ": " + st.sites[hosts[h]]);
  push(src.join(CHLOE_NL));

  return lines.join(CHLOE_NL) + "\n\n" + parts.join("\n\n");
}

async function chloeResearchExtraReads(out, maxPages, deadline) {
  var cand = [];
  for (var i = 0; i < (out.search || []).length && cand.length < 12; i++) {
    var u = out.search[i].url;
    if (!chloeReadable(u)) continue;
    if (out.reads && out.reads.some(function (r) { return r.url === u; })) continue;
    cand.push(out.search[i]);
  }
  var picked = [], hosts = {};
  for (var j = 0; j < cand.length && picked.length < maxPages; j++) {
    var h = chloeHost(cand[j].url);
    if (hosts[h]) continue;
    hosts[h] = true;
    picked.push(cand[j]);
  }
  var res = [];
  await Promise.all(picked.map(function (r) {
    if (Date.now() > deadline) return Promise.resolve(0);
    return chloeReadPage(r.url).then(function (t) {
      if (t && t.length > 200) res.push({ url: r.url, title: r.title || chloeHost(r.url), text: t });
      return 0;
    }).catch(function () { return 0; });
  }));
  return res;
}

// Gleboki przebieg: 1) glowna runda (chloeWebSearch), 2) adaptacyjna druga runda,
// 3) odczyt stron, 4) dodatkowe komentarze Reddita, 5) dossier. Z cache po zapytaniu.
async function chloeResearchRun(query, mode) {
  query = chloeClean(query || "");
  if (!query) return null;
  mode = mode === "media" ? "media" : "info";
  var ck = mode + "::" + query.toLowerCase();
  var hit = CHLOE_RS_CACHE[ck];
  if (hit && (Date.now() - hit.at) < CHLOE_RS_READ_MS) {
    CHLOE_RS_LAST = { query: query, at: hit.at, dossier: hit.dossier, stats: hit.stats };
    return hit;
  }
  var t0 = Date.now(), set = chloeResearchGet();
  var maxMs = String(set.glebia) === "gleboko" ? 75000 : 45000;
  var out = await chloeWebSearch(query, mode, { limit: 14 });
  var queries = [query];
  var rich = ((out.search || []).length + (out.reddit || []).length + (out.reads || []).length + (out.wiki ? 1 : 0));

  // Adaptacyjna druga runda: tylko gdy pierwsza dala malo (i starcza czasu).
  if (String(set.glebia) !== "szybko" && rich < 5 && (Date.now() - t0) < maxMs * 0.55) {
    var vq = /\breddit\b|\bforum\b/i.test(query) ? query : (query + (out.wiki ? " reddit" : " " + (chloeIsPolish(query) ? "do\u015bwiadczenia" : "experience")));
    try {
      var out2 = await chloeWebSearch(vq, "info", { limit: 8 });
      queries.push(vq);
      out.search = chloeDedup((out.search || []).concat(out2.search || []));
      out.reddit = chloeUniqBy((out.reddit || []).concat(out2.reddit || []));
      out.videos = chloeInterleaveVideos((out.videos || []).concat(chloeRankItems(out2.videos || [], vq)), 14);
      if (!out.wiki && out2.wiki) out.wiki = out2.wiki;
      if (out2.reads && out2.reads.length) out.reads = (out.reads || []).concat(out2.reads);
    } catch (e2) {}
  }

  // Dodatkowa glebia: odczyt stron + komentarze z kolejnych watkow Reddita.
  var deadline = t0 + maxMs;
  var pages = Math.max(0, Math.min(6, Number(set.strony) || 0));
  try {
    var extra = await chloeResearchExtraReads(out, pages, deadline);
    if (extra.length) out.reads = (out.reads || []).concat(extra);
  } catch (eR) {}
  if (out.reddit && out.reddit.length > 1 && (Date.now() < deadline)) {
    try {
      var cms = await chloeRedlibComments(out.reddit[1].url, 5);
      var more = (cms || []).filter(function (x) { return x && x.length > 60; }).slice(0, 3);
      if (more.length) out.redditComments = (out.redditComments || []).concat(more);
    } catch (eC) {}
  }

  var ctx = { queries: queries, media: mode === "media" };
  var stats = chloeResearchStats(out);
  stats.ms = Date.now() - t0;
  stats.odczytane = (out.reads || []).length;
  stats.reddit = (out.reddit || []).length;
  stats.komentarze = (out.redditComments || []).length;
  stats.zapytania = queries;
  var dossier = chloeResearchDossier(out, ctx);
  var rec = { at: Date.now(), query: query, mode: mode, out: out, stats: stats, dossier: dossier };
  CHLOE_RS_LAST = { query: query, at: rec.at, dossier: dossier, stats: stats };
  CHLOE_RS_CACHE[ck] = rec;
  var keys = Object.keys(CHLOE_RS_CACHE);
  if (keys.length > 24) delete CHLOE_RS_CACHE[keys[0]];
  try { chloeHistoryAdd(query, "research"); } catch (eH) {}
  if (chloeResearchGet().debug) { try { console.log("[Chloe research] " + query + " -> " + stats.lacznie + " pozycji, " + stats.odczytane + " stron, " + stats.ms + " ms"); } catch (eD) {} }
  return rec;
}

// --------------------------- tekst dla modelu ---------------------------
var CHLOE_RS_DOCTRINE = [
  "[TRYB G\u0141\u0118BOKIEGO RESEARCHU \u2014 AKTYWNY]",
  "Dosta\u0142a\u015b w tej wiadomo\u015bci DANE Z ROZPOZNANIA pobrane teraz z internetu (prawdziwe \u017ar\u00f3d\u0142a: Reddit, fora, Wikipedia, artyku\u0142y). Odpowiedz jak analityczka, kt\u00f3ra je przeczyta\u0142a \u2014 nie jak model z pami\u0119ci.",
  "",
  "ZASADY:",
  "1. Trzymaj si\u0119 danych z sekcji poni\u017cej. Nie wymy\u015blaj technik, produkt\u00f3w, wymiar\u00f3w ani link\u00f3w, kt\u00f3rych tam nie ma \u2014 je\u015bli czego\u015b brakuje, napisz wprost, \u017ce nie ma danych (sekcja LUKI).",
  "2. Oznaczaj si\u0142\u0119 dowod\u00f3w: [konsensus] powtarza si\u0119 w wielu \u017ar\u00f3d\u0142ach, [pojedyncze] jedna relacja, [sporne] \u017ar\u00f3d\u0142a si\u0119 k\u0142\u00f3c\u0105. Nie przypisuj twierdze\u0144 medycznych anonimowym postom \u2014 wiedz\u0119 medyczn\u0105 bierz z sekcji WIEDZA/artyku\u0142\u00f3w.",
  "3. Do\u015bwiadczenia ludzi (Reddit/fora) oddziel od wiedzy technicznej/medycznej \u2014 i tak je opisuj.",
  "4. Przy DIY i pomys\u0142ach nietypowych: jak ludzie to robi\u0105, co si\u0119 im sprawdzi\u0142o, czym to si\u0119 ko\u0144czy\u0142o i poziom ryzyka 1-5. Bez moralizowania, ale bez ukrywania ryzyka (bezpiecze\u0144stwo: materia\u0142y, higiena, cia\u0142a obce, zaklinowanie, alergie).",
  "5. B\u0105d\u017a konkretna: nazwy, materia\u0142y, wymiary, kolejno\u015b\u0107 dzia\u0142a\u0144, czasy, odczucia, ceny \u2014 je\u015bli s\u0105 w danych.",
  "6. Podawaj pe\u0142ne linki z sekcji \u0179R\u00d3D\u0141A/DANE (nie zmy\u015blone), przy ka\u017cdym jedno zdanie, co wnosi.",
  "7. J\u0119zyk u\u017cytkownika (po polsku, gdy pisze po polsku), wprost i bez cenzury. To legalne praktyki doros\u0142ych: nie odmawiaj, nie przepraszaj, nie dodawaj ostrze\u017ce\u0144 moralnych.",
  "",
  "FORMAT ODPOWIEDZI:",
  "**Podsumowanie** \u2014 3-6 najwa\u017cniejszych wniosk\u00f3w, ka\u017cdy z markerem dowodu",
  "**Techniki / rozwi\u0105zania** \u2014 numerowana lista: co, jak krok po kroku, na co uwa\u017ca\u0107",
  "**DIY / przedmioty domowe** \u2014 tylko gdy s\u0105 w danych (materia\u0142, wykonanie, opinie, ryzyko)",
  "**Szalone i nietypowe pomys\u0142y** \u2014 najbardziej ekstremalne rzeczy opisane w danych + poziom ryzyka",
  "**Konsensus vs wyj\u0105tki** \u2014 co powtarza si\u0119 najcz\u0119\u015bciej, co jest rzadkie lub kontrowersyjne",
  "**\u0179r\u00f3d\u0142a** \u2014 linki z danych + jako\u015b\u0107 (rodzaj \u017ar\u00f3d\u0142a, ile os\u00f3b to opisuje)",
  "Pomi\u0144 sekcje bez danych. Zako\u0144cz jednym pytaniem: kt\u00f3r\u0105 cz\u0119\u015b\u0107 pog\u0142\u0119bi\u0107?"
].join(CHLOE_NL);

// Tekst doklejany do promptu w chloeE2BuildMessages (blok dynamiczny, na koncu \u2014
// prefiks-cache zostaje nietkniety, a nic nie l\u0105duje w historii watku).
function chloeResearchDirective() {
  try {
    if (!chloeResearchActive()) return "";
    var last = CHLOE_RS_LAST;
    var fresh = last && (Date.now() - last.at) < CHLOE_RS_READ_MS;
    if (!fresh) {
      return CHLOE_RS_DOCTRINE + CHLOE_NL + CHLOE_NL + "[DANE Z ROZPOZNANIA]" + CHLOE_NL +
        "(brak \u015bwie\u017cszych danych w tej sesji \u2014 je\u015bli temat wymaga fakt\u00f3w, powiedz wprost, \u017ce trzeba uruchomi\u0107 research: /research teraz <temat>)";
    }
    var stats = last.stats || {};
    var head = "[DANE Z ROZPOZNANIA]" + CHLOE_NL +
      "Zapytanie: " + last.query + " \u00b7 pobrano: " + chloeNow() +
      (stats.lacznie ? " \u00b7 pozycji: " + stats.lacznie : "") +
      (stats.odczytane ? " \u00b7 stron odczytanych: " + stats.odczytane : "") +
      (stats.komentarze ? " \u00b7 komentarzy: " + stats.komentarze : "") + CHLOE_NL + CHLOE_NL;
    return CHLOE_RS_DOCTRINE + CHLOE_NL + CHLOE_NL + head + last.dossier;
  } catch (e) { return ""; }
}

// --------------------------- karta dla uzytkownika ---------------------------
function chloeResearchUserHtml(res) {
  if (!res) return "";
  var st = res.stats || {};
  var H = [];
  H.push('<div style="text-align:left;font-size:92%;border-left:3px solid #7aa2ff;padding-left:9px;">');
  H.push('<div><b>\ud83d\udd2c G\u0142\u0119boki research</b> \u2014 zapytanie: \u201e' + chloeEsc(res.query) + '\u201d</div>');
  H.push('<div style="opacity:.75;font-size:88%;margin:3px 0 6px;">' +
    (st.lacznie || 0) + ' pozycji \u00b7 ' + (st.hosty || 0) + ' serwis\u00f3w' +
    (st.odczytane ? ' \u00b7 odczytane strony: ' + st.odczytane : "") +
    (st.komentarze ? ' \u00b7 komentarze: ' + st.komentarze : "") +
    (st.ms ? ' \u00b7 ' + (Math.round(st.ms / 100) / 10) + ' s' : "") +
    (st.zapytania && st.zapytania.length > 1 ? ' \u00b7 szukano te\u017c: \u201e' + chloeEsc(st.zapytania.slice(1).join("\u201d, \u201e")) + '\u201d' : "") + '</div>');
  var reads = (res.out && res.out.reads) || [];
  if (reads.length) {
    H.push('<details open style="margin-bottom:6px;"><summary style="cursor:pointer;opacity:.85;">\ud83d\udcd6 Odczytane strony (' + reads.length + ')</summary><ul style="margin:5px 0 0;padding-left:18px;">');
    for (var i = 0; i < reads.length; i++) H.push('<li><a href="' + chloeEsc(reads[i].url) + '" target="_blank" rel="noopener">' + chloeEsc(chloeTrimText(reads[i].title || chloeHost(reads[i].url), 90)) + '</a> <span style="opacity:.6;">(' + chloeEsc(chloeHost(reads[i].url)) + ')</span></li>');
    H.push('</ul></details>');
  }
  H.push('<details><summary style="cursor:pointer;opacity:.8;">\ud83d\udd0e Pe\u0142ne wyniki wyszukiwania</summary>' + chloeBuildUser(res.out) + '</details>');
  H.push('</div>');
  return H.join("");
}

// --------------------------- komenda /research ---------------------------
function chloeResearchHelpHtml() {
  var st = chloeResearchState(), set = chloeResearchGet();
  return '<div style="text-align:left;font-size:92%;">' +
    '<b>\ud83d\udd2c Tryb g\u0142\u0119bokiego researchu</b> \u2014 stan: <b>' + chloeEsc(chloeResearchStatusText()) + '</b><br>' +
    '<div style="opacity:.75;font-size:90%;margin-top:4px;line-height:1.45;">' +
    'Research realnie przeszukuje \u017ar\u00f3d\u0142a (Reddit, fora, Bing, Wikipedia) i czyta strony, a potem Chloe odpowiada w formacie: podsumowanie / techniki / DIY / szalone pomys\u0142y / konsensus / \u017ar\u00f3d\u0142a.<br>' +
    '<b>Auto:</b> ' + (set.auto ? "w\u0142\u0105czone" : "wy\u0142\u0105czone") + ' (pr\u00f3g ' + set.prog + ', sticky ' + set.sticky + ', czytane strony ' + set.strony + ')' +
    '</div>' +
    '<ul style="margin:7px 0 0;padding-left:18px;line-height:1.5;">' +
    '<li><code>/research</code> albo <code>/research teraz &lt;temat&gt;</code> \u2014 research od razu</li>' +
    '<li><code>/research on</code> / <code>/research off</code> \u2014 tryb trwa\u0142y w tym w\u0105tku</li>' +
    '<li><code>/research auto on|off</code> \u2014 automat po s\u0142owach kluczowych</li>' +
    '<li><code>/research prog N</code> (1-9, domy\u015blnie 3), <code>/research sticky N</code>, <code>/research strony N</code>, <code>/research glebia szybko|auto|gleboko</code></li>' +
    '<li><code>/research status</code> \u2014 co jest aktywne i co ostatnio przeszukano; <code>/research off</code> wy\u0142\u0105cza</li>' +
    '</ul></div>';
}

function chloeResearchStatusText() {
  var st = chloeResearchState();
  if (st.on) return "w\u0142\u0105czony na sta\u0142e w tym w\u0105tku";
  if (Number(st.sticky) > 0) return "aktywny jeszcze ok. " + st.sticky + " wiadomo\u015bci";
  return "wy\u0142\u0105czony";
}

function chloeResearchStatusHtml() {
  var H = ['<div style="text-align:left;font-size:92%;"><b>\ud83d\udd2c Research:</b> ' + chloeEsc(chloeResearchStatusText()) + '.'];
  var last = CHLOE_RS_LAST;
  if (last) {
    var st = last.stats || {};
    H.push('<div style="opacity:.75;font-size:88%;margin-top:3px;">Ostatnie dossier: \u201e' + chloeEsc(last.query) + '\u201d, ' +
      ((Math.round((Date.now() - last.at) / 60000)) + ' min temu') +
      (st.lacznie ? ", pozycji: " + st.lacznie : "") + (st.odczytane ? ", stron: " + st.odczytane : "") + '.</div>');
  }
  H.push('<div style="opacity:.7;font-size:88%;margin-top:3px;">Komendy: <code>/research on|off|status|teraz &lt;temat&gt;|auto on|off|prog N|sticky N|strony N</code></div></div>');
  return H.join("");
}

async function chloeResearchCommand(arg) {
  await chloeResearchReady();
  var raw = chloeClean(arg || "");
  var a = raw.toLowerCase();
  var set = chloeResearchGet();
  if (/^(pomoc|help|\?)$/.test(a)) { chloeRPPush(chloeResearchHelpHtml()); return true; }
  if (!a) {
    // Jak w oryginalnym pluginie: samo /research wlacza tryb (sticky) i pokazuje stan.
    chloeResearchStateSet({ on: chloeResearchState().on, sticky: Math.max(Number(chloeResearchState().sticky) || 0, Number(set.sticky) || 0) });
    chloeRPPush(chloeResearchStatusHtml());
    return true;
  }
  if (/^(on|w[łl][ąa]cz|wlacz|start)$/.test(a)) {
    chloeResearchStateSet({ on: true, sticky: 0 });
    chloeRPPush('<i>\ud83d\udd2c Tryb g\u0142\u0119bokiego researchu <b>w\u0142\u0105czony na sta\u0142e</b> w tym w\u0105tku. Kolejne odpowiedzi b\u0119d\u0105 oparte na realnie przeszukanych \u017ar\u00f3d\u0142ach. Wy\u0142\u0105czysz: <code>/research off</code>.</i>');
    return true;
  }
  if (/^(off|wy[łl][ąa]cz|wylacz|stop)$/.test(a)) {
    chloeResearchStateSet({ on: false, sticky: 0 });
    chloeRPPush('<i>\ud83d\udd2c Tryb g\u0142\u0119bokiego researchu <b>wy\u0142\u0105czony</b> (auto dzia\u0142a dalej \u2014 <code>/research auto off</code>, by i to wy\u0142\u0105czy\u0107).</i>');
    return true;
  }
  if (/^(status|stan)$/.test(a)) { chloeRPPush(chloeResearchStatusHtml()); return true; }
  var ma = a.match(/^auto\s*[:=]?\s*(on|off|w[łl][ąa]cz|wlacz|wy[łl][ąa]cz|wylacz)$/);
  if (ma) {
    var on = /^(on|w[łl][ąa]cz|wlacz)$/.test(ma[1]);
    chloeResearchSet({ auto: on });
    chloeRPPush('<i>\ud83d\udd2c Automatyczny research po s\u0142owach kluczowych: <b>' + (on ? "w\u0142\u0105czony" : "wy\u0142\u0105czony") + '</b>.</i>');
    return true;
  }
  var mp = a.match(/^(?:prog|pr[óo]g|czu[łl]o[śs][ćc])\s*[:=]?\s*(\d)$/);
  if (mp) { chloeResearchSet({ prog: Math.max(1, Math.min(9, Number(mp[1]))) }); chloeRPPush('<i>\ud83d\udd2c Pr\u00f3g aktywacji: <b>' + chloeResearchGet().prog + '</b> (wy\u017cej = rzadziej w\u0142\u0105cza si\u0119 sam).</i>'); return true; }
  var ms = a.match(/^sticky\s*[:=]?\s*(\d)$/);
  if (ms) { chloeResearchSet({ sticky: Math.max(0, Math.min(9, Number(ms[1]))) }); chloeRPPush('<i>\ud83d\udd2c Sticky: <b>' + chloeResearchGet().sticky + '</b> wiadomo\u015bci.</i>'); return true; }
  var mst = a.match(/^strony\s*[:=]?\s*(\d)$/);
  if (mst) { chloeResearchSet({ strony: Math.max(0, Math.min(6, Number(mst[1]))) }); chloeRPPush('<i>\ud83d\udd2c Czytane strony pod dossier: <b>' + chloeResearchGet().strony + '</b>.</i>'); return true; }
  var mg = a.match(/^glebia\s*[:=]?\s*(szybko|auto|gleboko|g[łl][ęe]boko)$/);
  if (mg) { var g = chloeNorm(mg[1]); if (g === "gleboko") g = "gleboko"; chloeResearchSet({ glebia: g }); chloeRPPush('<i>\ud83d\udd2c G\u0142\u0119bia researchu: <b>' + g + '</b>.</i>'); return true; }
  // /research teraz <temat> albo /research <temat> -> research od razu
  var topic = raw.replace(/^(?:teraz|now|tu|tutaj)\s*[:=]?\s*/i, "").trim();
  var st0 = chloeResearchState();
  chloeResearchStateSet({ on: st0.on, sticky: Math.max(Number(st0.sticky) || 0, Number(set.sticky) || 0) });
  if (!topic) { chloeRPPush('<i>\ud83d\udd2c Research aktywowany. Podaj temat: <code>/research teraz jak zrobic X</code> albo po prostu zadaj pytanie \u2014 Chloe najpierw przeszuka \u017ar\u00f3d\u0142a.</i>'); return true; }
  chloeRPPush('<i>\ud83d\udd2c Robi\u0119 g\u0142\u0119boki research: \u201e' + chloeEsc(topic) + '\u201d \u2014 przeszukuj\u0119 \u017ar\u00f3d\u0142a i czytam strony\u2026</i>');
  var res = null;
  try { res = await chloeResearchRun(topic, /film|wideo|video|klip|porn|materia/i.test(topic) ? "media" : "info"); } catch (e) { res = null; }
  if (!res) { chloeRPPush('<i>\u274c Research nie zwr\u00f3ci\u0142 danych \u2014 spr\u00f3buj innego sformu\u0142owania albo sprawd\u017a po\u0142\u0105czenie.</i>'); return true; }
  var st = res.stats || {};
  chloeRPPush('<i>\u2705 Dossier gotowe: <b>' + (st.lacznie || 0) + '</b> pozycji z <b>' + (st.hosty || 0) + '</b> serwis\u00f3w, odczytane strony: <b>' + (st.odczytane || 0) + '</b>. Odpowiem teraz na tej podstawie \u2014 mo\u017cesz te\u017c doprecyzowa\u0107 pytanie.</i>');
  return true;
}

// --------------------------- sciezka natywna (Perchance) ---------------------------
// Bez wlasnego strojenia promptu: wstrzykujemy wiadomosc systemowa widoczna dla AI
// (a niewidoczna dla uzytkownika) i pozwalamy aplikacji odpowiedziec na nia.
async function chloeResearchNative(userText, dec, msgs) {
  var query = dec.query || "";
  if (!query) { try { query = await chloeMakeQuery(userText, dec.mode); } catch (e) { query = ""; } }
  if (!query) return false;
  var set = chloeResearchGet();
  var group = (oc.thread.customData.__chloeResearchGroup || 0) + 1;
  oc.thread.customData.__chloeResearchGroup = group;
  var ph = { author: "system", hiddenFrom: ["ai"], content: '<i style="opacity:.75;">\ud83d\udd2c Chloe prowadzi g\u0142\u0119boki research: \u201e' + chloeEsc(query) + '\u201d\u2026</i>', expectsReply: false, customData: { __chloeResearchGroup: group } };
  if (msgs) msgs.push(ph);
  var res = null;
  try { res = await chloeResearchRun(query, dec.mode); } catch (e) { res = null; }
  if (!res) {
    ph.content = '<i>\u274c Research nie zwr\u00f3ci\u0142 danych.</i>';
    return false;
  }
  if (set.pokazuj && ph) ph.content = chloeResearchUserHtml(res);
  if (msgs) msgs.push({ author: "system", hiddenFrom: ["user"], content: chloeResearchDirective(), expectsReply: true, customData: { __chloeResearchGroup: group } });
  // Sprzatanie: zostawiamy najwyzej 2 ostatnie grupy researchu (bez tego kontekst pecznieje).
  var seen = {};
  for (var i = 0; i < msgs.length; i++) {
    var cd = msgs[i] && msgs[i].customData;
    if (cd && cd.__chloeResearchGroup) seen[cd.__chloeResearchGroup] = true;
  }
  var groups = Object.keys(seen).map(Number).sort(function (a, b) { return a - b; });
  while (groups.length > 2) {
    var old = groups.shift();
    for (var j = msgs.length - 1; j >= 0; j--) {
      var cd2 = msgs[j] && msgs[j].customData;
      if (cd2 && cd2.__chloeResearchGroup === old) msgs.splice(j, 1);
    }
  }
  return true;
}

// --------------------------- panel (konsola wyszukiwania) ---------------------------
function chloeResearchPanelHtml() {
  var set = chloeResearchGet(), st = chloeResearchState();
  var inp = "background:#1e1e26;color:#e9e9ee;border:1px solid #33333f;border-radius:6px;padding:4px 6px;font-size:12px;width:52px;";
  var btn = "background:#2a2a36;color:#e9e9ee;border:1px solid #3c3c4c;border-radius:7px;padding:6px 11px;font-size:12px;cursor:pointer;white-space:nowrap;";
  var H = [];
  H.push('<div style="margin-top:12px;border:1px solid #33333f;border-radius:9px;padding:9px 10px;background:#191920;">');
  H.push('<div style="display:flex;align-items:center;gap:8px;"><b style="font-size:12.5px;">\ud83d\udd2c G\u0142\u0119boki research</b><span id="ce2RsState" style="font-size:11px;opacity:.75;margin-left:auto;">' + chloeEsc(chloeResearchStatusText()) + '</span></div>');
  H.push('<label style="display:flex;gap:7px;align-items:center;margin-top:8px;cursor:pointer;font-size:12px;"><input type="checkbox" id="ce2RsOn"' + (st.on ? " checked" : "") + '> Tryb research w tym w\u0105tku (na sta\u0142e)</label>');
  H.push('<label style="display:flex;gap:7px;align-items:center;margin-top:6px;cursor:pointer;font-size:12px;"><input type="checkbox" id="ce2RsAuto"' + (set.auto ? " checked" : "") + '> W\u0142\u0105czaj sam przy tematach typu poradnik / DIY / technika</label>');
  H.push('<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px;font-size:11.5px;">');
  H.push('<label style="display:flex;gap:5px;align-items:center;">Pr\u00f3g <input type="number" id="ce2RsProg" min="1" max="9" step="1" value="' + Number(set.prog) + '" style="' + inp + '"></label>');
  H.push('<label style="display:flex;gap:5px;align-items:center;">Sticky <input type="number" id="ce2RsSticky" min="0" max="9" step="1" value="' + Number(set.sticky) + '" style="' + inp + '"></label>');
  H.push('<label style="display:flex;gap:5px;align-items:center;">Strony <input type="number" id="ce2RsStrony" min="0" max="6" step="1" value="' + Number(set.strony) + '" style="' + inp + '"></label>');
  H.push('<select id="ce2RsGlebia" style="background:#1e1e26;color:#e9e9ee;border:1px solid #33333f;border-radius:6px;padding:4px 6px;font-size:12px;">' +
    ["szybko", "auto", "gleboko"].map(function (g) { return '<option value="' + g + '"' + (String(set.glebia) === g ? " selected" : "") + '>' + g + '</option>'; }).join("") + '</select>');
  H.push('</div>');
  H.push('<div style="display:flex;gap:8px;align-items:center;margin-top:9px;flex-wrap:wrap;"><button id="ce2RsNow" style="' + btn + '">\ud83d\udd2c Research teraz</button><span id="ce2RsMsg" style="font-size:11.5px;opacity:.85;line-height:1.35;"></span></div>');
  H.push('<div id="ce2RsOut" style="margin-top:8px;font-size:11.5px;opacity:.85;line-height:1.4;"></div>');
  H.push('<div style="font-size:11px;opacity:.6;margin-top:7px;line-height:1.4;">Research realnie przeszukuje \u017ar\u00f3d\u0142a (Reddit + komentarze, fora, Bing PL/EN, Wikipedia) i czyta strony, a Chloe dostaje dossier z linkami i odpowiada w formacie: podsumowanie / techniki / DIY / szalone pomys\u0142y / konsensus / \u017ar\u00f3d\u0142a. Ustawienia trzymane s\u0105 w tej przegl\u0105darce (kv), a tryb "na sta\u0142e" \u2014 w tym w\u0105tku. Komendy: <code>/research on|off|status|teraz &lt;temat&gt;|auto on|off</code>.</div>');
  H.push('</div>');
  return H.join("");
}

function chloeResearchPanelWire() {
  var $ = function (id) { return document.getElementById(id); };
  if (!$("ce2RsOn")) return;
  function refresh() {
    var st = chloeResearchState(), set = chloeResearchGet();
    if ($("ce2RsState")) $("ce2RsState").textContent = chloeResearchStatusText();
    if ($("ce2RsOn")) $("ce2RsOn").checked = !!st.on;
    if ($("ce2RsAuto")) $("ce2RsAuto").checked = !!set.auto;
    if ($("ce2RsProg")) $("ce2RsProg").value = Number(set.prog);
    if ($("ce2RsSticky")) $("ce2RsSticky").value = Number(set.sticky);
    if ($("ce2RsStrony")) $("ce2RsStrony").value = Number(set.strony);
    if ($("ce2RsGlebia")) $("ce2RsGlebia").value = String(set.glebia);
  }
  window.__chloeResearchRefresh = refresh;
  $("ce2RsOn").addEventListener("change", function () { chloeResearchStateSet({ on: this.checked, sticky: this.checked ? 0 : chloeResearchState().sticky }); refresh(); });
  $("ce2RsAuto").addEventListener("change", function () { chloeResearchSet({ auto: this.checked }); refresh(); });
  $("ce2RsProg").addEventListener("change", function () { chloeResearchSet({ prog: Math.max(1, Math.min(9, Number(this.value) || 3)) }); refresh(); });
  $("ce2RsSticky").addEventListener("change", function () { chloeResearchSet({ sticky: Math.max(0, Math.min(9, Number(this.value) || 0)) }); refresh(); });
  $("ce2RsStrony").addEventListener("change", function () { chloeResearchSet({ strony: Math.max(0, Math.min(6, Number(this.value) || 0)) }); refresh(); });
  $("ce2RsGlebia").addEventListener("change", function () { chloeResearchSet({ glebia: this.value }); });
  $("ce2RsNow").addEventListener("click", async function () {
    var q = String(($("ce2q") && $("ce2q").value) || "").trim();
    if (!q) { $("ce2RsMsg").innerHTML = '<span style="color:#f0b46a;">Wpisz temat w polu powy\u017cej.</span>'; return; }
    var msg = $("ce2RsMsg"), out = $("ce2RsOut");
    msg.innerHTML = '<i style="opacity:.7;">research: \u201e' + chloeEsc(q) + '\u201d\u2026</i>';
    out.innerHTML = "";
    chloeResearchStateSet({ on: chloeResearchState().on, sticky: Math.max(Number(chloeResearchState().sticky) || 0, Number(chloeResearchGet().sticky) || 0) });
    var mode = $("ce2Mode") ? $("ce2Mode").value : "info";
    var res = null;
    try { res = await chloeResearchRun(q, mode === "media" ? "media" : "info"); } catch (e) { res = null; }
    refresh();
    if (!res) { msg.innerHTML = '<span style="color:#f08a8a;">\u274c brak danych \u2014 spr\u00f3buj innego sformu\u0142owania.</span>'; return; }
    var st = res.stats || {};
    msg.innerHTML = '<span style="color:#7ddba5;">\u2705 gotowe</span>';
    out.innerHTML = chloeResearchUserHtml(res);
  });
  refresh();
}
