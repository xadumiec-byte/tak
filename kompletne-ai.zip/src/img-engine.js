// =====================================================================
// CHLOE IMAGE PROMPT ENGINE v7
// ---------------------------------------------------------------------
// v5 (po weryfikacji prawdziwego obrazu z mostka):
//  1) Marker briefu zmieniony z [[scena-obraz]] na @@scena-obraz@@ - pipeline
//     czatu zamienial [[...]] na <button onclick=...> i ten HTML szedl do Stheno.
//     Dodatkowo pipeline (custom code) nie tyka juz zawartosci <image>.
//  2) KONIEC Z DODAWANIEM UBRAN: zakotwiczenie wygladu Chloe nie wymienia juz
//     jej "zwyklych" ciuchow. Wczesniej do promptu wchodzilo "a short plaid
//     skirt" i obraz pokazywal spodniczke, ktorej w scenie nie bylo (i ktora
//     zaslaniala genitalia), mimo ze stan sceny mowil "rozpięta koszula,
//     krótkie spodenki".
//  3) Przy poziomie 2-3 zwykle ciuchy schodza ("pulled down and out of the way"),
//     a zostaja tylko wtedy, gdy sa fetyszem sceny (lateks/koronka/bielizna...).
//     Doszedl jawny zakaz: nic nie zakrywa cipki (fabric/clothing/hands).
//  4) Nazwy zabawek tlumaczone sensownie ("długa dłoń" = long latex fisting
//     glove, nie "small hand") + akcja POV dla zabawy z rekawica.
//  5) Budzet briefu liczony bez parametrow (negativePrompt:::), ktore i tak sa
//     wycinane przed mostkiem: 2200 -> ~2526 znakow tresci.
//
// v6 (maksymalna skutecznosc promptu; polecenie: "mocny NSFW, pelny obraz,
// idealnie trafiajacy w czat"):
//  6) KADR: domyslnie pelne cialo z genitaliami w kadrze (nic nie uciete),
//     a nie "extreme close-up". Zblizenie tylko na wyrazne zadanie
//     ("z bliska"/"close-up"/"detal") albo /obraz kadr close.
//  7) Tryb "wprost" (/obraz stheno off): brief jest splaszczany do czystego
//     promptu SD (bez etykiet "what is happening right now:" / "scene state:")
//     i mostek wysyla go DOKLADNIE tak do ComfyUI - bez przepisywania przez
//     Stheno, ktore streszczalo 3.5 KB do ~1 KB i gubilo szczegoly.
//     Mostek dokleja wtedy tez mocna NEGATIVE_DEFAULT do wezla 3.
//  8) Mostek (>= 1.1) przyjmuje pole "negative" (negatywa z (negativePrompt:::)
//     trafia wreszcie do wezla 3) oraz "direct". Starszy mostek te pola
//     ignoruje, wiec aplikacja dziala z obiema wersjami.
//  9) /obraz prompt pokazuje ostatni prompt obrazu (nasz brief + to, co
//     ostatecznie poszlo do modelu) ORAZ negatywe, ktora pojdzie do wezla 3.
//
// v7 (ostatnie maksymalizowanie jakosci; polecenie: "mocny, w pelni
// nieocenzurowany seksualny kontent idealnie trafiajacy w czat"):
// 10) Brief dostal na KONCU (po kadrze) jawna, pozytywna asercje: "raw
//     pornographic sex photo of a real woman, an obscene sex act clearly in
//     progress" - modele NSFW maja wbudowany ciag do "tasteful nude", a sama
//     lista negatywow w prompcie nie wystarcza. Pozytywna asercja dziala
//     mocniej niz zaprzeczenia.
// 11) Negatywa idzie do mostka z aplikacji ((negativePrompt:::...)) i mostek
//     dokleja do niej swoj NEGATIVE_CORE - patrz scratch/perchance_bridge.py.
//     Dzieki temu SD dostaje jawnie: "clothing over pussy, panties, shorts,
//     underwear, hands covering pussy, thighs pressed together, closed legs,
//     cropped genitals, sfw, tasteful, modesty".
// 12) /obraz prompt pokazuje tez negatywe (ile znakow + tresc), wiec widac,
//     ze mocna negatywa naprawde leci do modelu (wymaga mostka >= 3/1.1).
//
// Cel: obraz ma trafiac DOKLADNIE w to, co dzieje sie w scenie, i ma byc
// maksymalnie mocny: pelne, nieocenzurowane, wprost pornograficzne NSFW.
//
// JAK TO DZIALA OD POCZATKU DO KONCA (wazne - latwo sie zgubic):
//  1) Model (lokalny Stheno 8B albo Perchance) pisze w wiadomosci
//     <image>ANGLIELSKI OPIS</image>. Reguly CHLOE_E2_RULES kaza mu opisac
//     scene wprost, z detalami seksualnymi.
//  2) chloeImageEnrich() dokleja DO WNETRZA znacznika nasz brief sceny
//     (z markerem @@scena-obraz@@ na poczatku) - patrz nizej.
//  3) Aplikacja sklada finalny tekst:
//     imagePromptPrefix + tag + imagePromptSuffix + imagePromptTriggers
//     (prefix/suffix/triggers siedza w definicji postaci Chloe).
//  4) Mostek (perchance_bridge.py) wysyla ten tekst do Stheno, ktory
//     PRZEPISUJE go na finalny prompt dla ComfyUI (wezel 2), a ComfyUI
//     uzywa stalej negatywy z wezla 3.
//
// WNIOSKI Z PRAWDZIWEGO STACKU (EpicRealism + RealESRGAN, mostek przyjmuje
// TYLKO pole "prompt", max 4000 znakow, negatywy nie da sie podmienic):
//  - prompt musi byc CALY PO ANGIELSKU. CLIP nie rozumie polskiego, a stan
//    sceny jest pisany po polsku przez model czatu - dlatego tlumaczymy go
//    mini-slownikiem (CHLOE_IMG_TR) PRZED wyslaniem.
//  - styl (EpicRealism/raw photo) musi byc w 100% fotograficzny, bo stala
//    negatywa z wezla 3 zakazuje painting/illustration/anime/cartoon.
//  - NAJWIEKSZY problem modeli NSFW to "tasteful nude": gubi genitalia,
//    zaslania je rekami albo kadruje powyzej. Dlatego brief ZAWSZE niesie
//    jawne "genitals fully in frame, nothing cropped, no hands covering".
//  - Tagi z ostatniej tury czatu potrafia nadmiarowo dopisywac akty, ktorych
//    w scenie nie ma ("strap-on" z jednego slowa). Dlatego: (a) tagi ze stanu
//    i z prosby maja priorytet nad tagami z czatu, (b) tagi z czatu wchodza
//    tylko pierwsze dwa z danego wzorca, (c) obietnice/plany ("obietnice")
//    NIE opisuja terazniejszosci i nie generuja tagow.
//
// Brief jest JEDNOLINIOWY celowo: sciezka /image <opis> aplikacji bierze
// tylko pierwsza linie wiadomosci, a nasza komenda /obraz jedzie wlasnie nia.
//
// Kolejnosc tagow = priorytet (Stheno czyta od poczatku, a mostek tnie na
// 4000 znakach): AKTY (moc NSFW) -> KINKI -> CIALO -> POZA -> SCENA.
//
// Marker @@scena-obraz@@:
//   - idempotencja (drugie przejscie nic nie zmienia),
//   - chloeImgBriefStrip() wycina brief z kontekstu modelu (model widzi
//     tylko swoj wlasny opis, nie nasze etykiety i nie nasza liste granic),
//   - alt/title obrazu i tekst wysylany do mostka sa ucinane na markerze
//     (chloeCloudStripMark), wiec marker nigdy nie trafia do promptu.
//   UWAGA (naprawiony blad): marker NIE moze miec formy [[...]], bo
//   oc.messageRenderingPipeline w custom code zamienia KAZDE [[...]] na
//   <button onclick="chloeQuickAction(...)"> ZANIM aplikacja wycina <image>.
//   Wtedy do Stheno szedl surowy HTML przycisku zamiast tekstu. @@...@@
//   przechodzi przez markdown nietkniety.
//
// v8 (kotwica "biezacego momentu"; polecenie: "obrazy maja pokazywac
// dokladnie to, co dzieje sie TERAZ"):
// 13) chloeImgRecent() bierze DWA ostatnie wymiany (biezaca + poprzednia),
//     a nie jedna - poprzednia tylko jako slabe wsparcie (krotszy clip).
// 14) Nowy chloeImgMoment(): 1-2 zdania EN z OSTATNIEJ wymiany (AI > user),
//     czyszczone ze <<stan>>/[[akcje]]/<image>, wstawiane tuz za zdaniem akcji
//     jako "current moment, this exact frame:" - SD czyta moment przed tagami.
// 15) Zdanie akcji sortuje trafy po swiezosci (pozycja w tekscie), nie po
//     kolejnosci regul - nowszy akt wygrywa ze starszym.
// 16) Mniej rozwadniaczy: ulubione kinki 14 -> 6, "arousal N of 100" (bez sensu
//     dla SD) usuniete, world tylko gdy brak lok, sprzeczne akty rozszerzone
//     (strap-on i solo nie mieszaja sie z penetracja).
//
// Podglad/test z konsoli: window.__chloeImg.brief() / .enrich("...") / .tags("...")
// =====================================================================
var CHLOE_IMG_MARK = "@@scena-obraz@@";
var CHLOE_IMG_MARK_RE = /@@scena-obraz@@/gi;

// =====================================================================
// 1) MINI-TLUMACZ PL -> EN (tylko slownictwo sceny: miejsce, czas, pozy,
//    ubrania, cialo, czynnosc, nastroj). Reszta zdania zostaje po polsku -
//    Stheno i tak przepisuje calosc, a tagi sa juz angielskie.
// =====================================================================
var CHLOE_IMG_TR = [
  // --- ubrania (najpierw dluższe frazy) ---
  ["rękawiczki lateksowe", "latex gloves"], ["lateksowe rękawiczki", "latex gloves"],
  ["krótkie spodenki", "short shorts"], ["rozpięta koszula", "unbuttoned shirt"],
  ["podciągnięta sukienka", "dress pulled up"], ["zsunięta sukienka", "dress pulled down"],
  ["koronkowa bielizna", "lace lingerie"], ["czarna koronka", "black lace"],
  ["pończochy samonośne", "sheer stockings"], ["kostium kąpielowy", "swimsuit"],
  ["mokre włosy", "wet hair"], ["mokra skóra", "wet skin"], ["mokre ciało", "wet body"],
  ["spocona skóra", "sweaty skin"], ["twarde sutki", "hard nipples"],
  ["wilgotne sutki", "wet nipples"], ["czerwona skóra", "flushed red skin"],
  ["gęsia skórka", "goosebumps"], ["pot na skórze", "sweat on skin"],
  ["śliną", "saliva"], ["śliny", "saliva"], ["ślad klapsa", "spank mark"],
  ["ślady klapsów", "spanking marks"], ["zadrapania", "scratches"], ["siniaki", "bruises"],
  ["gryzienia", "bite marks"], ["opaska na oczy", "blindfold"], ["korek analny", "anal plug"],
  ["plug analny", "anal plug"], ["obroża", "collar"], ["smycz", "leash"],
  ["ręcznik", "towel"], ["kołdra", "blanket"], ["prześcieradło", "sheet"],
  ["koszula", "shirt"], ["sukienka", "dress"], ["spódniczka", "short skirt"],
  ["spódnica", "skirt"], ["spodenki", "shorts"], ["majtki", "panties"], ["stringi", "thong"],
  ["biustonosz", "bra"], ["stanik", "bra"], ["rajstopy", "pantyhose"],
  ["pończochy", "stockings"], ["skarpetki", "socks"], ["szpilki", "high heels"],
  ["buty", "shoes"], ["bluza", "hoodie"], ["sweter", "sweater"], ["płaszcz", "coat"],
  ["bielizna", "lingerie"], ["koronka", "lace"], ["lateks", "latex"], ["skóra", "skin"], ["skora", "skin"],
  ["róża", "rose"], ["naszyjnik", "necklace"], ["kolczyki", "earrings"],
  ["nadgarstki", "wrists"], ["kostki", "ankles"],
  ["naga", "nude"], ["nago", "nude"], ["nagie", "nude"], ["topless", "topless"],
  ["bez ubrania", "with no clothes on"], ["rozbrana", "undressed"], ["rozbieranie", "undressing"],
  ["rozpięta", "unbuttoned"], ["podciągnięta", "pulled up"], ["zsunięta", "pulled down"],
  ["opuszczone", "lowered"], ["mokra", "wet"], ["mokre", "wet"], ["mokry", "wet"],
  ["spocona", "sweaty"], ["wilgotna skóra", "wet skin"], ["wilgotna", "wet"], ["gładka", "smooth"], ["ogolona", "shaved"],
  // --- ciało ---
  ["wargi sromowe", "pussy lips"], ["palce u nóg", "toes"],
  // Nazwy zabawek z listy `zabawki` (uzytkownik wpisuje je po polsku).
  // UWAGA: "długa dłoń" to zabawka (dlugi lateksowy rekaw), a nie "small hand" -
  // stare tlumaczenie kazalo modelowi wymyslac dloniach na ciele.
  ["długa dłoń", "long latex fisting glove"], ["długą dłoń", "long latex fisting glove"],
  ["długa rękawica", "long latex fisting glove"], ["długie ramię", "long latex fisting glove"],
  ["długa ręka", "long latex fisting glove"], ["lateksowa rękawica", "long latex fisting glove"],
  ["cipka", "pussy"], ["cipkę", "pussy"], ["cipki", "pussy"], ["cipce", "pussy"], ["cipki", "pussy"],
  ["pizda", "pussy"], ["pizdę", "pussy"], ["wagina", "vagina"], ["waginy", "vagina"],
  ["łechtaczka", "clitoris"], ["łechtaczkę", "clitoris"], ["łechtaczki", "clitoris"],
  ["pochwa", "pussy"], ["pochwy", "pussy"], ["srom", "vulva"],
  ["piersi", "breasts"], ["piersiami", "breasts"], ["cycki", "breasts"], ["cycków", "breasts"],
  ["biust", "breasts"], ["sutki", "nipples"], ["sutek", "nipple"], ["sutka", "nipple"],
  ["pupa", "ass"], ["pupę", "ass"], ["pupy", "ass"], ["tyłek", "ass"], ["tyłka", "ass"],
  ["pośladki", "ass cheeks"], ["pośladków", "ass cheeks"], ["dupa", "ass"], ["dupę", "ass"],
  ["dupą", "ass"], ["zadek", "ass"], ["odbyt", "anus"], ["odbytu", "anus"], ["odbycie", "anus"],
  ["fiut", "cock"], ["fiuta", "cock"], ["kutas", "cock"], ["kutasa", "cock"],
  ["penis", "cock"], ["penisa", "cock"], ["członek", "cock"], ["jądra", "balls"],
  ["wzwód", "erection"], ["erekcja", "erection"], ["erekcyj", "erection"],
  ["brzuch", "stomach"], ["brzucha", "stomach"], ["plecy", "back"], ["szyja", "neck"],
  ["szyi", "neck"], ["gardło", "throat"], ["gardła", "throat"], ["włosy", "hair"],
  ["twarz", "face"], ["usta", "lips"], ["język", "tongue"], ["palce", "fingers"],
  ["palców", "fingers"], ["dłoń", "hand"], ["dłoni", "hand"], ["ręka", "hand"],
  ["ręce", "hands"], ["ramię", "arm"], ["ramiona", "arms"], ["nogi", "legs"],
  ["nogę", "leg"], ["nóg", "legs"], ["ugięte", "bent"], ["udo", "thigh"], ["uda", "thighs"],
  ["ud", "thighs"], ["łydki", "calves"], ["kostki", "ankles"], ["stopy", "feet"],
  ["stopa", "foot"], ["jędrne", "firm"], ["miękkie", "soft"], ["duże", "large"],
  ["małe", "small"], ["szczupłe", "slim"], ["obfite", "full"], ["mokre", "wet"],
  // --- pozy ---
  ["szeroko rozstawione", "spread wide"], ["szeroko rozłożone", "spread wide"],
  ["rozstawione nogi", "legs spread"], ["nogi do gory", "legs up"],
  ["nogi w górze", "legs raised"], ["skrzyżowane nogi", "crossed legs"],
  ["nad głową", "above her head"], ["na plecach", "on her back"], ["na brzuchu", "on her stomach"],
  ["na czworakach", "on all fours"], ["na kolanach", "on her knees"], ["na stojąco", "standing"],
  ["przy ścianie", "against the wall"], ["na łóżku", "on the bed"], ["na stole", "on the table"],
  ["na kanapie", "on the sofa"], ["na podłodze", "on the floor"], ["na krześle", "on the chair"],
  ["głowa odchylona", "head tilted back"], ["głowę odchyloną", "head tilted back"],
  ["plecami do", "back turned to"], ["biustem do przodu", "chest pushed forward"],
  ["ręce związane", "hands tied"], ["ręce nad", "arms above"], ["wypięta", "ass raised"],
  ["pochylona", "bent over"], ["przechylona", "leaning"], ["klęcząca", "kneeling"],
  ["klęczy", "kneeling"], ["siedząca", "sitting"], ["siedzi", "sitting"],
  ["stojąca", "standing"], ["stoi", "standing"], ["leżąca", "lying"], ["leży", "lying"],
  ["okrakiem", "straddling"], ["na nim", "on top of him"], ["pod nim", "underneath him"],
  ["ugina się", "arching"], ["odgina się", "arching back"], ["wygięta", "arched"],
  ["rozchylone", "spread open"], ["rozsunięte", "spread apart"], ["w powietrzu", "in the air"],
  // --- miejsca / czas ---
  ["późna noc", "late night"], ["późny wieczór", "late evening"], ["świt", "dawn"],
  ["poranek", "morning"], ["rano", "morning"], ["południe", "noon"],
  ["popołudnie", "afternoon"], ["wieczór", "evening"], ["wieczorem", "evening"],
  ["noc", "night"], ["nocą", "night"], ["dzień", "day"], ["dzien", "day"],
  ["kuchni", "kitchen"], ["kuchnia", "kitchen"], ["salon", "living room"],
  ["salonie", "living room"], ["sypialni", "bedroom"], ["sypialnia", "bedroom"],
  ["łazienk", "bathroom"], ["łazienka", "bathroom"], ["łóżko", "bed"], ["łóżku", "bed"],
  ["kanapa", "sofa"], ["kanapie", "sofa"], ["sofa", "sofa"], ["stół", "table"],
  ["stoliku", "table"], ["stole", "table"], ["blat", "countertop"], ["biurko", "desk"],
  ["krzesło", "chair"], ["krzesle", "chair"], ["podłoga", "floor"], ["podłodze", "floor"],
  ["prysznic", "shower"], ["prysznicem", "shower"], ["wanna", "bathtub"],
  ["wannie", "bathtub"], ["lustro", "mirror"], ["lustrze", "mirror"], ["okno", "window"],
  ["oknie", "window"], ["balkon", "balcony"], ["taras", "terrace"], ["winda", "elevator"],
  ["samochód", "car"], ["samochodzie", "car"], ["auto", "car"], ["basen", "pool"],
  ["ogród", "garden"], ["ogrodzie", "garden"], ["las", "forest"], ["plaży", "beach"],
  ["plaża", "beach"], ["park", "park"], ["biuro", "office"], ["biurze", "office"],
  ["klasie", "classroom"], ["szkoła", "school"], ["biblioteka", "library"],
  ["bibliotece", "library"], ["hotel", "hotel"], ["pokój", "room"], ["pokoju", "room"],
  // --- czynnosc / kinki (do etykiety stanu i ulubionych) ---
  ["masaż prostaty", "prostate massage"], ["prostaty", "prostate"], ["prostatę", "prostate"],
  ["seks analny", "anal sex"], ["analny", "anal"], ["analnie", "anal"], ["od tyłu", "from behind"],
  ["seks oralny", "oral sex"], ["oralnie", "oral"], ["mineta", "cunnilingus"],
  ["minetę", "cunnilingus"], ["obciąga", "sucking his cock"], ["obciąganie", "blowjob"],
  ["pieprzenie", "fucking"], ["pieprzy", "fucking"], ["pierdoli", "fucking"],
  ["rucha", "fucking"], ["jebie", "fucking"], ["stosunek", "intercourse"], ["seks", "sex"],
  ["seksem", "sex"], ["penetracja", "penetration"], ["penetrację", "penetration"],
  ["orgazm", "orgasm"], ["orgazmu", "orgasm"], ["orgazmem", "orgasm"],
  ["wytrysk", "cumshot"], ["wytrysku", "cumshot"], ["sperma", "semen"], ["spermy", "semen"],
  ["nasienie", "semen"], ["squirt", "squirting"], ["squirting", "squirting"],
  ["palcówka", "fingering"], ["palcuje", "fingering"], ["palcówki", "fingering"],
  ["dildo", "dildo"], ["dildem", "dildo"], ["wibrator", "vibrator"], ["wibratorem", "vibrator"],
  ["zabawki", "sex toys"], ["zabawek", "sex toys"], ["zabawka", "sex toy"],
  ["kajdany", "handcuffs"], ["kajdanach", "handcuffs"], ["lina", "rope"], ["liną", "rope"],
  ["związana", "tied up"], ["skrępowana", "restrained"], ["unieruchomiona", "immobilised"],
  ["knebel", "gag"], ["knebla", "gag"], ["kneblem", "gag"], ["pejcz", "whip"],
  ["korbacz", "flogger"], ["klaps", "spank"], ["klapsy", "spanks"], ["klapsa", "spank"],
  ["żel", "lube"], ["żelem", "lube"], ["lubrykant", "lube"], ["prezerwatywa", "condom"],
  ["gumka", "condom"], ["ślinę", "saliva"], ["śliny", "saliva"], ["śliną", "saliva"],
  ["ujeżdża", "riding him"], ["ujeżdżanie", "riding him"], ["jeździ", "riding"],
  ["dominuje", "dominating"], ["uległa", "submissive"], ["poddaje", "submitting"],
  ["ujarzmia", "taming"], ["poniża", "humiliating"], ["poniżenie", "humiliation"],
  ["zawstydzona", "embarrassed"], ["drży", "trembling"], ["dyszy", "panting"],
  ["stęka", "moaning"], ["jęczy", "moaning"], ["wzdycha", "sighing"],
  ["krzyczy", "crying out"], ["całuje", "kissing"], ["całują", "kissing"],
  ["pocałunek", "kiss"], ["przytula", "hugging"], ["obejmuje", "holding"],
  ["masuje", "massaging"], ["dotyka", "touching"], ["pieści", "fondling"],
  ["lize", "licking"], ["liże", "licking"], ["lizać", "licking"], ["ssie", "sucking"],
  ["połyka", "swallowing"], ["gryzie", "biting"], ["drapa", "scratching"],
  ["dusi", "choking"], ["dławi", "choking"], ["wchodzi", "entering her"],
  ["wsuwa", "sliding into her"], ["wbija", "thrusting into her"], ["wychodzi", "pulling out"],
  // --- nastroj ---
  ["opowiadanie fantazji", "fantasy talk"], ["brudne gadki", "dirty talk"], ["brudna gadka", "dirty talk"],
  ["przedgra", "foreplay"], ["pieszczoty", "foreplay"], ["pieszczota", "foreplay"],
  ["finisz", "finish"], ["odpoczynek", "afterglow"], ["rozmowa", "talking"],
  ["gra wstępna", "foreplay"], ["gra", "play"], ["zabawa", "play"],
  ["wyzywająca", "provocative"], ["wyzywająco", "provocatively"], ["uwodzicielska", "seductive"],
  ["dzika", "wild"], ["nieśmiała", "shy"], ["zalotna", "flirtatious"],
  ["rozpalona", "aroused"], ["pobudzona", "aroused"], ["podniecona", "aroused"],
  ["zmęczona", "tired"], ["zadowolona", "satisfied"], ["bezwstydna", "shameless"],
  ["bezczelna", "cheeky"], ["rozkosz", "bliss"], ["ekstaza", "ecstasy"],
  // --- warianty bez polskich znakow (model czatu czasem je gubi) ---
  ["siedzaca", "sitting"], ["kleczaca", "kneeling"], ["lezaca", "lying"],
  ["lozku", "bed"], ["lozko", "bed"], ["posladki", "ass cheeks"], ["posladkow", "ass cheeks"],
  ["związana", "tied up"], ["zwiazana", "tied up"], ["mokra skora", "wet skin"],
  ["twarde sutki", "hard nipples"], ["cipke", "pussy"], ["pizde", "pussy"],
  ["rece", "hands"], ["reka", "hand"], ["nogi", "legs"], ["uda", "thighs"],
  ["rozstawione", "spread"], ["szeroko", "wide"],
  // --- odmiany przymiotnikow (model czatu odmienia, a tagi musza byc czytelne) ---
  ["lateksowa", "latex"], ["lateksowe", "latex"], ["lateksowy", "latex"],
  ["koronkowa", "lace"], ["koronkowe", "lace"], ["koronkowy", "lace"],
  ["skórzana", "leather"], ["skórzane", "leather"], ["skorzana", "leather"],
  ["jedwabna", "silk"], ["jedwabne", "silk"], ["bawełniana", "cotton"],
  ["przezroczysta", "sheer"], ["przezroczyste", "sheer"], ["siateczkowa", "fishnet"],
  ["czarna", "black"], ["czarne", "black"], ["czarny", "black"],
  ["biała", "white"], ["białe", "white"], ["czerwona", "red"], ["czerwone", "red"],
  ["wilgotne", "wet"], ["wilgotny", "wet"], ["mokrego", "wet"], ["mokrych", "wet"],
  ["obcisła", "tight"], ["obcisłe", "tight"], ["luźna", "loose"],
  ["duże piersi", "large breasts"], ["małe piersi", "small breasts"], ["jędrne piersi", "firm breasts"],
  ["duży biust", "large breasts"], ["duże cycki", "big tits"], ["małe cycki", "small tits"],
  ["szczupła", "slim"], ["krągła", "curvy"], ["krągłe", "curvy"],
  // --- czasowniki z prosby (zeby Stheno nie musial ich tlumaczyc) ---
  ["bierze", "takes"], ["weź", "take"], ["bierz", "take"], ["mocno", "hard"], ["mocniej", "harder"],
  ["ostro", "roughly"], ["brutalnie", "brutally"], ["delikatnie", "gently"], ["wolno", "slowly"],
  ["głęboko", "deep"], ["głębiej", "deeper"], ["szybko", "fast"], ["wolniej", "slower"],
  ["pieprz", "fuck"], ["pieprzysz", "fucking"], ["wchodź", "go in"], ["wchodzi", "enters her"],
  ["liż", "lick"], ["liżesz", "licking"], ["ssij", "suck"], ["ssiesz", "sucking"],
  ["dotykaj", "touch"], ["dotyka", "touches"], ["masuj", "massage"], ["masuje", "massaging"],
  ["rozkładam", "I spread"], ["rozstawiam", "I spread"], ["rozkłada", "spreads"], ["rozstawia", "spreads"],
  ["wypina", "sticks out her ass"], ["wypinam", "I stick out her ass"], ["wypięta", "ass raised"],
  ["klęka", "kneels"], ["klękam", "I kneel"], ["siada", "sits down"], ["siadam", "I sit down"],
  ["pokazuje", "shows"], ["podnosi", "raises"], ["unosi", "lifts"], ["opiera", "leans"],
  ["zdejmij", "take off"], ["zdejmuje", "takes off"], ["rozepnij", "unbutton"], ["rozpina", "unbuttons"],
  ["chcę", "I want"], ["chce", "wants"], ["pragnę", "I crave"], ["prosi", "asks"],
  ["jest", "is"], ["są", "are"], ["sa", "are"], ["będzie", "will be"], ["była", "was"],
  ["robi", "does"], ["trzyma", "holds"], ["przytrzymuje", "holds down"], ["ciągnie", "pulls"],
  ["całuje", "kisses"], ["przytula", "hugs"], ["gryzie", "bites"], ["drapie", "scratches"],
  // --- slowka funkcyjne: usuwamy TYLKO z tekstu po polsku (patrz CHLOE_IMG_TR_STOP) ---
  ["go", "him"], ["ją", "her"], ["je", "them"], ["ja", "I"]
];

// Polskie slowka funkcyjne. Stosujemy je wylacznie wtedy, gdy tekst NAPRAWDE
// jest po polsku - inaczej wycielibysmy slowa z angielskiej prosby ("go down
// on her" -> "him down on her").
var CHLOE_IMG_TR_STOP = [
  ["się", ""], ["sie", ""], ["jak", ""], ["już", ""], ["juz", ""], ["też", ""], ["tez", ""],
  ["bardzo", ""], ["tylko", ""], ["nawet", ""], ["że", ""], ["ze", ""], ["żeby", ""], ["zeby", ""],
  ["ale", ""], ["oraz", ""], ["gdy", ""], ["kiedy", ""], ["który", ""], ["która", ""], ["które", ""],
  ["których", ""], ["swoją", ""], ["swoje", ""], ["swój", ""], ["proszę", ""], ["prosze", ""],
  ["czy", ""], ["właśnie", ""], ["wlansie", ""], ["potem", ""], ["nagle", ""], ["znowu", ""],
  ["jest", "is"], ["są", "are"], ["sa", "are"], ["będzie", "will be"], ["była", "was"],
  ["mnie", "me"], ["mi", "me"], ["mu", "him"], ["jej", "her"], ["jego", "his"],
  ["ma", "has"], ["mam", "I have"], ["chcę", "I want"], ["chce", "wants"], ["robi", "does"]
];

var CHLOE_IMG_PL_WORDS = (function () {
  var w = {}, list = "się sie jest nie tak jak już juz chcę chce bardzo tylko oraz mnie mi mu jej jego żeby zeby wiem jestem jesteś mam masz ma mamy macie mają robi zrobi zrobisz teraz potem nagle znowu też tez albo lub czy to na do za w z o po pod nad przy przez dla ten ta to tego tej tym tam tu jest są sa".split(" ");
  for (var i = 0; i < list.length; i++) w[list[i]] = 1;
  return w;
})();

function chloeImgIsPl(s) {
  var t = String(s == null ? "" : s);
  if (/[ąćęłńóśźż]/i.test(t)) return true;
  var words = t.toLowerCase().split(/[^a-z]+/), hits = 0;
  for (var i = 0; i < words.length; i++) if (words[i] && CHLOE_IMG_PL_WORDS[words[i]]) hits++;
  return hits >= 2;
}

// Slownik jest dlugi - kompilujemy raz, od najdluzszych fraz, z granica slowa
// (zeby "nogi" nie zamienialo sie w srodku "nogi" w innym wyrazie).
var CHLOE_IMG_TR_LB = (function () { try { new RegExp("(?<!a)b"); return true; } catch (e) { return false; } })();
function chloeImgCompileTr(pairs) {
  pairs = pairs.slice().sort(function (a, b) { return b[0].length - a[0].length; });
  var out = [];
  for (var i = 0; i < pairs.length; i++) {
    var key = pairs[i][0].replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
    try {
      if (CHLOE_IMG_TR_LB) out.push([new RegExp("(?<![a-ząćęłńóśźż0-9])" + key + "(?![a-ząćęłńóśźż0-9])", "gi"), pairs[i][1]]);
      else out.push([new RegExp("(^|[^a-ząćęłńóśźż0-9])(" + key + ")(?![a-ząćęłńóśźż0-9])", "gi"), "$1" + pairs[i][1]]);
    } catch (e) {}
  }
  return out;
}
var CHLOE_IMG_TR_RE = chloeImgCompileTr(CHLOE_IMG_TR);
var CHLOE_IMG_TR_STOP_RE = chloeImgCompileTr(CHLOE_IMG_TR_STOP);

function chloeImgTr(s, withStop) {
  var t = String(s == null ? "" : s);
  if (!t) return "";
  if (withStop === undefined) withStop = true; // teksty stanu sa zawsze po polsku
  for (var i = 0; i < CHLOE_IMG_TR_RE.length; i++) t = t.replace(CHLOE_IMG_TR_RE[i][0], CHLOE_IMG_TR_RE[i][1]);
  if (withStop) for (var j = 0; j < CHLOE_IMG_TR_STOP_RE.length; j++) t = t.replace(CHLOE_IMG_TR_STOP_RE[j][0], CHLOE_IMG_TR_STOP_RE[j][1]);
  return t.replace(/\s+/g, " ").replace(/^[\s,]+|[\s,]+$/g, "").trim();
}

// Prosba uzytkownika: pelne tlumaczenie + czyszczenie slowek funkcyjnych tylko
// wtedy, gdy prosba jest po polsku.
function chloeImgTrAsk(s) {
  return chloeImgTr(s, chloeImgIsPl(s));
}

// Pola stanu bywaja tablicami, a Array.toString() sklada je BEZ spacji po
// przecinku ("wilgotna skóra,twarde sutki") - dlatego zawsze skladamy sami.
function chloeImgStr(v) {
  if (v == null) return "";
  if (Array.isArray(v)) return v.filter(Boolean).join(", ");
  return String(v);
}

// =====================================================================
// 2) LEX: fragment sceny (PL/EN) -> [wzorzec, tagi, grupa]
// Grupy: act (akt seksualny/plyny), kink, body, pose, scene, cloth.
// Wzorce sa odporne na polskie znaki (klasy [lł], [aą] ...), bo stan sceny
// i czat sa po polsku, a tagi obrazu po angielsku.
// UWAGA: jeden wzorzec = JEDEN zestaw tagow. Nie wolno wrzucac do jednego
// wzorca rzeczy, ktore moga wystapic osobno (np. "anal" razem ze "strap-on"),
// bo wtedy jedno slowo z czatu wciaga 5 tagow, ktorych w scenie nie ma.
// =====================================================================
var CHLOE_IMG_LEX = [
  [/(minet|oral|obci[aą]g|lodzik|loda\b|blowjob|fellatio|ssie (?:penis|fiut|kut)|ssan\w* (?:penisa|fiuta|kuta)|w gardle|do gard[lł]a|g[lł][eę]bok\w*.{0,18}gard[lł]|deepthroat|facefuck|twarz[aęy].{0,18}(?:penis|fiut|kut))/i,
    "fellatio, hard cock deep in throat, lips stretched around the shaft, saliva, tongue out, hand gripping the base", "act"],
  [/(cunniling|minetka|liz[aąe].{0,22}(?:cipk|pizd|wag[cę]|l[ł]echtaczk|clit)|j[eę]zyk.{0,20}(?:cipk|pizd|l[ł]echtaczk)|face.?sitting|siad[aą]\w*.{0,10}na twarzy)/i,
    "cunnilingus, tongue on clitoris, face buried between her thighs, her thighs squeezing his head", "act"],
  [/(ssie (?:piersi|sut|pier[sś])|ssanie piersi|ssie sut|gryz[iaę] sut|pie[śs]ci piersi|j[eę]zyk.{0,16}sutk|circel?\w* (?:the )?areola)/i,
    "sucking her nipples, tongue circling the areola, saliva on her breast", "act"],
  [/(palcówk|palcuje|fingering|(?:d[lł]o[ńn]|r[eę]k[ai]|palc\w*).{0,24}(?:cipk|pizd|wag[cę]|mi[eę]dzy nogi|wn[eę]trz|odbyt)|wsuwa palce|palce w [śs]rodku)/i,
    "fingering, two fingers inside her pussy, spread pussy lips, wet glistening folds, hand between her thighs", "act"],
  [/(masturb|onaniz|zabawia si[eę] sama|sama si[eę] (?:pie[śs]ci|doprowadza)|rub(?:s|bing)|palcuje si[eę])/i,
    "masturbating, fingers rubbing her clitoris, legs spread, alone, self-pleasure, solo", "act"],
  [/(prostat)/i,
    "prostate massage, gloved lubricated finger pressing deep inside him, visible anus, latex glove", "act"],
  [/(pegging|strap.?on|harness|pas z dildo|przypina dildo|przyrz[aą]d.{0,16}(?:erot|seksual|dla doros))/i,
    "strap-on harness, pegging, dildo strapped over her hips, harness straps on her thighs", "kink"],
  [/(anal(?:ny|nie|u|em)?\b|ass ?fuck|anal sex|do dupy|w dup[eę]|w pup[eę]|analn)/i,
    "anal penetration, stretched anal opening, spread ass cheeks, cock buried in her ass, oiled skin", "act"],
  [/(odbyt|anilingu|rimming|otw[oó]r odbytu)/i,
    "visible anus, spread ass cheeks, oiled skin, ass presented to the camera", "act"],
  [/(doggy|od ty[lł]u|from behind|na czworak)/i,
    "doggy style from behind, seen from behind, ass raised high, back arched", "act"],
  [/(penetrac|pierdol|jeb(?:ie|ać|ac)|rucha|stosunek|\bseks\b|kopulac|fuck|penetrat|na je[źz]d[źz]ca|missionar|uprawia)/i,
    "vaginal penetration, erect cock inside her, deep thrust, bodies pressed tight, motion blur", "act"],
  [/(orgazm|dochodz|kulminacj|szczyt(?:uje|owanie)|ekstaz|orgasm|climax)/i,
    "climax, arched back, curled toes, clenched fists, mouth open, ecstatic face, trembling thighs", "act"],
  [/(squirt|tryska|strumie[ńn]|fontann)/i,
    "squirting hard, fluid spraying, soaked thighs and wet sheets", "act"],
  [/(creampie|wytrysk.{0,12}w |wype[lł]nia.{0,18}(?:wn[eę]trz|cipk)|zostawia.{0,18}w (?:środku|niej)|sperm.{0,12}(?:w środku|w cipce))/i,
    "creampie, cum dripping out of her pussy, filled pussy, semen on inner thighs", "act"],
  [/(cum|sperm|wytrysk|sperma|nasien|spust|trysn|obtrysk|na twarz|facial|bukakke)/i,
    "cum, semen on her skin, thick white fluid, strands of cum on face and chest", "act"],
  [/(fisting|pi[eę][śs][ćc]|gape|rozci[aą]gni[eę]t[aey]|prolapse|speculum|wziernik)/i,
    "extremely stretched opening, extreme close-up on gaping hole, glistening stretched tissue, speculum", "act"],
  [/(sounding|urethra|c[eę]wnik|brzmi[aą]c)/i,
    "thin metal rod in urethra, extreme close-up on penis tip, medical precision", "act"],
  [/(laktac|mlek|milking|doi(?:c|enie)|ssanie piersi|karmi)/i,
    "lactation, milk dripping from her nipples, suckling", "act"],
  [/(edging|denial|powstrzym|odmowa|zakaz doj[śs]cia|nie wolno ci)/i,
    "denied orgasm, straining muscles, desperate expression, swollen hard erection, precum", "act"],
  [/(ca[lł]uj|poca[lł]unk|kiss|nami[eę]tn)/i,
    "deep wet kiss, tongues touching, hands roaming over her body, bodies pressed together, foreplay", "act"],
  [/(rozbiera|zdejmuje|ściąga|sciaga|rozpina|zsuwa|podciąga sukienk|obna[żz]a|zdejmowan)/i,
    "mid-undress, clothing pulled aside, bra strap slipping down, half-removed clothes, exposed skin", "act"],

  [/(dildo|wibrator|zabawk|butt ?plug|anal ?plug|massage ?wand|korek analny|wibruj|wibrac)/i,
    "sex toy, dildo, ribbed vibrator in her hand, wet with lube, visible toy in frame", "kink"],
  [/(kajdan|cuffs|wi[aą]z|wi[eę]z|bondage|sznur|(?:^|[^a-ząćęłńóśźż])(?:lin[aąeęy]|linka|lince|lino)|(?:^|[^a-ząćęłńóśźż])s?kr[eę]p|unieruchom|przywi[aą]zan|shibari|kn[oó]t)/i,
    "bondage, rope around wrists, wrists tied to the bed frame, shibari rope harness, restrained, helpless pose", "kink"],
  [/(knebel|kaganiec|gag|ball ?gag|opaska na oczy|blindfold|zatyczk)/i,
    "ball gag in her mouth, blindfold over her eyes, drooling around the gag", "kink"],
  [/(obro[żz]|smycz|collar|leash|petplay|kitten|puppy|kociak|szczeniaczek)/i,
    "leather collar with a metal ring, leash pulled taut, on all fours like a pet", "kink"],
  [/(klaps|spank|lanie|ch[lł]ost|pejcz|bat\b|krzy[żz]yk|crop|whip|dyscyplin)/i,
    "red handprints on her ass, spanking marks, flushed reddened skin, whip marks", "kink"],
  [/(duszen|dusi|dusi[lł]|za gard[lł]o|chwyta za szyj|[śs]ciska szyj|chok|throat.?grab|r[eę]ka na szyi)/i,
    "his hand around her throat, fingers gripping her neck, breath play, reddened neck", "kink"],
  [/(za w[lł]osy|w[lł]osy.{0,14}(?:ci[aą]gn|poci[aą]gn|szarp|trzym)|hair.?pull)/i,
    "hair pulled hard, head tilted back, exposed throat", "kink"],
  [/(poni[żz]an|upokarz|degradac|humiliat|wstyd|obna[żz]on|zawstydz)/i,
    "humiliated expression, exposed and vulnerable, blushing, degrading pose", "kink"],
  [/(domin|pani\b|mistrz|kontrol|femdom|podporz[aą]dk|uleg[lł]|submis|niewolni|tresur)/i,
    "dominant stance, commanding gaze, hand on hip, collar and leash, submissive partner", "kink"],
  [/(ch[lł]ust|enema|watersport|z[lł]ota|piss|mocz)/i,
    "soaked body, streaming fluid, drenched skin", "kink"],
  [/(klatk[aę]|chastity|pasek cnot|zawieszon|suspension|drabink)/i,
    "chastity cage, steel belt, rope suspension from the ceiling", "kink"],
  [/(wielu|dw[oó]ch m[eę][żz]czyzn|gangbang|threesome|tr[oó]jka|orgia|double)/i,
    "multiple partners, threesome, surrounded by hands, group scene", "kink"],
  [/(monstr|potw[oó]r|tentacl|macki|demon|furry|knot|smok|dragon)/i,
    "tentacles wrapping her body, monster silhouette, fantasy creature, dim otherworldly light", "kink"],
  [/(futa|futanari|she.?male|trans\b|penis i cipka)/i,
    "futanari, both erect cock and pussy visible", "kink"],
  [/(himbofic|bimbofik|transfor|hypno|hipnoz|tg\b|tf\b)/i,
    "transformed bimbo body, glassy hypnotised eyes, exaggerated curves, glossy lips", "kink"],

  [/(piersi|cyck|sutk|breast|nipple|biust|dekolt|cleavage|stanik|bra\b)/i,
    "bare breasts, erect nipples, deep cleavage, natural soft breast shape", "body"],
  [/(cipk|pizd|wag[eęc]|srom|vulva|pussy|l[eę]chtaczk|clit|wargi sromowe|labia|szpar|sromn)/i,
    "exposed pussy, spread pussy lips, wet glistening folds, visible clitoris, smooth shaved skin", "body"],
  [/(fiut|kutas|penis|cz[lł]onek|cock|dick\b|napletek|erekcj|wzw[oó]d|erect)/i,
    "erect cock, visible veins, glistening head, foreskin pulled back, hand gripping the shaft", "body"],
  [/(ty[lł]ek|pupa|po[śs]ladk|ass\b|butts?\b|dupa|pupcia|zadek)/i,
    "round bare ass, soft cheeks, oiled skin, visible anus", "body"],
  [/(stop[ayie]|st[oó]p[ayie]?(?![a-ząćęłńóśźż])|feet\b|foot\b|palce u n[oó]g|toes\b|podeszw|soles?\b)/i,
    "bare feet, soles visible, curled toes, ankle in frame", "body"],
  [/(pachwin|[lł]ydk|(?:^|[^a-ząćęłńóśźż])ud[ao](?![a-ząćęłńóśźż])|nog[aię]|thighs?|legs?\b|rozk[lł]ada nogi|rozstawia nogi|mi[eę]dzy nogami)/i,
    "legs spread wide, soft inner thighs, glistening thighs, flexible pose", "body"],
  [/((?:^|[^a-ząćęłńóśźż])pot(?![a-ząćęłńóśźż])|spocon|sweat|wilgotn|glistening|[śs]liski|mokr[aey])/i,
    "sweaty glistening skin, wet sheen, droplets on her skin", "body"],
  [/(ci[aą][żz]|pregnant|brzuch|ci[eę][żz]arn)/i,
    "pregnant belly, swollen breasts, full curves", "body"],

  [/(kl[eę]cz|na kolanach|kneel)/i, "kneeling on the floor, thighs apart, looking up", "pose"],
  [/(czworak|na czterech|all ?fours|wypi[eę]t|bi(?:u|ó)st do przodu|arch)/i,
    "on all fours, ass raised high, back arched, face down", "pose"],
  [/(na plecach|le[żz]y|le[żz][aą]c|on her back|misjonar|nogi w g[oó]r[eę]|uniesione nogi)/i,
    "lying on her back, legs raised and spread, ankles up, belly exposed", "pose"],
  [/(przysiad|siad\w*.{0,12}(?:na|okrakiem)|na je[źz]d[źz]ca|riding|cowgirl|je[źz]d[źz]c)/i,
    "straddling him, riding, hips grinding, bouncing breasts", "pose"],
  [/(st[oó][lł]|blat|biurko|desk|na stole)/i, "on top of a table, table edge and surface in frame", "pose"],
  [/(lustr|mirror|przed lustrem)/i, "mirror reflection, seen from two angles at once", "pose"],
  [/(pov|z jej perspektywy|z mojej perspektywy|widok z g[oó]ry|z g[oó]ry)/i,
    "POV shot, viewer looking down at her, hands in the frame", "pose"],
  [/(patrzy na mnie|patrzy w obiektyw|w oczy|looks? at (?:the )?camera|eye contact|do obiektywu)/i,
    "direct eye contact with the camera, looking straight into the lens, parted lips", "pose"],

  [/(lateks|latex|guma|pvc|leather|koronk|(?:^|[^a-ząćęłńóśźż])laces?(?![a-ząćęłńóśźż])|bielizn|lingerie|po[ńn]czoch|stockings?|kabaretk|fishnet|gorsec|corset|szpil|heels)/i,
    "black lace and latex lingerie, garter belt, fishnet stockings, high heels", "cloth"],
  [/(prysznic|wanna|k[aą]piel|shower|bath|\bmokr)/i, "wet skin, water droplets, steam, soaked hair", "scene"],
  [/(wirtual|vr\b|headset|gogle)/i, "VR headset, first person view, glowing virtual room", "scene"],
  [/(noc\b|nocn|ciemn|mrok|ksi[eę][żz]yc|moonlight)/i, "darkness, single warm lamp, deep shadows, moonlight rim light", "scene"],
  [/(rano|poranek|dzie[ńn]\b|s[lł]o[ńn]c|daylight|okno|window)/i, "morning daylight through the window, soft sun flare", "scene"],
  [/(deszcz|burz|śnieg|[śs]nie[żz]|zimn|zima)/i, "rain streaked window, cold blue light, wet glass", "scene"],
  [/(bibliotek|ksi[aą][żz]k|nauczycielk|szko[lł]|lekcj|uczennic|student|librar|study)/i,
    "floor to ceiling bookshelves, old books and desk lamp, scholarly messy room", "scene"],
  [/(kuchni|kitchen|kuchenn)/i, "kitchen interior, tiled counter, dishes in the background, warm home light", "scene"],
  [/(sypialni|bedroom|[lł][oó][żz]k|bed\b)/i, "bedroom, bed with rumpled sheets, dim warm lamp light", "scene"],
  [/(salon|living room|kanap|sofa|couch)/i, "living room, sofa in frame, soft lamp light, home interior", "scene"],
  [/([lł]azienk|bathroom|wann|bathtub)/i, "bathroom, wet tiles, steam in the air, mirror in frame", "scene"],
  [/(og[róo]d|garden|las\b|forest|pla[żz]|beach|park|na zewn|outdoor)/i,
    "outdoor setting, natural daylight, greenery, open sky", "scene"],
  [/(biuro|office|firmow)/i, "home office desk, papers and keyboard in frame, desk lamp", "scene"],
  [/(samoch|car\b|auto\b|w aucie)/i, "car interior, dashboard and seat in frame, night city lights outside", "scene"]
];

// Maksymalna liczba tagow z kazdej grupy (kolejnosc = priorytet NSFW).
var CHLOE_IMG_GROUP_MAX = { act: 22, kink: 12, body: 10, pose: 4, cloth: 3, scene: 4 };

function chloeImgLexHits(text, isCore) {
  var t = " " + String(text == null ? "" : text) + " ";
  var out = [], seen = {};
  for (var i = 0; i < CHLOE_IMG_LEX.length; i++) {
    if (!CHLOE_IMG_LEX[i][0].test(t)) continue;
    var group = CHLOE_IMG_LEX[i][2] || "scene";
    var tags = CHLOE_IMG_LEX[i][1].split(", ");
    for (var j = 0; j < tags.length; j++) {
      var tag = tags[j].replace(/\s+/g, " ").trim();
      if (!tag) continue;
      var key = chloeNorm(tag);
      if (seen[key]) continue;
      seen[key] = 1;
      out.push({ tag: tag, group: group, rule: i, core: !!isCore });
    }
  }
  return out;
}

function chloeImgLexTags(text) {
  var hits = chloeImgLexHits(text), out = [];
  for (var i = 0; i < hits.length; i++) out.push(hits[i].tag);
  return out;
}

// Slowo "bielizna" przewaznie nie znaczy, ze ma byc ubrana w scenie, w ktorej
// jest juz nago - dlatego przy poziomie 2-3 ubranie wchodzi tylko wtedy, gdy
// stan sceny naprawde o nim mowi.
var CHLOE_IMG_CLOTH_WORDS = /(lateks|latex|koronk|lace|bielizn|lingerie|po[ńn]czoch|stocking|kabaretk|fishnet|gorsec|corset|szpil|heels|kostium|stroj)/i;

// Kinki, ktorych nie da sie pokazac na jednym zdjeciu (rozmowa, pisanie,
// fantazjowanie, wymiana wiadomosci). Na liscie "kinks she loves" tylko
// rozwadniaja prompt obrazu i zabieraja miejsce eksplicytnym aktom.
// Dolne czesci ubrania, ktorych NIE wolno wymieniac w opisie przy poziomie 2-3:
// samo slowo "shorts" sprawia, ze SD rysuje spodenki na cipce.
var CHLOE_IMG_CLOTH_LOWER = /(\bspoden|szort|\bshorts?\b|majtk|string|panties|thong|sp[oó]dnic|\bskirt|jeans|d[żz]ins|trousers|spodni|leggins|rajstop|pantyhose|pas\b|cummerbund)/i;

var CHLOE_IMG_KINK_NOVIS = /(sexting|dirty ?talk|fantasy ?talk|fantas|opowiad|rozmow|s[lł]ow|tekst|chat|pisani|rolplay|role ?play|wymian|telefon|zdj[eę]ci|photo ?exchange|wysy[lł]a)/i;

// =====================================================================
// 3) POZIOM EKSPLICYTNOSCI 0..3
// =====================================================================
var CHLOE_IMG_LV = [
  "sensual suggestive photograph, teasing pose, seductive glance at the camera, soft ambient light, clearly aroused but dressed",
  "semi-nude tease, clothes pulled open, hard nipples through thin fabric, bare thighs, hand on her own body, biting her lower lip, aroused and inviting",
  "fully nude, completely naked, bare breasts with erect nipples, exposed pussy with no fabric over her crotch, spread legs, wet glistening pussy lips, hand between her thighs, arched back, sweat on her skin, uncensored nudity, nothing hidden, no censorship",
  "explicit hardcore pornography, completely naked, clothes off or pushed fully aside and never over her crotch, legs spread wide, exposed and spread bare pussy, visible penetration, gaping wet opening, juices and sweat, erect cock or fingers clearly inside her, genital detail in sharp focus, obscene explicit pose, absolutely uncensored, no mosaic, no censorship, nothing covered and nothing cropped"
];
var CHLOE_IMG_LV_HARD = /(penetrac|wchodz|wbij|wsuwa|pierdol|jeb|rucha|stosunek|\bseks\b|anal|oral|minet|obci[aą]g|orgazm|dochodz|squirt|creampie|cum|sperm|wytrysk|fist|gape|dildo|wibrator|pegging|strap|cunniling|fingering|palc[ue]|klaps|spank|bondage|kajdan|wi[aą]z|duszen|gard[lł]|sounding|prolapse|edging|denial|laktac|milking|tentacl|masturb|onaniz|hardcore|brutal|perwers|zbocz|explicit|uncensored|bez cenzury|nieocenzurow)/i;

// Warianty dla scen, w ktorych ona NIE jest calkiem nago (koszula rozpięta,
// sukienka podciagnieta). Bez tego prompt mowil jednoczesnie "completely
// naked" i "clothes: unbuttoned shirt" - model srednil i ubieral ja z powrotem.
var CHLOE_IMG_LV_DRESSED = {
  2: "clothes pulled open and pushed aside, breasts and pussy fully exposed, hard nipples, bare thighs, one leg out of her clothes, half-dressed and shameless, nothing hidden, no censorship",
  3: "explicit hardcore pornography, her clothes pulled wide open and pushed fully aside so nothing covers her crotch, bare breasts and completely exposed bare pussy, legs spread wide, visible penetration, gaping wet opening, juices and sweat, erect cock or fingers clearly inside her, genital detail in sharp focus, obscene explicit pose, absolutely uncensored, no mosaic, no censorship, nothing covered and nothing cropped"
};
var CHLOE_IMG_NUDE = /(nago|naga|nagie|nude|naked|topless|bez ubran|rozbier|rozbrana|bielizn|lingerie|do naga|obna[żz]|piersi|cyck|sutk|cipk|pizd|pup[ay]|ty[lł]ek|fiut|kutas|penis|cock)/i;

function chloeImgLevel(ctx) {
  var st = ctx.st || {};
  var txt = String(ctx.all || "");
  var ar = Number(st.pobudz) || 0;
  var faza = chloeNorm(st.faza || "");
  var lv = 0;
  if (CHLOE_IMG_NUDE.test(txt)) lv = 2;
  if (CHLOE_IMG_LV_HARD.test(txt)) lv = 3;
  if (/(seks|penetracj|oral|anal|orgia|hardcore|pierdol|rucha)/.test(faza)) lv = 3;
  else if (/(gra|foreplay|pieszczot|oraln)/.test(faza) && ar >= 40) lv = Math.max(lv, 2);
  if (ar >= 45) lv = Math.max(lv, 1);
  if (ar >= 60) lv = Math.max(lv, 2);
  if (ar >= 80) lv = Math.max(lv, 3);
  if (ctx.level != null && ctx.level !== "") lv = Math.max(lv, Number(ctx.level) || 0);
  // Trwala preferencja uzytkownika (/obraz poziom N) wybiera poziom automatycznie.
  try {
    var pref = Number(chloeRPGet().imgpoziom) || 0;
    if (pref >= 1) lv = Math.max(lv, Math.min(3, pref));
  } catch (eL) {}
  return Math.max(0, Math.min(3, lv));
}

// =====================================================================
// 4) ZDANIE AKCJI - jeden naturalny angielski opis TEGO, CO SIE DZIEJE.
// Stheno i SD rozumieja zdanie lepiej niz liste tagow, a to jest wlasnie
// "idealnie trafiajacy w czat" element briefu.
// =====================================================================
var CHLOE_IMG_ACT_SENT = [
  // Rekawica / dluga dlonia = zabawa z zabawka: partner to widz (POV), bo to
  // jego cialo jest w scenie. Bez tego tag "prostate massage" ladowal jako
  // "anal play" bez osoby, ktora mialaby byc masowana.
  [/(prostat|d[łl]ug[aąeę] (?:d[łl]o[ńn]|r[ęe]k[aię]|ramię|ramie)|fisting glove|r[ęe]kawic)/i,
    "reaching between the viewer's spread legs with a long latex fisting glove on, her gloved fingers sunk deep inside him, shot from the viewer's own point of view"],
  [/(pegging|strap.?on|harness|pas z dildo)/i, "fucking him with a strap-on harness"],
  [/(minet|oral|obci[aą]g|lodzik|blowjob|deepthroat|gard[lł])/i, "on her knees sucking a hard cock, lips stretched around the shaft, saliva dripping"],
  [/(cunniling|minetka|liz[aąe].{0,22}(?:cipk|pizd|wag[cę]|l[ł]echtaczk))/i, "legs spread while he eats her out, tongue buried in her pussy"],
  [/(palcówk|palcuje|fingering|wsuwa palce|palce w [śs]rodku)/i, "getting fingered, two fingers deep inside her wet pussy"],
  [/(masturb|onaniz|sama si[eę])/i, "masturbating, her own fingers rubbing her clitoris"],
  [/(dildo|wibrator|zabawk|plug)/i, "with a sex toy pushed deep inside her"],
  [/(anal|od ty[lł]u|w dup|w pup|doggy)/i, "fucked hard from behind, anal penetration, ass raised"],
  [/(penetrac|pierdol|jeb|rucha|stosunek|\bseks\b|fuck|wchodzi|wsuwa|wbija)/i, "being fucked hard, a thick cock buried deep inside her"],
  [/(orgazm|dochodz|squirt|tryska)/i, "cumming hard, body trembling, back arched, moaning"],
  [/(cum|sperm|wytrysk|sperma|creampie)/i, "covered in thick warm cum"],
  [/(klaps|spank|lanie)/i, "getting spanked, red handprints on her ass"],
  [/(duszen|dusi|za gard[lł]o|chwyta za szyj|[śs]ciska szyj|chok|throat.?grab)/i, "his hand wrapped around her throat"],
  [/(kajdan|wi[aą]z|bondage|sznur|lin[aąy]|unieruchom)/i, "tied up and helpless, wrists bound"],
  [/(knebel|gag|kaganiec)/i, "gagged, drooling around the gag"],
  [/(ca[lł]uj|poca[lł]unk|kiss)/i, "kissing deeply, tongues touching"],
  [/(rozbiera|zdejmuje|rozpina|zsuwa)/i, "stripping her clothes off mid-scene"],
  [/(kl[eę]cz|na kolanach)/i, "kneeling submissively in front of him"],
  [/(przysiad|okrakiem|riding|je[źz]d[źz]c|na nim)/i, "riding him, hips grinding, bouncing on top"],
  [/(le[żz]y|na plecach|on her back)/i, "lying on her back with her legs raised and spread"]
];

function chloeImgSentence(ctx, text, lv, ubr) {
  var frags = [];
  for (var i = 0; i < CHLOE_IMG_ACT_SENT.length; i++) {
    var m = String(text).match(CHLOE_IMG_ACT_SENT[i][0]);
    if (m) frags.push({ s: CHLOE_IMG_ACT_SENT[i][1], pos: String(text).length - (m.index || 0) });
  }
  frags.sort(function (a, b) { return a.pos - b.pos; });
  frags = frags.slice(0, 2).map(function (f) { return f.s; });
  var bits = [];
  if (frags.length) bits.push(frags.join(", and "));
  var pose = chloeImgTr(ctx.st.poz || "");
  var lok = chloeImgTr(ctx.st.lok || "");
  var czas = chloeImgTr(ctx.st.czas || "");
  var ub = chloeImgTr(ubr || "");
  if (pose) bits.push(pose);
  // Ubranie: przy poziomie 2-3 zdjecie ma byc BEZCZELNE, a nie "tasteful nude".
  // Dlatego zwykle ciuchy schodza ("pulled down and out of the way"), a zostaja
  // tylko wtedy, gdy SA FETYSZEM sceny (lateks, koronka, bielizna, ponczochy) -
  // inaczej model trzyma spodniczke na cipce i zaslania genitalia.
  var clothFetish = CHLOE_IMG_CLOTH_WORDS.test(String(ubr || "")) || CHLOE_IMG_CLOTH_WORDS.test(String(ctx.ask || ""));
  if (lv >= 2) {
    if (ub && !/(nude|naked|no clothes)/i.test(ub)) {
      if (clothFetish) {
        bits.push("still wearing " + ub + ", pulled open and half off");
      } else {
        // UWAGA: "krotkie spodenki zdjete" to dla SD nadal "spodenki" - model je
        // rysuje i zakrywa nia cipke (sprawdzone na prawdziwym obrazie). Dlatego
        // przy poziomie 2-3 chodzi TYLKO to, co naprawde ma zostac na ciele
        // (np. rozpięta koszula), a dol ciala jest jawnie NAGI i bez nazw ciuchow.
        var upper = String(ub).split(/\s*,\s*/).filter(function (piece) {
          return piece && !CHLOE_IMG_CLOTH_LOWER.test(piece);
        }).join(", ");
        // UWAGA (zmierzone na prawdziwym obrazie): samo "clothes on her lower body
        // completely off" nie wystarczylo - Stheno potrafil opisac rozpięta koszule
        // jako zielony top, ktory zjechal na biodra i zakryl krok, a SD to
        // narysowalo (obraz 1 z 2 w teście v7). Dlatego mowimy wprost: gorna
        // czesc jest podniesiona NAD talie i nic nie schodzi ponizej pasa.
        bits.push(upper ? "only a " + upper + ", open and pushed up above her waist" : "completely naked");
        bits.push("nothing on her lower body: no clothes, no shorts, no panties, no garment of any kind reaching down to her crotch or hips, her lower body completely bare from the waist down");
      }
    } else if (ub) bits.push(ub);
  } else if (ub) bits.push("wearing " + ub);
  var where = [];
  if (lok) where.push("in the " + lok);
  if (czas) where.push(czas);
  if (where.length) bits.push(where.join(", "));
  if (!bits.length) bits.push(lv >= 2 ? "in an intimate camera framing, her body fully exposed and spread open" : "in a teasing seductive pose");
  var s = "what is happening right now: Chloe is " + bits.join(", ") + ".";
  // Kadr: przy akcji genitalia MUSZA byc widoczne i nie moze ich nic zaslaniac.
  if (lv >= 2) s += " Her thighs are spread wide apart with her knees open and the camera looks straight between them: her crotch is open and completely bare, no fabric, no clothing and no hands cover it, nothing stands in front of her genitals, nothing blocks the view and nothing is cropped.";
  return s.replace(/\s+/g, " ").replace(/,\s*,+/g, ", ").trim();
}

// ---------------------------------------------------------------------
// KADR: "pelny obraz" czy zblizenie?
// Zdjecie ma pokazywac CALE cialo i scene (nic nie uciete), a jednoczesnie
// genitalia musza byc widoczne - dlatego domyslnie pelne cialo w kadrze,
// a nie makro na genitalia. Zblizenie wybieramy tylko wtedy, gdy uzytkownik
// naprawde o nie prosi ("z bliska", "detal") albo ustawi /obraz kadr close.
// ---------------------------------------------------------------------
var CHLOE_IMG_SHOT = {
  full: "full body shot, her whole figure visible from head to toes, legs spread wide open, wide vertical composition, the room visible around her, nothing cut off by the frame, nothing draped over her crotch or hips, no garment hanging down over her body, her open crotch in the center of the frame and in sharp focus",
  body: "full body visible from head to thighs in one frame, medium full shot, low camera angle, legs spread wide open with her thighs apart, nothing draped over her crotch or hips, no garment hanging down over her body, no cloth between her legs, her exposed open crotch centered in the frame, genitals prominent, unobscured and in sharp focus, nothing blocking them and nothing cut off by the frame",
  close: "extreme close-up on the action between her spread legs, low camera angle, nothing draped over her crotch, genital detail in sharp focus, shallow depth of field"
};
var CHLOE_IMG_SHOT_CLOSE_ASK = /(z bliska|zbli[żz]|close.?up|detal|makro|macro|tylko (?:cipka|pizda|detal)|sam[ay] (?:cipk|pizd))/i;
var CHLOE_IMG_SHOT_FULL_ASK = /(ca[lł]e cia[lł]o|pe[lł]n[aey] posta[ćc]|od st[oó]p|w ca[lł]o[śs]ci|full body|wide shot|szeroki kadr|ca[lł]a sylwetk)/i;

function chloeImgKadr() {
  var k = "";
  try { k = String(chloeRPGet().imgkadr || ""); } catch (e) {}
  if (!k || k === "auto") { try { k = String(chloeE2Get().kadr || ""); } catch (e2) {} }
  k = chloeNorm(k);
  if (k === "full" || k === "pelny" || k === "caly") return "full";
  if (k === "close" || k === "zblizenie" || k === "blisko") return "close";
  return "auto"; // auto = pelne cialo, zblizenie tylko na wyrazna prosbe
}

function chloeImgShot(tags, kadr, ask) {
  var mode = kadr || chloeImgKadr();
  if (mode === "full") return CHLOE_IMG_SHOT.full;
  if (mode === "close") return CHLOE_IMG_SHOT.close;
  var a = String(ask || "");
  if (CHLOE_IMG_SHOT_CLOSE_ASK.test(a)) return CHLOE_IMG_SHOT.close;
  if (CHLOE_IMG_SHOT_FULL_ASK.test(a)) return CHLOE_IMG_SHOT.full;
  var s = chloeNorm((tags || []).join(" "));
  if (/pov shot/.test(s)) return "POV shot, viewer looking down at her, hands in the frame, her whole body visible from head to thighs";
  return CHLOE_IMG_SHOT.body;
}

// Twarde granice -> lista wykluczen (nigdy na obrazie).
function chloeImgHardLimits() {
  var out = [], lim = {};
  try { lim = chloeRPLimits(); } catch (e) { return []; }
  for (var k in lim) {
    if (!lim.hasOwnProperty(k)) continue;
    if (String(lim[k]) === "hard") out.push(chloeImgTr(String(k).slice(0, 40)));
  }
  return out.slice(0, 20);
}

function chloeImgClip(s, n) {
  var t = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  if (t.length <= n) return t;
  return t.slice(t.length - n).replace(/^\S*\s/, "");
}

// Ostatnie tury czatu. Krotkie wersje ida do briefu, dluzsze do wykrywania tagow.
// Bierzemy DWA ostatnie wymiany (biezaca + poprzednia): biezaca to "teraz",
// poprzednia to slabe wsparcie. Wazna kolejnosc: najnowsze najpierw.
function chloeImgRecent() {
  var user = "", ai = "", userLong = "", aiLong = "";
  var userPrev = "", aiPrev = "";
  try {
    var h = chloeE2History(10, 4000);
    var aiSeen = 0, userSeen = 0;
    for (var i = h.length - 1; i >= 0; i--) {
      if (h[i].author === "ai" && aiSeen === 0) { ai = h[i].content; aiLong = h[i].content; aiSeen++; }
      else if (h[i].author === "ai" && aiSeen === 1) { aiPrev = h[i].content; aiSeen++; }
      else if (h[i].author === "user" && userSeen === 0) { user = h[i].content; userLong = h[i].content; userSeen++; }
      else if (h[i].author === "user" && userSeen === 1) { userPrev = h[i].content; userSeen++; }
      if (aiSeen > 1 && userSeen > 1) break;
    }
  } catch (e) {}
  return {
    user: chloeImgClip(user, 260), ai: chloeImgClip(ai, 340),
    userLong: chloeImgClip(userLong, 420), aiLong: chloeImgClip(aiLong, 1200),
    userPrev: chloeImgClip(userPrev, 200), aiPrev: chloeImgClip(aiPrev, 400)
  };
}

// Kotwica "biezacego momentu": 1-2 zdania EN z OSTATNIEJ wymiany (AI > user),
// czyszczone ze znacznikow i dialogowych ozdobnikow. Idzie tuz za zdaniem akcji,
// przed tagami - zeby SD czytalo najpierw to, co dzieje sie TERAZ.
function chloeImgMoment(rec, cleanAsk) {
  var bits = [];
  try {
    var ai = String((rec && rec.aiLong) || "");
    var us = String((rec && rec.userLong) || "");
    var clean = function (t) {
      t = String(t == null ? "" : t);
      t = t.replace(/<<stan[\s\S]*?>>/gi, " ");
      t = t.replace(/\[\[[^\]]*\]\]/g, " ");
      t = t.replace(/<\s*image[\s\S]*?<\s*\/\s*image\s*>/gi, " ");
      t = t.replace(/@@scena-obraz@@[\s\S]*/gi, " ");
      t = t.replace(/["„”«»]/g, " ");
      return t.replace(/\s+/g, " ").trim();
    };
    ai = clean(ai); us = clean(us);
    ai = chloeImgClip(ai, 480); us = chloeImgClip(us, 260);
    var aiEn = ai ? chloeImgTr(ai) : "";
    var usEn = us ? chloeImgTr(us) : "";
    aiEn = aiEn.replace(/\s+/g, " ").trim();
    usEn = usEn.replace(/\s+/g, " ").trim();
    if (aiEn && aiEn.length > 24) bits.push("right now: " + chloeImgClip(aiEn, 380));
    if (usEn && usEn.length > 16 && chloeNorm(usEn).length > 8) bits.push("and: " + chloeImgClip(usEn, 200));
  } catch (eM) {}
  return bits.join(" ").replace(/\s+/g, " ").trim();
}

// Wyczysc prosbe uzytkownika ("wygeneruj mi zdjecie, jak...") z polecen i smieci,
// zeby do promptu nie wchodzily slowa-polecenia.
function chloeImgCleanAsk(s) {
  var t = String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  var B = "(^|[^a-ząćęłńóśźż])";
  var E = "(?![a-ząćęłńóśźż])";
  var verbs = "wygeneruj|stworz|stwórz|narysuj|namaluj|pokaz|pokaż|wyswietl|wyświetl|zrob|zrób|daj|wyslij|wyślij|przeslij|prześlij|podeslij|podeślij|wrzuc|wrzuć|dodaj|szybko|teraz|prosze|proszę|please|generate|create|make|draw|send|show";
  var nouns = "obraz|obrazek|zdjecie|zdjęcie|zdjecia|zdjęcia|fotk[eę]|foto|grafike|grafikę|ilustracje|ilustrację|render|selfie|picture|image|photo";
  t = t.replace(new RegExp(B + "(?:" + verbs + ")" + E, "gi"), "$1");
  t = t.replace(new RegExp(B + "(?:" + nouns + ")" + E, "gi"), "$1");
  // Zaimki/"mi" po polsku - bez \b, bo polskie znaki diakrytyczne lamia granice slowa.
  t = t.replace(new RegExp(B + "(?:mi|mnie)" + E, "gi"), "$1");
  t = t.replace(/\s*[,.;:]+/g, ", ").replace(/\s+/g, " ").replace(/^[\s,]+|[\s,]+$/g, "");
  return t;
}

// Ile znakow wolno nam wydac na brief, zeby CALY prompt (prefix + brief +
// suffix + triggery) zmiescil sie w limicie mostka (4000 znakow, twarde 400).
// Bez tego dlugi brief + dlugie triggery = HTTP 400 i brak obrazu.
function chloeImgBudget() {
  var overhead = 0;
  try {
    // Z triggerow liczy sie TYLKO tekst, ktory naprawde wchodzi do promptu -
    // sam wzorzec regexa (np. "/(nude|pussy|...)/i") nie idzie do obrazu.
    var lines = String(oc.character.imagePromptTriggers || "").split("\n"), desc = 0;
    for (var i = 0; i < lines.length; i++) {
      var L = String(lines[i]).trim();
      if (!L) continue;
      var mm = L.match(/^\/(.+?)\/([gimsuv]*):([\s\S]*)$/);
      desc += ((mm ? mm[3] : (L.split(":").slice(1).join(":") || L)).length) + 3;
    }
    // Parametry (negativePrompt:::),(resolution:::),(seed:::),(steps:::) itd.
    // wycina z tekstu chloeCloudParseParams (index.html) ZANIM cokolwiek pojdzie
    // do mostka, wiec nie zajmuja limitu 4000 znakow - bez tego krotszy niz
    // trzeba budzet briefu.
    var suf = String(oc.character.imagePromptSuffix || "").replace(/\([a-zA-Z]+:::[\s\S]*?\)\s*$/g, "");
    overhead = String(oc.character.imagePromptPrefix || "").length + suf.length + desc + 50;
  } catch (e) { overhead = 0; }
  if (!overhead) return 1700;
  // Twardy limit mostka to 4000 znakow (dluzszy prompt = HTTP 400 i brak obrazu),
  // a aplikacja ucina nadwyzke bez ostrzezenia - dlatego zostawiamy 250 znakow
  // zapasu i liczymy budzet od realnego narzutu (prefix + suffix bez parametrow
  // + teksty triggerow), a nie od stalej.
  return Math.max(1100, Math.min(2600, 4000 - overhead - 250));
}

// =====================================================================
// 5) GLOWNE: brief sceny do promptu obrazu (JEDNA LINIA)
// =====================================================================
function chloeImageBrief(ask, opts) {
  opts = opts || {};
  var ctx = { st: {}, k: {}, lim: {}, p: {}, w: {}, ask: "" };
  try { ctx.st = chloeRPState() || {}; } catch (e) {}
  try { ctx.k = chloeRPKinks() || {}; } catch (e) {}
  try { ctx.p = chloeRPProfil() || {}; } catch (e) {}
  try { ctx.w = chloeRPWorld() || {}; } catch (e) {}
  var rec = chloeImgRecent();
  var cleanAsk = chloeImgCleanAsk(ask);
  var st = ctx.st;
  var toys = chloeImgStr(st.zabawki);
  var ubr = chloeImgStr(st.ubr);
  var cialo = chloeImgStr(st.cialo);
  var poz = chloeImgStr(st.poz);
  var lok = chloeImgStr(st.lok);

  // Dwa zrodla tagow:
  //  core = prosba uzytkownika + BIEZACY stan sceny (to jest terazniejszosc),
  //  chat = ostatnie tury czatu (wsparcie - moze dotyczyc czegos, co juz minelo).
  // Tagi z "core" sa pelne; z "chat" wchodza tylko pierwsze dwa z danego wzorca,
  // zeby jedno slowo z czatu nie wciagnelo calego pakietu (np. "strap-on").
  // UWAGA: st.obietnice (plany/obietnice) NIE wchodzi do tagow - to nie scenа.
  var coreText = [cleanAsk, lok, st.czas, ubr, poz, st.faza, st.nastroj, cialo, toys].filter(Boolean).join(" ; ");
  var chatText = [rec.userLong, rec.aiLong, rec.userPrev, rec.aiPrev].filter(Boolean).join(" ; ");
  var levelText = [cleanAsk, rec.user, rec.ai, lok, st.czas, ubr, poz, st.faza,
    st.nastroj, cialo, toys].filter(Boolean).join(" ; ");
  ctx.all = levelText;
  ctx.ask = cleanAsk;
  if (opts.level != null) ctx.level = opts.level;

  var lv = chloeImgLevel(ctx);
  var kadr = chloeImgKadr();
  // Tryb "wprost" ustawia sie w panelu Obrazy (checkbox) lub /obraz stheno on|off.
  var directSd = false;
  try { directSd = !!chloeE2Get().directToComfy; } catch (eD) {}

  // Ulubione kinki uzytkownika -> miekka podpowiedz (tlumaczona na angielski).
  var favs = [];
  for (var kk in ctx.k) {
    if (!ctx.k.hasOwnProperty(kk)) continue;
    var v = String(ctx.k[kk]);
    if (v === "5" || v === "lubi" || v === "curious") {
      var enFav = chloeImgTr(kk);
      // Kinki bez obrazu (sexting, dirty talk, fantazje) nie wchodza - patrz
      // CHLOE_IMG_KINK_NOVIS.
      if (!CHLOE_IMG_KINK_NOVIS.test(enFav)) favs.push(enFav);
    }
  }

  // Twarde granice nie moga wejsc na obraz - usuwamy ich tagi i slowa z prosby.
  var hard = chloeImgHardLimits();
  var dropTags = {};
  if (hard.length) {
    var dropList = chloeImgLexTags(hard.join(", "));
    for (var di = 0; di < dropList.length; di++) dropTags[chloeNorm(dropList[di])] = 1;
    cleanAsk = cleanAsk.split(/\s*,\s*/).filter(function (piece) {
      var low = chloeNorm(piece);
      for (var hi = 0; hi < hard.length; hi++) if (low.indexOf(chloeNorm(hard[hi])) !== -1) return false;
      return true;
    }).join(", ");
  }

  var coreHits = chloeImgLexHits(coreText, true);
  var coreKeys = {};
  for (var ci = 0; ci < coreHits.length; ci++) coreKeys[chloeNorm(coreHits[ci].tag)] = 1;
  var chatAll = chloeImgLexHits(chatText, false), chatHits = [];
  for (var hi3 = 0; hi3 < chatAll.length; hi3++) {
    var perHit = 0;
    for (var ti = 0; ti < CHLOE_IMG_LEX[chatAll[hi3].rule][1].split(", ").length; ti++) {
      var tg = CHLOE_IMG_LEX[chatAll[hi3].rule][1].split(", ")[ti].replace(/\s+/g, " ").trim();
      if (!tg) continue;
      if (coreKeys[chloeNorm(tg)]) continue;
      chatHits.push({ tag: tg, group: chatAll[hi3].group, rule: chatAll[hi3].rule, core: false });
      if (++perHit >= 2) break;
    }
  }
  var hitKeys = {};
  var hits = [];
  for (var mi = 0; mi < coreHits.length + chatHits.length; mi++) {
    var hh = mi < coreHits.length ? coreHits[mi] : chatHits[mi - coreHits.length];
    if (hitKeys[chloeNorm(hh.tag)]) continue;
    hitKeys[chloeNorm(hh.tag)] = 1;
    hits.push(hh);
    if (chatAll && hits.length > 90) break;
  }
  // "fully nude" + "czarna koronka i bielizna" naraz = model ubiera ja w scenie
  // seksu. Ubranie z LEX wchodzi wiec tylko wtedy, gdy stan sceny naprawde o nim
  // mowi (lateks/koronka/bielizna/ponczochy...), i nigdy przy poziomie 2-3 bez tego.
  var clothOn = CHLOE_IMG_CLOTH_WORDS.test(ubr) || CHLOE_IMG_CLOTH_WORDS.test(cleanAsk);
  if (lv >= 2 && !clothOn) hits = hits.filter(function (h) { return h.group !== "cloth"; });
  if (Object.keys(dropTags).length) hits = hits.filter(function (h) { return !dropTags[chloeNorm(h.tag)]; });

  // Budzet tagow per grupa + kolejnosc = priorytet NSFW.
  var order = ["act", "kink", "body", "pose", "cloth", "scene"];
  var used = {}, picked = [];
  for (var g = 0; g < order.length; g++) {
    var grp = order[g], cap = CHLOE_IMG_GROUP_MAX[grp] || 3, n = 0;
    for (var hi2 = 0; hi2 < hits.length; hi2++) {
      if (hits[hi2].group !== grp) continue;
      var key2 = chloeNorm(hits[hi2].tag);
      if (used[key2]) continue;
      used[key2] = 1;
      picked.push(hits[hi2].tag);
      if (++n >= cap) break;
    }
  }

  // Sprzeczne akty: jesli scena jest analna, nie doklejamy penetracji pochwowej
  // (inaczej obraz pokazuje dwie rzeczy naraz i zadnej dobrze). Tak samo
  // strap-on i solowa masturbacja wykluczaja "zwykla" penetracje/solo z partnerem.
  var pickKeys = {};
  for (var pk = 0; pk < picked.length; pk++) pickKeys[chloeNorm(picked[pk])] = 1;
  var hasTag = function (t) { return !!pickKeys[chloeNorm(t)]; };
  if (hasTag("anal penetration")) {
    picked = picked.filter(function (t) {
      var k = chloeNorm(t);
      return k !== chloeNorm("vaginal penetration") && k !== chloeNorm("erect cock inside her") && k !== chloeNorm("deep thrust");
    });
  }
  if (hasTag("strap-on harness")) {
    picked = picked.filter(function (t) {
      var k = chloeNorm(t);
      return k !== chloeNorm("vaginal penetration") && k !== chloeNorm("erect cock inside her") && k !== chloeNorm("deep thrust");
    });
  }
  if (hasTag("vaginal penetration") || hasTag("anal penetration")) {
    picked = picked.filter(function (t) {
      var k = chloeNorm(t);
      return k !== chloeNorm("masturbating") && k !== chloeNorm("self-pleasure") && k !== chloeNorm("solo");
    });
  }

  // Kolejnosc: NAJMOCNIEJSZE i najwazniejsze rzeczy na przod (SD wazy poczatek
  // promptu, a Stheno czyta od lewej).
  var head = [];
  head.push(CHLOE_IMG_MARK);
  head.push("Chloe");
  var dressed = lv >= 2 && ubr && !/(nude|naked|no clothes|with no clothes)/i.test(chloeImgTr(ubr));
  var lvText = dressed ? (CHLOE_IMG_LV_DRESSED[lv] || CHLOE_IMG_LV[lv]) : CHLOE_IMG_LV[lv];
  head.push(lvText);
  // Prosba uzytkownika jest NADRZEDNA wobec zgadywania z czatu.
  if (cleanAsk) head.push("the user asked for exactly this: " + chloeImgClip(chloeImgTrAsk(cleanAsk), 220));
  head.push(chloeImgSentence(ctx, coreText + " ; " + chatText, lv, ubr));
  var momentLine = "";
  try { momentLine = chloeImgMoment(rec, cleanAsk); } catch (eM2) { momentLine = ""; }
  if (momentLine) head.push("current moment, this exact frame: " + momentLine);
  var tagsPos = head.length;
  head.push(picked.join(", "));
  head.push(chloeImgShot(picked, kadr, cleanAsk));
  // Styl (EpicRealism, fotografia, ziarno) siedzi juz w imagePromptPrefix
  // i imagePromptSuffix - powtarzanie go tutaj zjada budzet i rozwadnia
  // tresc seksualna, wiec brief niesie WYLACZNIE scene i eksplicytnosc.
  if (lv >= 2) head.push("raw pornographic sex photo of a real woman, an obscene sex act clearly in progress, explicit uncensored hardcore pornography, full frontal nudity, legs spread wide open, open crotch centered in the frame, bare pussy completely exposed and unobstructed, no fabric and no clothing over her crotch, nothing covering her genitals, nothing in front of them, no hands covering her pussy, nothing cropped, spread labia, detailed vulva, visible clitoris, wet glistening folds, hard nipples, no censorship, no mosaic, no blur");
  var stLine = [];
  if (lok) stLine.push("place: " + chloeImgClip(chloeImgTr(lok), 70));
  if (st.czas) stLine.push("time: " + chloeImgClip(chloeImgTr(st.czas), 40));
  if (ubr) stLine.push("clothes: " + chloeImgClip(chloeImgTr(ubr), 90));
  if (poz) stLine.push("pose: " + chloeImgClip(chloeImgTr(poz), 100));
  if (st.faza) stLine.push("phase: " + chloeImgClip(chloeImgTr(st.faza), 40));
  if (st.nastroj) stLine.push("mood: " + chloeImgClip(chloeImgTr(st.nastroj), 50));
  if (cialo) stLine.push("marks: " + chloeImgClip(chloeImgTr(cialo), 70));
  if (toys) stLine.push("toys in use: " + chloeImgClip(chloeImgTr(toys), 70));
  if (!lok && ctx.w && ctx.w.lokacja) stLine.push("world: " + chloeImgClip(chloeImgTr(ctx.w.lokacja), 60));
  var tail = [];
  if (stLine.length) tail.push("scene state: " + stLine.join(", "));
  if (favs.length) tail.push("kinks she loves (use them if the scene allows): " + favs.slice(0, 6).join(", "));
  if (hard.length) tail.push("never render in this image: " + hard.join(", "));

  var joinParts = function (ps) {
    return ps.filter(Boolean).join(", ").replace(/\s+/g, " ").replace(/,\s*,+/g, ", ").replace(/\s+,/g, ",").trim();
  };
  var cap = chloeImgBudget();
  var out = joinParts(head.concat(tail));
  // Jesli brief nie miesci sie w budzecie, obcinamy od konca to, co najmniej
  // wazne (ulubione -> granice -> caly stan sceny -> ostatnie tagi). Styl i
  // anatomia zostaja, bo to one decyduja o jakosci i o "braku cenzury".
  if (out.length > cap) { tail = tail.filter(function (t) { return t.indexOf("kinks she loves") !== 0; }); out = joinParts(head.concat(tail)); }
  if (out.length > cap) { tail = tail.filter(function (t) { return t.indexOf("never render") !== 0; }); out = joinParts(head.concat(tail)); }
  if (out.length > cap) { tail = []; out = joinParts(head.concat(tail)); }
  while (out.length > cap && picked.length > 6) {
    picked = picked.slice(0, picked.length - 1);
    head[tagsPos] = picked.join(", ");
    out = joinParts(head.concat(tail));
  }
  if (out.length > cap) {
    var cut = out.slice(0, cap);
    var lastComma = cut.lastIndexOf(", ");
    out = (lastComma > cap - 90 ? cut.slice(0, lastComma) : cut.replace(/[\s,]+$/, ""));
  }
  // TRYB "WPROST" (bez Stheno): prompt leci do SDXL w calosci, wiec musi byc
  // krotszy (~1500 znakow) i bez etykiet - inaczej ogon rozwadnia to, co
  // najwazniejsze, a CLIP czyta tylko ~77 tokenow na fragment.
  if (directSd) {
    var dcap = 1500;
    if (out.length > dcap) { tail = tail.filter(function (t) { return t.indexOf("kinks she loves") !== 0; }); out = joinParts(head.concat(tail)); }
    if (out.length > dcap) { tail = tail.filter(function (t) { return t.indexOf("never render") !== 0; }); out = joinParts(head.concat(tail)); }
    while (out.length > dcap && picked.length > 6) {
      picked = picked.slice(0, picked.length - 1);
      head[tagsPos] = picked.join(", ");
      out = joinParts(head.concat(tail));
    }
    out = chloeImgFlattenSd(out);
    if (out.length > dcap) {
      var cut2 = out.slice(0, dcap), lc2 = cut2.lastIndexOf(", ");
      out = (lc2 > dcap - 90 ? cut2.slice(0, lc2) : cut2.replace(/[\s,]+$/, ""));
    }
    // Parametr dla mostka: (direct:::1) wycina chloeCloudParseParams i ustawia
    // pole "direct" zadania, wiec prompt nie jest przepisywany przez Stheno.
    out = out + " (direct:::1)";
  }
  return out;
}

// Tryb "wprost": brief idzie do SDXL bez Stheno, wiec musi byc czystym
// promptem - bez etykiet ("what is happening right now:", "scene state:"),
// ktore dla CLIP-a sa tylko pustymi tokenami rozwadniajacymi tresc.
function chloeImgFlattenSd(s) {
  return String(s == null ? "" : s)
    .replace(CHLOE_IMG_MARK_RE, " ")
    .replace(/what is happening right now:\s*/gi, "")
    .replace(/the user asked for exactly this:\s*/gi, "")
    .replace(/scene state:\s*/gi, "")
    .replace(/kinks she loves \(use them if the scene allows\):\s*/gi, "also includes ")
    .replace(/never render in this image:\s*/gi, "not in this image: ")
    .replace(/\s+/g, " ").replace(/,\s*,+/g, ", ")
    .replace(/^[\s,]+|[\s,]+$/g, "").trim();
}

// =====================================================================
// 6) DOKLEJANIE BRIEFU + WYCINANIE GO Z KONTEKSTU MODELU
// =====================================================================
function chloeImageEnrich(text) {
  var s = String(text == null ? "" : text);
  if (s.indexOf("<image") === -1) return s;
  if (s.indexOf(CHLOE_IMG_MARK) !== -1) return s; // juz wzbogacone (idempotencja)
  var on = true;
  try { on = chloeRPGet().imgbrief !== false; } catch (e) {}
  if (!on) return s;
  var brief = "";
  try { brief = chloeImageBrief(""); } catch (e) { return s; }
  if (!brief) return s;
  return s.replace(/<\s*image\s*>([\s\S]*?)<\s*\/\s*image\s*>/gi, function (m, core) {
    var c = String(core == null ? "" : core).replace(/\s+$/, "").trim();
    if (c.indexOf(CHLOE_IMG_MARK) !== -1) return m;
    return "<image>" + (c ? c + " " : "") + brief + "</image>";
  });
}

// Wycina brief z tekstu, ktory idzie do KONTEKSTU modelu (zeby nie zaśmiecać
// historii czatu i nie uczyc modelu naszego formatu briefu).
function chloeImgBriefStrip(text) {
  var s = String(text == null ? "" : text);
  if (s.indexOf(CHLOE_IMG_MARK) === -1) return s;
  s = s.replace(/@@scena-obraz@@[\s\S]*?(?=<\s*\/\s*image\s*>)/gi, "");
  s = s.replace(/@@scena-obraz@@[\s\S]*$/i, "");
  return s.replace(/<image>\s*<\/image>/gi, "").replace(/[ \t]+$/gm, "").replace(/\s+$/, "");
}

// Usuwa marker briefu z tekstu, ktory WYCHODZI na zewnatrz (mostek / natywny
// plugin / alt obrazu) - zeby Stheno nie zobaczyl naszych etykiet.
function chloeCloudStripMark(text) {
  var s = String(text == null ? "" : text);
  if (s.indexOf(CHLOE_IMG_MARK) === -1) return s;
  return s.replace(CHLOE_IMG_MARK_RE, " ").replace(/<button[\s\S]*?<\/button>/gi, " ").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

// =====================================================================
// 7) /obraz [poziom] [opis] : obraz wprost ze sceny, bez udzialu modelu
// =====================================================================
// Idzie sciezka aplikacji "/image <opis>", bo tylko ona tworzy wiadomosc z
// prawdziwym id (bez tego obraz nie zapisalby sie w watku na stale).
function chloeImgCommand(arg) {
  var raw = String(arg == null ? "" : arg).trim();
  // /obraz kadr full | /obraz kadr auto | /obraz kadr close
  var mk = raw.match(/^(?:kadr|kamera|framing)\s*[:=]?\s*([a-ząćęłńóśźż]+)$/i);
  if (mk) {
    var kv = chloeNorm(mk[1]);
    var kmode = "auto";
    if (kv === "full" || kv === "pelny" || kv === "caly" || kv === "cialo") kmode = "full";
    else if (kv === "close" || kv === "zblizenie" || kv === "blisko" || kv === "detal") kmode = "close";
    else if (kv !== "auto" && kv !== "body") { chloeRPPush("<i>❌ Kadr: <code>auto</code> (pelne cialo), <code>full</code> (cala sylwetka), <code>close</code> (zblizenie).</i>"); return true; }
    chloeRPSet({ imgkadr: kmode });
    var kDesc = { auto: "auto - pelne cialo z genitaliami w kadrze, zblizenie tylko gdy o nie poprosisz", full: "full - cala sylwetka od stop do glow", close: "close - zblizenie na to, co sie dzieje" }[kmode];
    chloeRPPush("<i>🖼️ Kadr obrazow: <b>" + kDesc + "</b>.</i>");
    return true;
  }
  // /obraz stheno on|off - czy prompt ma przepisywac Stheno (off = wprost do ComfyUI)
  var ms = raw.match(/^(?:stheno|rewrite|przepisywanie)\s*[:=]?\s*(on|off|wl|w[łl]|wyl|wy[łl]|direct|wprost)$/i);
  if (ms) {
    var sRaw = chloeNorm(ms[1]);
    var sOn = !(sRaw === "off" || sRaw === "wyl" || sRaw === "direct" || sRaw === "wprost");
    try { chloeE2Set({ directToComfy: !sOn }); } catch (eS) {}
    chloeRPPush("<i>🖼️ Prompt obrazu: <b>" + (sOn ? "przepisuje Stheno" : "wprost do ComfyUI (bez Stheno)") + "</b>. " +
      (sOn ? "Stheno wygladza prompt, ale streszcza go ok. 3x - traci czesc szczegolow." : "Pelna kontrola: do modelu idzie dokladnie nasz opis (wymaga mostka >= 1.1).") + "</i>");
    return true;
  }
  // /obraz prompt - pokaz, co dokladnie idzie do obrazu
  if (/^(?:prompt|podglad|podgląd|ostatni)$/i.test(raw)) {
    var mine = "";
    try { mine = chloeImageBrief(""); } catch (eP) {}
    var last = null;
    try { last = JSON.parse(localStorage.getItem("chloe_last_image_prompt") || "null"); } catch (eL) {}
    var outH = "<div style=\"text-align:left;font-size:92%;\"><b>🖼️ Prompt obrazu</b>";
    outH += "<div style=\"margin-top:5px;\"><b>Nasz brief z tej sceny</b> (" + mine.length + " znakow, kadr: " + chloeImgKadr() + "):</div>";
    outH += "<div style=\"font-size:88%;opacity:.85;word-break:break-word;border:1px solid rgba(127,127,127,0.3);border-radius:6px;padding:6px;margin-top:4px;\">" + chloeEsc(mine) + "</div>";
    if (last && last.sthenoPrompt) {
      outH += "<div style=\"margin-top:7px;\"><b>" + (last.direct ? "Prompt wyslany wprost do ComfyUI" : "Prompt po przepisaniu przez Stheno") + "</b> (" + String(last.sthenoPrompt).length + " znakow" + (last.direct ? ", tryb wprost" : "") + "):</div>";
      outH += "<div style=\"font-size:88%;opacity:.85;word-break:break-word;border:1px solid rgba(127,127,127,0.3);border-radius:6px;padding:6px;margin-top:4px;\">" + chloeEsc(String(last.sthenoPrompt).slice(0, 2200)) + "</div>";
    } else {
      outH += "<div style=\"margin-top:6px;opacity:.7;\">Ostatni finalny prompt pojawi sie tu po pierwszym obrazie wygenerowanym przez mostek.</div>";
    }
    var neg = "";
    try { neg = chloeImgNeg(); } catch (eN) {}
    outH += "<div style=\"margin-top:7px;\"><b>Negatywa</b> (" + neg.length + " znakow" + (neg ? "" : " - BRAK, SD dostanie slaba stala negatywe z wezla 3") + "):</div>";
    outH += "<div style=\"font-size:88%;opacity:.85;word-break:break-word;border:1px solid rgba(127,127,127,0.3);border-radius:6px;padding:6px;margin-top:4px;\">" + chloeEsc(neg || "(brak)") + "</div>";
    outH += "<div style=\"margin-top:4px;font-size:88%;opacity:.85;\">Mostek (>=1.1) dokleja do niej swoj rdzen (jakosc, anatomia, zakaz ubran/rak/przycietego kadru na kropce) i wpisuje wynik do wezla 3 workflow.</div>";
    outH += "</div>";
    chloeRPPush(outH);
    return true;
  }
  // /obraz poziom 2 | /obraz poziom auto
  var mp = raw.match(/^(?:poziom|lvl|level)\s*[:=]?\s*(auto|[0-3])$/i);
  if (mp) {
    var v = /auto/i.test(mp[1]) ? 0 : Number(mp[1]);
    chloeRPSet({ imgpoziom: v });
    var lvName = ["auto (z tego, co sie dzieje w scenie)", "1/3 - sugestywnie", "2/3 - nago, bez cenzury", "3/3 - hardcore wprost"];
    chloeRPPush("<i>🖼️ Poziom obrazow: <b>" + lvName[v] + "</b>. Jednorazowo: <code>/obraz 3 opis</code>.</i>");
    return true;
  }
  // /obraz tryb <nazwa> | /obraz tryb - tryb pracy ComfyUI (preset mostka: default/fast/sdxl_*)
  var mt = raw.match(/^(?:tryb|preset|workflow)\b\s*[:=]?\s*([\s\S]*)$/i);
  if (mt) {
    var argT = chloeNorm(mt[1]).replace(/^\s+|\s+$/g, "");
    if (!argT || argT === "lista" || argT === "list" || argT === "?") {
      var curT = "";
      try { curT = String(chloeCloudGet().localFlowPreset || ""); } catch (eTc) {}
      var listH = "<div style=\"text-align:left;font-size:92%;\"><b>🖼️ Tryby obrazu mostka</b> \u2014 aktualny: <b>" + chloeEsc(curT || "auto (mostek wybiera)") + "</b><br>";
      for (var ti = 0; ti < CHLOE_PRESETS.length; ti++) listH += "\u2022 <code>" + CHLOE_PRESETS[ti][0] + "</code> \u2014 " + chloeEsc(chloePresetDesc(CHLOE_PRESETS[ti][0])) + "<br>";
      listH += "<span style=\"opacity:.75;\">Ustaw: <code>/obraz tryb sdxl_std</code>; wyczysc: <code>/obraz tryb auto</code>. Dokladna liste dzialajacego mostka (z jego wersja i czasem ostatniego obrazu) pokaze panel Obrazy \u2192 <b>Odswiez tryby</b>.</span></div>";
      chloeRPPush(listH);
      return true;
    }
    var nameT = argT.replace(/\s+/g, "_");
    if (nameT === "auto" || nameT === "brak" || nameT === "zaden" || nameT === "puste") nameT = "";
    else if (!chloePresetIsKnown(nameT)) {
      chloeRPPush("<i>❌ Nie znam trybu <code>" + chloeEsc(nameT) + "</code>. Dostepne: <code>" + CHLOE_PRESET_ORDER.join("</code>, <code>") + "</code>. Pelna lista: <code>/obraz tryb</code>.</i>");
      return true;
    }
    try { chloeCloudSet({ localFlowPreset: nameT }); } catch (eTs) {}
    try { chloePresetSyncSelect(); } catch (eTy) {}
    chloeRPPush("<i>🖼️ Tryb obrazu: <b>" + (nameT || "auto (mostek wybiera)") + "</b>" + (nameT ? " \u2014 " + chloeEsc(chloePresetDesc(nameT)) : "") + ". Zmiana dziala od nastepnego obrazu.</i>");
    return true;
  }
  var level = null;
  var m2 = raw.match(/^([0-3])\s+(.*)$/);
  if (m2) { level = Number(m2[1]); raw = m2[2]; }
  var ask = chloeImgCleanAsk(raw);
  var prompt = "";
  try { prompt = chloeImageBrief(ask, { level: level }); } catch (e) { prompt = ""; }
  if (!prompt || prompt.replace(/\[\[[^\]]*\]\]/g, "").trim().length < 12) {
    chloeRPPush("<i>❌ Nie udalo sie zbudowac opisu obrazu (brak stanu sceny).</i>");
    return true;
  }
  var lv = 0;
  try { lv = chloeImgLevel({ st: chloeRPState(), all: prompt, ask: ask, level: level }); } catch (eLv) {}
  chloeRPPush("<i>🖼️ Generuję obraz ze sceny" + (ask ? " + Twój opis" : "") + " (poziom " + lv + "/3)… obraz pojawi się pod tą wiadomością.</i>");
  try { chloeQuickAction("/image " + prompt); } catch (e) {
    try {
      oc.thread.messages.push({ author: "user", content: "<image>" + prompt + "</image>", expectsReply: false });
    } catch (e2) {
      chloeRPPush("<i>❌ Nie udalo sie dodac zadania obrazu: " + chloeEsc(String((e && e.message) || e)) + "</i>");
    }
  }
  return true;
}

// Negatywa, ktora naprawde pojedzie do mostka: parametr (negativePrompt:::)
// z definicji postaci Chloe. Trzymana tutaj osobno, zeby /obraz prompt mogl ja
// pokazac - bez tego nie widac, czy SD dostaje zakaz "ubranie/rece/uda na
// drodze do cipki", czy tylko slaba, stala negatywe z wezla 3.
function chloeImgNeg() {
  var s = "";
  try { s = String(oc.character.imagePromptSuffix || ""); } catch (e) { return ""; }
  var needle = "(negativePrompt:::";
  var at = s.toLowerCase().indexOf(needle.toLowerCase());
  if (at === -1) return "";
  var depth = 0, end = -1;
  for (var i = at; i < s.length; i++) {
    if (s[i] === "(") depth++;
    else if (s[i] === ")") { depth--; if (depth <= 0) { end = i; break; } }
  }
  if (end === -1) return "";
  return s.slice(at + needle.length, end).trim();
}

window.__chloeImg = {
  brief: function (ask, lv) { return chloeImageBrief(ask || "", { level: lv }); },
  enrich: chloeImageEnrich,
  strip: chloeImgBriefStrip,
  markless: chloeCloudStripMark,
  tags: chloeImgLexTags,
  hits: function (t, core) { return chloeImgLexHits(t || "", core).map(function (h) { return (h.core ? "C:" : "c:") + h.group + ":" + h.tag; }); },
  level: function (extra) { try { return chloeImgLevel({ st: chloeRPState(), all: String(extra || ""), ask: "" }); } catch (e) { return -1; } },
  tr: chloeImgTr,
  sent: function (ask, lv) {
    try {
      var st = chloeRPState() || {};
      return chloeImgSentence({ st: st }, String(ask || "") + " ; " + [st.lok, st.poz, st.cialo, st.faza].filter(Boolean).join(" ; "), lv == null ? 3 : lv, chloeImgStr(st.ubr));
    } catch (e) { return "ERR " + e.message; }
  },
  budget: chloeImgBudget,
  command: chloeImgCommand,
  kadr: chloeImgKadr,
  shot: function (t2, m2) { return chloeImgShot(String(t2 || "").split(", "), m2, ""); },
  flatten: chloeImgFlattenSd,
  direct: function () { try { return !!chloeE2Get().directToComfy; } catch (e) { return false; } },
  last: function () { try { return JSON.parse(localStorage.getItem("chloe_last_image_prompt") || "null"); } catch (e) { return null; } },
  mark: CHLOE_IMG_MARK,
  neg: chloeImgNeg,
  lex: function () { return CHLOE_IMG_LEX.length; },
  groups: function () { return CHLOE_IMG_GROUP_MAX; },
  limits: chloeImgHardLimits,
  recent: chloeImgRecent,
  moment: function () { try { return chloeImgMoment(chloeImgRecent(), ""); } catch (e) { return "ERR " + e.message; } }
};
try { window.__chloeRP.img = window.__chloeImg; } catch (eI) {}
