@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title Chloe - ComfyUI ROCm + mostek Hermes
set "CHL_VER=v4.3 z 24.09.2026"

rem =====================================================================
rem  Start_Comfy_i_Hermes.bat  -  WERSJA FINALNA (v4)
rem
rem  JEDEN plik, ktory uruchamia cala lokalna czesc Chloe:
rem     1) ComfyUI na ROCm
rem     2) mostek Hermes - czat przez OpenRouter, obrazy przez ComfyUI
rem     3) weryfikacje calego stosu i instrukcje do panelu Chloe
rem
rem  Uruchomienie: dwuklik. Stop mostka: --stop. Restart: --restart.
rem
rem  Tryby:
rem     --check      nic nie uruchamia - tylko diagnoza i raport
rem     --serve      dodatkowo Tailscale Serve, czyli HTTPS dla telefonu
rem     --simple     zapasowy workflow bez LoRy i upscalera
rem     --no-comfy   nie startuj ComfyUI, juz chodzi
rem     --restart    zamknij dzialajacy mostek i uruchom go od nowa
rem     --stop       zamknij dzialajacy mostek i wyjdz
rem     --test       wyslij przez mostek jedno krotkie zapytanie czatu
rem     --bench      po starcie zmierz tempo ComfyUI (base/hires s/krok) i zapisz raport
rem     --attn=X     sposob liczenia attention: default|split|quad|pytorch|sage
rem     --restart-comfy   zamknij dzialajace ComfyUI (potrzebne, gdy zmieniasz --attn)
rem     --bench-runs=N --bench-steps=N   parametry pomiaru (domyslnie 3 przebiegi po 3 kroki)
rem     reszta argumentow leci do mostka, np. --no-refine --size 768x768
rem
rem  O SZYBKOSCI (24.09.2026): ten sam graf potrafi isc 4 s/krok albo 26 s/krok - zalezy,
rem  na jaka sciezke attention/traktowania VRAM trafil proces ComfyUI. Nie zgaduj:
rem      Start_Comfy_i_Hermes.bat --bench
rem      Start_Comfy_i_Hermes.bat --bench --attn=split
rem  i porownaj liczby z raport_wydajnosci.txt. Adresy /health i log pozostaja bez zmian.
rem  Uwaga: zmiana --attn dziala tylko wtedy, gdy ComfyUI wstaje od zera - dlatego przy
rem  porownaniach dopisz --restart-comfy (albo zamknij okno ComfyUI). Dla wygody jest
rem  Zmierz_tempo.bat, ktory robi to samo co "--bench".
rem
rem  ZASADA numer jeden: stanu mostka NIGDY nie sprawdzamy przez netstat.
rem  Tailscale Serve trzyma 100.x.x.x:8443 jako LISTENING, wiec netstat klamie
rem  "mostek juz dziala", choc mostka nie ma. Pytamy wprost HTTP:
rem     mostek  - http://127.0.0.1:8443/health
rem     ComfyUI - http://127.0.0.1:8188/system_stats
rem
rem  Log ComfyUI: <folder pakietu>\user\comfyui.log
rem  Zmienne maja prefiks CHL_ celowo - ComfyUI dziedziczy to srodowisko,
rem  wiec ogolne nazwy moglyby mu cos nadpisac i zepsuc start.
rem =====================================================================

echo ======================================================================
echo  Start_Comfy_i_Hermes.bat   %CHL_VER%
echo ======================================================================
echo.

rem ---------------------------------------------- 0) argumenty
set "CHL_MODE=start"
set "CHL_SERVE=0"
set "CHL_NOCOMFY=0"
set "CHL_RESTART=0"
set "CHL_RESTART_COMFY=0"
set "CHL_STOP=0"
set "CHL_TEST=0"
set "CHL_PASS="
set "CHL_ATTN="
set "CHL_ATTNLBL=domyslne (bez flagi attention)"
set "CHL_BENCH=0"
set "CHL_BENCH_RUNS=3"
set "CHL_BENCH_STEPS=3"

:args
if "%~1"=="" goto :args_done
if /I "%~1"=="--check"    (set "CHL_MODE=check" & shift & goto :args)
if /I "%~1"=="--raport"   (set "CHL_MODE=check" & shift & goto :args)
if /I "%~1"=="--diagnoza" (set "CHL_MODE=check" & shift & goto :args)
if /I "%~1"=="--serve"    (set "CHL_SERVE=1" & shift & goto :args)
if /I "%~1"=="--no-comfy" (set "CHL_NOCOMFY=1" & shift & goto :args)
if /I "%~1"=="--restart"  (set "CHL_RESTART=1" & shift & goto :args)
if /I "%~1"=="--restart-comfy" (set "CHL_RESTART_COMFY=1" & shift & goto :args)
if /I "%~1"=="--stop"     (set "CHL_STOP=1" & shift & goto :args)
if /I "%~1"=="--test"     (set "CHL_TEST=1" & shift & goto :args)
if /I "%~1"=="--bench"    (set "CHL_BENCH=1" & shift & goto :args)
set "CHL_TMP=%~1"
if not "!CHL_TMP!"=="!CHL_TMP:--attn=!" (set "CHL_ATTN=!CHL_TMP:--attn=!" & shift & goto :args)
if not "!CHL_TMP!"=="!CHL_TMP:--bench-runs=!" (set "CHL_BENCH_RUNS=!CHL_TMP:--bench-runs=!" & shift & goto :args)
if not "!CHL_TMP!"=="!CHL_TMP:--bench-steps=!" (set "CHL_BENCH_STEPS=!CHL_TMP:--bench-steps=!" & shift & goto :args)
if /I "%~1"=="--simple"   (set "CHL_PASS=%CHL_PASS% --workflow-file workflow_api_simple.json" & shift & goto :args)
set "CHL_PASS=%CHL_PASS% %~1"
shift
goto :args
:args_done

rem Rozmiar bazowy obrazu dla mostka: aplikacja Chloe NIE wysyla rozmiaru,
rem wiec liczy sie to, co tu podamy. 512x768 pasuje do koncowego 1024x1536
rem i trwa ok. 2 minuty. 768x768 przy 4x upscalerze to obraz posredni
rem 3072x3072 i ponad 6 minut. Nadpisanie: dopisz --size 768x768.
set "CHL_NOSIZE=1"
if not "!CHL_PASS!"=="!CHL_PASS:--size=!" set "CHL_NOSIZE=0"
if not "!CHL_PASS!"=="!CHL_PASS:--size !" set "CHL_NOSIZE=0"
if "!CHL_NOSIZE!"=="1" set "CHL_PASS=--size 512x768 !CHL_PASS!"

rem ---------------------------------------------- 1) co gdzie lezy
set "CHL_ROOT=%~dp0"
set "CHL_ROOT=%CHL_ROOT:~0,-1%"

set "CHL_PACK="
if exist "%CHL_ROOT%\python_env\python.exe" set "CHL_PACK=%CHL_ROOT%"
if not defined CHL_PACK if exist "%CHL_ROOT%\comfyui-rocm-091926\python_env\python.exe" set "CHL_PACK=%CHL_ROOT%\comfyui-rocm-091926"
if not defined CHL_PACK for /d %%D in ("%CHL_ROOT%\comfyui-rocm*") do if not defined CHL_PACK if exist "%%~fD\python_env\python.exe" set "CHL_PACK=%%~fD"
if not defined CHL_PACK for /d %%D in ("%CHL_ROOT%\..\comfyui-rocm*") do if not defined CHL_PACK if exist "%%~fD\python_env\python.exe" set "CHL_PACK=%%~fD"
if not defined CHL_PACK (
    echo [BLAD] Nie znalazlem pakietu ComfyUI ROCm, czyli pliku python_env\python.exe.
    echo        Szukalem w: "%CHL_ROOT%" oraz w podfolderach comfyui-rocm*
    echo        Poloz ten plik obok folderu ComfyUI albo bezposrednio w nim.
    echo.
    pause
    exit /b 1
)

set "CHL_HOME="
for %%D in ("%CHL_ROOT%" "%CHL_PACK%" "%CHL_ROOT%\.." "%CHL_PACK%\..") do if not defined CHL_HOME if exist "%%~fD\hermes_comfy_bridge.py" set "CHL_HOME=%%~fD"
if not defined CHL_HOME (
    echo [BLAD] Nie znalazlem pliku hermes_comfy_bridge.py.
    echo        Ten plik .bat musi lezec obok mostka albo obok folderu ComfyUI.
    echo        Szukalem w: "%CHL_ROOT%" oraz "%CHL_PACK%"
    echo.
    pause
    exit /b 1
)

set "CHL_PYENV=%CHL_PACK%\python_env"
set "CHL_BRIDGE=%CHL_HOME%\hermes_comfy_bridge.py"
set "CHL_CHECK=%CHL_HOME%\sprawdz_comfy.py"
set "CHL_KEYFILE=%CHL_HOME%\openrouter_key.txt"
set "CHL_RAPORT=%CHL_HOME%\raport_mostka.txt"

if not defined CHL_HOST set "CHL_HOST=desktop-254m5ge.tail6d92a0.ts.net"
if not defined CHL_PORT set "CHL_PORT=8443"
if not defined CHL_COMFY_URL set "CHL_COMFY_URL=http://127.0.0.1:8188"
if not defined CHL_WAIT set "CHL_WAIT=300"

set "CHL_WF=%CHL_HOME%\workflow_api.json"
if not exist "%CHL_WF%" if exist "%CHL_PACK%\workflow_api.json" set "CHL_WF=%CHL_PACK%\workflow_api.json"
if not "%CHL_PASS%"=="" (
    set "CHL_PREV="
    for %%A in (%CHL_PASS%) do (
        if /I "!CHL_PREV!"=="--workflow-file" set "CHL_WF=%%~A"
        set "CHL_PREV=%%A"
    )
)
if not exist "%CHL_WF%" if exist "%CHL_HOME%\%CHL_WF%" set "CHL_WF=%CHL_HOME%\%CHL_WF%"
if not exist "%CHL_WF%" if exist "%CHL_PACK%\%CHL_WF%" set "CHL_WF=%CHL_PACK%\%CHL_WF%"

set "CHL_PY=%CHL_PYENV%\python.exe"
set "CHL_PYARG="
set "CHL_PYOK=1"
if not exist "%CHL_PY%" set "CHL_PYOK=0"
if "%CHL_PYOK%"=="0" (
    where py >nul 2>&1
    if not errorlevel 1 (set "CHL_PY=py" & set "CHL_PYARG=-3" & set "CHL_PYOK=1")
)
if "%CHL_PYOK%"=="0" (
    where python >nul 2>&1
    if not errorlevel 1 (set "CHL_PY=python" & set "CHL_PYOK=1")
)
if "%CHL_PYOK%"=="0" (
    echo [BLAD] Nie znalazlem Pythona. Zainstaluj Python 3 z python.org
    echo        zaznaczajac "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

set "CHL_HAVEKEY=0"
if exist "%CHL_KEYFILE%" set "CHL_HAVEKEY=1"
if defined OPENROUTER_API_KEY set "CHL_HAVEKEY=1"

echo [0/6] preflight
echo   mostek   : %CHL_BRIDGE%
echo   ComfyUI  : %CHL_PACK%
echo   workflow : %CHL_WF%
echo   python   : %CHL_PY% %CHL_PYARG%
if not exist "%CHL_WF%" echo   [UWAGA] brak pliku workflow - mostek go potrzebuje [ComfyUI: Workflow, Export API]
if "%CHL_HAVEKEY%"=="0" echo   [UWAGA] brak klucza OpenRoutera - wklej go do %CHL_KEYFILE% (mostek v10 uzyje tez klucza z aplikacji Chloe, jesli go wysle)
echo.

if "%CHL_STOP%"=="1" goto :stop_only
if "%CHL_MODE%"=="check" goto :raport

rem ---------------------------------------------- 2) srodowisko ROCm
echo [1/6] rocm-sdk init ...
set "PATH=%CHL_PYENV%;%CHL_PYENV%\Scripts;%PATH%"
"%CHL_PYENV%\Scripts\rocm-sdk.exe" init >"%TEMP%\chloe-rocm-init.log" 2>&1
if errorlevel 1 (
    echo       [i] rocm-sdk init zwrocil kod bledu. Czesc instalacji odpowiada tak, gdy
    echo       [i] srodowisko jest juz zainicjalizowane, wiec to zwykle nie jest problem.
    echo       [i] Log [moze byc pusty]:
    if exist "%TEMP%\chloe-rocm-init.log" type "%TEMP%\chloe-rocm-init.log"
)

rem HIP_PATH czytamy z PLIKU. for /f z komenda w cudzyslowie to bug cmd:
rem gubi cudzyslowy i zwraca blad 123 zamiast sciezki.
set "HIP_PATH="
del "%TEMP%\chloe-rocm-root.txt" >nul 2>&1
"%CHL_PYENV%\Scripts\rocm-sdk.exe" path --root >"%TEMP%\chloe-rocm-root.txt" 2>nul
if exist "%TEMP%\chloe-rocm-root.txt" for /f "usebackq delims=" %%i in ("%TEMP%\chloe-rocm-root.txt") do if not defined HIP_PATH set "HIP_PATH=%%i"
set "CHL_HIPFALLBACK="
if not defined HIP_PATH set "CHL_HIPFALLBACK=1"
if not defined HIP_PATH set "HIP_PATH=%CHL_PYENV%\Lib\site-packages\_rocm_sdk_devel"
if not exist "%HIP_PATH%\bin" set "CHL_HIPFALLBACK=1"
if not exist "%HIP_PATH%\bin" set "HIP_PATH=%CHL_PYENV%\Lib\site-packages\_rocm_sdk_devel"
set "ROCM_PATH=%HIP_PATH%"
set "PATH=%HIP_PATH%\bin;%CHL_PYENV%\Lib\site-packages\_rocm_sdk_core\bin;%PATH%"
if defined CHL_HIPFALLBACK echo       [i] rocm-sdk nie podal sciezki - uzywam zapasowej _rocm_sdk_devel
echo       HIP_PATH = %HIP_PATH%

echo [2/6] wykrywam GPU ...
set "GPU_ARCH="
del "%TEMP%\chloe-gpuarch.txt" >nul 2>&1
"%CHL_PYENV%\python.exe" -c "import torch;print(torch.cuda.get_device_properties(0).gcnArchName)" >"%TEMP%\chloe-gpuarch.txt" 2>nul
if exist "%TEMP%\chloe-gpuarch.txt" for /f "usebackq delims=" %%G in ("%TEMP%\chloe-gpuarch.txt") do set "GPU_ARCH=%%G"
if defined GPU_ARCH if not "!GPU_ARCH:~0,3!"=="gfx" set "GPU_ARCH="
if not defined GPU_ARCH if exist "%CHL_PACK%\detect_gpu.py" (
    del "%TEMP%\chloe-gpuarch2.txt" >nul 2>&1
    pushd "%CHL_PACK%"
    "%CHL_PYENV%\python.exe" "detect_gpu.py" >"%TEMP%\chloe-gpuarch2.txt" 2>"%CHL_PACK%\gpu_detect_debug.log"
    popd
    if exist "%TEMP%\chloe-gpuarch2.txt" for /f "usebackq delims=" %%G in ("%TEMP%\chloe-gpuarch2.txt") do if not defined GPU_ARCH set "GPU_ARCH=%%G"
)
set "IS_LEGACY_GPU=0"
if /I "!GPU_ARCH:~0,6!"=="gfx101" set "IS_LEGACY_GPU=1"
if /I "!GPU_ARCH:~0,6!"=="gfx103" set "IS_LEGACY_GPU=1"
if not defined GPU_ARCH (
    echo       [UWAGA] nie udalo sie wykryc architektury GPU - startuje bez ustawien MIOpen.
) else (
    echo       GPU arch = !GPU_ARCH!
)

rem ------------------------- cache i bazy (wzgledne, w folderze pakietu) -----
set "PYTORCH_TUNABLEOP_CACHE_DIR=%CHL_PACK%\tunableop-cache"
set "TRITON_CACHE_DIR=%CHL_PACK%\triton-cache"
if not exist "%TRITON_CACHE_DIR%" mkdir "%TRITON_CACHE_DIR%"
if not exist "%PYTORCH_TUNABLEOP_CACHE_DIR%" mkdir "%PYTORCH_TUNABLEOP_CACHE_DIR%"

rem MIOpen i rocBLAS: sciezki tylko dla GPU innych niz gfx1100
if /I NOT "!GPU_ARCH!"=="gfx1100" (
    set "MIOPEN_SYSTEM_DB_PATH=%CHL_PACK%\python_env\Lib\site-packages\_rocm_sdk_devel\bin"
    set "ROCBLAS_TENSILE_DB_PATH=%CHL_PACK%\python_env\Lib\site-packages\_rocm_sdk_devel\bin\rocblas"
    set "ROCBLAS_TENSILE_LIBPATH=%CHL_PACK%\python_env\Lib\site-packages\_rocm_sdk_devel\bin\rocblas\library"
)

rem ------------------------- ustawienia MIOpen / triton ----------------------
rem RDNA3 gfx1102 [RX 7600S]: MIOpen omija ciezki fallback VAE/UNet.
set "COMFYUI_ENABLE_MIOPEN=0"
if /I "!GPU_ARCH!"=="gfx1102" set "COMFYUI_ENABLE_MIOPEN=1"
echo       MIOpen = !COMFYUI_ENABLE_MIOPEN!
set "FLASH_ATTENTION_TRITON_AMD_ENABLE=TRUE"
set "MIOPEN_FIND_ENFORCE=1"
set "MIOPEN_FIND_MODE=2"
set "MIOPEN_DEBUG_DISABLE_FIND_DB=0"
set "MIOPEN_SEARCH_CUTOFF=1"
set "MIOPEN_ENABLE_LOGGING=0"
set "MIOPEN_LOG_LEVEL=0"
set "MIOPEN_ENABLE_LOGGING_CMD=0"
set "TRITON_PRINT_AUTOTUNING=0"
set "TRITON_CACHE_AUTOTUNING=0"

rem Przy bledzie "CUDA error: invalid kernel file" odkomentuj linijke nizej:
rem set "HIP_VISIBLE_DEVICES=1"

rem ------------------------- parametry startu ComfyUI ------------------------
rem Gdy zabraknie VRAM przy wiekszych modelach dopisz na koncu: --lowvram
set "PARAMS=--enable-cors-header * --disable-api-nodes --disable-triton-backend"
rem Podmiana calej listy parametrow ComfyUI bez edycji pliku (np. zeby przetestowac bez
rem --disable-triton-backend): ustaw zmienna CHL_COMFY_PARAMS. Przyklad w README.
if defined CHL_COMFY_PARAMS set "PARAMS=%CHL_COMFY_PARAMS%"
rem --attn=... doklada flage attention (mapowanie w :attn_flags na koncu pliku).
if defined CHL_ATTN call :attn_flags
rem Dodatkowe flagi bez podmiany calej listy: zmienna CHL_COMFY_EXTRA.
if defined CHL_COMFY_EXTRA set "PARAMS=%PARAMS% %CHL_COMFY_EXTRA%"
echo       Parametry ComfyUI: !PARAMS!
echo       Attention: !CHL_ATTNLBL!
if "!IS_LEGACY_GPU!"=="1" if not defined CHL_ATTN set "PARAMS=%PARAMS% --use-quad-cross-attention"

rem ---------------------------------------------- 3) ComfyUI
set "CHL_COMFY_RUN=1"
rem --restart-comfy: potrzebne przy zmianie flag startowych ComfyUI (np. --attn=...),
rem bo dzialajacy proces zostal uruchomiony ze STARYMI parametrami.
if "%CHL_RESTART_COMFY%"=="1" call :kill_comfy
"%CHL_PY%" %CHL_PYARG% -c "import urllib.request;urllib.request.urlopen('%CHL_COMFY_URL%/system_stats',timeout=3)" >nul 2>&1
if not errorlevel 1 set "CHL_COMFY_RUN=0"
if "%CHL_COMFY_RUN%"=="0" echo [3/6] ComfyUI juz odpowiada na %CHL_COMFY_URL% - nie uruchamiam drugiego.
if "%CHL_COMFY_RUN%"=="1" if "%CHL_NOCOMFY%"=="1" echo [3/6] --no-comfy: nie uruchamiam ComfyUI.
if "%CHL_COMFY_RUN%"=="1" if "%CHL_NOCOMFY%"=="0" (
    echo [3/6] startuje ComfyUI w osobnym oknie, zminimalizowane ...
    start "ComfyUI ROCm" /min /d "%CHL_PACK%" "%ComSpec%" /k ""%CHL_PYENV%\python.exe" main.py %PARAMS%"
)

echo [4/6] czekam na ComfyUI, limit %CHL_WAIT% s ...
echo       [i] pierwszy start ComfyUI na ROCm trwa zwykle 60-180 s - nie zamykaj jego okna.
if not exist "%CHL_CHECK%" goto :wait_ps
"%CHL_PY%" %CHL_PYARG% "%CHL_CHECK%" --wait %CHL_WAIT% --comfy "%CHL_COMFY_URL%" --workflow "%CHL_WF%"
set "CHL_CHK=!ERRORLEVEL!"
if !CHL_CHK! GEQ 2 echo [UWAGA] Brakuje plikow modeli z workflow - mozesz ruszyc na prostym workflow, dodaj argument --simple
if !CHL_CHK! EQU 1 call :comfy_diag
goto :after_wait

:wait_ps
rem zapas, gdy brakuje sprawdz_comfy.py
powershell -NoProfile -Command "$until=(Get-Date).AddSeconds(%CHL_WAIT%); do { Start-Sleep -Seconds 2; try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 '%CHL_COMFY_URL%/system_stats'; if($r.StatusCode -eq 200){exit 0} } catch {} } while((Get-Date) -lt $until); exit 1"
if errorlevel 1 call :comfy_diag
goto :after_wait

:comfy_diag
echo [UWAGA] ComfyUI nie odpowiedzial w %CHL_WAIT% s. Sprawdzam, czy proces w ogole zyje ...
powershell -NoProfile -Command "$p=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*main.py*' }; if($p){ Write-Host ('[i] proces ComfyUI zyje [PID '+$p.ProcessId+'] - dalej sie laduje, daj mu wiecej czasu') } else { Write-Host '[!] procesu ComfyUI NIE ma - okno ComfyUI ROCm pokaze blad, np. zly argument albo brak plikow modeli' }"
if exist "%CHL_PACK%\user\comfyui.log" powershell -NoProfile -Command "Write-Host '     ostatnie 25 linii user\comfyui.log:'; Get-Content -Tail 25 '%CHL_PACK%\user\comfyui.log'"
exit /b 0

:after_wait
rem Jakie attention faktycznie wstalo - to jest dowod, ktore ustawienie zadzialalo.
if exist "%CHL_PACK%\user\comfyui.log" echo       attention wg logu ComfyUI:
if exist "%CHL_PACK%\user\comfyui.log" powershell -NoProfile -Command "Select-String -Path '%CHL_PACK%\user\comfyui.log' -Pattern 'attention' | Select-Object -Last 2 | ForEach-Object { '         ' + ($_.Line -replace '^[0-9T:.\-]+ - ','') }"
rem ------------------------- VRAM: sprzatanie po starym ----------------------
rem koboldcpp nie jest juz do niczego potrzebny, a zabiera VRAM karcie. Jesli
rem chcesz go zostawic w spokoju - usun obie linie "powershell" nizej.
powershell -NoProfile -Command "$ids=@(); try { $ids=(Get-NetTCPConnection -State Listen -LocalPort 5001 -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess) } catch {}; foreach($procId in $ids){ $p=Get-Process -Id $procId -ErrorAction SilentlyContinue; if($p -and $p.ProcessName -match 'kobold'){ Write-Host ('[i] Zamykam zalegla instancje na 5001, VRAM dla ComfyUI: PID '+$procId+' '+$p.ProcessName); Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue } }"
powershell -NoProfile -Command "$old=Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'koboldcpp*' }; foreach($p in $old){ Write-Host ('[i] Zamykam koboldcpp, VRAM dla ComfyUI: PID '+$p.ProcessId); Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }"

rem ---------------------------------------------- 5) mostek Hermes
echo [5/6] mostek: pytam http://127.0.0.1:%CHL_PORT%/health ...
set "CHL_UP=0"
"%CHL_PY%" %CHL_PYARG% -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:%CHL_PORT%/health',timeout=3)" >nul 2>&1
if not errorlevel 1 set "CHL_UP=1"
if "%CHL_UP%"=="1" if "%CHL_RESTART%"=="1" (
    echo       mostek dziala, ale jest --restart - zamykam go ...
    call :kill_bridge
    timeout /t 2 /nobreak >nul
    set "CHL_UP=0"
)
if "%CHL_UP%"=="1" (
    echo       mostek JUZ odpowiada na /health - nie uruchamiam drugiego.
) else (
    echo       startuje mostek w osobnym oknie ...
    start "Mostek Hermes" /min /d "%CHL_HOME%" "%ComSpec%" /k ""%CHL_PY%" %CHL_PYARG% "%CHL_BRIDGE%" %CHL_PASS%"
)

echo [6/6] czekam, az mostek zacznie odpowiadac ...
set "CHL_UP2=0"
for /l %%N in (1,1,30) do if "!CHL_UP2!"=="0" (
    "%CHL_PY%" %CHL_PYARG% -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:%CHL_PORT%/health',timeout=3)" >nul 2>&1
    if not errorlevel 1 (set "CHL_UP2=1") else (timeout /t 1 /nobreak >nul)
)
if "%CHL_UP2%"=="1" echo       mostek odpowiada na /health.
if "%CHL_UP2%"=="0" echo [UWAGA] mostek nie odpowiedzial w 30 s - zobacz okno "Mostek Hermes".

if "%CHL_SERVE%"=="1" (
    echo [i] Tailscale Serve: https://%CHL_HOST%:%CHL_PORT%
    tailscale serve --bg --https=%CHL_PORT% http://127.0.0.1:%CHL_PORT%
    if errorlevel 1 echo [UWAGA] "tailscale serve" nie zadzialal - sprawdz, czy Tailscale jest zalogowany.
)

rem ---------------------------------------------- 6) raport i instrukcje
:raport
del "%CHL_RAPORT%" >nul 2>&1
call :blank
call :say "======================================================================"
call :say " RAPORT - lokalny stos Chloe"
call :say "----------------------------------------------------------------------"
call :say " mostek /health:"
"%CHL_PY%" %CHL_PYARG% -c "import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:%CHL_PORT%/health',timeout=5).read().decode('utf-8','replace').strip())" >>"%CHL_RAPORT%" 2>&1
call :say " wersja mostka [kod na dysku vs dzialajacy proces]:"
"%CHL_PY%" %CHL_PYARG% -c "import json,re,urllib.request;live=json.load(urllib.request.urlopen('http://127.0.0.1:%CHL_PORT%/health',timeout=5)).get('version');code=0;m=re.search(chr(34)+'version'+chr(34)+r':\s*(\d+)',open(r'%CHL_BRIDGE%',encoding='utf-8',errors='replace').read());code=int(m.group(1)) if m else 0;print('   w kodzie v'+str(code)+' / w dzialajacym procesie v'+str(live)+('   OK' if code and live==code else '   UWAGA: dziala STARSZY kod mostka - uruchom Start_Comfy_i_Hermes.bat --restart'))" >>"%CHL_RAPORT%" 2>&1
call :blank
call :say " ComfyUI [sprawdz_comfy.py --no-wait]:"
if not exist "%CHL_CHECK%" goto :skip_comfy_chk
"%CHL_PY%" %CHL_PYARG% "%CHL_CHECK%" --no-wait --comfy "%CHL_COMFY_URL%" --workflow "%CHL_WF%" >>"%CHL_RAPORT%" 2>&1
goto :after_comfy_chk
:skip_comfy_chk
call :say "   brak sprawdz_comfy.py - pomijam"
:after_comfy_chk
call :blank
call :say " mostek --selftest [workflow, ComfyUI, klucz OpenRoutera]:"
"%CHL_PY%" %CHL_PYARG% "%CHL_BRIDGE%" --selftest >>"%CHL_RAPORT%" 2>&1
call :say "   kod wyjscia: %ERRORLEVEL%"
call :blank
call :say " Tailscale [serve/funnel]:"
where tailscale >nul 2>&1
if errorlevel 1 goto :ts_brak
tailscale serve status >"%TEMP%\chloe-ts.txt" 2>&1
findstr /C:"8188" "%TEMP%\chloe-ts.txt" >nul 2>&1
if errorlevel 1 goto :ts_ok
type "%TEMP%\chloe-ts.txt" >>"%CHL_RAPORT%" 2>&1
call :say "   [UWAGA] port 8188 [ComfyUI] jest wystawiony przez tailscale."
call :say "           jesli to Funnel, ComfyUI jest publicznie w internecie bez hasla."
call :say "           wylacz: tailscale funnel --https=443 off"
goto :ts_koniec
:ts_ok
type "%TEMP%\chloe-ts.txt" >>"%CHL_RAPORT%" 2>&1
goto :ts_koniec
:ts_brak
call :say "   brak komendy tailscale w PATH - pomijam"
:ts_koniec
if not "%CHL_TEST%"=="1" goto :skip_test
call :blank
call :say " Test czatu przez mostek [Hermes / OpenRouter]:"
"%CHL_PY%" %CHL_PYARG% -c "import json,urllib.request;d=json.dumps({'messages':[{'role':'user','content':'Odpowiedz jednym slowem: dziala?'}],'max_tokens':16}).encode();r=urllib.request.Request('http://127.0.0.1:%CHL_PORT%/v1/chat/completions',data=d,headers={'Content-Type':'application/json'});print('   odpowiedz modelu: '+json.load(urllib.request.urlopen(r,timeout=120))['choices'][0]['message']['content'].strip())" >>"%CHL_RAPORT%" 2>&1
:skip_test
call :blank
call :say " CO WPISAC W PANELU CHLOE [przycisk model / panel, lub /model i /panel]:"
call :say "   Model  - Base URL: http://127.0.0.1:%CHL_PORT%"
call :say "   Obrazy - Stheno / ComfyUI lokalnie: ten sam adres"
call :say "   Obrazy - wlasny endpoint: ten sam adres"
call :say "   Status mostka w przegladarce: http://127.0.0.1:%CHL_PORT%/"
call :say "   Telefon: uruchom z --serve i wpisz https://%CHL_HOST%:%CHL_PORT%"
call :say "----------------------------------------------------------------------"
call :say " koniec raportu"
call :say "======================================================================"

rem ---------------------------------------------- 6b) pomiar tempa (--bench)
if not "%CHL_BENCH%"=="1" goto :skip_bench
call :blank
call :say " [bench] pomiar tempa ComfyUI [%CHL_BENCH_RUNS% przebiegi po %CHL_BENCH_STEPS% krokow]:"
echo [bench] pomiar tempa ComfyUI: %CHL_BENCH_RUNS% przebiegi po %CHL_BENCH_STEPS% krokow ...
echo         (trwa 1-3 minuty; obrazow do galerii nie zapisuje)
if not exist "%CHL_HOME%\bench_comfy.py" (
    echo [UWAGA] brak bench_comfy.py obok mostka - pomijam pomiar.
    call :say "   brak bench_comfy.py obok mostka - pomijam pomiar"
    goto :skip_bench
)
"%CHL_PY%" %CHL_PYARG% "%CHL_HOME%\bench_comfy.py" --comfy "%CHL_COMFY_URL%" --workflow "%CHL_WF%" --runs !CHL_BENCH_RUNS! --steps !CHL_BENCH_STEPS! --report "%CHL_HOME%\raport_wydajnosci.txt"
set "CHL_BENCH_CODE=%ERRORLEVEL%"
call :say "   kod wyjscia pomiaru: %CHL_BENCH_CODE% [0 = stabilnie, 2 = wolny tryb]"
call :say "   pelny pomiar: raport_wydajnosci.txt obok mostka"
echo [bench] kod wyjscia: %CHL_BENCH_CODE%  [0 = stabilnie, 2 = jeden przebieg duzo wolniejszy]
if "%CHL_BENCH_CODE%"=="2" echo [bench] UWAGA: wlaczyl sie wolny tryb - zmien --attn=... i zmierz ponownie
:skip_bench

echo.
type "%CHL_RAPORT%"
echo.
if not "%CHL_MODE%"=="start" goto :fin
echo ======================================================================
echo  Gotowe. Mostek dziala w osobnym oknie "Mostek Hermes".
echo  Zamkniecie tamtego okna konczy mostek. To okno mozesz zamknac.
echo  Stop mostka bez szukania okna:  Start_Comfy_i_Hermes.bat --stop
echo ======================================================================
:fin
echo.
pause
exit /b 0

rem =====================================================================
rem  tryb --stop: zamknij dzialajacy mostek i wyjdz
rem =====================================================================
:stop_only
echo Szukam mostka na porcie %CHL_PORT% ...
call :kill_bridge
echo Gotowe. ComfyUI [jesli dziala] zostaje otwarte - zamknij jego okno recznie.
echo.
pause
exit /b 0

rem =====================================================================
rem  pomocnicze
rem =====================================================================
:kill_bridge
powershell -NoProfile -Command "Get-NetTCPConnection -State Listen -LocalPort %CHL_PORT% -ErrorAction SilentlyContinue | ForEach-Object { $p = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $_.OwningProcess) -ErrorAction SilentlyContinue; if ($p -and $p.CommandLine -like '*hermes_comfy_bridge.py*') { Write-Host ('[i] Zamykam mostek PID ' + $_.OwningProcess); Stop-Process -Id $_.OwningProcess -Force } }"
exit /b 0

:say
if defined CHL_RAPORT >>"%CHL_RAPORT%" echo %~1
exit /b 0

:blank
if defined CHL_RAPORT >>"%CHL_RAPORT%" echo.
exit /b 0

rem =====================================================================
rem  :kill_comfy - zamyka dzialajacy proces ComfyUI (tryb --restart-comfy).
rem  Uzywane przy zmianie flag startowych: dzialajacy proces ma stare.
rem =====================================================================
:kill_comfy
echo       --restart-comfy: zamykam dzialajacy proces ComfyUI, zeby wstal z nowymi flagami ...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*main.py*' } | ForEach-Object { Write-Host ('[i] Zamykam ComfyUI PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force }"
timeout /t 3 /nobreak >nul
exit /b 0

rem =====================================================================
rem  :attn_flags - mapuje --attn=X na flage startowa ComfyUI
rem  (dokladnie te nazwy podaje sam ComfyUI w logu, gdy radzi zmienic
rem   attention przy problemach z pamiecia lub szybkoscia)
rem =====================================================================
:attn_flags
set "CHL_ATTN=!CHL_ATTN: =!"
if /I "!CHL_ATTN!"=="none" exit /b 0
if /I "!CHL_ATTN!"=="default" exit /b 0
if /I "!CHL_ATTN!"=="split" (set "PARAMS=!PARAMS! --use-split-cross-attention" & set "CHL_ATTNLBL=split-cross --use-split-cross-attention" & exit /b 0)
if /I "!CHL_ATTN!"=="quad" (set "PARAMS=!PARAMS! --use-quad-cross-attention" & set "CHL_ATTNLBL=quad-cross --use-quad-cross-attention" & exit /b 0)
if /I "!CHL_ATTN!"=="pytorch" (set "PARAMS=!PARAMS! --use-pytorch-cross-attention" & set "CHL_ATTNLBL=pytorch SDPA --use-pytorch-cross-attention" & exit /b 0)
if /I "!CHL_ATTN!"=="sage" (set "PARAMS=!PARAMS! --use-sage-attention" & set "CHL_ATTNLBL=sage-attention --use-sage-attention" & exit /b 0)
echo [UWAGA] nie znam --attn=!CHL_ATTN! - zostawiam domyslne. Dozwolone: default, split, quad, pytorch, sage
set "CHL_ATTN="
exit /b 0
