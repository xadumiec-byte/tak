#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dodaj_facedetailer.py - doklada FaceDetailer (Impact Pack) do workflow_api.json.

Po co: przy kadrze calego ciala twarz ma kilkadziesiat pikseli, wiec model maluje
ja "na oko" i wychodzi rozmyta, niespojna albo znieksztalcona. FaceDetailer
wykrywa twarz, wyluskuje ja, przemalowuje w wiekszej rozdzielczosci i wkleja
z powrotem z miekkim przejsciem. Koszt: jeden dodatkowy przebieg KSamplera na
malym wycinku (u Ciebie ok. 40-90 s zaleznie od --guide-size i --steps).

Skrypt czyta /object_info/FaceDetailer z Twojego ComfyUI i buduje nod tylko
z pol, ktore ta wersja Impact Packu faktycznie ma - dlatego dziala z roznymi
wersjami wtyczki (nazwy i typy pol sie zmieniaja miedzy wydaniami).

Uzycie:
    python dodaj_facedetailer.py                  # sprawdz + dopisz do workflow_api.json
    python dodaj_facedetailer.py --dry-run        # pokaz, co by zrobil, nic nie zapisuj
    python dodaj_facedetailer.py --test           # po wstawieniu zrob probe generacji
    python dodaj_facedetailer.py --detector bbox/face_yolov8m.pt
    python dodaj_facedetailer.py --denoise 0.45 --guide-size 384 --steps 16
    python dodaj_facedetailer.py --sam            # dopnij SAMLoader, jesli masz model SAM
    python dodaj_facedetailer.py --remove         # wyciagnij FaceDetailer z workflow
    python dodaj_facedetailer.py --wiecej         # wypisz pelny opis nodu FaceDetailer z ComfyUI

Kody wyjscia:
    0  OK (wpisane albo juz bylo),
    1  brak ComfyUI albo blad krytyczny,
    2  brakuje detektora twarzy (napisze, skad pobrac),
    3  brakuje Impact Packu (brak nodu FaceDetailer).

Bez zewnetrznych bibliotek - tylko standardowa biblioteka Pythona 3.8+.
Przed zapisem robi kopie workflow_api.json -> workflow_api.backup-fd.json.
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid

WERSJA = "1.0 z 24.09.2026"

KLASA_FD = "FaceDetailer"
KLASA_DETEKTOR = "UltralyticsDetectorProvider"
KLASA_SAM = "SAMLoader"

OKNO_DETEKTORA_OPIS = (
    "   Pobierz plik face_yolov8m.pt i wgraj go do folderu\n"
    "   <ComfyUI>\\models\\ultralytics\\bbox\\face_yolov8m.pt\n"
    "   https://huggingface.co/Bingsu/adetailer/resolve/main/face_yolov8m.pt\n"
    "   (ten sam folder, ktory ComfyUI pokazuje w liscie pola 'model_name' nodu\n"
    "    UltralyticsDetectorProvider). Potem uruchom ten skrypt jeszcze raz."
)

# Ile kosztuje detal: to samo, co w panelu "Img-Engine v7" (denoise 0.35-0.40,
# crop factor 3.0, feather 16), a guide_size 512 zamiast 1024, bo model to SD1.5.
CHCE = {
    "seed": 0,
    "steps": 20,
    "cfg": 6.0,
    "sampler_name": "dpmpp_2m",
    "scheduler": "karras",
    "denoise": 0.40,
    "feather": 16,
    "noise_mask": True,
    "force_inpaint": True,
    "bbox_threshold": 0.50,
    "bbox_dilation": 10,
    "bbox_crop_factor": 3.0,
    "drop_size": 10,
    "wildcard": "",
    "guide_size": 512,
    "guide_size_for": True,
    "max_size": 1024,
    "sam_detection_hint": "center-1",
    "sam_dilation": 0,
    "sam_threshold": 0.93,
    "sam_bbox_expansion": 0,
    "sam_mask_hint_threshold": 0.70,
    "sam_mask_hint_use_negative": "False",
}


class Blad(Exception):
    pass


def http_json(url, timeout=10.0):
    """GET -> (status, objekt, tekst_bl edu). Nigdy nie rzuca wyjatkiem."""
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "chloe-fd/" + WERSJA},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8", "replace")), ""
    except urllib.error.HTTPError as exc:
        try:
            tresc = exc.read().decode("utf-8", "replace")
        except Exception:
            tresc = ""
        return exc.code, None, tresc[:400]
    except Exception as exc:
        return None, None, str(exc)


def http_post(url, objekt, timeout=60.0):
    """POST JSON -> (status, objekt, tekst). Nigdy nie rzuca wyjatkiem."""
    dane = json.dumps(objekt).encode("utf-8")
    req = urllib.request.Request(
        url, data=dane,
        headers={"Content-Type": "application/json", "Accept": "application/json",
                 "User-Agent": "chloe-fd/" + WERSJA},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8", "replace")), ""
    except urllib.error.HTTPError as exc:
        try:
            tresc = exc.read().decode("utf-8", "replace")
        except Exception:
            tresc = ""
        return exc.code, None, tresc[:1200]
    except Exception as exc:
        return None, None, str(exc)


def object_info(comfy, klasa, timeout=30.0):
    """Opis jednego typu noda z /object_info. None = ComfyUI go nie zna."""
    status, obj, tekst = http_json(comfy.rstrip("/") + "/object_info/" + klasa, timeout)
    if status == 200 and isinstance(obj, dict) and klasa in obj:
        return obj[klasa]
    return None


def pola_nodu(opis):
    """Zwraca dict pole -> spec (z required + optional)."""
    out = {}
    sekcje = opis.get("input") or {}
    for nazwa in ("required", "optional"):
        czesc = sekcje.get(nazwa) or {}
        if isinstance(czesc, dict):
            for pole, spec in czesc.items():
                out[pole] = spec
    return out


def pola_wymagane(opis):
    """Nazwy pol z sekcji 'required' - tylko tych braku nie wolno nam przemilczec."""
    sekcje = (opis or {}).get("input") or {}
    return set((sekcje.get("required") or {}).keys())


def typ_i_opcje(spec):
    """(typ, opcje) dla jednego pola. typ: INT/FLOAT/STRING/BOOLEAN/COMBO/albo typ wezla."""
    if not isinstance(spec, list) or not spec:
        return "?", []
    pierwszy = spec[0]
    meta = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
    if isinstance(pierwszy, list):
        return "COMBO", [str(x) for x in pierwszy]
    if isinstance(pierwszy, str) and pierwszy.upper() == "COMBO":
        return "COMBO", [str(x) for x in (meta.get("options") or [])]
    if isinstance(pierwszy, str):
        return pierwszy.upper(), []
    return "?", []


def nazwa_bazowa(sciezka):
    return str(sciezka).replace("\\", "/").split("/")[-1]


def wartosc_domyslna(typ, spec, opcje):
    meta = spec[1] if isinstance(spec, list) and len(spec) > 1 and isinstance(spec[1], dict) else {}
    if typ == "COMBO":
        dom = meta.get("default")
        if dom is not None and str(dom) in opcje:
            return str(dom)
        return opcje[0] if opcje else ""
    if typ == "INT":
        try:
            return int(meta.get("default", meta.get("min", 0)) or 0)
        except Exception:
            return 0
    if typ == "FLOAT":
        try:
            return float(meta.get("default", meta.get("min", 0.0)) or 0.0)
        except Exception:
            return 0.0
    if typ == "BOOLEAN":
        return bool(meta.get("default", False))
    if typ == "STRING":
        return str(meta.get("default", "") or "")
    return None


def dopasuj(chce, typ, opcje):
    """Wrzuca moja wartosc w typ, ktorego chce ComfyUI. None = nie da sie dopasowac."""
    if typ == "COMBO":
        if not opcje:
            return None
        for opcja in opcje:
            if str(opcja) == str(chce):
                return opcja
        # ComfyUI czesto zwraca sciezki z podfolderem (np. "bbox/face_yolov8m.pt"),
        # wiec porownujemy tez sama nazwe pliku.
        for opcja in opcje:
            if nazwa_bazowa(opcja) == nazwa_bazowa(chce):
                return opcja
        if isinstance(chce, bool):
            for kandydat in (("bbox", "True", "true", "tak") if chce else ("mask", "False", "false", "nie")):
                for opcja in opcje:
                    if str(opcja).lower() == kandydat.lower():
                        return opcja
        if isinstance(chce, (int, float)):
            for opcja in opcje:
                try:
                    if float(opcja) == float(chce):
                        return opcja
                except Exception:
                    continue
        return None
    if typ == "INT":
        try:
            return int(round(float(chce)))
        except Exception:
            return None
    if typ == "FLOAT":
        try:
            return float(chce)
        except Exception:
            return None
    if typ == "BOOLEAN":
        if isinstance(chce, str):
            return chce.strip().lower() in ("1", "true", "tak", "yes", "on")
        return bool(chce)
    if typ == "STRING":
        return str(chce)
    return None


def zbuduj_nod_fd(opis, detektor_nod, chce, linki):
    """Buduje wezel FaceDetailer z opisu z ComfyUI.

    Pola liczbowe/tekstowe bierzemy z CHCE, pola wskazujace na inne wezly
    (model, clip, vae, positive, negative) z `linki`. Zwraca (nod, pominiete,
    brakujace) - brakujace to wymagane pola, ktorych nie umiemy wypelnic i przy
    ktorych lepiej sie zatrzymac, niz zapisac popsuty workflow.
    """
    pola = pola_nodu(opis)
    wymagane = pola_wymagane(opis)
    wejscia = {}
    pominiete = []
    brakujace = []
    spec_pol = dict(pola)
    for pole, spec in pola.items():
        typ, opcje = typ_i_opcje(spec)
        if pole in ("image", "bbox_detector", "sam_model_opt", "segm_model_opt",
                    "segm_detector_opt", "detailer_hook", "scheduler_func_opt"):
            continue  # obraz, detektor i SAM dopinamy osobno; reszta jest opcjonalna
        wartosc = None
        if pole in chce:
            wartosc = dopasuj(chce[pole], typ, opcje)
            if wartosc is None and typ == "COMBO":
                wartosc = wartosc_domyslna(typ, spec, opcje)
                pominiete.append(pole + " (nie ma opcji " + str(chce[pole]) + ", wziete "
                                 + str(wartosc) + ")")
        else:
            wartosc = wartosc_domyslna(typ, spec, opcje)
        if wartosc is not None:
            wejscia[pole] = wartosc
            continue
        if linki.get(pole):
            wejscia[pole] = linki[pole]
            continue
        if pole in wymagane:
            brakujace.append(pole + " (" + typ + ")")
        else:
            pominiete.append(pole + " (opcjonalne, pomijam)")
    wejscia["bbox_detector"] = [detektor_nod, 0]
    nod = {"inputs": wejscia, "class_type": KLASA_FD,
           "_meta": {"title": "FaceDetailer (twarz w pelnym kadrze)"}}
    return nod, pominiete, brakujace, spec_pol


def nowe_id(graf):
    najwyzsze = 0
    for klucz in graf.keys():
        try:
            najwyzsze = max(najwyzsze, int(str(klucz)))
        except Exception:
            continue
    return str(najwyzsze + 1), str(najwyzsze + 2)


def wezly_typu(graf, klasa):
    return [k for k in graf.keys()
            if isinstance(graf.get(k), dict) and str(graf[k].get("class_type")) == klasa]


def zbuduj_nod_prosty(klasa, opis, tytul, chce=None):
    """Buduje prosty nod (np. SAMLoader, UltralyticsDetectorProvider) z opisu ComfyUI.

    Wypelnia wszystkie wymagane pola - te podane w `chce`, reszte domyslnymi z opisu.
    Bez tego ComfyUI odrzucilby nod, ktoremu brakuje np. 'device_mode'.
    """
    chce = chce or {}
    wejscia = {}
    for pole, spec in pola_nodu(opis).items():
        typ, opcje = typ_i_opcje(spec)
        wartosc = dopasuj(chce[pole], typ, opcje) if pole in chce else None
        if wartosc is None:
            wartosc = wartosc_domyslna(typ, spec, opcje)
        if wartosc is None:
            continue
        wejscia[pole] = wartosc
    if not wejscia:
        raise Blad("nie umiem zbudowac nodu " + klasa + " - brak pol do wypelnienia")
    return {"inputs": wejscia, "class_type": klasa, "_meta": {"title": tytul}}


def zrodlo_obrazu(graf, node_id, pole="image"):
    """[id, slot] albo None."""
    wejscia = (graf.get(node_id) or {}).get("inputs") or {}
    wartosc = wejscia.get(pole)
    if isinstance(wartosc, list) and len(wartosc) == 2:
        return wartosc
    return None


def link(graf, node_id, pole):
    """[id, slot] tylko wtedy, gdy wskazuje na nod, ktory naprawde jest w grafie."""
    wartosc = zrodlo_obrazu(graf, node_id, pole)
    if wartosc is not None and str(wartosc[0]) in graf:
        return [str(wartosc[0]), wartosc[1]]
    return None


def bazowy_sampler(graf):
    """Nod KSamplera, ktory maluje od zera (denoise ~1)."""
    wszystkie = wezly_typu(graf, "KSampler") + wezly_typu(graf, "KSamplerAdvanced")
    for kid in wszystkie:
        try:
            if float(((graf[kid].get("inputs") or {}).get("denoise", 1) or 1) >= 0.999):
                return kid
        except Exception:
            return kid
    return wszystkie[0] if wszystkie else None


def linki_dla_detalu(graf):
    """Wyciaga z workflow to, czym detal ma malowac: model, clip, vae, prompty.

    Dzieki temu twarz jest przemalowywana tym samym modelem i LoRA i z tym samym
    promptem co reszta kadru - inaczej dostalibysmy "doklejona" twarz w innym stylu.
    """
    wyjscie = {}
    baza = bazowy_sampler(graf)
    if not baza:
        return wyjscie
    for pole in ("model", "clip", "vae", "positive", "negative"):
        gotowy = link(graf, baza, pole)
        if gotowy:
            wyjscie[pole] = gotowy
    # CLIP nie jest podpiety wprost do KSamplera - bierzemy go z nodu promptu
    if "clip" not in wyjscie and "positive" in wyjscie:
        gotowy = link(graf, wyjscie["positive"][0], "clip")
        if gotowy:
            wyjscie["clip"] = gotowy
    if "vae" not in wyjscie:
        for dekoder in wezly_typu(graf, "VAEDecode"):
            gotowy = link(graf, dekoder, "vae")
            if gotowy:
                wyjscie["vae"] = gotowy
                break
    return wyjscie


def wybierz_detektor(opcje, zadany):
    if zadany:
        for opcja in opcje:
            if str(opcja) == zadany or nazwa_bazowa(opcja) == nazwa_bazowa(zadany):
                return opcja
        return None
    for pref in ("face_yolov8m.pt", "face_yolov8s.pt", "face_yolov8n.pt"):
        for opcja in opcje:
            if nazwa_bazowa(opcja) == pref:
                return opcja
    for opcja in opcje:
        if "face" in nazwa_bazowa(opcja).lower():
            return opcja
    return None


def wczytaj(sciezka):
    if not os.path.isfile(sciezka):
        raise Blad("nie ma pliku " + sciezka)
    try:
        with open(sciezka, "r", encoding="utf-8-sig") as fh:
            graf = json.load(fh)
    except Exception as exc:
        raise Blad("nie moge wczytac " + sciezka + ": " + str(exc))
    if not isinstance(graf, dict) or not graf:
        raise Blad("to nie jest workflow w formacie API (klucz = ID noda)")
    return graf


def zapisz(sciezka, graf, kopia=True):
    if kopia:
        kopia_sciezka = os.path.join(os.path.dirname(os.path.abspath(sciezka)), "workflow_api.backup-fd.json")
        if not os.path.isfile(kopia_sciezka):
            with open(kopia_sciezka, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(wczytaj(sciezka), ensure_ascii=False, indent=2))
            print("[i] kopia oryginalu: " + os.path.basename(kopia_sciezka))
    with open(sciezka, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(graf, ensure_ascii=False, indent=2))
    print("[OK] zapisane: " + sciezka)


def test_generacji(comfy, graf, limit):
    """Kolejkuje graf i czeka na wynik. True = ComfyUI przetworzyl bez bledow."""
    status, odp, tekst = http_post(comfy.rstrip("/") + "/prompt",
                                  {"prompt": graf, "client_id": "chloe-fd-" + uuid.uuid4().hex[:8]}, 60.0)
    if status != 200 or not isinstance(odp, dict) or not odp.get("prompt_id"):
        print("[BLAD] ComfyUI nie przyjal grafu: HTTP " + str(status))
        print("       " + str(tekst)[:800])
        return False
    pid = odp["prompt_id"]
    print("[..] proba generacji, prompt_id " + pid + "  (limit " + str(int(limit)) + " s)")
    start = time.time()
    while time.time() - start < limit:
        time.sleep(3.0)
        status, hist, tekst = http_json(comfy.rstrip("/") + "/history/" + pid, 30.0)
        if status != 200 or not isinstance(hist, dict) or pid not in hist:
            continue
        wpis = hist[pid]
        czas = time.time() - start
        stan = ((wpis.get("status") or {}).get("status_str")) or "?"
        bledy = []
        for wiad in ((wpis.get("status") or {}).get("messages") or []):
            if isinstance(wiad, list) and len(wiad) > 1 and wiad[0] == "execution_error":
                bledy.append(json.dumps(wiad[1], ensure_ascii=False)[:500])
        obrazy = []
        for out in (wpis.get("outputs") or {}).values():
            for img in (out.get("images") or []):
                obrazy.append(str(img.get("filename")))
        if bledy:
            print("[BLAD] ComfyUI przerwal generacje po " + str(round(czas, 1)) + " s:")
            for b in bledy:
                print("       " + b)
            return False
        if stan == "success" and obrazy:
            print("[OK] obraz gotowy w " + str(round(czas, 1)) + " s: " + ", ".join(obrazy[:3]))
            return True
        if stan in ("error", "failed"):
            print("[BLAD] status " + stan + " po " + str(round(czas, 1)) + " s")
            return False
    print("[BLAD] przekroczono limit oczekiwania (" + str(int(limit)) + " s)")
    return False


def usun_fd(graf):
    """Wypina FaceDetailer i zwraca (graf, ile_usunietych)."""
    usuniete = 0
    for fd_id in wezly_typu(graf, KLASA_FD):
        zrodlo = zrodlo_obrazu(graf, fd_id)
        if zrodlo is None:
            print("[!] nod " + fd_id + " nie ma wejscia image - pomijam")
            continue
        # wszystko, co bralo obraz z FaceDetailera, ma teraz brac z jego zrodla
        for inny in graf.keys():
            wejscia = (graf.get(inny) or {}).get("inputs")
            if not isinstance(wejscia, dict):
                continue
            for pole, wartosc in list(wejscia.items()):
                if isinstance(wartosc, list) and len(wartosc) == 2 and str(wartosc[0]) == str(fd_id):
                    wejscia[pole] = [zrodlo[0], zrodlo[1]]
        del graf[fd_id]
        usuniete += 1
    # detektory, ktorych juz nikt nie uzywa
    for det_id in list(wezly_typu(graf, KLASA_DETEKTOR)) + list(wezly_typu(graf, KLASA_SAM)):
        uzywany = False
        for inny in graf.keys():
            wejscia = (graf.get(inny) or {}).get("inputs")
            if not isinstance(wejscia, dict):
                continue
            for wartosc in wejscia.values():
                if isinstance(wartosc, list) and len(wartosc) == 2 and str(wartosc[0]) == str(det_id):
                    uzywany = True
        if not uzywany:
            del graf[det_id]
    return graf, usuniete


def main():
    ap = argparse.ArgumentParser(description="Doklada FaceDetailer (Impact Pack) do workflow_api.json.")
    ap.add_argument("--comfy", default=os.environ.get("COMFY_URL", "http://127.0.0.1:8188"),
                    help="adres ComfyUI, domyslnie http://127.0.0.1:8188")
    ap.add_argument("--workflow", default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                       "workflow_api.json"),
                    help="plik workflow w formacie API")
    ap.add_argument("--detector", default="", help="nazwa modelu detektora, np. bbox/face_yolov8m.pt")
    ap.add_argument("--denoise", type=float, default=None, help="denoise detalu, domyslnie 0.40")
    ap.add_argument("--steps", type=int, default=None, help="kroki detalu, domyslnie jak w bazowym KSamplerze")
    ap.add_argument("--guide-size", type=int, default=None, help="bok wycinka dla detalu, domyslnie 512 (384 = szybciej)")
    ap.add_argument("--cfg", type=float, default=None, help="CFG detalu, domyslnie 6.0")
    ap.add_argument("--sam", action="store_true", help="dopnij SAMLoader (potrzebny model SAM w models/sams)")
    ap.add_argument("--dry-run", action="store_true", help="pokaz, co by zrobil, ale nie zapisuj")
    ap.add_argument("--remove", action="store_true", help="wyciagnij FaceDetailer z workflow")
    ap.add_argument("--test", action="store_true", help="po wstawieniu zrob probe generacji")
    ap.add_argument("--test-limit", type=float, default=900.0, help="limit proby generacji w sekundach")
    ap.add_argument("--wiecej", action="store_true", help="wypisz pelny opis nodu FaceDetailer z ComfyUI")
    args = ap.parse_args()

    print("=== dodaj_facedetailer.py " + WERSJA + " ===")
    print("")

    try:
        graf = wczytaj(args.workflow)
    except Blad as exc:
        print("[BLAD] " + str(exc))
        return 1
    print("[i] workflow: " + args.workflow + "  (" + str(len(graf)) + " nodow)")

    if args.remove:
        graf, ile = usun_fd(graf)
        if not ile:
            print("[i] nie bylo czego usuwac - w workflow nie ma nodu FaceDetailer")
            return 0
        print("[OK] wypisane nody FaceDetailer: " + str(ile))
        if args.dry_run:
            print("[i] --dry-run: nie zapisuje")
            return 0
        zapisz(args.workflow, graf, kopia=False)
        return 0

    if wezly_typu(graf, KLASA_FD):
        print("[i] workflow juz ma FaceDetailer. Chcesz zmienic parametry?")
        print("    python dodaj_facedetailer.py --remove   (a potem uruchom mnie znowu)")
        return 0

    status, sysinfo, tekst = http_json(args.comfy.rstrip("/") + "/system_stats", 8.0)
    if status != 200:
        print("[BLAD] ComfyUI nie odpowiada pod " + args.comfy + "  (" + str(tekst)[:200] + ")")
        print("       Uruchom Start_Comfy_i_Hermes.bat i sprobuj ponownie.")
        return 1
    wersja = ((sysinfo or {}).get("system") or {}).get("comfyui_version", "?")
    print("[OK] ComfyUI " + str(wersja) + " odpowiada")

    opis_fd = object_info(args.comfy, KLASA_FD)
    if opis_fd is None:
        print("[BRAK] ComfyUI nie zna nodu FaceDetailer - brakuje wtyczki ComfyUI Impact Pack.")
        print("       ComfyUI-Manager -> Install Custom Nodes -> 'ComfyUI Impact Pack' (comfyui-impact-pack),")
        print("       potem restart ComfyUI i uruchom ten skrypt jeszcze raz.")
        return 3

    opis_det = object_info(args.comfy, KLASA_DETEKTOR)
    if opis_det is None:
        print("[BRAK] ComfyUI nie ma nodu UltralyticsDetectorProvider.")
        print("       FaceDetailer JEST (Impact Pack zainstalowany), ale nie ma czym wykryc twarzy,")
        print("       bo modul z detektorem YOLO sie nie zaladowal - prawie zawsze dlatego, ze")
        print("       w srodowisku ComfyUI brakuje pakietu 'ultralytics'.")
        print("       Napraw jednym kliknieciem: Dodaj_detektor_twarzy.bat")
        print("       (recznie: " + "python_env\\python.exe -m pip install --no-deps ultralytics")
        print("        potem restart ComfyUI i jeszcze raz ten skrypt)")
        return 3

    opcje_det = typ_i_opcje(pola_nodu(opis_det).get("model_name"))[1]
    print("[i] modele detektora widziane przez ComfyUI: "
          + (", ".join(opcje_det) if opcje_det else "BRAK (folder models\\ultralytics\\bbox jest pusty)"))
    detektor = wybierz_detektor(opcje_det, args.detector)
    if detektor is None:
        print("[BRAK] nie ma zadnego wykrywacza twarzy w models\\ultralytics\\bbox.")
        if args.detector:
            print("       chciales: " + args.detector)
        print(OKNO_DETEKTORA_OPIS)
        return 2
    if args.detector and nazwa_bazowa(detektor) != nazwa_bazowa(args.detector):
        print("[i] zamiast '" + args.detector + "' uzyje '" + detektor + "'")
    print("[OK] detektor twarzy: " + detektor)

    chce = dict(CHCE)
    # kroki domyslnie jak w bazowym KSamplerze (denoise 1.0), zeby detal nie byl "innej jakosci"
    if args.steps is None:
        for kid in wezly_typu(graf, "KSampler") + wezly_typu(graf, "KSamplerAdvanced"):
            wejscia = (graf.get(kid) or {}).get("inputs") or {}
            try:
                if float(wejscia.get("denoise", 1)) >= 1.0 and int(wejscia.get("steps") or 0) > 0:
                    chce["steps"] = int(wejscia["steps"])
                    break
            except Exception:
                continue
    for nazwa, wartosc in (("denoise", args.denoise), ("steps", args.steps),
                           ("guide_size", args.guide_size), ("cfg", args.cfg)):
        if wartosc is not None:
            chce[nazwa] = wartosc

    fd_id, det_id = nowe_id(graf)
    linki = linki_dla_detalu(graf)
    if not linki.get("model") or not linki.get("positive"):
        print("[BLAD] nie umiem wyciagnac z workflow modelu/promptu dla detalu.")
        print("       Spodziewam sie KSamplera z denoise 1.0 podpietego do checkpointu i CLIPTextEncode.")
        return 1
    print("[i] detal bedzie malowal: model <- nod " + str(linki.get("model", ["?"])[0])
          + ", prompt <- nod " + str(linki.get("positive", ["?"])[0])
          + (", vae <- nod " + str(linki["vae"][0]) if linki.get("vae") else ""))
    nod_fd, pominiete, brakujace, _spec = zbuduj_nod_fd(opis_fd, det_id, chce, linki)
    if brakujace:
        print("[BLAD] nie umiem wypelnic wymaganych pol nodu FaceDetailer:")
        for pole in brakujace:
            print("       " + pole)
        print("       Twoja wersja Impact Packu ma inny zestaw pol - podeslij ich liste")
        print("       (python dodaj_facedetailer.py --wiecej) i dopiszemy je do skryptu.")
        print("       workflow_api.json NIE zostal zmieniony.")
        return 1
    graf[det_id] = zbuduj_nod_prosty(KLASA_DETEKTOR, opis_det, "Detektor twarzy (Impact Pack)",
                                     {"model_name": detektor})
    graf[fd_id] = nod_fd

    # --- gdzie wpiac detal: przed upscalem (taniej) albo przed SaveImage ---
    cel = None
    for klasa in ("ImageUpscaleWithModel", "UltimateSDUpscale"):
        kandydaci = wezly_typu(graf, klasa)
        if kandydaci:
            cel = kandydaci[0]
            break
    if cel is None:
        kandydaci = wezly_typu(graf, "SaveImage") + wezly_typu(graf, "PreviewImage")
        if not kandydaci:
            print("[BLAD] w workflow nie ma SaveImage/PreviewImage - nie ma gdzie wpiac detalu")
            return 1
        cel = kandydaci[0]
    zrodlo = zrodlo_obrazu(graf, cel)
    if zrodlo is None:
        print("[BLAD] nod " + cel + " (" + str(graf[cel].get("class_type")) + ") nie ma wejscia image")
        return 1
    graf[fd_id]["inputs"]["image"] = [zrodlo[0], zrodlo[1]]
    graf[cel]["inputs"]["image"] = [fd_id, 0]
    print("[i] detal wpiety w: " + str(graf[cel].get("class_type")) + " (nod " + cel + ")"
          + " <- obraz z nodu " + str(zrodlo[0]) + ", detal = nod " + fd_id)

    if args.sam:
        opis_sam = object_info(args.comfy, KLASA_SAM)
        opcje_sam = typ_i_opcje(pola_nodu(opis_sam).get("model_name"))[1] if opis_sam else []
        if opcje_sam:
            sam_id = str(max(int(fd_id), int(det_id)) + 1)
            graf[sam_id] = zbuduj_nod_prosty(KLASA_SAM, opis_sam, "SAM (maska twarzy)",
                                             {"model_name": opcje_sam[0]})
            graf[fd_id]["inputs"]["sam_model_opt"] = [sam_id, 0]
            print("[i] dopiety SAM: " + opcje_sam[0] + " (nod " + sam_id + ")")
        else:
            print("[!] --sam, ale ComfyUI nie widzi zadnego modelu SAM w models\\sams - pomijam")

    print("")
    print("--- parametry detalu ---")
    for klucz in sorted(graf[fd_id]["inputs"].keys()):
        wartosc = graf[fd_id]["inputs"][klucz]
        if isinstance(wartosc, list) and len(wartosc) == 2 and not isinstance(wartosc[1], dict):
            print("   " + klucz + " = <- nod " + str(wartosc[0]))
        else:
            print("   " + klucz + " = " + str(wartosc))
    for uwaga in pominiete:
        print("[i] " + uwaga)

    if args.wiecej:
        print("")
        print("--- pelny opis FaceDetailer z Twojego ComfyUI ---")
        print(json.dumps(opis_fd, ensure_ascii=False, indent=2)[:8000])

    if args.dry_run:
        print("")
        print("[i] --dry-run: nic nie zapisuje.")
        return 0

    zapisz(args.workflow, graf)
    print("[i] mostek sam wykryje zmiane pliku (kontroluje date modyfikacji) - restart nie jest potrzebny.")
    print("[i] Zeby cofnac: python dodaj_facedetailer.py --remove")

    if args.test:
        print("")
        if not test_generacji(args.comfy, graf, args.test_limit):
            print("[!] proba nie przeszla - cofnij zmiane: python dodaj_facedetailer.py --remove")
            return 1
    else:
        print("[i] Proba generacji: python dodaj_facedetailer.py jest juz wpisany -")
        print("    mozesz sprawdzic obraz normalnie w Chloe (albo w ComfyUI).")

    print("")
    print("=== WYNIK: FaceDetailer dopisany do " + os.path.basename(args.workflow) + " ===")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("")
        print("przerwane")
        sys.exit(130)
    except Blad as blad:
        print("[BLAD] " + str(blad))
        sys.exit(1)
