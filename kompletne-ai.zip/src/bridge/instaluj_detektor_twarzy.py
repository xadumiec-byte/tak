#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""instaluj_detektor_twarzy.py - dokancza instalacje detektora twarzy (Impact Subpack).

Uruchamiany przez Dodaj_detektor_twarzy.bat, ktory najpierw wgrywa sam pakiet
(custom_nodes\\ComfyUI-Impact-Subpack). Ten skrypt robi reszte:

  1) sprawdza, czy srodowisko ComfyUI ma wszystko, czego potrzebuje
     "from ultralytics import YOLO" - czyli to, co robi nod UltralyticsDetectorProvider,
  2) brakujace pakiety instaluje z flaga --no-deps, ZEBY NIE RUSZYC Twojego
     torch/torchvision. To jest kluczowe przy ROCm: zwykly "pip install ultralytics"
     potrafi podmienic torch na wersje CUDA i wtedy ComfyUI przestaje widziec karte.
     Dlatego zaleznosci ultralytics dokladamy pojedynczo, a jesli czegos brakuje,
     skrypt sam odczytuje z bledu nazwe modulu i doklada tylko niego,
  3) sciaga model face_yolov8m.pt do models\\ultralytics\\bbox,
  4) mowi, co zrobic dalej (restart ComfyUI + python dodaj_facedetailer.py).

Uzycie:
    python instaluj_detektor_twarzy.py                 # wykryj folder ComfyUI sam
    python instaluj_detektor_twarzy.py --pack "C:\\...\\comfyui-rocm-091926"
    python instaluj_detektor_twarzy.py --dry-run       # tylko pokaz plan
    python instaluj_detektor_twarzy.py --no-model      # nie sciagaj modelu
    python instaluj_detektor_twarzy.py --bbox "D:\\inne\\models\\ultralytics\\bbox"

Bez zewnetrznych bibliotek - tylko standardowa biblioteka Pythona 3.8+.
"""

import argparse
import glob
import os
import re
import subprocess
import sys
import time
import urllib.request

WERSJA = "1.0 z 24.09.2026"

MODEL_URL = "https://huggingface.co/Bingsu/adetailer/resolve/main/face_yolov8m.pt"
MODEL_FOLDER = os.path.join("models", "ultralytics", "bbox")
MODEL_PLIK = "face_yolov8m.pt"
SUBPACK_FOLDER = "ComfyUI-Impact-Subpack"

# (modul do sprawdzenia, pakiet do instalacji). cv2 sprawdzamy, ale NIE dokladamy
# opencv-python-headless, jesli cv2 juz jest - inaczej dwa opakowania opencv
# nadpisalyby sobie pliki i cv2 moglby przestac importowac.
DO_SPRAWDZENIA = [
    ("cv2", "opencv-python-headless"),
    ("yaml", "pyyaml"),
    ("requests", "requests"),
    ("tqdm", "tqdm"),
    ("psutil", "psutil"),
    ("cpuinfo", "py-cpuinfo"),
    ("scipy", "scipy"),
    ("pandas", "pandas"),
    ("matplotlib", "matplotlib"),
    ("dill", "dill"),
]
ULTRA_PAKIETY = ["ultralytics", "matplotlib"]
ZNAJDZ_MODUL = re.compile(r"No module named '([^']+)'")
MAX_DOKLADEK = 10


def uruchom(komenda, dry_run=False):
    """Uruchamia proces i zwraca (kod, stdout+stderr)."""
    if dry_run:
        print("      [dry-run] " + " ".join(komenda))
        return 0, ""
    try:
        gotowe = subprocess.run(komenda, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                universal_newlines=True)
        return gotowe.returncode, gotowe.stdout or ""
    except Exception as exc:
        return 1, "nie udalo sie uruchomic: " + str(exc)


def ma_moduly(python, moduly):
    """Zwraca liste modulow, ktorych interpreter nie widzi."""
    kod = ("import importlib.util, sys\n"
           "brak = [m for m in " + repr(list(moduly)) + " if importlib.util.find_spec(m) is None]\n"
           "print(' '.join(brak))\n")
    wynik_kod, wyjscie = uruchom([python, "-c", kod])
    if wynik_kod != 0:
        return list(moduly)
    return [m for m in wyjscie.strip().split() if m]


def pip(python, pakiety, dry_run=False):
    if not pakiety:
        return True
    print("      pip install --no-deps " + " ".join(pakiety))
    kod, wyjscie = uruchom([python, "-m", "pip", "install", "--no-deps",
                            "--disable-pip-version-check", "--upgrade"] + list(pakiety), dry_run)
    if kod != 0:
        print("      [BLAD] pip zwrocil " + str(kod) + ":")
        for linia in (wyjscie or "").strip().splitlines()[-8:]:
            print("        " + linia)
        return False
    return True


def test_importu(python, dry_run=False):
    """(czy_dziala, brakujacy_modul, pelne_wyjscie)."""
    kod, wyjscie = uruchom([python, "-c",
                            "from ultralytics import YOLO; import ultralytics; print('OK ' + ultralytics.__version__)"],
                           dry_run)
    if kod == 0:
        return True, "", wyjscie
    trafienie = ZNAJDZ_MODUL.search(wyjscie or "")
    return False, (trafienie.group(1) if trafienie else ""), wyjscie


def szukaj_packu(start):
    """Szuka folderu ComfyUI (main.py + models + custom_nodes) w okolicy."""
    kandydaci = [start]
    for wzor in ("comfyui-rocm*", os.path.join("..", "comfyui-rocm*")):
        kandydaci += sorted(glob.glob(os.path.join(start, wzor)))
    kandydaci += [os.path.join(start, ".."), os.path.join(start, "..", "..")]
    for folder in kandydaci:
        folder = os.path.abspath(folder)
        if (os.path.isfile(os.path.join(folder, "main.py"))
                and os.path.isdir(os.path.join(folder, "models"))):
            return folder
    return ""


def sciagnij_model(sciezka, dry_run=False):
    if os.path.isfile(sciezka):
        print("      [OK] plik juz jest (" + str(os.path.getsize(sciezka)) + " bajtow)")
        return True
    folder = os.path.dirname(sciezka)
    if not dry_run:
        os.makedirs(folder, exist_ok=True)
    if dry_run:
        print("      [dry-run] sciagnalbym " + MODEL_URL + " -> " + sciezka)
        return True
    print("      sciagam " + MODEL_URL)
    start = time.time()
    try:
        with urllib.request.urlopen(MODEL_URL, timeout=300) as odp, open(sciezka, "wb") as plik:
            while True:
                kawalek = odp.read(1024 * 256)
                if not kawalek:
                    break
                plik.write(kawalek)
    except Exception as exc:
        print("      [BLAD] nie udalo sie sciagnac: " + str(exc)[:200])
        if os.path.isfile(sciezka):
            try:
                os.remove(sciezka)
            except OSError:
                pass
        return False
    print("      [OK] " + str(os.path.getsize(sciezka)) + " bajtow w "
          + str(round(time.time() - start, 1)) + " s")
    return True


def main():
    ap = argparse.ArgumentParser(description="Dokancza instalacje detektora twarzy (Impact Subpack).")
    ap.add_argument("--pack", default="", help="folder ComfyUI (z main.py i models)")
    ap.add_argument("--bbox", default="", help="folder na face_yolov8m.pt (domyslnie <pack>\\models\\ultralytics\\bbox)")
    ap.add_argument("--python", default="", help="interpreter srodowiska ComfyUI (domyslnie python_env obok)")
    ap.add_argument("--no-model", action="store_true", help="nie sciagaj modelu detektora")
    ap.add_argument("--dry-run", action="store_true", help="tylko pokaz, co by zrobil")
    args = ap.parse_args()

    print("=== instaluj_detektor_twarzy.py " + WERSJA + " ===")
    print("")
    wynik = 0

    # --- folder ComfyUI
    pack = args.pack.strip() or szukaj_packu(os.path.dirname(os.path.abspath(__file__)) or ".")
    if not pack:
        print("[BLAD] nie znalazlem folderu ComfyUI (main.py + models). Podaj go: --pack \"C:\\...\\comfyui-rocm-091926\"")
        return 1
    print("[i] ComfyUI: " + pack)
    if not os.path.isfile(os.path.join(pack, "main.py")):
        print("[BLAD] Ten folder nie wyglada na ComfyUI - nie ma w nim main.py.")
        print("       Podaj folder z main.py i models, np. ...\\comfyui-rocm-091926")
        return 1

    # --- interpreter
    python = args.python.strip()
    if not python:
        kandydat = os.path.join(pack, "python_env", "python.exe")
        if os.path.isfile(kandydat):
            python = kandydat
        else:
            python = sys.executable
    print("[i] Python : " + python)
    kod_py, wyjscie_py = uruchom([python, "-c", "import sys; print(sys.version.split()[0])"], args.dry_run)
    if kod_py == 0 and wyjscie_py.strip():
        print("           wersja " + wyjscie_py.strip().splitlines()[-1])
    kod_t, wyjscie_t = uruchom([python, "-c", "import torch; print(torch.__version__)"], args.dry_run)
    if kod_t == 0 and wyjscie_t.strip():
        print("[i] torch  : " + wyjscie_t.strip().splitlines()[-1]
              + "   <- tyle ma byc TAKZE po instalacji (wersja z '+rocm')")

    # --- czy sam pakiet jest na miejscu
    subpack = os.path.join(pack, "custom_nodes", SUBPACK_FOLDER)
    if os.path.isfile(os.path.join(subpack, "__init__.py")):
        print("[OK] pakiet na miejscu: custom_nodes\\" + SUBPACK_FOLDER)
    else:
        print("[BRAK] custom_nodes\\" + SUBPACK_FOLDER + " - uruchom najpierw Dodaj_detektor_twarzy.bat")
        print("       (albo zainstaluj 'ComfyUI Impact Subpack' w ComfyUI-Manager)")
        wynik = 2

    # --- zaleznosci
    print("")
    print("[1/3] Sprawdzam moduly w srodowisku ComfyUI...")
    brakujace = ma_moduly(python, [m for m, _ in DO_SPRAWDZENIA]) if not args.dry_run else [m for m, _ in DO_SPRAWDZENIA]
    do_pip = []
    for modul, pakiet in DO_SPRAWDZENIA:
        if modul in brakujace and modul != "cv2":
            do_pip.append(pakiet)
    if "cv2" in brakujace:
        print("      [i] brak cv2 - dokladam opencv-python-headless")
        do_pip.append("opencv-python-headless")
    if do_pip:
        print("      brakuje: " + ", ".join(do_pip))
    else:
        print("      [OK] podstawowe moduly sa na miejscu")

    print("")
    print("[2/3] Instaluje ultralytics i to, czego brakuje (zawsze --no-deps, zeby nie ruszyc torch/ROCm)...")
    if not pip(python, do_pip + ULTRA_PAKIETY, args.dry_run):
        print("      [!] cos sie nie zainstalowalo - sprawdz, czy import dziala nizej")
    dziala, brakujacy, wyjscie = (True, "", "") if args.dry_run else test_importu(python)
    proby = 0
    while not dziala and brakujacy and proby < MAX_DOKLADEK:
        proby += 1
        print("      [i] brakuje modulu '" + brakujacy + "' - dokladam i probuje znowu")
        if not pip(python, [brakujacy.replace("_", "-")]):
            break
        dziala, brakujacy, wyjscie = test_importu(python)
    if args.dry_run:
        print("      [dry-run] pomijam test importu")
    elif dziala:
        ostatnia = [l for l in (wyjscie or "").splitlines() if l.startswith("OK ")]
        print("      [OK] import ultralytics dziala" + (" (" + ostatnia[-1][3:] + ")" if ostatnia else ""))
        kod_t2, wyjscie_t2 = uruchom([python, "-c", "import torch; print(torch.__version__)"])
        if kod_t2 == 0 and wyjscie_t2.strip():
            print("      [i] torch po instalacji: " + wyjscie_t2.strip().splitlines()[-1]
                  + "   (ma byc taka sama jak na poczatku)")
    else:
        print("      [BLAD] import ultralytics nie dziala. Ostatnie linie bledu:")
        for linia in (wyjscie or "").strip().splitlines()[-10:]:
            print("        " + linia)
        wynik = 1

    # --- model detektora
    print("")
    print("[3/3] Model detektora twarzy")
    bbox = args.bbox.strip() or os.path.join(pack, MODEL_FOLDER)
    sciezka = os.path.join(bbox, MODEL_PLIK)
    print("      folder: " + bbox)
    if args.no_model:
        print("      [i] --no-model: pomijam (zadbalby o to install.py pakietu)")
    elif not sciagnij_model(sciezka, args.dry_run):
        wynik = 1

    print("")
    if wynik == 0:
        print("=== WYNIK: detektor gotowy. Zrestartuj ComfyUI i wpisz: python dodaj_facedetailer.py ===")
    else:
        print("=== WYNIK: cos nie wyszlo (patrz wyzej). Skopiuj mi ten tekst, dokoncze to ===")
    return wynik


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("")
        print("przerwane")
        sys.exit(130)
