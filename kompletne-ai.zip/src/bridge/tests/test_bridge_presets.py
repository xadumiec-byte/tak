# Testy mostka v11 — presety trybow obrazu ("fast" / "hq" / SDXL).
# Nie wymagaja sieci ani ComfyUI: sprawdzamy dobor trybu, latanie grafu, pierwszenstwo
# rozmiaru i parametrow oraz czytelne komunikaty o brakujacych modelach.
#
# Uruchomienie (z katalogu src/bridge):
#     python tests/test_bridge_presets.py
# Kod wyjscia 0 = wszystko OK, 1 = sa bledy.

import importlib.util
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BRIDGE = HERE.parent

failures = []


def check(name, condition, detail=""):
    if condition:
        print("  OK   " + name)
    else:
        print("  BLAD " + name + ((" -> " + str(detail)) if detail else ""))
        failures.append(name)


def load_bridge():
    spec = importlib.util.spec_from_file_location("bridge", str(BRIDGE / "hermes_comfy_bridge.py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules["bridge"] = module
    spec.loader.exec_module(module)
    return module


def make_cfg(bridge, workflow="workflow_api.json", size="auto"):
    cfg = bridge.Config()
    cfg.workflow_file = str(BRIDGE / workflow)
    cfg.size = size
    cfg.pos_node = "2"
    cfg.neg_node = "3"
    return cfg


def main():
    print("=== TESTY MOSTKA: presety trybow obrazu ===")
    bridge = load_bridge()
    cfg = make_cfg(bridge)

    print("\n[1] Tabela presetow")
    table = bridge.preset_table(cfg)
    for name in ("default", "fast", "classic", "sdxl_fast", "sdxl_cfg8", "sdxl_std", "sdxl_hq"):
        check("preset " + name + " istnieje", name in table)
    check("kazdy preset ma plik na dysku",
          all(bridge.preset_path(cfg, p).exists() for p in table.values()),
          [str(bridge.preset_path(cfg, p)) for p in table.values() if not bridge.preset_path(cfg, p).exists()])

    print("\n[2] Wybor trybu")
    name, preset = bridge.resolve_preset(cfg, "")
    check("brak pola preset -> domyslny", name == "default", name)
    name, preset = bridge.resolve_preset(cfg, "fast")
    check("preset fast -> plik fast", name == "fast" and preset["workflow_file"] == "workflow_sd15_fast.json", preset)
    cfg.preset = "classic"
    name, _ = bridge.resolve_preset(cfg, "")
    check("preset z configu", name == "classic", name)
    try:
        bridge.resolve_preset(cfg, "nie_ma_takiego")
        check("nieznany preset zglasza blad", False)
    except Exception as exc:
        check("nieznany preset zglasza blad", "nieznany tryb obrazu" in str(exc) and "fast" in str(exc), exc)

    print("\n[3] Sciezki plikow presetow")
    cfg.preset = "default"
    check("sciezka wzgledna obok workflow",
          bridge.preset_path(cfg, {"workflow_file": "workflow_sd15_fast.json"}).name == "workflow_sd15_fast.json")
    check("pusty workflow_file = glowny workflow",
          bridge.preset_path(cfg, {}) == Path(cfg.workflow_file))

    print("\n[4] Pierwszenstwo parametrow (zadanie > preset)")
    eff = bridge.effective_overrides({"steps": 8, "cfg": 5.5, "sampler": "euler"}, {"cfg": 7, "seed": 1})
    check("preset ustawia steps", eff.get("steps") == 8, eff)
    check("zadanie nadpisuje cfg", eff.get("cfg") == 7, eff)
    check("puste wartosci nie nadpisuja", "denoise" not in eff, eff)

    print("\n[5] Prefiks/sufiks promptu")
    styled = bridge.apply_prompt_style({"prompt_prefix": "masterpiece, best quality", "prompt_suffix": "score_9"},
                                       "1girl, nude, on bed")
    check("prefiks dodany", styled.startswith("masterpiece, best quality, "), styled)
    check("sufiks dodany", styled.endswith(", score_9"), styled)
    again = bridge.apply_prompt_style({"prompt_prefix": "masterpiece, best quality"}, styled)
    check("prefiks nie dubluje sie", again.count("masterpiece") == 1, again)

    print("\n[6] Latanie grafu (build_graph)")
    graph = bridge.build_graph(cfg, "test prompt", "test negative", "", 1234, {}, bridge.preset_table(cfg)["default"])
    check("prompt w wezel 2", graph["2"]["inputs"]["text"] == "test prompt")
    check("negatywa w wezel 3", graph["3"]["inputs"]["text"] == "test negative")
    check("rozmiar z presetu (768x1152)",
          graph["4"]["inputs"]["width"] == 768 and graph["4"]["inputs"]["height"] == 1152, graph["4"]["inputs"])
    check("seed ustawiony", graph["5"]["inputs"]["seed"] == 1234)
    check("prefiks zapisu podmieniony", "1234" in graph["12"]["inputs"]["filename_prefix"], graph["12"]["inputs"])

    fast = bridge.preset_table(cfg)["fast"]
    graph = bridge.build_graph(cfg, "p", "n", "", 7, bridge.effective_overrides(fast, {}), fast)
    check("tryb fast: rozmiar 512x768", graph["4"]["inputs"]["width"] == 512 and graph["4"]["inputs"]["height"] == 768)
    check("tryb fast: sampler z presetu", graph["5"]["inputs"]["sampler_name"] == "dpmpp_2m")
    check("tryb fast: upscaler ESRGAN obecny", graph["18"]["inputs"]["model_name"] == "RealESRGAN_x2plus.pth")
    check("tryb domyslny nie uzywa ESRGAN",
          "18" not in bridge.build_graph(cfg, "p", "n", "", 7, {}, bridge.preset_table(cfg)["default"]))

    graph = bridge.build_graph(cfg, "p", "n", "1024x1024", 7, {}, fast)
    check("size z zadania wygrywa z presetem",
          graph["4"]["inputs"]["width"] == 1024 and graph["4"]["inputs"]["height"] == 1024)

    cfg2 = make_cfg(bridge, size="768x768")
    graph = bridge.build_graph(cfg2, "p", "n", "", 7, {}, {"size": "auto"})
    check("preset 'auto' -> rozmiar z cfg", graph["4"]["inputs"]["width"] == 768, graph["4"]["inputs"])

    print("\n[7] Podmiana checkpointu i parametrow z zadania")
    graph = bridge.build_graph(cfg, "p", "n", "", 7, {"checkpoint": "inny_model.safetensors", "steps": 12, "cfg": 4.5,
                                                       "sampler": "euler", "scheduler": "sgm_uniform"},
                               bridge.preset_table(cfg)["default"])
    check("checkpoint podmieniony", graph["1"]["inputs"]["ckpt_name"] == "inny_model.safetensors")
    check("steps z zadania", graph["5"]["inputs"]["steps"] == 12)
    check("cfg z zadania", graph["5"]["inputs"]["cfg"] == 4.5)
    check("sampler z zadania", graph["5"]["inputs"]["sampler_name"] == "euler")
    check("scheduler z zadania", graph["5"]["inputs"]["scheduler"] == "sgm_uniform")

    print("\n[8] Kontrola brakujacych modeli")
    original = bridge.comfy_model_list
    bridge.comfy_model_list = lambda cfg_, folder: {
        "checkpoints": ["epicrealism_naturalSinRC1VAE.safetensors", "lustifySDXLNSFW_endgame.safetensors"],
        "loras": ["epiCRealismHelper.safetensors"],
        "vae": [],
        "upscale_models": ["RealESRGAN_x2plus.pth"],
    }.get(folder)
    cfg3 = make_cfg(bridge)
    graph = bridge.build_graph(cfg3, "p", "n", "", 7, {}, bridge.preset_table(cfg3)["default"])
    check("graf z poprawnymi modelami przechodzi", bridge.preflight_graph(cfg3, graph) == [])
    graph = bridge.build_graph(cfg3, "p", "n", "", 7, {}, {"checkpoint": "brak_takiego.safetensors"})
    missing = bridge.preflight_graph(cfg3, graph)
    check("brak checkpointu wykryty", len(missing) == 1 and missing[0]["pole"] == "ckpt_name", missing)
    opis = bridge.describe_missing_models(missing)
    check("komunikat po polsku", "brak modelu checkpoints/" in opis, opis)
    sdxl = bridge.preset_table(cfg3)["sdxl_fast"]
    graph = bridge.build_graph(cfg3, "p", "n", "", 7, bridge.effective_overrides(sdxl, {}), sdxl)
    check("tryb SDXL: brak LoRA Lightning wykryty",
          any("lora_name" in m["pole"] for m in bridge.preflight_graph(cfg3, graph)))
    bridge.comfy_model_list = original

    print("\n[9] Przepisywacz promptu per tryb")
    default_system = bridge.refine_system({"prompt_prefix": "masterpiece, best quality"})
    check("wlasny prefiks w regulach", "Begin the prompt with: masterpiece, best quality" in default_system)
    with_hint = bridge.refine_system({"prompt_prefix": "masterpiece", "refine_hint": "Tagi anime z danbooru."})
    check("dopisek refine_hint", "Tagi anime z danbooru." in with_hint and "EXTRA RULES" in with_hint)
    check("bez presetu zostaje domyslny prefiks",
          "Begin the prompt with: " + bridge.QUALITY_PREFIX in bridge.refine_system({}))

    print("\n[10] Lista presetow dla /health")
    public = bridge.preset_public(cfg, bridge.preset_table(cfg)["sdxl_fast"])
    check("opis presetu ma plik i rozmiar", public["plik"] == "workflow_sdxl_fast.json" and public["rozmiar"] == "832x1216", public)
    check("istnienie pliku raportowane", public["plik_istnieje"] is True, public)
    check("rodzina presetu raportowana", public.get("rodzina") == "sdxl", public)

    print("\n[11] Automatyczny dobor checkpointu (gdy brakuje tego z workflow)")
    check("rodzina presetu sdxl_cfg8", bridge.preset_family(bridge.preset_table(cfg)["sdxl_cfg8"]) == "sdxl")
    check("rodzina presetu default = sd15", bridge.preset_family(bridge.preset_table(cfg)["default"]) == "sd15")
    check("rodzina z nazwy trybu", bridge.preset_family({}, "sdxl_fast") == "sdxl")

    original_list = bridge.comfy_model_list
    bridge.comfy_model_list = lambda cfg_, folder: {
        "checkpoints": ["epicrealism_naturalSinRC1VAE.safetensors", "waiNSFWIllustrious_v14.safetensors"],
    }.get(folder, [])
    cfg4 = make_cfg(bridge)
    chosen, info = bridge.pick_checkpoint(cfg4, "sdxl", "lustifySDXLNSFW_endgame.safetensors")
    check("brakujacy SDXL -> inny model SDXL z dysku", chosen == "waiNSFWIllustrious_v14.safetensors", (chosen, info))
    check("podmiana opisana (bylo/jest)", bool(info) and info["bylo"].startswith("lustify") and info["jest"] == chosen, info)
    chosen, info = bridge.pick_checkpoint(cfg4, "sdxl", "epicrealism_naturalSinRC1VAE.safetensors")
    check("wyraznie zadany model jest honorowany", chosen == "epicrealism_naturalSinRC1VAE.safetensors" and info is None, (chosen, info))
    chosen, info = bridge.pick_checkpoint(cfg4, "sdxl", "")
    check("pusty checkpoint w trybie SDXL -> model SDXL, nie SD1.5", chosen == "waiNSFWIllustrious_v14.safetensors", (chosen, info))
    chosen, info = bridge.pick_checkpoint(cfg4, "sd15", "epicrealism_naturalSinRC1VAE.safetensors")
    check("obecny checkpoint -> bez zmian", chosen == "epicrealism_naturalSinRC1VAE.safetensors" and info is None, (chosen, info))

    bridge.comfy_model_list = lambda cfg_, folder: {
        "checkpoints": ["epicrealism_naturalSinRC1VAE.safetensors"],
    }.get(folder, [])
    chosen, info = bridge.pick_checkpoint(cfg4, "sdxl", "lustifySDXLNSFW_endgame.safetensors")
    check("brak kandydata SDXL -> pusty wybor (zostaje czytelny blad)", chosen == "" and info is None, (chosen, info))
    chosen, info = bridge.pick_checkpoint(cfg4, "sd15", "brak_takiego.safetensors")
    check("brakujacy SD1.5 -> epicRealism", chosen == "epicrealism_naturalSinRC1VAE.safetensors", (chosen, info))
    chosen, info = bridge.pick_checkpoint(cfg4, "sd15", "")
    check("pusty workflow -> nadal wybiera z dysku", chosen == "epicrealism_naturalSinRC1VAE.safetensors", (chosen, info))

    bridge.comfy_model_list = lambda cfg_, folder: {
        "checkpoints": ["epicrealism_naturalSinRC1VAE.safetensors", "waiNSFWIllustrious_v14.safetensors"],
        "loras": ["epiCRealismHelper.safetensors"],
        "vae": [],
        "upscale_models": ["RealESRGAN_x2plus.pth"],
    }.get(folder, [])
    sdxl = bridge.preset_table(cfg4)["sdxl_cfg8"]
    graph = bridge.build_graph(cfg4, "p", "n", "", 7, bridge.effective_overrides(sdxl, {}), sdxl)
    notes = bridge.autofix_checkpoints(cfg4, graph, bridge.preflight_graph(cfg4, graph), "sdxl")
    check("autofix podmienia ckpt_name w grafie",
          graph["1"]["inputs"]["ckpt_name"] == "waiNSFWIllustrious_v14.safetensors", graph["1"]["inputs"])
    check("autofix zwraca opis podmiany", len(notes) == 1 and notes[0]["jest"] == "waiNSFWIllustrious_v14.safetensors", notes)
    check("po autofixie brakuje tylko LoRA",
          all(m["folder"] != "checkpoints" for m in bridge.preflight_graph(cfg4, graph)),
          bridge.preflight_graph(cfg4, graph))
    bridge.comfy_model_list = lambda cfg_, folder: {
        "checkpoints": ["epicrealism_naturalSinRC1VAE.safetensors", "waiNSFWIllustrious_v14.safetensors"],
        "loras": ["HyperSD\\SDXL\\Hyper-SDXL-8steps-CFG-lora.safetensors"],
        "vae": [],
        "upscale_models": ["RealESRGAN_x2plus.pth"],
    }.get(folder, [])
    graph = bridge.build_graph(cfg4, "p", "n", "", 7, bridge.effective_overrides(sdxl, {}), sdxl)
    notes = bridge.autofix_checkpoints(cfg4, graph, bridge.preflight_graph(cfg4, graph), "sdxl")
    check("autofix + LoRA na dysku = graf gotowy", bridge.preflight_graph(cfg4, graph) == [], bridge.preflight_graph(cfg4, graph))
    check("autofix nie rusza LoRA",
          graph["19"]["inputs"]["lora_name"] == "HyperSD\\SDXL\\Hyper-SDXL-8steps-CFG-lora.safetensors" and len(notes) == 1,
          graph["19"]["inputs"])
    bridge.comfy_model_list = original_list

    print("\n[12] Tryb sdxl_std (SDXL bez destylacji) i bezpieczny hires")
    std = bridge.preset_table(cfg)["sdxl_std"]
    graph = bridge.build_graph(cfg, "p", "n", "", 7, bridge.effective_overrides(std, {}), std)
    klasy = [n.get("class_type") for n in graph.values()]
    check("sdxl_std nie uzywa LoRA", "LoraLoader" not in klasy, klasy)
    check("sdxl_std: 24 kroki, CFG 6, dpmpp_2m + karras",
          graph["5"]["inputs"]["steps"] == 24 and graph["5"]["inputs"]["cfg"] == 6.0
          and graph["5"]["inputs"]["sampler_name"] == "dpmpp_2m"
          and graph["5"]["inputs"]["scheduler"] == "karras", graph["5"]["inputs"])
    check("sdxl_std: model prosto z checkpointu", graph["5"]["inputs"]["model"] == ["1", 0], graph["5"]["inputs"]["model"])
    check("sdxl_std: 832x1216", graph["4"]["inputs"]["width"] == 832 and graph["4"]["inputs"]["height"] == 1216, graph["4"]["inputs"])
    check("sdxl_std: denoise 1 w jednym samplerze", graph["5"]["inputs"]["denoise"] == 1, graph["5"]["inputs"])
    hq = bridge.preset_table(cfg)["sdxl_hq"]
    gh = bridge.build_graph(cfg, "p", "n", "", 7, {}, hq)
    check("sdxl_hq: hires denoise 0.3", gh["21"]["inputs"]["denoise"] == 0.3, gh["21"]["inputs"])
    check("sdxl_hq: latent upscale nearest-exact", gh["20"]["inputs"]["upscale_method"] == "nearest-exact", gh["20"]["inputs"])
    check("sdxl_hq: kroki z pliku workflow nietkniete (28 + 14)",
          gh["5"]["inputs"]["steps"] == 28 and gh["21"]["inputs"]["steps"] == 14,
          (gh["5"]["inputs"]["steps"], gh["21"]["inputs"]["steps"]))

    print("\n=== WYNIK ===")
    if failures:
        print("BLEDY (" + str(len(failures)) + "): " + ", ".join(failures))
        return 1
    print("Wszystkie testy przeszly.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
