@echo off
rem  Dwuklik = restart mostka Hermesa: zamyka stary proces i startuje nowy, z aktualnego kodu.
rem  To skrot - robi dokladnie to samo, co:  Start_Comfy_i_Hermes.bat --restart
rem  (przydatne, bo w cmd nie da sie wpisac samego '--restart' - to argument, nie komenda).
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0Start_Comfy_i_Hermes.bat" (
    echo [BLAD] Nie widze Start_Comfy_i_Hermes.bat obok tego pliku.
    echo        Folder: %~dp0
    echo        Poloz oba pliki w tym samym folderze i uruchom ponownie.
    pause
    exit /b 1
)
call "%~dp0Start_Comfy_i_Hermes.bat" --restart
exit /b 0
