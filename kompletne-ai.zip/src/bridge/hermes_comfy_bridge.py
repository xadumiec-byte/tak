#!/usr/bin/env python3
"""Mostek "Hermes + ComfyUI" dla Chloe (Perchance ai-character-chat).

Zastepuje stary mostek Stheno -> ComfyUI. Nie uruchamia zadnego lokalnego modelu
tekstowego: role LLM przejmuje Hermes 3 70B przez OpenRouter (klucz trzyma TEN
proces, nie przegladarka). ComfyUI obsluguje przez natywne API grafowe.

Endpoints (wszystkie z CORS dla *.perchance.org):

  GET  /health
        {"ok":true,"busy":<bool>,"comfy":{...},"refine":{...}}
        - pole "busy" czyta aplikacja i czeka w kolejce, gdy GPU jest zajete.

  POST /api/generate                (provider "localflow" w panelu Obrazy)
        {"prompt":"...", "negative":"...", "direct":false,
         "preset":"fast",            (opcjonalnie — patrz "Tryby obrazu" nizej)
         "size":"768x1152", "steps":20, "cfg":6, "sampler":"dpmpp_2m",
         "scheduler":"karras", "denoise":1, "seed":123,
         "checkpoint":"innyModel.safetensors"}
        -> {"ok":true,"image_url":"/images/<plik>.png","prompt":"<uzyty prompt>",
            "negative":"<uzyta negatywa>","direct":false,"seed":123,
            "tryb":"fast","workflow":"workflow_sd15_fast.json",
            "ms":4210,"ms_comfy":3900,"ms_refine":310}
        - prompt jest najpierw przepisany przez Hermesa na tagi SD (chyba ze direct),
          potem wstrzykniety w workflow ComfyUI i uruchomiony.
        - pole "preset" wybiera tryb obrazu (plik workflow + parametry + rozmiar);
          brak pola = tryb z konfiguracji (klucz "preset", domyslnie "default").
        - HTTP 503 = GPU zajete (aplikacja sama ponawia).

  POST /images/generations          (provider "custom"/OpenAI w panelu Obrazy)
        {"prompt":"...","size":"768x768","n":1,"response_format":"b64_json"}
        -> {"created":..., "data":[{"b64_json":"...","url":"/images/<plik>.png"}]}

  POST /v1/chat/completions         (Base URL w panelu Model; stream i non-stream)
        -> przekazywane 1:1 do OpenRouter; gdy brak "model", podstawiany jest Hermes.
  GET  /v1/models                   (lista modeli dla przycisku "test")
  GET  /v1/api/extra/true_max_context_length  -> {"value": 131072}

  GET  /last                        podglad ostatniego zadania (prompt/negatywa/czas)
  GET  /images/<plik>               serwowanie wygenerowanych obrazow
  GET  /                            strona statusu (podglad w przegladarce/na telefonie)

Uruchomienie (na komputerze z ComfyUI):

  python hermes_comfy_bridge.py --openrouter-key sk-or-... --port 8443

Albo: wpisz klucz do pliku openrouter_key.txt obok skryptu (wygodne na Windows)
i uruchom bez argumentow. Pelna lista opcji: --help.

Telefon / dostep z zewnatrz (HTTPS wymagane przez panel Obrazy):

  tailscale serve --bg --https=8443 http://127.0.0.1:8443

i w panelu wpisz bazowy adres HTTPS z :8443. Adres bazowy bez koncowki /v1 —
mostek sam obsluguje i /v1, i sciezki bez prefiksu.

Tryby obrazu (presety) — pole "preset" w zadaniu obrazu albo klucz "preset" w
bridge_config.json. Kazdy preset to plik workflow + parametry + rozmiar:

  default    workflow_api.json          SD1.5 realistic NSFW, natywne 768x1152, 20 krokow (~18 s)
  fast       workflow_sd15_fast.json    512x768 + upscale ESRGAN 2x -> 1024x1536 (~3-4 s)
  classic    workflow_sd15_classic.json stary uklad 25+20 krokow z upscalem 4x (~64 s)
  sdxl_fast  workflow_sdxl_fast.json    SDXL + LoRA Lightning, 8 krokow (wymaga checkpointu SDXL)
  sdxl_cfg8  workflow_sdxl_cfg8.json    SDXL + Hyper-SD, 8 krokow z CFG 5.5
  sdxl_std   workflow_sdxl_std.json     SDXL bez destylacji, 24 kroki CFG 6 (~43 s, najlepszy kompromis)
  sdxl_hq    workflow_sdxl_hq.json      SDXL 28 krokow karras + hires 1.5x (~2 min, bywa niestabilny)

Preset moze ustawic: workflow_file, size, steps, cfg, sampler, scheduler, denoise,
checkpoint, prompt_prefix, prompt_suffix, refine_hint, desc. Wlasne presety dodaje sie
w bridge_config.json w sekcji "presets" (przyklad w komentarzu przy PRESET_DEFAULTS).

Workflow ComfyUI: plik workflow_api.json obok skryptu (Workflow -> Export (API)).
Mostek podmienia tylko: tekst promptu (wezel --pos-node, domyslnie "2"),
negatywe (--neg-node, domyslnie "3"), rozmiar (wezel EmptyLatentImage) i seed
(takze w nodach detalowania, np. FaceDetailer - kazdy obraz dostaje inny szum).
Reszta workflow zostaje Twoja.
"""

from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

try:
    sys.stdout.reconfigure(encoding="utf-8")  # Windows: polskie znaki w konsoli
except Exception:
    pass


ROOT = Path(__file__).resolve().parent
DEFAULT_OPENROUTER = "https://openrouter.ai/api/v1"
DEFAULT_MODEL = "nousresearch/hermes-3-llama-3.1-70b"
# Lancuch modeli awaryjnych OpenRoutera. Mostek wysyla go w polu `models`, wiec gdy model
# glowny zawiedzie (provider blokuje prompt, moderacja, rate limit, downtime, za male okno
# kontekstu) OpenRouter sam probuje kolejnych - i liczy tylko ten, ktory odpowiedzial.
# Wszystkie ID zweryfikowane w /api/v1/models (2026-09-21), zaden nie jest moderowany.
# Kolejnosc: najblizej persony Hermesa (nieocenzurowany finetune RP), potem najlepszy NSFW
# wg ludzi, na koncu najtanszy model z 0% odmow (i 1,3M kontekstu).
DEFAULT_FALLBACKS = [
    "thedrummer/cydonia-24b-v4.1",
    "mistralai/mistral-small-2603",
    "deepseek/deepseek-v4-flash-0731",
]
# Naglowek, ktorym aplikacja Chloe podaje identyfikator watku (sticky routing + cache).
SESSION_HEADER = "X-Session-Id"
# Domyslne parametry probkowania dla modeli RP (Hermes 3 / Cydonia / Mistral / DeepSeek).
# Mostek doklada je TYLKO wtedy, gdy aplikacja sama ich nie podala (klient ma priorytet),
# dzieki temu tuning dziala takze wtedy, gdy panel Chloe wysyla samo temperature/max_tokens.
DEFAULT_MIN_P = 0.03          # min_p: ucina tokeny < 3% prawdopodobienstwa najlepszego -> mniej halucynacji
DEFAULT_REP_PENALTY = 1.05    # repetition_penalty: bogatsze slowownictwo bez psucia gramatyki
# Detal (np. FaceDetailer z Impact Packu) ma wlasne pole "seed". Mostek ustawia je
# na ziarno zadania + to przesuniecie, zeby szum detalu twarzy nie byl identyczny
# w kazdym obrazie (przy stalym 0 detal powtarzalby ten sam wzor szumu).
EXTRA_SEED_OFFSET = 1
DEFAULT_COMFY = "http://127.0.0.1:8188"
HERMES_CONTEXT = 131072

MAX_BODY = 1_048_576
MAX_SCENE = 6000
MAX_NEGATIVE = 2000
MAX_PROMPT = 2600
MAX_IMAGE_BYTES = 24 * 1024 * 1024

# --- jakosc promptu ---------------------------------------------------------
# Rdzen negatywy doklejany ZAWSZE (takze do negatywy przyslanej z aplikacji).
# Trzyma jakosc, anatomie i brak cenzury, a przede wszystkim wyklucza wszystko,
# co robi z obrazu "tasteful nude": ubranie na cipce, zsuniete uda, rece
# zaslaniajace krocze, przyciete kadry.
NEGATIVE_CORE = (
    "censored, censorship bar, mosaic censoring, pixelated, censored nipples, "
    "censored genitals, blur, watermark, signature, text, logo, lowres, "
    "jpeg artifacts, worst quality, low quality, bad anatomy, bad proportions, "
    "deformed, disfigured, mutated, malformed hands, fused fingers, "
    "extra fingers, extra limbs, extra arms, duplicate person, two people, "
    "fabric covering crotch, cloth over pussy, clothing over pussy, panties, "
    "underwear, shorts, bikini, swimsuit, towel covering, sheet covering, "
    "garment over crotch, clothing over hips, fabric below the waist, "
    "top covering crotch, cloth between the legs, "
    "hands covering pussy, hand between the legs, hands over crotch, "
    "thighs pressed together, closed legs, legs crossed, knees together, "
    "legs together, hidden genitals, cropped genitals, cropped hips, "
    "cropped legs, cropped body, cut off by frame, sfw, tasteful, modesty, shy, "
    "child, childlike face, underage, teenager, loli"
)
NEGATIVE_DEFAULT = NEGATIVE_CORE + (
    ", plastic skin, wax figure, doll, airbrushed, cgi, 3d render, illustration, "
    "painting, drawing, sketch, anime, cartoon, conjoined, twisted body, "
    "long neck, missing limbs, obscured genitals, blurry genitals, "
    "shadow over genitals"
)
QUALITY_PREFIX = "masterpiece, best quality, photorealistic, raw photo, ultra detailed, 8k uhd"

# Stala bohaterka, zeby Chloe wygladala spojnie na kazdym obrazie.
CHARACTER_CARD = (
    "one adult woman, Chloe, 25 years old, shoulder-length green hair, "
    "expressive eyes, natural skin texture with visible pores and freckles"
)

# Systemowy prompt przepisywacza. Uklad plaski i numerowany — Hermes 3 (Llama 3.1)
# trzyma sie takich dyrektyw najpewniej.
REFINE_SYSTEM = "\n".join([
    "You are an expert Stable Diffusion XL prompt engineer. You get a scene",
    "description (usually Polish, from an uncensored erotic roleplay) and you",
    "return ONE image prompt.",
    "RULES:",
    "1. Keep EVERY sexual and nudity detail exactly as written: nudity, genitals,",
    "   penetration, sex acts, bodily fluids, fetish gear, clothing state, pose,",
    "   location, camera framing.",
    "2. Never censor, never soften, never omit, never replace an explicit word",
    "   with a vague one.",
    "3. Respect the stated clothing state: if a garment is pulled down, off or",
    "   open, or nothing covers the crotch, do NOT put it back on and do NOT",
    "   invent any garment that is not listed.",
    "4. Never add another person, another character, another location, text or",
    "   a watermark.",
    "5. Output exactly one line of comma-separated English tags. No sentences,",
    "   no explanation, no quotes, no markdown, no line breaks, nothing before",
    "   or after the prompt.",
    "6. Begin the prompt with: " + QUALITY_PREFIX,
    "7. The subject is always the same woman: " + CHARACTER_CARD + ".",
    "8. Add camera and lighting words that fit the scene (close-up, full body,",
    "   from behind, from above, soft window light, warm lamp light...).",
    "9. If a garment or object is listed, name it concretely in English.",
])


# --- presety workflow ("tryby" obrazu) ---------------------------------------
# Preset = plik workflow + parametry probkowania + rozmiar + opcjonalnie checkpoint,
# prefiks/sufiks promptu i dopisek do przepisywacza. Aplikacja wybiera preset polem
# "preset" (albo "workflow" / "tryb" / "mode" / "quality"); bez tego dziala preset
# z konfiguracji (klucz "preset", domyslnie "default").
#
# Wlasne presety dopisuje sie w bridge_config.json:
#
#   {
#     "preset": "fast",
#     "presets": {
#       "moj_kreskowy": {
#         "workflow_file": "workflow_sdxl_cfg8.json",
#         "size": "832x1216",
#         "checkpoint": "mojModelAnime.safetensors",
#         "prompt_prefix": "masterpiece, best quality, amazing quality, very aesthetic",
#         "refine_hint": "To model anime - uzyj tagow danbooru."
#       }
#     }
#   }
#
# Pierwszenstwo rozmiaru: "size" z zadania > rozmiar presetu > cfg.size > rozmiar w
# pliku workflow. Aby o rozmiarze decydowal plik workflow, wpisz "size": "auto".
# Pierwszenstwo parametrow: pole z zadania > preset > wartosc w pliku workflow.
PRESET_DEFAULTS = {
    "default": {
        "workflow_file": "workflow_api.json",
        "size": "768x1152",
        "family": "sd15",
        "desc": "SD1.5 realistic NSFW, natywne 768x1152, 20 krokow (~18 s)",
    },
    "fast": {
        "workflow_file": "workflow_sd15_fast.json",
        "size": "512x768",
        "steps": 20,
        "cfg": 6.0,
        "sampler": "dpmpp_2m",
        "scheduler": "karras",
        "family": "sd15",
        "desc": "SD1.5 512x768 + upscale ESRGAN 2x -> 1024x1536 (~3-4 s)",
    },
    "classic": {
        "workflow_file": "workflow_sd15_classic.json",
        "size": "512x768",
        "family": "sd15",
        "desc": "stary uklad 25+20 krokow z upscalem 4x (~64 s) — tylko do porownan",
    },
    "sdxl_fast": {
        "workflow_file": "workflow_sdxl_fast.json",
        "size": "832x1216",
        "steps": 8,
        "cfg": 1.5,
        "sampler": "euler",
        "scheduler": "sgm_uniform",
        "family": "sdxl",
        "desc": "SDXL + LoRA Lightning, 8 krokow (najszybciej; wymaga checkpointu SDXL)",
    },
    "sdxl_cfg8": {
        "workflow_file": "workflow_sdxl_cfg8.json",
        "size": "832x1216",
        "steps": 8,
        "cfg": 5.5,
        "sampler": "euler",
        "scheduler": "sgm_uniform",
        "family": "sdxl",
        "desc": "SDXL + Hyper-SD 8 krokow z CFG 5.5 (lepsze trzymanie promptu niz Lightning)",
    },
    "sdxl_std": {
        "workflow_file": "workflow_sdxl_std.json",
        "size": "832x1216",
        "steps": 24,
        "cfg": 6.0,
        "sampler": "dpmpp_2m",
        "scheduler": "karras",
        "family": "sdxl",
        "desc": "SDXL bez destylacji: 24 kroki, CFG 6, dpmpp_2m+karras (~43 s) - najlepszy stosunek jakosci do czasu",
    },
    "sdxl_hq": {
        "workflow_file": "workflow_sdxl_hq.json",
        "size": "832x1216",
        "family": "sdxl",
        "desc": "SDXL 28 krokow + hires 1.5x (~2 min) — najwieksza rozdzielczosc, ale wolny i potrafi zepsuc anatomie na czesci seedow",
    },
}

# Pola presetu, ktore moga nadpisac plik workflow (i ktore moze nadpisac zadanie).
PRESET_NUMERIC = ("steps", "cfg", "denoise")
PRESET_TEXT = ("sampler", "scheduler", "checkpoint")

# Pola modeli w grafie, ktore sprawdzamy przed kolejkowaniem (czytelny blad zamiast
# "value not in list" z ComfyUI, gdy brakuje pliku modelu).
COMFY_MODEL_FIELDS = (
    ("CheckpointLoaderSimple", "checkpoints", "ckpt_name"),
    ("CheckpointLoader", "checkpoints", "ckpt_name"),
    ("LoraLoader", "loras", "lora_name"),
    ("LoraLoaderModelOnly", "loras", "lora_name"),
    ("VAELoader", "vae", "vae_name"),
    ("UpscaleModelLoader", "upscale_models", "model_name"),
    ("UNETLoader", "diffusion_models", "unet_name"),
)


def log(msg: str) -> None:
    print("[" + time.strftime("%H:%M:%S") + "] " + str(msg), flush=True)


# --- maly klient HTTP (stdlib, zero zaleznosci) ------------------------------

def http_request(url, data=None, headers=None, method=None, timeout=30):
    """-> (status, body_bytes, headers_dict). status 0 = blad sieci."""
    hdrs = dict(headers or {})
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method or ("POST" if data is not None else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
        except Exception:
            body = b""
        return exc.code, body, dict(exc.headers or {})
    except Exception as exc:
        return 0, str(exc).encode("utf-8", "replace"), {}


def http_json(url, payload=None, headers=None, method=None, timeout=30):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    hdrs = {"Content-Type": "application/json"}
    if headers:
        hdrs.update(headers)
    status, body, _ = http_request(url, data, hdrs, method, timeout)
    obj = None
    try:
        obj = json.loads(body.decode("utf-8", "replace"))
    except Exception:
        obj = None
    text = body.decode("utf-8", "replace") if body else ""
    return status, obj, text


# --- konfiguracja ------------------------------------------------------------

class Config(object):
    def __init__(self, args=None):
        self.host = "127.0.0.1"
        self.port = 8443
        self.openrouter = DEFAULT_OPENROUTER
        self.api_key = ""
        self.model = DEFAULT_MODEL
        self.fallback_models = list(DEFAULT_FALLBACKS)
        self.session_cache = True
        self.data_collection = "deny"
        self.min_p = DEFAULT_MIN_P
        self.rep_penalty = DEFAULT_REP_PENALTY
        self.refine_model = ""
        self.refine = True
        self.refine_temp = 0.7
        self.refine_tokens = 480
        self.refine_timeout = 90
        self.comfy = DEFAULT_COMFY
        self.workflow_file = str(ROOT / "workflow_api.json")
        # Tryb obrazu: nazwa presetu uzywanego, gdy zadanie nie poda wlasnego.
        self.preset = "default"
        self.presets = {}
        self.pos_node = "2"
        self.neg_node = "3"
        self.latent_node = ""
        self.prefix = "chloe"
        self.out_dir = str(ROOT / "images")
        self.size = "768x768"
        self.seed_mode = "same"
        self.direct_default = False
        self.timeout = 15 * 60
        self.poll = 1.2
        # Ile kolejnych odpywan bez sladu zadania w ComfyUI uznajemy za restart ComfyUI.
        self.restart_misses = 5
        self.token = ""
        self.return_url = True
        self.allow_origin = r"^https?://([a-z0-9-]+\.)*perchance\.org$|^https?://(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$"
        self.selftest = False
        self.selftest_scene = ""
        self.selftest_gen = False
        if args is not None:
            self._load_file(getattr(args, "config", "") or "")
            self._from_args(args)
        self._origin_re = re.compile(self.allow_origin, re.IGNORECASE)

    def _load_file(self, path):
        if not path:
            candidate = ROOT / "bridge_config.json"
            if not candidate.exists():
                return
            path = str(candidate)
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as exc:
            log("Nie udalo sie wczytac configu " + str(path) + ": " + str(exc))
            return
        if not isinstance(data, dict):
            return
        for key, value in data.items():
            key = str(key).replace("-", "_")
            if hasattr(self, key) and value is not None:
                setattr(self, key, value)
        self.fallback_models = norm_model_list(self.fallback_models)
        log("Wczytano config: " + str(path))

    def _from_args(self, args):
        for key in ("host", "port", "openrouter", "model", "refine_model", "comfy", "workflow_file",
                    "pos_node", "neg_node", "latent_node", "prefix", "out_dir", "size", "seed_mode",
                    "timeout", "poll", "restart_misses", "token", "allow_origin", "selftest_scene",
                    "preset"):
            value = getattr(args, key, None)
            if value not in (None, ""):
                setattr(self, key, value)
        key = getattr(args, "openrouter_key", "") or getattr(args, "api_key", "")
        if not key:
            key = os.environ.get("OPENROUTER_API_KEY", "") or os.environ.get("HERMES_API_KEY", "")
        if not key:
            key_file = ROOT / "openrouter_key.txt"
            if key_file.exists():
                try:
                    key = key_file.read_text(encoding="utf-8").strip()
                except Exception:
                    key = ""
        self.api_key = key or self.api_key
        fb = getattr(args, "fallback_models", None)
        if fb not in (None, ""):
            self.fallback_models = norm_model_list(fb)
        if getattr(args, "no_fallbacks", False):
            self.fallback_models = []
        if getattr(args, "no_session_cache", False):
            self.session_cache = False
        mp = getattr(args, "min_p", None)
        if mp is not None:
            self.min_p = float(mp)
        rp = getattr(args, "rep_penalty", None)
        if rp is not None:
            self.rep_penalty = float(rp)
        dc = getattr(args, "data_collection", None)
        if dc not in (None, ""):
            dc = str(dc).strip().lower()
            self.data_collection = "" if dc in ("off", "none", "brak") else dc
        if getattr(args, "no_refine", False):
            self.refine = False
        if getattr(args, "direct_default", False):
            self.direct_default = True
        if getattr(args, "selftest", False):
            self.selftest = True
        if getattr(args, "selftest_gen", False):
            self.selftest = True
            self.selftest_gen = True

    def allows_origin(self, origin):
        if not origin:
            return True
        try:
            return bool(self._origin_re.match(origin))
        except Exception:
            return True

    def display(self):
        return {
            "listen": self.host + ":" + str(self.port),
            "openrouter": self.openrouter,
            "model": self.effective_model,
            "api_key": ("ustawiony (" + str(len(self.api_key)) + " znakow)") if self.api_key else "BRAK",
            "refine": self.refine,
            "comfy": self.comfy,
            "workflow": self.workflow_file,
            "tryb obrazu": str(self.preset or "default") + " (presety: " + ", ".join(sorted(preset_table(self))) + ")",
            "nodes": {"positive": self.pos_node, "negative": self.neg_node, "latent": self.latent_node or "auto (EmptyLatentImage)"},
            "size": self.size,
            "out_dir": self.out_dir,
            "fallbacks": list(self.fallback_models),
            "session_cache": self.session_cache,
            "data_collection": self.data_collection or "(nie narzucam)",
            "sampling": {"min_p": self.min_p, "repetition_penalty": self.rep_penalty},
            "token": "wlaczony" if self.token else "brak (tylko tailnet!)",
        }

    @property
    def effective_model(self):
        return self.refine_model or self.model

    @property
    def out_path(self):
        path = Path(self.out_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path


def preset_table(cfg):
    """Wszystkie dostepne presety: wbudowane + te z bridge_config.json (klucz "presets")."""
    table = {}
    for name, item in PRESET_DEFAULTS.items():
        table[name] = dict(item)
    for name, item in (getattr(cfg, "presets", {}) or {}).items():
        if not isinstance(item, dict):
            continue
        merged = dict(table.get(str(name)) or {})
        merged.update(item)
        table[str(name)] = merged
    return table


def resolve_preset(cfg, wanted=""):
    """Zwraca (nazwa, definicja). Nieznana nazwa = czytelny blad z lista dostepnych."""
    table = preset_table(cfg)
    name = str(wanted or "").strip() or str(getattr(cfg, "preset", "") or "").strip() or "default"
    if name in table:
        return name, table[name]
    raise RuntimeError("nieznany tryb obrazu: '" + name + "' (dostepne: " + ", ".join(sorted(table)) + ")")


def preset_path(cfg, preset):
    """Sciezka pliku workflow dla presetu (nazwa wzgledna = obok glownego workflow)."""
    raw = str(preset.get("workflow_file") or "").strip()
    base = Path(cfg.workflow_file)
    if not raw:
        return base
    path = Path(raw)
    if path.is_absolute():
        return path
    folder = base if base.is_dir() else base.parent
    if path.name == base.name and path.parent == Path("."):
        return base
    return folder / raw


def preset_public(cfg, preset):
    """Skrocony opis presetu dla /health i strony statusu."""
    out = {
        "plik": Path(str(preset.get("workflow_file") or "")).name or Path(cfg.workflow_file).name,
        "rozmiar": preset.get("size") or "auto (jak w pliku)",
        "opis": str(preset.get("desc") or ""),
        "plik_istnieje": preset_path(cfg, preset).exists(),
    }
    if preset.get("family"):
        out["rodzina"] = preset["family"]
    for key in ("steps", "cfg", "sampler", "scheduler", "denoise", "checkpoint"):
        if preset.get(key) not in (None, ""):
            out[key] = preset[key]
    return out


def preset_from_body(body):
    """Nazwa trybu z zadania (rozne aliasy, bo aplikacja moze nazywac to roznie)."""
    for key in ("preset", "workflow", "tryb", "mode", "quality", "image_preset"):
        value = (body or {}).get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def comfy_model_list(cfg, folder):
    """Lista plikow danego typu w ComfyUI (None = nie udalo sie pobrac)."""
    status, obj, _ = http_json(cfg.comfy.rstrip("/") + "/models/" + folder, None, None, "GET", 8)
    if status != 200 or not isinstance(obj, list):
        return None
    return [str(x) for x in obj]


def preflight_graph(cfg, graph):
    """Sprawdza, czy pliki modeli z grafu sa widoczne w ComfyUI. Zwraca liste brakow."""
    cache = {}
    missing = []
    for node_id, node in (graph or {}).items():
        if not isinstance(node, dict):
            continue
        class_type = str(node.get("class_type") or "")
        for want_type, folder, field in COMFY_MODEL_FIELDS:
            if class_type != want_type:
                continue
            name = str((node.get("inputs") or {}).get(field) or "").strip()
            if not name:
                continue
            if folder not in cache:
                cache[folder] = comfy_model_list(cfg, folder)
            names = cache[folder]
            if names is None or name in names:
                continue
            stem = name.replace("\\", "/").rsplit("/", 1)[-1].lower().split(".")[0][:18]
            similar = [n for n in names if stem and stem in n.lower()][:3]
            missing.append({"wezel": str(node_id), "pole": field, "plik": name,
                            "folder": folder, "podobne": similar})
    return missing


def describe_missing_models(missing):
    parts = []
    for item in missing:
        text = ("brak modelu " + item["folder"] + "/" + item["plik"] + " (wezel " + item["wezel"] + ")")
        if item["podobne"]:
            text += " — w folderze jest podobny: " + ", ".join(item["podobne"])
        parts.append(text)
    parts.append("modele NSFW pobierzesz plikiem Pobierz_modele_NSFW.bat (menu 1-6 checkpointy, "
                 "7-8 LoRA), potem zrestartuj ComfyUI; inny model wybierzesz polem "
                 "\"checkpoint\" w zadaniu albo w bridge_config.json")
    return (" | ".join(parts))[:900]


# --- automatyczny wybor checkpointu, gdy ten z workflow nie jest pobrany -------
# Sens: pobranie modelu z Pobierz_modele_NSFW.bat ma dzialac od razu. Gdy graf
# wskazuje plik, ktorego nie ma na dysku, a w folderze lezy inny model tej samej
# rodziny (SDXL / SD1.5), mostek bierze go i loguje podmiane. Bez tego kazdy nowy
# checkpoint wymagal recznej edycji bridge_config.json.
CHECKPOINT_PREFERENCE = {
    "sdxl": ("lustifysdxlnsfw", "cyberrealisticxl", "wainsfw", "illustrious", "ponydiffusion", "sdxl"),
    "sd15": ("epicrealism", "naturalsin", "hassakuhentai", "hassaku", "realistic", "deliberate"),
}
CHECKPOINT_REJECT = {
    "sd15": ("xl", "illustrious", "pony", "wai", "sdxl"),
    "sdxl": ("sd15", "sd1", "epicrealism", "naturalsin", "v1-5", "v1.5"),
}


def preset_family(preset, name=""):
    """Rodzina modelu presetu: \"sdxl\" albo \"sd15\" (klucz do doboru checkpointu)."""
    fam = str((preset or {}).get("family") or "").strip().lower()
    if fam in ("sdxl", "sd15"):
        return fam
    label = (str(name or "") + " " + str((preset or {}).get("workflow_file") or "")).lower()
    return "sdxl" if "sdxl" in label else "sd15"


def _plain_name(name):
    return str(name or "").replace("\\", "/").rsplit("/", 1)[-1]


def pick_checkpoint(cfg, family, wanted=""):
    """(nazwa, info) - checkpoint, ktorego mozna uzyc. Pusty, gdy brak kandydata.

    Gdy 'wanted' jest widoczny w ComfyUI, zwraca go bez zmian (info = None)."""
    names = comfy_model_list(cfg, "checkpoints")
    if not names:
        return "", None
    if wanted and wanted in names:
        return wanted, None
    family = "sdxl" if str(family).lower().startswith("sdxl") else "sd15"
    reject = CHECKPOINT_REJECT.get(family, ())
    prefer = CHECKPOINT_PREFERENCE.get(family, ())

    def rank(name):
        low = _plain_name(name).lower()
        for index, key in enumerate(prefer):
            if key in low:
                return index
        return len(prefer)

    candidates = [n for n in names if not any(bad in _plain_name(n).lower() for bad in reject)]
    if not candidates:
        return "", None
    candidates.sort(key=lambda n: (rank(n), _plain_name(n).lower()))
    chosen = candidates[0]
    return chosen, {"bylo": wanted or "(z workflow)", "jest": chosen, "rodzina": family,
                    "dostepne": [_plain_name(n) for n in names][:12]}


def autofix_checkpoints(cfg, graph, missing, family):
    """Podmienia brakujace checkpointy na to, co jest na dysku. Zwraca liste podmian."""
    notes = []
    for item in missing or []:
        if str(item.get("folder")) != "checkpoints":
            continue
        want = str(item.get("plik") or "")
        chosen, info = pick_checkpoint(cfg, family, want)
        if not chosen or not info:
            continue
        for node in (graph or {}).values():
            if not isinstance(node, dict):
                continue
            if str(node.get("class_type")) not in ("CheckpointLoaderSimple", "CheckpointLoader"):
                continue
            inputs = node.get("inputs")
            if isinstance(inputs, dict) and str(inputs.get("ckpt_name") or "") == want:
                inputs["ckpt_name"] = chosen
        notes.append(info)
    return notes


CFG = None  # type: Config


def or_headers(cfg):
    headers = {"Content-Type": "application/json", "HTTP-Referer": "https://perchance.org/", "X-Title": "Chloe Hermes bridge"}
    if cfg.api_key:
        headers["Authorization"] = "Bearer " + cfg.api_key
    return headers


# Klucz OpenRoutera moze przyjsc z aplikacji Chloe (naglowek Authorization w zadaniu do mostka).
# Mostek uzywa najpierw swojego (openrouter_key.txt / --openrouter-key), a gdy go nie ma,
# bierze klucz klienta - bez tego kazdy czat konczy sie bledem 401 z OpenRoutera
# ("No cookie auth credentials found"), mimo ze klucz jest wpisany w panelu aplikacji.
CLIENT_AUTH = {"header": "", "used": False}


def bearer_of(value):
    """'Bearer sk-or-...' -> 'sk-or-...'; '' gdy to nie wyglada na klucz."""
    text = str(value or "").strip()
    if not text:
        return ""
    if text.lower().startswith("bearer "):
        text = text[7:].strip()
    return text if len(text) >= 12 else ""


def upstream_headers(cfg, extra=None):
    """Naglowki do OpenRoutera: wlasny klucz mostka, a gdy go nie ma - klucz klienta."""
    headers = or_headers(cfg)
    if "Authorization" not in headers:
        token = bearer_of(CLIENT_AUTH.get("header") if extra is None else extra)
        if token:
            headers["Authorization"] = "Bearer " + token
            CLIENT_AUTH["used"] = True
    return headers


def key_source(cfg):
    if cfg.api_key:
        return "wlasny (openrouter_key.txt / --openrouter-key)"
    if CLIENT_AUTH["used"]:
        return "klienta (Authorization z aplikacji Chloe)"
    return "BRAK - czat zwroci 401"


def norm_model_list(value):
    """['a','b'] albo 'a, b' -> ['a','b'] (bez pustych i duplikatow)."""
    if value is None:
        return []
    if isinstance(value, str):
        value = value.split(",")
    out = []
    for item in value:
        name = str(item or "").strip()
        if name and name not in out:
            out.append(name)
    return out


def chat_session_id(cfg, body, header=""):
    """Klucz sticky routingu OpenRoutera: ten sam klucz => ten sam provider => trafienia
    w cache promptu w kolejnych turach (cache read jest kilkanascie razy tanszy od inputu).

    Kolejnosc: naglowek X-Session-Id od klienta > pole session_id w ciele > odcisk
    rozmowy (system + pierwsza wiadomosc usera + model). Odcisk jest zapasem dla klientow,
    ktorzy nie podaja wlasnego id - OpenRouter sam robi cos podobnego, ale nasz jest
    stabilny takze wtedy, gdy aplikacja przytnie poczatek historii (a przytnie)."""
    if not getattr(cfg, "session_cache", True):
        return ""
    value = str(header or "").strip() or str((body or {}).get("session_id") or "").strip()
    if not value:
        messages = (body or {}).get("messages") or []
        parts = []
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "system":
                parts.append(str(msg.get("content") or "")[:2000])
                break
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "user":
                parts.append(str(msg.get("content") or "")[:400])
                break
        raw = str((body or {}).get("model") or cfg.effective_model) + "\x00" + "\x00".join(parts)
        value = hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:32]
    return value[:256]


def apply_openrouter_extras(cfg, body, header=""):
    """Dokłada do zadania rozszerzenia OpenRoutera. Mostek i tak gada tylko z OpenRouterem,
    wiec aplikacja nie musi o nich wiedziec:
      models[]   - lancuch modeli awaryjnych (OpenRouter sam przelacza przy bledzie),
      provider   - data_collection: deny => tylko providerzy nie trenujacy na Twoich danych,
      session_id - sticky routing => cache promptu trafia miedzy turami tej samej rozmowy.
    Zwraca uzyty identyfikator sesji (albo "")."""
    if not isinstance(body, dict):
        return ""
    if "models" not in body:
        chain = [m for m in norm_model_list(getattr(cfg, "fallback_models", [])) if m != body.get("model")]
        if chain:
            body["models"] = chain
    if getattr(cfg, "data_collection", ""):
        provider = body.get("provider")
        if not isinstance(provider, dict):
            provider = {}
        provider.setdefault("data_collection", cfg.data_collection)
        body["provider"] = provider
    # Parametry probkowania (patrz DEFAULT_MIN_P / DEFAULT_REP_PENALTY). Klient ma priorytet:
    # jesli aplikacja sama podala min_p / repetition_penalty, nie nadpisujemy jej wartosci.
    try:
        mp = float(getattr(cfg, "min_p", 0) or 0)
    except (TypeError, ValueError):
        mp = 0.0
    if mp > 0 and "min_p" not in body:
        body["min_p"] = mp
    try:
        rp = float(getattr(cfg, "rep_penalty", 1.0) or 1.0)
    except (TypeError, ValueError):
        rp = 1.0
    if abs(rp - 1.0) > 1e-9 and "repetition_penalty" not in body:
        body["repetition_penalty"] = rp
    sid = chat_session_id(cfg, body, header)
    if sid and not body.get("session_id"):
        body["session_id"] = sid
    return sid


LAST_CHAT = {}


def note_chat(cfg, model_used, session_id, streaming, requested=""):
    """Zapis ostatniego czatu - widac w /health, czy odpowiedzial model glowny,
    czy ktos z lancucha awaryjnego."""
    used = str(model_used or "")
    req = str(requested or "")
    LAST_CHAT.clear()
    LAST_CHAT.update({
        "at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model": used or "(brak w odpowiedzi)",
        "requested": req or cfg.effective_model,
        "fallback": bool(used and req and used != req),
        "session": session_id or "-",
        "stream": bool(streaming),
    })


# --- ComfyUI -----------------------------------------------------------------

QUEUE_CACHE = {"at": 0.0, "data": None}
QUEUE_LOCK = threading.Lock()
JOB_LOCK = threading.Lock()
LAST_JOB = {}
# Co robi mostek w tej chwili (podglad na /health i /) — ulatwia diagnoze z drugiego komputera.
JOB_STATE = {}


def job_stage(stage, **extra):
    if not JOB_STATE.get("started"):
        JOB_STATE["started"] = time.time()
    JOB_STATE["stage"] = stage
    for key, value in extra.items():
        if value is not None:
            JOB_STATE[key] = value


def job_done():
    JOB_STATE.clear()


def job_view():
    if not JOB_STATE:
        return {}
    data = dict(JOB_STATE)
    started = float(data.pop("started", 0) or 0)
    if started:
        data["elapsed_s"] = round(time.time() - started, 1)
    if data.get("prompt_id"):
        data["prompt_id"] = str(data["prompt_id"])[:8]
    return data


def comfy_queue_state(cfg):
    now = time.time()
    with QUEUE_LOCK:
        if QUEUE_CACHE["data"] is not None and now - QUEUE_CACHE["at"] < 1.5:
            return QUEUE_CACHE["data"]
    status, obj, _ = http_json(cfg.comfy.rstrip("/") + "/queue", None, None, "GET", 4)
    if not obj:
        data = {"reachable": False, "running": 0, "pending": 0}
    else:
        data = {
            "reachable": True,
            "running": len(obj.get("queue_running") or []),
            "pending": len(obj.get("queue_pending") or []),
        }
    with QUEUE_LOCK:
        QUEUE_CACHE["at"] = now
        QUEUE_CACHE["data"] = data
    return data


def comfy_free(cfg):
    state = comfy_queue_state(cfg)
    if not state.get("reachable"):
        return True  # brak polaczenia zglasza dopiero generowanie (czytelniejszy blad)
    return state.get("running", 0) == 0 and state.get("pending", 0) == 0


WORKFLOW_CACHE = {}  # {sciezka: {"mtime": ..., "graph": ...}}
# Ile nodow detalowania (np. FaceDetailer) dostalo w ostatnim grafie ziarno zadania.
EXTRA_SEEDS = {"count": 0}


def load_workflow(cfg, path=None):
    path = Path(path or cfg.workflow_file)
    if not path.exists():
        raise RuntimeError("brak pliku workflow: " + str(path) + " (ComfyUI: Workflow -> Export (API))")
    key = str(path)
    mtime = path.stat().st_mtime
    cached = WORKFLOW_CACHE.get(key)
    if cached is not None and cached.get("mtime") == mtime:
        return copy.deepcopy(cached["graph"])
    try:
        graph = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError("workflow nie jest poprawnym JSON: " + str(exc))
    if not isinstance(graph, dict) or not graph:
        raise RuntimeError("workflow musi byc obiektem JSON (klucz = ID noda) — to nie jest format API")
    WORKFLOW_CACHE[key] = {"mtime": mtime, "graph": graph}
    return copy.deepcopy(graph)


def nodes_of_type(graph, class_type):
    out = []
    for node_id, node in graph.items():
        if isinstance(node, dict) and str(node.get("class_type") or "") == class_type:
            out.append(str(node_id))
    return out


def parse_size(size):
    match = re.match(r"^\s*(\d{2,4})\s*[xX*]\s*(\d{2,4})\s*$", str(size or ""))
    if not match:
        return 0, 0
    width = max(64, min(2048, int(match.group(1))))
    height = max(64, min(2048, int(match.group(2))))
    return (width // 8) * 8, (height // 8) * 8


def build_graph(cfg, scene_prompt, negative, size, seed, overrides, preset=None, workflow_path=None):
    if workflow_path is None and preset:
        workflow_path = preset_path(cfg, preset)
    graph = load_workflow(cfg, workflow_path)
    pos_node = str(cfg.pos_node or "").strip()
    if pos_node not in graph:
        raise RuntimeError("we workflow nie ma noda o ID " + pos_node + " (prompt dodatni)")
    if not isinstance(graph[pos_node].get("inputs"), dict):
        raise RuntimeError("nod " + pos_node + " nie ma obiektu inputs")
    graph[pos_node]["inputs"]["text"] = scene_prompt

    neg_node = str(cfg.neg_node or "").strip()
    if neg_node and neg_node in graph:
        if not isinstance(graph[neg_node].get("inputs"), dict):
            raise RuntimeError("nod " + neg_node + " nie ma obiektu inputs")
        graph[neg_node]["inputs"]["text"] = negative
    elif neg_node:
        raise RuntimeError("we workflow nie ma noda o ID " + neg_node + " (prompt ujemny)")

    # Podmiana checkpointu (preset albo pole "checkpoint" w zadaniu) — pozwala zmieniac
    # model bazowy bez dotykania pliku workflow (np. realistic <-> anime/hentai).
    checkpoint = str((preset or {}).get("checkpoint") or (overrides or {}).get("checkpoint") or "").strip()
    if checkpoint:
        loaders = nodes_of_type(graph, "CheckpointLoaderSimple") + nodes_of_type(graph, "CheckpointLoader")
        if not loaders:
            raise RuntimeError("tryb/zadanie podaje checkpoint, a workflow nie ma CheckpointLoaderSimple")
        for node_id in loaders:
            wejscia = graph[node_id].get("inputs")
            if isinstance(wejscia, dict) and "ckpt_name" in wejscia:
                wejscia["ckpt_name"] = checkpoint

    # Rozmiar: pole "size" z zadania > rozmiar presetu > cfg.size > rozmiar z pliku workflow.
    # Jawne "auto"/"workflow" (w zadaniu albo w presecie) = zostaw to, co jest w pliku.
    zadany = str(size or "").strip()
    z_presetu = str((preset or {}).get("size") or "").strip()
    puste = ("", "auto", "workflow", "domyslny", "default")
    if zadany and zadany.lower() not in puste:
        width, height = parse_size(zadany)
    elif z_presetu and z_presetu.lower() not in puste:
        width, height = parse_size(z_presetu)
    elif zadany or z_presetu:
        width, height = 0, 0
    else:
        width, height = parse_size(cfg.size)
    latent_node = str(cfg.latent_node or "").strip()
    if not latent_node:
        found = nodes_of_type(graph, "EmptyLatentImage") or nodes_of_type(graph, "EmptySD3LatentImage")
        latent_node = found[0] if found else ""
    if latent_node and latent_node in graph and width and height:
        graph[latent_node]["inputs"]["width"] = width
        graph[latent_node]["inputs"]["height"] = height

    samplers = nodes_of_type(graph, "KSampler") + nodes_of_type(graph, "KSamplerAdvanced")
    for index, node_id in enumerate(samplers):
        inputs = graph[node_id].get("inputs")
        if not isinstance(inputs, dict):
            continue
        if seed is not None and "seed" in inputs:
            inputs["seed"] = int(seed) + index if str(cfg.seed_mode) == "increment" else int(seed)
        for key, field in (("steps", "steps"), ("cfg", "cfg"), ("sampler", "sampler_name"),
                           ("scheduler", "scheduler"), ("denoise", "denoise")):
            value = overrides.get(key)
            if value not in (None, "") and field in inputs:
                inputs[field] = value

    # Nody losujace inne niz KSampler (np. FaceDetailer / DetailerForEach z Impact
    # Packu, RandomNoise) tez dostaja ziarno zadania - inaczej detal twarzy liczylby
    # sie zawsze z tym samym szumem, mimo ze baza jest losowa.
    dodatkowe = 0
    if seed is not None:
        for node_id in list(graph.keys()):
            node = graph.get(node_id)
            if not isinstance(node, dict):
                continue
            if str(node.get("class_type") or "") in ("KSampler", "KSamplerAdvanced"):
                continue
            wejscia = node.get("inputs")
            if not isinstance(wejscia, dict) or "seed" not in wejscia:
                continue
            if not isinstance(wejscia.get("seed"), (int, float)):
                continue
            dodatkowe += 1
            wejscia["seed"] = int(seed) + EXTRA_SEED_OFFSET * dodatkowe
    EXTRA_SEEDS["count"] = dodatkowe

    stamp = time.strftime("%Y%m%d-%H%M%S")
    prefix = str(cfg.prefix or "chloe").strip().strip("/").replace("..", "")
    save_prefix = (prefix + "/" if prefix else "") + stamp + "-" + str(seed)
    savers = (nodes_of_type(graph, "SaveImage") + nodes_of_type(graph, "PreviewImage")
              + nodes_of_type(graph, "SaveImageWebsocket"))
    if not savers:
        raise RuntimeError("we workflow nie ma noda SaveImage/PreviewImage — nie bedzie czego pobrac")
    for node_id in savers:
        inputs = graph[node_id].get("inputs")
        if isinstance(inputs, dict) and "filename_prefix" in inputs:
            inputs["filename_prefix"] = save_prefix
    return graph


def describe_graph_errors(graph, node_errors):
    """Zamienia node_errors z /prompt na czytelny komunikat (co i gdzie jest zle)."""
    parts = []
    for node_id, info in (node_errors or {}).items():
        node = (graph or {}).get(str(node_id)) or {}
        label = str(node.get("class_type") or "?")
        if info is True:  # niektore wersje ComfyUI zwracaja True zamiast listy bledow
            parts.append("wezel " + str(node_id) + " (" + label + "): nieznany blad")
            continue
        messages = []
        for err in (info or {}).get("errors") or []:
            if isinstance(err, dict):
                message = str(err.get("message") or err.get("type") or "").strip()
                detail = str(err.get("details") or "").strip()
                if detail and detail not in message:
                    message = (message + " " + detail).strip()
            else:
                message = str(err).strip()
            if message:
                messages.append(message)
        parts.append("wezel " + str(node_id) + " (" + label + "): " + ("; ".join(messages) if messages else "blad walidacji"))
    text = " | ".join(parts)
    return ("ComfyUI odrzucilo graf — " + (text[:700] if text else "blad walidacji (szczegoly w logu ComfyUI)"))[:900]


def describe_execution_error(entry, graph):
    """Czytelny powod przerwania generowania (blad noda / Cancel w ComfyUI)."""
    node_id = ""
    node_type = ""
    detail = ""
    interrupted = False
    for item in ((entry.get("status") or {}).get("messages") or []):
        try:
            name, payload = item[0], item[1]
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        if name == "execution_interrupted":
            interrupted = True
        elif name == "execution_error":
            detail = str(payload.get("exception_message") or payload.get("exception_type") or "").strip()
        else:
            continue
        node_id = node_id or str(payload.get("node_id") or "")
        node_type = node_type or str(payload.get("node_type") or "")
    if not node_type and node_id and (graph or {}).get(node_id):
        node_type = str((graph or {})[node_id].get("class_type") or "")
    where = ("wezel " + node_id + (" (" + node_type + ")" if node_type else "")) if node_id else ""
    if interrupted:
        return "ComfyUI: generowanie przerwane" + (" — " + where if where else "") + " (ktos nacisnal Cancel/Interrupt w ComfyUI)"
    text = "ComfyUI przerwal generowanie"
    if where:
        text += " — " + where
    if detail:
        text += ": " + detail[:240]
    return text + " — pelne szczegoly w logu ComfyUI"


def comfy_prompt_in_queue(cfg, prompt_id):
    """Czy zadanie jest jeszcze w kolejce ComfyUI? None = nie wiem (brak polaczenia)."""
    status, obj, _ = http_json(cfg.comfy.rstrip("/") + "/queue", None, None, "GET", 4)
    if not isinstance(obj, dict):
        return None
    ids = set()
    for item in (obj.get("queue_running") or []) + (obj.get("queue_pending") or []):
        if isinstance(item, (list, tuple)) and len(item) > 1:
            ids.add(str(item[1]))
    return prompt_id in ids


def comfy_run(cfg, graph):
    """Kolejkuje graf, czeka na wynik i zwraca bajty obrazu."""
    client_id = "chloe-bridge-" + secrets.token_hex(4)
    status, obj, text = http_json(cfg.comfy.rstrip("/") + "/prompt", {"prompt": graph, "client_id": client_id}, None, "POST", 60)
    if not obj:
        if status == 0:
            raise RuntimeError("brak polaczenia z ComfyUI pod " + str(cfg.comfy) + " — sprawdz, czy ComfyUI dziala i czy adres jest dobry")
        raise RuntimeError("ComfyUI /prompt " + str(status) + ": " + str(text)[:300])
    if obj.get("node_errors"):
        raise RuntimeError(describe_graph_errors(graph, obj.get("node_errors")))
    if not obj.get("prompt_id"):
        raise RuntimeError("ComfyUI /prompt " + str(status) + " bez prompt_id: " + str(text)[:300])
    prompt_id = str(obj["prompt_id"])
    job_stage("comfy", prompt_id=prompt_id)
    log("ComfyUI przyjal zadanie " + prompt_id[:8])
    deadline = time.time() + float(cfg.timeout)
    misses = 0
    entry = None
    while time.time() < deadline:
        time.sleep(float(cfg.poll))
        status, history, _ = http_json(cfg.comfy.rstrip("/") + "/history/" + prompt_id, None, None, "GET", 30)
        if status != 200 or not isinstance(history, dict):
            continue
        entry = history.get(prompt_id)
        if not isinstance(entry, dict):
            entry = None
            # Zadania nie ma w historii — jesli zniknelo tez z kolejki, to prawie na pewno
            # restart ComfyUI w trakcie generowania. Wtedy konczymy od razu zamiast czekac 15 min.
            in_queue = comfy_prompt_in_queue(cfg, prompt_id)
            misses = 0 if in_queue is None else (misses if in_queue else misses + 1)
            if misses >= max(2, int(getattr(cfg, "restart_misses", 5) or 5)):
                raise RuntimeError("ComfyUI zrestartowalo sie w trakcie generowania (zadanie zniknelo z kolejki i historii) — uruchom generowanie ponownie")
            continue
        misses = 0
        state = str((entry.get("status") or {}).get("status_str") or "")
        if state == "error":
            raise RuntimeError(describe_execution_error(entry, graph))
        if entry.get("outputs"):
            break
        entry = None
    if not entry:
        raise RuntimeError("ComfyUI: przekroczono czas oczekiwania (" + str(int(float(cfg.timeout))) + " s)")

    outputs = entry.get("outputs") or {}
    best = None
    for node_id in outputs:
        images = (outputs[node_id] or {}).get("images") or []
        for image in images:
            if image.get("filename"):
                best = image
                break
        if best:
            break
    if not best:
        raise RuntimeError("ComfyUI: brak obrazu w wynikach (dodaj node SaveImage)")

    query = parse_qs(urlparse("/view").query)
    query["filename"] = [best.get("filename", "")]
    query["subfolder"] = [best.get("subfolder", "")]
    query["type"] = [best.get("type", "output")]
    url = cfg.comfy.rstrip("/") + "/view?" + "&".join(
        k + "=" + urllib.parse.quote(str(v[0])) for k, v in query.items())
    status, body, _ = http_request(url, None, None, "GET", 180)
    if status != 200 or not body:
        raise RuntimeError("ComfyUI /view " + str(status) + ": nie udalo sie pobrac obrazu")
    return body, str(best.get("filename", "image.png"))


# --- przepisywacz promptu (Hermes przez OpenRouter) --------------------------

def clean_prompt(text, fallback):
    value = str(text or "").strip()
    value = re.sub(r"`{3,}[A-Za-z0-9]*", "", value)  # plotki fence w dowolnym miejscu
    value = value.replace("`", "")                   # inline code: backticki nie naleza do promptu
    value = value.replace("\r", "\n")
    value = value.replace("\u00a0", " ")
    value = re.sub(r"\n{2,}", "\n", value)
    value = re.sub(r"\n", ", ", value)
    # Wstepniaki ("Sure, here is the prompt:") zdejmujemy w petli — po usunieciu
    # jednego czesto zostaje nastepny.
    for _ in range(3):
        before = value
        value = re.sub(r"^\s*(?:sure|ok(?:ay)?|alright|this is|here(?:'s| is| it is| you go| you are| you have))[^,:]{0,80}?[,:]\s*", "", value, flags=re.IGNORECASE)
        value = re.sub(r"^\s*[^,]{0,90}?\b(?:prompt|tags|output|image)\b\s*[:\-]\s*", "", value, flags=re.IGNORECASE)
        if value == before:
            break
    value = value.strip().strip('"').strip("'").strip()
    value = re.sub(r"\s*\((?:note|uwaga|remember)[^)]{0,240}\)\s*$", "", value, flags=re.IGNORECASE).strip()
    value = re.sub(r"\s*,\s*", ", ", value)
    value = re.sub(r"(?:,\s*){2,}", ", ", value)
    value = value.strip(" ,.")
    if len(value) < 12:
        return fallback
    if len(value) > MAX_PROMPT:
        value = value[:MAX_PROMPT].rsplit(",", 1)[0].strip(" ,")
    return value


def refine_system(preset=None):
    """Systemowy prompt przepisywacza, dopasowany do trybu (prefiks tagow + dopisek)."""
    text = REFINE_SYSTEM
    prefix = str((preset or {}).get("prompt_prefix") or "").strip().strip(",")
    if prefix:
        text = text.replace("6. Begin the prompt with: " + QUALITY_PREFIX,
                            "6. Begin the prompt with: " + prefix)
    hint = str((preset or {}).get("refine_hint") or "").strip()
    if hint:
        text = text + "\nEXTRA RULES:\n" + hint
    return text


def refine_prompt(cfg, scene, preset=None):
    system_text = refine_system(preset)
    payload = {
        "model": cfg.effective_model,
        "messages": [
            {"role": "system", "content": system_text},
            {"role": "user", "content": str(scene)[:MAX_SCENE]},
        ],
        "temperature": float(cfg.refine_temp),
        "max_tokens": int(cfg.refine_tokens),
    }
    if getattr(cfg, "session_cache", True):
        payload["session_id"] = "chloe-refine-" + hashlib.sha1(system_text.encode("utf-8", "replace")).hexdigest()[:12]
    apply_openrouter_extras(cfg, payload)
    status, obj, text = http_json(cfg.openrouter.rstrip("/") + "/chat/completions", payload, upstream_headers(cfg), "POST", float(cfg.refine_timeout))
    if status != 200 or not isinstance(obj, dict):
        raise RuntimeError("OpenRouter (przepisywanie promptu) " + str(status) + ": " + str(text)[:300])
    choices = obj.get("choices") or []
    if not choices:
        raise RuntimeError("OpenRouter: brak choices w odpowiedzi przepisywacza")
    message = choices[0].get("message") or {}
    return clean_prompt(message.get("content"), fallback="")


def build_negative(app_negative):
    parts, seen = [], set()
    for chunk in (app_negative or "").split(","):
        key = chunk.strip().lower()
        if key and key not in seen:
            seen.add(key)
            parts.append(key)
    for chunk in NEGATIVE_DEFAULT.split(","):
        key = chunk.strip().lower()
        if key and key not in seen:
            seen.add(key)
            parts.append(key)
    return ", ".join(parts)[:MAX_NEGATIVE]


def remember(cfg, job):
    LAST_JOB.clear()
    LAST_JOB.update(job)
    try:
        (cfg.out_path / "last.json").write_text(json.dumps(job, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def run_image_job(cfg, scene, negative_raw, size, direct, overrides, wanted=1, preset_name="", preset=None):
    """Wspolny pipeline: [Hermes] -> ComfyUI -> zapis plikow. Zwraca liste wynikow."""
    job_stage("start")
    try:
        return _run_image_job(cfg, scene, negative_raw, size, direct, overrides, wanted, preset_name, preset)
    finally:
        job_done()


def effective_overrides(preset, overrides):
    """Parametry probkowania: wartosci z presetu, nadpisane tym, co przyszlo w zadaniu."""
    effective = {}
    for key in PRESET_NUMERIC + PRESET_TEXT:
        value = (preset or {}).get(key)
        if value not in (None, ""):
            effective[key] = value
    for key, value in (overrides or {}).items():
        if value not in (None, ""):
            effective[key] = value
    return effective


def apply_prompt_style(preset, text):
    """Prefiks/sufiks promptu pod konkretna rodzine modeli (np. tagi score_9 dla Pony)."""
    prefix = str((preset or {}).get("prompt_prefix") or QUALITY_PREFIX).strip().strip(",")
    suffix = str((preset or {}).get("prompt_suffix") or "").strip().strip(",")
    value = str(text or "").strip().strip(",")
    first = prefix.split(",")[0].strip().lower()
    if prefix and first and first not in value.lower()[:120]:
        value = prefix + ", " + value
    if suffix and suffix.lower() not in value.lower()[-200:]:
        value = value + ", " + suffix
    return value


def _run_image_job(cfg, scene, negative_raw, size, direct, overrides, wanted=1, preset_name="", preset=None):
    """Wlasciwa robota dla run_image_job (opakowana w podglad stanu na /health)."""
    scene = str(scene or "").strip()
    if not scene:
        raise RuntimeError("brak pola prompt")
    overrides = dict(overrides or {})
    if preset is None:
        preset_name, preset = resolve_preset(cfg, preset_name)
    preset_name = str(preset_name or "default")
    workflow_path = preset_path(cfg, preset)
    negative = build_negative(negative_raw)
    started = time.time()
    refined = None
    t_refine = 0.0
    if cfg.refine and not direct:
        job_stage("refine")
        t0 = time.time()
        try:
            refined = refine_prompt(cfg, scene, preset)
        except Exception as exc:
            log("UWAGA: przepisywacz zawiodl (" + str(exc)[:160] + ") — uzywam opisu sceny jak jest")
            refined = None
        t_refine = time.time() - t0
    if refined:
        used = refined
    elif direct:
        used = scene
    else:
        used = clean_prompt(scene, fallback=scene)
    used = apply_prompt_style(preset, used)
    steps_eff = effective_overrides(preset, overrides)
    results = []
    t_comfy = 0.0
    auto_note = []
    for index in range(max(1, min(4, int(wanted or 1)))):
        seed = overrides.get("seed")
        if seed in (None, ""):
            seed = secrets.randbelow(2 ** 31)
        image_seed = int(seed)
        if index:  # n>1: kazdy obraz ma inny seed
            image_seed += index * (1000 if str(cfg.seed_mode) == "increment" else 9973)
        graph = build_graph(cfg, used, negative, size, image_seed, steps_eff, preset, workflow_path)
        missing = preflight_graph(cfg, graph)
        if missing:
            auto_note = autofix_checkpoints(cfg, graph, missing, preset_family(preset, preset_name))
            for item in auto_note:
                log("UWAGA: brak checkpointu " + str(item["bylo"]) + " — uzywam "
                    + str(item["jest"]) + " (rodzina " + str(item["rodzina"]) + ")")
            if auto_note:
                missing = preflight_graph(cfg, graph)
        if missing:
            raise RuntimeError(describe_missing_models(missing))
        job_stage("comfy", tryb=preset_name)
        t0 = time.time()
        body, original_name = comfy_run(cfg, graph)
        t_comfy += time.time() - t0
        if len(body) > MAX_IMAGE_BYTES:
            body = body[:MAX_IMAGE_BYTES]
        name = time.strftime("%Y%m%d-%H%M%S") + "-" + str(image_seed) + "-" + secrets.token_hex(2) + ".png"
        path = cfg.out_path / name
        path.write_bytes(body)
        sidecar = {
            "at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "seed": image_seed,
            "size": size,
            "tryb": preset_name,
            "workflow": workflow_path.name,
            "sampling": steps_eff,
            "direct": bool(refined is None),
            "prompt": used,
            "negative": negative,
            "scene": scene[:4000],
            "comfy_file": original_name,
            "detail_seeds": EXTRA_SEEDS["count"],
            "checkpoint_auto": auto_note,
        }
        try:
            path.with_suffix(".txt").write_text(json.dumps(sidecar, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        results.append({"file": name, "url": "/images/" + name, "seed": image_seed, "bytes": len(body)})
        log("obraz gotowy: " + name + " (tryb " + preset_name + ", " + str(round(time.time() - started, 1)) + " s, seed " + str(image_seed) + ", direct=" + str(refined is None) + ")")
    ms_total = int((time.time() - started) * 1000)
    remember(cfg, {
        "at": time.time(),
        "prompt": used,
        "negative": negative,
        "direct": bool(refined is None),
        "size": size,
        "tryb": preset_name,
        "workflow": workflow_path.name,
        "sampling": steps_eff,
        "files": [r["file"] for r in results],
        "ms": ms_total,
        "ms_comfy": int(t_comfy * 1000),
        "ms_refine": int(t_refine * 1000),
        "checkpoint_auto": auto_note,
    })
    return {"prompt": used, "negative": negative, "direct": bool(refined is None), "results": results,
            "tryb": preset_name, "workflow": workflow_path.name, "sampling": steps_eff,
            "checkpoint_auto": auto_note,
            "ms": ms_total, "ms_comfy": int(t_comfy * 1000), "ms_refine": int(t_refine * 1000)}


# --- HTTP handler ------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "ChloeHermesComfyBridge/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        log("http " + str(self.address_string()) + " " + (fmt % args))

    # --- helpers
    def _cors(self):
        origin = self.headers.get("Origin")
        if not origin:
            return True
        if not CFG.allows_origin(origin):
            log("odrzucony Origin: " + str(origin))
            return False
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, " + SESSION_HEADER)
        self.send_header("Access-Control-Max-Age", "600")
        return True

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        allowed = self._cors()
        self.end_headers()
        if allowed:
            try:
                self.wfile.write(body)
            except Exception:
                pass

    def _bytes(self, status, body, content_type, cache="no-store"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        allowed = self._cors()
        self.end_headers()
        if allowed:
            try:
                self.wfile.write(body)
            except Exception:
                pass

    def _read_json(self, limit=MAX_BODY):
        # Zapamietujemy naglowek klienta: gdy mostek nie ma wlasnego klucza OpenRoutera,
        # uzyje tego z aplikacji (patrz upstream_headers).
        CLIENT_AUTH["header"] = str(self.headers.get("Authorization") or "")
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return {}
        if length > limit:
            raise ValueError("cialo zadania za duze (" + str(length) + " B)")
        raw = self.rfile.read(length)
        try:
            obj = json.loads(raw.decode("utf-8", "replace"))
        except Exception:
            return {}
        return obj if isinstance(obj, dict) else {}

    def _authed(self):
        if not CFG.token:
            return True
        header = str(self.headers.get("Authorization") or "").strip()
        return header == "Bearer " + CFG.token or header == CFG.token

    def _path(self):
        return unquote(urlparse(self.path).path)

    # --- GET
    def do_GET(self):
        path = self._path()
        try:
            if path in ("/", "/index.html"):
                return self._status_page()
            if path == "/health":
                return self._json(200, self._health())
            if path == "/last":
                if not self._authed():
                    return self._json(401, {"ok": False, "error": "unauthorized"})
                return self._json(200, {"ok": True, "last": LAST_JOB})
            if path in ("/v1/models", "/models"):
                models = []
                for name in [CFG.effective_model] + list(CFG.fallback_models or []):
                    if name and name not in models:
                        models.append(name)
                return self._json(200, {"object": "list", "data": [
                    {"id": model, "object": "model", "owned_by": "openrouter"} for model in models
                ]})
            if path in ("/v1/api/extra/true_max_context_length", "/api/extra/true_max_context_length"):
                return self._json(200, {"value": HERMES_CONTEXT})
            if path.startswith("/images/"):
                return self._serve_image(path[len("/images/"):])
            if path == "/favicon.ico":
                return self._bytes(204, b"", "image/x-icon")
            return self._json(404, {"ok": False, "error": "nie ma takiej sciezki: " + path})
        except Exception as exc:
            log("blad GET " + path + ": " + repr(exc))
            return self._json(500, {"ok": False, "error": str(exc)[:300]})

    # --- POST
    def do_POST(self):
        path = self._path()
        try:
            if not self._authed():
                return self._json(401, {"ok": False, "error": "unauthorized"})
            if path in ("/v1/chat/completions", "/chat/completions"):
                return self._chat()
            if path in ("/api/generate", "/generate"):
                return self._api_generate()
            if path in ("/images/generations", "/v1/images/generations"):
                return self._images_generations()
            if path == "/api/refine":
                body = self._read_json()
                scene = str(body.get("prompt") or "").strip()
                if not scene:
                    return self._json(400, {"ok": False, "error": "brak pola prompt"})
                _, preset = resolve_preset(CFG, preset_from_body(body))
                refined = refine_prompt(CFG, scene, preset)
                return self._json(200, {"ok": True, "prompt": apply_prompt_style(preset, refined),
                                        "negative": build_negative(body.get("negative"))})
            return self._json(404, {"ok": False, "error": "nie ma takiej sciezki: " + path})
        except ValueError as exc:
            return self._json(413, {"ok": False, "error": str(exc)})
        except Exception as exc:
            log("blad POST " + path + ": " + repr(exc))
            return self._json(500, {"ok": False, "error": str(exc)[:400]})

    def do_OPTIONS(self):
        self.send_response(204)
        allowed = self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()
        if not allowed:
            return

    # --- poszczegolne endpointy
    def _health(self):
        queue = comfy_queue_state(CFG)
        busy = bool(JOB_LOCK.locked()) or bool(queue.get("running")) or bool(queue.get("pending"))
        return {
            "ok": True,
            "service": "Hermes (OpenRouter) -> ComfyUI",
            "busy": busy,
            "version": 12,
            "features": ["negative", "negative_core", "direct", "refine", "openai_images", "chat_proxy",
                         "model_fallbacks", "sticky_sessions", "data_collection", "sampling_defaults",
                         "detail_seeds", "job_watchdog", "graph_error_details", "client_key_forward",
                         "presets", "preset_sizes", "preset_checkpoint", "prompt_style", "model_preflight",
                         "checkpoint_autopick", "timing_breakdown"],
            "model": CFG.effective_model,
            "fallbacks": list(CFG.fallback_models),
            "session_cache": bool(CFG.session_cache),
            "data_collection": CFG.data_collection or "",
            "sampling": {"min_p": CFG.min_p, "repetition_penalty": CFG.rep_penalty},
            "last_chat": dict(LAST_CHAT),
            "key_source": key_source(CFG),
            "comfy": queue,
            "busy_local": bool(JOB_LOCK.locked()),
            "job": job_view(),
            "workflow": Path(CFG.workflow_file).name,
            "tryb": str(CFG.preset or "default"),
            "tryby": {name: preset_public(CFG, item) for name, item in sorted(preset_table(CFG).items())},
            "last_image": {"tryb": LAST_JOB.get("tryb"), "ms": LAST_JOB.get("ms"),
                           "ms_comfy": LAST_JOB.get("ms_comfy"), "ms_refine": LAST_JOB.get("ms_refine"),
                           "sampling": LAST_JOB.get("sampling"),
                           "checkpoint_auto": LAST_JOB.get("checkpoint_auto") or []},
        }

    def _status_page(self):
        health = self._health()
        last = LAST_JOB or {}
        rows = "".join(
            "<tr><td>" + key + "</td><td>" + str(value) + "</td></tr>"
            for key, value in CFG.display().items()
        )
        image_html = ""
        if last.get("files"):
            image_html = ('<p><img src="/images/' + str(last["files"][-1]) + '" style="max-width:360px;border-radius:8px;border:1px solid #333"></p>')
        html = (
            "<!doctype html><meta charset='utf-8'><title>Chloe bridge</title>"
            "<style>body{background:#141419;color:#e8e8ef;font:14px/1.5 system-ui,sans-serif;margin:0;padding:22px}"
            "table{border-collapse:collapse;margin:10px 0}td{border-bottom:1px solid #2b2b36;padding:3px 12px 3px 0}"
            "code,pre{background:#1d1d25;border-radius:6px;padding:2px 6px;font-size:12.5px}"
            "pre{padding:10px;white-space:pre-wrap}a{color:#8ab4ff}</style>"
            "<h2>Mostek Hermes + ComfyUI</h2>"
            "<p>Stan: <b>" + ("GPU zajete" if health["busy"] else "wolny") + "</b> · kolejka ComfyUI: "
            + str(health["comfy"].get("running", 0)) + " / " + str(health["comfy"].get("pending", 0)) + "</p>"
            + ("<p>Teraz robi: <code>" + str(health.get("job")) + "</code></p>" if health.get("job") else "")
            + "<p>Klucz OpenRoutera: <b>" + str(health.get("key_source")) + "</b></p>"
            + "<h3>Tryby obrazu (presety)</h3>"
            + "<p>Tryb domyslny: <b>" + str(health.get("tryb")) + "</b> — aby wybrac inny, dodaj pole <code>preset</code> w zadaniu obrazu (np. <code>preset: fast</code>).</p>"
            + "<table><tr><td><b>tryb</b></td><td><b>rodzina</b></td><td><b>plik</b></td><td><b>rozmiar</b></td><td><b>parametry</b></td><td><b>opis</b></td></tr>"
            + "".join(
                "<tr><td><code>" + name + "</code></td><td>" + str(item.get("rodzina") or "?") + "</td><td>" + str(item.get("plik")) + "</td><td>" + str(item.get("rozmiar"))
                + "</td><td>" + ", ".join(str(k) + "=" + str(v) for k, v in item.items() if k in ("steps", "cfg", "sampler", "scheduler", "checkpoint"))
                + "</td><td>" + str(item.get("opis")) + "</td></tr>"
                for name, item in (health.get("tryby") or {}).items())
            + "</table>"
            + (("<p>Ostatni obraz: tryb <b>" + str((health.get("last_image") or {}).get("tryb"))
                + "</b>, lacznie " + str((health.get("last_image") or {}).get("ms"))
                + " ms (ComfyUI " + str((health.get("last_image") or {}).get("ms_comfy"))
                + " ms, przepisywacz " + str((health.get("last_image") or {}).get("ms_refine")) + " ms)"
                + ("; podmieniony checkpoint: <code>" + str((((health.get("last_image") or {}).get("checkpoint_auto") or [{}])[0]).get("jest")) + "</code>" if (health.get("last_image") or {}).get("checkpoint_auto") else "")
                + "</p>")
               if (health.get("last_image") or {}).get("tryb") else "")
            + "<table>" + rows + "</table>"
            + image_html
            + "<h3>Co wpisac w panelu Chloe</h3>"
            "<p>Model &rarr; Base URL: <code>https://&lt;twoj-host&gt;:8443</code> (mostek doda <code>/v1/chat/completions</code>)</p>"
            "<p>Obrazy &rarr; Stheno &rarr; ComfyUI (localflow) Base URL: <code>https://&lt;twoj-host&gt;:8443</code></p>"
            "<p>Obrazy &rarr; wlasny endpoint (custom): <code>https://&lt;twoj-host&gt;:8443</code> (mostek doda <code>/images/generations</code>)</p>"
            "<h3>Ostatni prompt</h3><pre>" + (str(last.get("prompt") or "(brak)")) + "</pre>"
            "<h3>Ostatnia negatywa</h3><pre>" + (str(last.get("negative") or "(brak)")) + "</pre>"
        )
        self._bytes(200, html.encode("utf-8"), "text/html; charset=utf-8")

    def _serve_image(self, name):
        clean = Path(name).name
        if not clean or clean != name or clean.startswith("."):
            return self._json(400, {"ok": False, "error": "zla nazwa pliku"})
        path = CFG.out_path / clean
        if not path.exists() or not path.is_file():
            path = CFG.out_path / (clean + ".png")
        if not path.exists() or not path.is_file():
            return self._json(404, {"ok": False, "error": "brak pliku"})
        body = path.read_bytes()
        return self._bytes(200, body, "image/png", cache="public, max-age=86400")

    def _api_generate(self):
        body = self._read_json()
        scene = str(body.get("prompt") or "").strip()
        if not scene:
            return self._json(400, {"ok": False, "error": "brak pola prompt"})
        if JOB_LOCK.locked() or not comfy_free(CFG):
            return self._json(503, {"ok": False, "error": "GPU zajete — sprobuj za chwile", "busy": True})
        try:
            preset_name, preset = resolve_preset(CFG, preset_from_body(body))
        except Exception as exc:
            return self._json(400, {"ok": False, "error": str(exc)})
        direct = bool(body.get("direct")) or bool(CFG.direct_default)
        overrides = {
            "seed": body.get("seed"),
            "steps": body.get("steps"),
            "cfg": body.get("cfg"),
            "sampler": body.get("sampler"),
            "scheduler": body.get("scheduler"),
            "denoise": body.get("denoise"),
            "checkpoint": body.get("checkpoint"),
        }
        size = str(body.get("size") or "")
        with JOB_LOCK:
            result = run_image_job(CFG, scene, body.get("negative") or body.get("negative_prompt"),
                                   size, direct, overrides, 1, preset_name, preset)
        first = result["results"][0]
        return self._json(200, {
            "ok": True,
            "image_url": first["url"],
            "prompt": result["prompt"],
            "negative": result["negative"],
            "direct": result["direct"],
            "seed": first["seed"],
            "tryb": result["tryb"],
            "workflow": result["workflow"],
            "size": size or str(preset.get("size") or "auto"),
            "sampling": result["sampling"],
            "ms": result["ms"],
            "ms_comfy": result["ms_comfy"],
            "ms_refine": result["ms_refine"],
            "checkpoint_auto": result.get("checkpoint_auto") or [],
        })

    def _images_generations(self):
        body = self._read_json()
        scene = str(body.get("prompt") or "").strip()
        if not scene:
            return self._json(400, {"ok": False, "error": "brak pola prompt"})
        if JOB_LOCK.locked() or not comfy_free(CFG):
            return self._json(503, {"ok": False, "error": "GPU zajete — sprobuj za chwile", "busy": True})
        try:
            preset_name, preset = resolve_preset(CFG, preset_from_body(body))
        except Exception as exc:
            return self._json(400, {"ok": False, "error": str(exc)})
        size = str(body.get("size") or "")
        wanted = int(body.get("n") or 1)
        direct = bool(body.get("direct")) or bool(CFG.direct_default)
        if body.get("enhance") is False:
            direct = True
        overrides = {
            "seed": body.get("seed"),
            "steps": body.get("steps"),
            "cfg": body.get("cfg"),
            "sampler": body.get("sampler"),
            "scheduler": body.get("scheduler"),
            "denoise": body.get("denoise"),
            "checkpoint": body.get("checkpoint"),
        }
        try:
            with JOB_LOCK:
                result = run_image_job(CFG, scene, body.get("negative_prompt") or body.get("negative"),
                                       size, direct, overrides, wanted, preset_name, preset)
        except Exception as exc:
            return self._json(500, {"ok": False, "error": str(exc)[:400]})
        wants_b64 = str(body.get("response_format") or "b64_json").lower() != "url"
        data = []
        for item in result["results"]:
            entry = {"url": item["url"], "seed": item["seed"]}
            if wants_b64:
                try:
                    entry["b64_json"] = base64.b64encode((CFG.out_path / item["file"]).read_bytes()).decode("ascii")
                except Exception:
                    entry["b64_json"] = ""
            data.append(entry)
        return self._json(200, {
            "created": int(time.time()),
            "model": str(body.get("model") or CFG.effective_model),
            "data": data,
            "prompt": result["prompt"],
            "negative": result["negative"],
            "direct": result["direct"],
            "tryb": result["tryb"],
            "workflow": result["workflow"],
            "sampling": result["sampling"],
            "ms": result["ms"],
            "ms_comfy": result["ms_comfy"],
            "ms_refine": result["ms_refine"],
            "checkpoint_auto": result.get("checkpoint_auto") or [],
        })

    def _chat(self):
        """Przekazanie 1:1 do OpenRouter — strumieniowo albo zwyklym JSON-em."""
        body = self._read_json(4 * MAX_BODY)
        if not body.get("model"):
            body["model"] = CFG.effective_model
        requested = str(body.get("model") or "")
        sid = apply_openrouter_extras(CFG, body, self.headers.get(SESSION_HEADER))
        streaming = bool(body.get("stream"))
        if streaming and not body.get("stream_options"):
            body["stream_options"] = {"include_usage": True}
        url = CFG.openrouter.rstrip("/") + "/chat/completions"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = upstream_headers(CFG)
        if streaming:
            headers["Accept"] = "text/event-stream"
        if not streaming:
            status, obj, text = http_json(url, body, headers, "POST", 600)
            if obj is None:
                return self._json(status or 502, {"error": {"message": text[:500] or "brak odpowiedzi z OpenRouter"}})
            note_chat(CFG, (obj.get("model") if isinstance(obj, dict) else ""), sid, False, requested)
            if LAST_CHAT.get("fallback"):
                log("czat: odpowiedzial model awaryjny " + str(LAST_CHAT.get("model")) + " [prosba o " + requested + "]")
            return self._json(status, obj)
        request = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            upstream = urllib.request.urlopen(request, timeout=600)
        except urllib.error.HTTPError as exc:
            payload = exc.read()[:500]
            return self._json(exc.code, {"error": {"message": payload.decode("utf-8", "replace")}})
        except Exception as exc:
            return self._json(502, {"error": {"message": "brak polaczenia z OpenRouter: " + str(exc)[:200]}})
        with upstream:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            allowed = self._cors()
            self.end_headers()
            if not allowed:
                return
            try:
                first_model = ""
                for raw in iter(upstream.readline, b""):
                    if not raw.strip():
                        continue
                    if not first_model and b'"model"' in raw:
                        text_chunk = raw.decode("utf-8", "replace").strip()
                        if text_chunk.startswith("data:"):
                            text_chunk = text_chunk[5:].strip()
                        try:
                            first_model = str(json.loads(text_chunk).get("model") or "")
                        except Exception:
                            first_model = ""
                        if first_model:
                            note_chat(CFG, first_model, sid, True, requested)
                            if LAST_CHAT.get("fallback"):
                                log("czat [stream]: odpowiedzial model awaryjny " + first_model + " [prosba o " + requested + "]")
                    self.wfile.write(raw if raw.endswith(b"\n") else raw + b"\n")
                    self.wfile.write(b"\n")
                    self.wfile.flush()
            except Exception as exc:
                log("strumien przerwany: " + repr(exc))
            self.close_connection = True


# --- self-test ---------------------------------------------------------------

def selftest(cfg):
    print("=== SELF-TEST mostka ===")
    print(json.dumps(cfg.display(), ensure_ascii=False, indent=2))
    problems = []

    print("\n[1/4] Workflow")
    try:
        graph = load_workflow(cfg)
        print("  plik: " + cfg.workflow_file + " (" + str(len(graph)) + " nodow)")
        for label, node_id in (("prompt dodatni", cfg.pos_node), ("prompt ujemny", cfg.neg_node)):
            if node_id and node_id in graph:
                print("  OK  " + label + ": nod " + str(node_id) + " (" + str(graph[node_id].get("class_type")) + ")")
            elif node_id:
                print("  BLAD " + label + ": brak noda " + str(node_id))
                problems.append("brak noda " + label)
        latent = nodes_of_type(graph, "EmptyLatentImage")
        print("  rozmiar: " + (("nod " + latent[0]) if latent else "brak EmptyLatentImage (rozmiar zostanie jak w workflow)"))
        savers = nodes_of_type(graph, "SaveImage") + nodes_of_type(graph, "PreviewImage")
        print("  zapis: " + (("nody " + ", ".join(savers)) if savers else "BRAK SaveImage/PreviewImage"))
        if not savers:
            problems.append("brak noda zapisu obrazu")
    except Exception as exc:
        print("  BLAD: " + str(exc))
        problems.append("workflow: " + str(exc))

    print("\n[1b/4] Tryby obrazu (presety)")
    for name, preset in sorted(preset_table(cfg).items()):
        path = preset_path(cfg, preset)
        if not path.exists():
            print("  BLAD " + name + ": brak pliku " + str(path))
            problems.append("tryb " + name + ": brak pliku " + path.name)
            continue
        try:
            graph = load_workflow(cfg, path)
            missing = preflight_graph(cfg, graph)
        except Exception as exc:
            print("  BLAD " + name + ": " + str(exc))
            problems.append("tryb " + name + ": " + str(exc))
            continue
        if missing:
            print("  UWAGA " + name + " (" + str(preset.get("size")) + "): brakuje modeli -> " + describe_missing_models(missing))
        else:
            print("  OK  " + name + " (" + path.name + ", " + str(preset.get("size") or "auto") + ") " + str(preset.get("desc") or ""))

    print("\n[2/4] ComfyUI " + cfg.comfy)
    status, obj, text = http_json(cfg.comfy.rstrip("/") + "/system_stats", None, None, "GET", 8)
    if status == 200 and obj:
        devices = ", ".join(str(d.get("name") or "?") for d in (obj.get("devices") or []))
        print("  OK  ComfyUI odpowiada, wersja " + str(obj.get("system", {}).get("comfyui_version") or "?"))
        print("  GPU: " + (devices or "?"))
    else:
        print("  BLAD: brak odpowiedzi z ComfyUI (" + str(status) + ") " + str(text)[:160])
        print("  -> uruchom ComfyUI albo popraw --comfy")
        problems.append("ComfyUI nieosiagalne")
    queue = comfy_queue_state(cfg)
    print("  kolejka: running=" + str(queue.get("running")) + " pending=" + str(queue.get("pending")))

    print("\n[3/4] OpenRouter " + cfg.openrouter)
    if not cfg.api_key:
        print("  BLAD: brak klucza (--openrouter-key, zmienna OPENROUTER_API_KEY albo plik openrouter_key.txt)")
        problems.append("brak klucza OpenRoutera")
    else:
        status, obj, text = http_json(cfg.openrouter.rstrip("/") + "/key", None, or_headers(cfg), "GET", 20)
        if status == 200 and obj:
            data = obj.get("data") or {}
            print("  OK  klucz przyjety, etykieta: " + str(data.get("label") or "?") +
                  ", uzycie: " + str(data.get("usage") or 0) + " / " + str(data.get("limit") or "brak limitu"))
        else:
            print("  BLAD: OpenRouter odrzucil klucz (" + str(status) + ") " + str(text)[:200])
            problems.append("zly klucz OpenRoutera")

    chain = norm_model_list(getattr(cfg, "fallback_models", []))
    if chain:
        status, obj, text = http_json(cfg.openrouter.rstrip("/") + "/models", None, or_headers(cfg), "GET", 30)
        if status == 200 and isinstance(obj, dict):
            known = set(str(m.get("id")) for m in (obj.get("data") or []) if isinstance(m, dict))
            missing = [m for m in chain if m not in known]
            if missing:
                print("  BLAD lancuch awaryjny - nie ma tego na OpenRouterze: " + ", ".join(missing))
                problems.append("zly model awaryjny: " + ", ".join(missing))
            else:
                print("  OK  lancuch awaryjny (" + str(len(chain)) + "): " + ", ".join(chain))
        else:
            print("  ?   nie udalo sie pobrac listy modeli (" + str(status) + ")")
    print("  sesja/cache: " + ("wlaczona - sticky routing + cache promptu" if getattr(cfg, "session_cache", True) else "wylaczona")
          + " | provider.data_collection: " + (getattr(cfg, "data_collection", "") or "(nie narzucam)"))
    mp_show = float(getattr(cfg, "min_p", 0) or 0)
    rp_show = float(getattr(cfg, "rep_penalty", 1.0) or 1.0)
    print("  probkowanie: min_p " + (("%.3f" % mp_show) if mp_show > 0 else "(nie wysylam)")
          + " | repetition_penalty " + (("%.3f" % rp_show) if abs(rp_show - 1.0) > 1e-9 else "(nie wysylam)"))

    if cfg.selftest_scene:
        print("\n[4/4] Przepisywacz (Hermes)")
        try:
            refined = refine_prompt(cfg, cfg.selftest_scene)
            print("  OK  prompt: " + refined)
        except Exception as exc:
            print("  BLAD: " + str(exc))
            problems.append("przepisywacz: " + str(exc))
    else:
        print("\n[4/4] Przepisywacz — pominiety (dodaj --selftest-scene \"opis sceny po polsku\")")

    if cfg.selftest_gen:
        print("\n[+] Pelna generacja probna")
        try:
            result = run_image_job(cfg, cfg.selftest_scene or "portrait of the subject, sitting on a bed, soft light",
                                   "", "", False, {}, 1)
            print("  OK  plik: " + str(Path(cfg.out_dir) / result["results"][0]["file"]))
        except Exception as exc:
            print("  BLAD: " + str(exc))
            problems.append("generacja: " + str(exc))

    print("\n=== WYNIK ===")
    if problems:
        print("PROBLEMY (" + str(len(problems)) + "):")
        for item in problems:
            print("  - " + item)
        return 1
    print("Wszystko gotowe. Uruchom bez --selftest i ustaw adresy w panelu Chloe.")
    return 0


# --- CLI ---------------------------------------------------------------------

def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Mostek Hermes (OpenRouter) + ComfyUI dla Chloe / Perchance ai-character-chat",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Endpointy: /health, /api/generate, /images/generations, /v1/chat/completions, /v1/models, /last, /images/<plik>, /",
    )
    parser.add_argument("--host", default=None, help="domyslnie 127.0.0.1 (tylko lokalnie; Tailscale Serve daje HTTPS)")
    parser.add_argument("--port", type=int, default=None, help="domyslnie 8443")
    parser.add_argument("--openrouter", default=None, help="bazowy URL OpenRoutera (domyslnie https://openrouter.ai/api/v1)")
    parser.add_argument("--openrouter-key", default=None, help="klucz API OpenRoutera (albo OPENROUTER_API_KEY / openrouter_key.txt)")
    parser.add_argument("--model", default=None, help="model czatu, domyslnie nousresearch/hermes-3-llama-3.1-70b")
    parser.add_argument("--fallback-models", default=None, help="modele awaryjne OpenRoutera po przecinku (domyslnie cydonia-24b-v4.1, mistral-small-2603, deepseek-v4-flash-0731)")
    parser.add_argument("--no-fallbacks", action="store_true", help="nie dokladaj lancucha modeli awaryjnych")
    parser.add_argument("--no-session-cache", action="store_true", help="nie wysylaj session_id (bez sticky routingu i cache promptu)")
    parser.add_argument("--min-p", dest="min_p", type=float, default=None, help="min_p dla czatu (domyslnie 0.03; 0 = nie wysylaj)")
    parser.add_argument("--rep-penalty", dest="rep_penalty", type=float, default=None, help="repetition_penalty dla czatu (domyslnie 1.05; 1.0 = nie wysylaj)")
    parser.add_argument("--data-collection", default=None, help="polityka providera: deny (domyslnie) = tylko providerzy nie trenujacy na danych, allow = bez ograniczen")
    parser.add_argument("--refine-model", default=None, help="osobny model do przepisywania promptu obrazu (domyslnie ten sam)")
    parser.add_argument("--no-refine", action="store_true", help="wylacz przepisywanie promptu (prompt idzie wprost)")
    parser.add_argument("--direct-default", action="store_true", help="domyslnie tryb wprost (bez przepisywania)")
    parser.add_argument("--comfy", default=None, help="adres ComfyUI, domyslnie http://127.0.0.1:8188")
    parser.add_argument("--workflow-file", default=None, help="plik z workflow API (domyslnie workflow_api.json obok skryptu)")
    parser.add_argument("--pos-node", default=None, help="ID noda promptu dodatniego (domyslnie 2)")
    parser.add_argument("--neg-node", default=None, help="ID noda negatywy (domyslnie 3)")
    parser.add_argument("--latent-node", default=None, help="ID noda rozmiaru (domyslnie auto: EmptyLatentImage)")
    parser.add_argument("--prefix", default=None, help="prefiks nazw plikow w ComfyUI (domyslnie chloe)")
    parser.add_argument("--out-dir", default=None, help="katalog na obrazy (domyslnie ./images)")
    parser.add_argument("--size", default=None, help="domyslny rozmiar, np. 832x1216")
    parser.add_argument("--seed-mode", choices=["same", "increment"], default=None, help="seed dla kolejnych samplerow (domyslnie same)")
    parser.add_argument("--timeout", type=float, default=None, help="limit generowania w sekundach (domyslnie 900)")
    parser.add_argument("--poll", type=float, default=None, help="odstep odpytywania ComfyUI (domyslnie 1.2 s)")
    parser.add_argument("--restart-misses", type=float, default=None, help="ile odpywan bez sladu zadania = restart ComfyUI (domyslnie 5)")
    parser.add_argument("--token", default=None, help="opcjonalny token; wtedy POST-y wymagaja Authorization: Bearer <token>")
    parser.add_argument("--allow-origin", default=None, help="regex dodatkowych Originow CORS (domyslnie *.perchance.org i localhost)")
    parser.add_argument("--config", default=None, help="plik JSON z ustawieniami (domyslnie bridge_config.json obok skryptu)")
    parser.add_argument("--selftest", action="store_true", help="sprawdz workflow, ComfyUI i klucz, potem wyjdz")
    parser.add_argument("--selftest-scene", default=None, help="opis sceny do sprawdzenia przepisywacza w --selftest")
    parser.add_argument("--selftest-gen", action="store_true", help="w --selftest zrob tez pelna generacje obrazu")
    return parser.parse_args(argv)


def main(argv=None):
    global CFG
    args = parse_args(argv)
    cfg = Config(args)
    CFG = cfg
    if cfg.selftest:
        return selftest(cfg)
    server = ThreadingHTTPServer((cfg.host, cfg.port), Handler)
    server.daemon_threads = True
    print("=" * 74)
    print(" Mostek Hermes (OpenRouter) + ComfyUI — dla Chloe")
    print("=" * 74)
    print(json.dumps(cfg.display(), ensure_ascii=False, indent=2))
    print("-" * 74)
    print(" W panelu Chloe wpisz:")
    print("   Model      -> Base URL: http://" + cfg.host + ":" + str(cfg.port) + "  (albo HTTPS z Tailscale Serve)")
    print("   Obrazy     -> Stheno -> ComfyUI (localflow): ten sam bazowy adres")
    print("   Obrazy     -> wlasny endpoint (custom): ten sam bazowy adres")
    print("   Strona statusu: http://" + cfg.host + ":" + str(cfg.port) + "/")
    if not cfg.api_key:
        print(" UWAGA: brak klucza OpenRoutera — czat przez mostek nie zadziala.")
    if not cfg.allows_origin("https://abc123.perchance.org"):
        print(" UWAGA: CORS nie przepuszcza *.perchance.org — sprawdz --allow-origin.")
    print(" Ctrl+C konczy.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nZatrzymano.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
