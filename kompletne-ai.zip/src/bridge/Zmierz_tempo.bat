@echo off
rem  Dwuklik = pomiar tempa ComfyUI: ile realnie trwa jeden krok (base i hires).
rem  Robi dokladnie to samo, co:  Start_Comfy_i_Hermes.bat --bench
rem  Mozna dopisac argumenty, np.:
rem      Zmierz_tempo.bat --attn=split
rem      Zmierz_tempo.bat --runs=5
rem  Wynik lezy w raport_wydajnosci.txt obok mostka.
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0Start_Comfy_i_Hermes.bat" (
    echo [BLAD] Nie widze Start_Comfy_i_Hermes.bat obok tego pliku.
    echo        Folder: %~dp0
    echo        Poloz oba pliki w tym samym folderze i uruchom ponownie.
    pause
    exit /b 1
)
call "%~dp0Start_Comfy_i_Hermes.bat" --bench %*
exit /b 0
