@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title Chloe - detektor twarzy dla FaceDetailer (Impact Subpack)
set "CHL_VER=v1.0 z 24.09.2026"

rem =====================================================================
rem  Dodaj_detektor_twarzy.bat
rem
rem  Diagnoza (24.09.2026):
rem    ComfyUI ma Impact Pack, wiec nod FaceDetailer (detal twarzy) JEST.
rem    Brakuje jednak nodu UltralyticsDetectorProvider - czyli tego, co
rem    wykrywa twarze. Ten nod NIE jest czescia Impact Packu, tylko
rem    osobnego pakietu "ComfyUI Impact Subpack" (od V8 Impact Packu
rem    nie instaluje sie automatycznie). Dlatego FaceDetailer nie ma
rem    czym wykryc twarzy.
rem
rem  Ten skrypt:
rem    1) wgrywa custom_nodes\ComfyUI-Impact-Subpack (z kopii na uploads,
rem       z zapasowym GitHubem, bez potrzeby instalowania gita),
rem    2) wola instaluj_detektor_twarzy.py, ktory doklada zaleznosci
rem       (ultralytics) ZAWSZE z --no-deps, zeby nie podmienic Twojego
rem       torch/ROCm, i sciaga face_yolov8m.pt do models\ultralytics\bbox,
rem    3) mowi, co zrobic dalej.
rem
rem  Uruchomienie: dwuklik. Alternatywa: ComfyUI-Manager -> Install Custom
rem  Nodes -> "ComfyUI Impact Subpack" (Manager zrobi to samo, tylko
rem  zaleznosci instaluje swoim sposobem - jesli po tym zniknie karta
rem  GPU, to znaczy ze podmienil torch i trzeba wrocic do wersji ROCm).
rem =====================================================================

echo ======================================================================
echo  Dodaj_detektor_twarzy.bat   %CHL_VER%
echo ======================================================================
echo.

rem ---------------------------------------------- 1) gdzie jest ComfyUI
set "CHL_ROOT=%~dp0"
set "CHL_ROOT=%CHL_ROOT:~0,-1%"

set "CHL_PACK="
if exist "%CHL_ROOT%\main.py" if exist "%CHL_ROOT%\models" set "CHL_PACK=%CHL_ROOT%"
if not defined CHL_PACK if exist "%CHL_ROOT%\python_env\python.exe" if exist "%CHL_ROOT%\models" set "CHL_PACK=%CHL_ROOT%"
if not defined CHL_PACK if exist "%CHL_ROOT%\comfyui-rocm-091926\main.py" set "CHL_PACK=%CHL_ROOT%\comfyui-rocm-091926"
if not defined CHL_PACK for /d %%D in ("%CHL_ROOT%\comfyui-rocm*") do if not defined CHL_PACK if exist "%%~fD\main.py" set "CHL_PACK=%%~fD"
if not defined CHL_PACK for /d %%D in ("%CHL_ROOT%\..\comfyui-rocm*") do if not defined CHL_PACK if exist "%%~fD\main.py" set "CHL_PACK=%%~fD"
if not defined CHL_PACK (
    echo [BLAD] Nie znalazlem folderu ComfyUI ^(main.py + models^).
    echo        Szukalem w: "%CHL_ROOT%" oraz w podfolderach comfyui-rocm*
    echo        Poloz ten plik obok folderu ComfyUI albo bezposrednio w nim.
    echo.
    pause
    exit /b 1
)

set "CHL_CN=%CHL_PACK%\custom_nodes"
set "CHL_SUB=%CHL_CN%\ComfyUI-Impact-Subpack"
set "CHL_PY=%CHL_PACK%\python_env\python.exe"
if not exist "%CHL_PY%" set "CHL_PY=python"

echo [i] ComfyUI      : %CHL_PACK%
echo [i] custom_nodes : %CHL_CN%
if "%CHL_PY%"=="python" (
    echo [UWAGA] Nie ma python_env\python.exe - uzyje "python" z PATH.
    echo     Instaluj zaleznosci TYLKO interpretetorem ComfyUI, inaczej ultralytics
    echo     trafi do innego srodowiska i ComfyUI go nie zobaczy.
) else (
    echo [i] Python       : %CHL_PY%
)
echo.

rem ---------------------------------------------- 2) czy pakiet juz jest
if exist "%CHL_SUB%\__init__.py" (
    echo [OK] Pakiet juz jest: custom_nodes\ComfyUI-Impact-Subpack
    goto :pakiet_gotowy
)
if not exist "%CHL_CN%" (
    echo [BLAD] Nie ma folderu custom_nodes w %CHL_PACK% - to na pewno folder ComfyUI?
    echo.
    pause
    exit /b 1
)

rem ---------------------------------------------- 3) pobranie pakietu
echo [1/3] Pobieram ComfyUI-Impact-Subpack ^(ok. 26 kB^)...
set "CHL_ZIP=%TEMP%\chloe-impact-subpack.zip"
set "CHL_URL1=https://user.uploads.dev/file/4ff2a7aac10c0293574388fe0b64835a.zip"
set "CHL_URL2=https://github.com/ltdrdata/ComfyUI-Impact-Subpack/archive/refs/heads/main.zip"

powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%CHL_URL1%' -OutFile '%CHL_ZIP%' -UseBasicParsing; exit 0 } catch { exit 1 }"
if errorlevel 1 (
    echo       kopia na uploads nie odpowiedziala - probuje GitHub...
    powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%CHL_URL2%' -OutFile '%CHL_ZIP%' -UseBasicParsing; exit 0 } catch { Write-Host ('      ' + $_.Exception.Message); exit 1 }"
)
if not exist "%CHL_ZIP%" (
    echo [BLAD] Nie udalo sie pobrac pakietu. Pobierz recznie:
    echo        %CHL_URL2%
    echo        i rozpakuj folder ComfyUI-Impact-Subpack-main do:
    echo        %CHL_SUB%
    echo        potem uruchom: "%CHL_PY%" instaluj_detektor_twarzy.py --pack "%CHL_PACK%"
    echo.
    pause
    exit /b 1
)

echo       rozpakowuje...
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Expand-Archive -LiteralPath '%CHL_ZIP%' -DestinationPath '%CHL_CN%' -Force; exit 0 } catch { Write-Host ('      ' + $_.Exception.Message); exit 1 }"
if errorlevel 1 (
    echo [BLAD] Nie udalo sie rozpakowac %CHL_ZIP%.
    echo        Rozpakuj go recznie do %CHL_CN% i uruchom ten plik ponownie.
    echo.
    pause
    exit /b 1
)

if exist "%CHL_SUB%\__init__.py" goto :pakiet_gotowy
if exist "%CHL_CN%\ComfyUI-Impact-Subpack-main\__init__.py" (
    echo       poprawiam nazwe folderu...
    move "%CHL_CN%\ComfyUI-Impact-Subpack-main" "%CHL_SUB%" >nul
)
if not exist "%CHL_SUB%\__init__.py" (
    echo [BLAD] Po rozpakowaniu nie ma pliku %CHL_SUB%\__init__.py.
    echo        Zajrzyj do %CHL_CN% i popraw nazwe folderu na ComfyUI-Impact-Subpack.
    echo.
    pause
    exit /b 1
)
del "%CHL_ZIP%" >nul 2>&1

:pakiet_gotowy
echo.
echo [2/3] Dokanczam instalacje: zaleznosci ^(bez ruszania torch^) + model detektora
echo.
if not exist "%~dp0instaluj_detektor_twarzy.py" (
    echo [BLAD] Brak pliku instaluj_detektor_twarzy.py obok tego .bat
    echo        Poloz oba pliki w tym samym folderze.
    echo.
    pause
    exit /b 1
)
"%CHL_PY%" "%~dp0instaluj_detektor_twarzy.py" --pack "%CHL_PACK%"
set "CHL_KOD=%ERRORLEVEL%"

echo.
echo [3/3] Podsumowanie
if not "%CHL_KOD%"=="0" (
    echo   Instalacja nie dobiegla konca ^(kod %CHL_KOD%^) - skopiuj mi tekst z ekranu.
    echo   Alternatywa: zainstaluj "ComfyUI Impact Subpack" w ComfyUI-Manager.
    echo.
    pause
    exit /b %CHL_KOD%
)

echo   Zrob teraz to, po kolei:
echo    1^) Zamknij ComfyUI i uruchom go od nowa:  Start_Comfy_i_Hermes.bat
echo       ^(bez restartu nowy nod sie nie pojawi^)
echo    2^) W oknie launchera sprawdz, czy widnieje:
echo         [OK]   UltralyticsDetectorProvider
echo         [FACE] gotowe do wdrozenia
echo    3^) Wpisz:  python dodaj_facedetailer.py
echo       ^(dopisze detal twarzy do workflow_api.json; podglad: --dry-run,
echo        cofniecie: --remove, proba generacji: --test^)
echo.
echo   Mostka nie restartuj - sam zauwazy zmiane workflow.
echo ======================================================================
echo.
pause
endlocal
