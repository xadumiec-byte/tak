@echo off
rem =====================================================================
rem  Odpalacz dla Chloe: ComfyUI + mostek Hermes (OpenRouter) + ComfyUI
rem  Dwuklik = ComfyUI + mostek. Ctrl+C w tym oknie konczy mostek
rem  i (po potwierdzeniu) zamyka ComfyUI.
rem
rem  Przyklady (z wiersza polecen):
rem    odpal.bat --no-comfy          tylko mostek (ComfyUI juz chodzi)
rem    odpal.bat --comfy-only        tylko ComfyUI
rem    odpal.bat --find-comfy        pokaz, gdzie szukalem ComfyUI
rem    odpal.bat --comfy-dir "C:\ComfyUI"
rem    odpal.bat -- --no-refine      argumenty po "--" leca do mostka
rem
rem  UWAGA: po Ctrl+C cmd moze jeszcze zapytac "Terminate batch job (Y/N)?".
rem  Wtedy wpisz Y (albo odpalaj z konsoli: py -3 odpal.py).
rem =====================================================================
setlocal
cd /d "%~dp0"
title Chloe: ComfyUI + mostek

set "PYCMD="
where py >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
  where python >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
  echo Nie znalazlem Pythona w PATH.
  echo Zainstaluj Pythona 3 z python.org (zaznacz "Add python.exe to PATH"),
  echo albo uruchom odpal.py swoim interpreterem.
  goto koniec
)

%PYCMD% "%~dp0odpal.py" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Kod wyjscia: %RC%

:koniec
echo.
echo Nacisnij dowolny klawisz, aby zamknac to okno...
pause >nul
endlocal
