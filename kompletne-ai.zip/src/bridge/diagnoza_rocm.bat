@echo off
setlocal EnableExtensions
title Diagnostyka ComfyUI ROCm

rem =====================================================================
rem  diagnoza_rocm.bat - zbiera do raport_rocm_sdk.txt to, czego brakuje,
rem  zeby naprawic start ComfyUI ROCm:
rem    * prawdziwy blad rocm-sdk init / path --root - launcher comfyui-rocm.bat
rem      wysyla go do >nul, wiec w oknie go nie widac,
rem    * czy python_env / SDK nie zostaly przeniesione lub zmienione,
rem    * czy torch widzi karte i pelny traceback, jesli nie,
rem    * osobno detect_gpu.py, bo to ono daje puste GPU_ARCH,
rem    * karta i sterownik AMD z Windows.
rem  Nic nie zmienia w systemie: tylko czyta i uruchamia programy diagnostyczne.
rem
rem  Wymaga dwoch plikow w folderze ComfyUI:
rem    diagnoza_rocm.bat  (ten plik)  i  diagnoza_rocm.py
rem  Oba leza obok main.py, czyli w C:\Users\adamo\Desktop\AI.KURWA\comfyui-rocm-091926
rem =====================================================================

set "CHL_ROOT=%~dp0"
if not exist "%CHL_ROOT%python_env\python.exe" (
    set "CHL_ROOT=%~dp0comfyui-rocm-091926\"
)
set "CHL_CDIR=%CHL_ROOT%"
set "CHL_PY=%CHL_CDIR%python_env\python.exe"
set "CHL_REP=%CHL_CDIR%raport_rocm_sdk.txt"
set "CHL_LOG=%CHL_CDIR%raport_rocm_sdk_konsola.txt"

if not exist "%CHL_PY%" (
    echo [BLAD] Nie ma pliku: "%CHL_PY%"
    echo        Ten .bat musi lezec w folderze ComfyUI, tam gdzie main.py
    echo        i podfolder python_env.
    pause
    exit /b 1
)
if not exist "%CHL_CDIR%diagnoza_rocm.py" (
    echo [BLAD] Brak diagnoza_rocm.py w "%CHL_CDIR%"
    echo        Skopiuj go tam, gdzie lezy main.py.
    pause
    exit /b 1
)

echo ======================================================================
echo  Diagnostyka ComfyUI ROCm
echo  folder: %CHL_CDIR%
echo  raport: %CHL_REP%
echo ----------------------------------------------------------------------
echo  Moze potrwac kilka minut - nie zamykaj tego okna.
echo ======================================================================
echo.

pushd "%CHL_CDIR%"
"%CHL_PY%" diagnoza_rocm.py raport_rocm_sdk.txt >> "%CHL_LOG%" 2>&1
set "CHL_RC=%ERRORLEVEL%"
popd

echo.
if not exist "%CHL_REP%" (
    echo [BLAD] Nie powstal raport - interpreter python_env nie wystartowal.
    echo        Podglad bledu: "%CHL_LOG%"
    echo        Wrzuc ten plik jako zalacznik.
    start "" notepad "%CHL_LOG%"
    pause
    exit /b 1
)

echo Gotowe, kod %CHL_RC%. Otwieram raport w notatniku.
echo.
echo Wrzuc raport_rocm_sdk.txt jako zalacznik w czacie z Chloe.
echo.
start "" notepad "%CHL_REP%"
pause
