# Mostek „Hermes + ComfyUI" (`hermes_comfy_bridge.py`)

Jeden lokalny proces, który obsługuje Chloe z dwóch stron naraz:

- **czat** — `POST /v1/chat/completions` przekazywany 1:1 do **OpenRoutera** (domyślnie
  `nousresearch/hermes-3-llama-3.1-70b`), więc aplikacja nie trzyma klucza w przeglądarce;
- **obrazy** — sekwencja **Hermes dopracowuje prompt → ComfyUI generuje**: prompt ze scenki
  („Stheno" w tej roli jest tu zastąpiony przez Hermesa) jest przepisywany na tagi SDXL,
  wstrzykiwany do Twojego workflow API i uruchamiany, a gotowy PNG wraca do czatu.

Zero zależności: czysty Python (stdlib), bez Flaska, bez `pip install`, bez lokalnego LLM-a
(8B Stheno nie jest już potrzebny). ComfyUI musi działać obok.

## Pliki

| Plik | Rola |
|---|---|
| `hermes_comfy_bridge.py` | sam mostek (Python 3.8+), obecnie **v12** — wersję, `features`, `key_source` i listę trybów (`tryby`) widać w `/health` |
| `odpal.py` | **odpalacz**: uruchamia ComfyUI + mostek razem (patrz niżej) |
| `odpal.bat` | dwuklik dla Windows: odpala `odpal.py` |
| `Start_Comfy_i_Hermes.bat` | **jednoplikowy launcher v4.3**: ustawia środowisko ROCm/HIP, startuje `comfyui-rocm-091926` w osobnym oknie, czeka na `:8188`, sprawdza pliki modeli z workflow, sprząta VRAM po starym koboldcpp, startuje mostek w osobnym oknie i na koniec weryfikuje cały stos (`--check`/`--stop`/`--restart`/`--test`/`--serve`/`--simple`/`--no-comfy`). Od v4.3: `--bench` (pomiar tempa, patrz niżej), `--attn=default\|split\|quad\|pytorch\|sage` (sposób liczenia attention), `--restart-comfy` (zamknij ComfyUI przed startem — potrzebne przy zmianie `--attn`), `--bench-runs=N`/`--bench-steps=N`, zmienna `CHL_COMFY_EXTRA` (dopisuje flagi do ComfyUI bez podmiany całej listy) |
| `Zmierz_tempo.bat` | dwuklik = to samo co `Start_Comfy_i_Hermes.bat --bench`; można dopisać argumenty, np. `Zmierz_tempo.bat --attn=split` |
| `bench_comfy.py` | pomiar tempa ComfyUI: wysyła Twój workflow z 3 krokami w KSamplerach i mierzy **s/krok osobno dla base i hires**; wykrywa „wolny tryb" (jeden przebieg ≥2,5x wolniejszy). Kod wyjścia 0 = stabilnie, 1 = błąd, 2 = wolny tryb |
| `raport_wydajnosci.txt` | wynik ostatniego `--bench` (pisze się sam obok plików mostka) |
| `Restart_Mostka.bat` | dwuklik = to samo co `Start_Comfy_i_Hermes.bat --restart` (bez wpisywania argumentów w cmd). Wypisuje błąd, jeśli launcher nie leży obok |
| `sprawdz_comfy.py` | czeka, aż ComfyUI wstanie, i porównuje workflow z `/object_info` — wypisuje brakujące checkpointy/LoRy/upscalery i do jakiego folderu je wgrać (kody wyjścia 0/1/2) |
| `odpal_config.json` | ustawienia odpalacza (tworzy się sam; np. `comfy_dir`, `wait_sec`, `cors`) |
| `workflow_api.json` | **domyślny tryb** (mostek v11): checkpoint → LoRA → 768x1152 natywnie, 20 kroków, CFG 6, dpmpp_2m+karras (~18 s). Mostek podmienia w nim prompt, negatywę, rozmiar i seed |
| `workflow_sd15_fast.json` | tryb `fast`: 512x768, 20 kroków → dekodowanie → upscale ESRGAN 2x do 1024x1536 (**~3-4 s**) |
| `workflow_sd15_classic.json` | stary układ 25+20 kroków z upscalem 4x NMKD (**~64 s**) — do porównań i rollbacku |
| `workflow_sdxl_fast.json` | tryb `sdxl_fast`: SDXL + LoRA SDXL-Lightning, 8 kroków, CFG 1,5, euler+sgm_uniform |
| `workflow_sdxl_cfg8.json` | tryb `sdxl_cfg8`: SDXL + Hyper-SD 8 kroków z CFG 5,5 (lepsze trzymanie promptu) |
| `workflow_sdxl_std.json` | tryb `sdxl_std`: SDXL bez destylacji — 24 kroki, CFG 6, dpmpp_2m+karras, 832x1216 (**~43 s, najlepszy kompromis jakość/czas**, zmierzone 25.09.2026) |
| `workflow_sdxl_hq.json` | tryb `sdxl_hq`: SDXL 28 kroków + hires 1,5x (~2 min). Po pomiarach 25.09.2026: **hires denoise 0,3 i latent upscale nearest-exact** (mniej halo), ale na części seedów hires i tak psuje anatomię — traktuj jako eksperyment, nie jako tryb „na gotowe" |
| `NSFW_CONFIG.md` | **audyt workflow + pomiary + zalecenia pod hard NSFW** (modele, samplery, promptowanie, dalsze przyspieszanie) — czytaj to pierwsze przy zmianach w obrazach |
| `Pobierz_modele_NSFW.bat` | dwuklik: pobiera checkpointy NSFW (LUSTIFY SDXL, CyberRealisticXL Play, WAI-NSFW-Illustrious, Pony V6 XL, Hassaku) i LoRA przyspieszające z HuggingFace; sam znajduje folder ComfyUI (albo przyjmuje przeciągnięty folder), wznawia przerwane pobieranie, `S` = sprawdź co masz, a po pobraniu podpowiada tryb. Od 25.09 **uruchamia się w swoim oknie przez `cmd /k`** (okno zostaje otwarte nawet po błędzie) i pisze `pobieranie_log.txt`. **Koniec linii musi być CRLF** — przy LF (Linux) cmd.exe zamyka okno bez komunikatu |
| `POLECENIA_curl.txt` | plan B, gdy `.bat` nie chce wystartować: gotowe linijki `curl.exe` do wklejenia w zwykłe okno cmd (te same modele, ta sama ścieżka, wznawianie przez `-C -`) |
| `tests/test_bridge_presets.py` | testy mostka v12 (presety, latanie grafu, pierwszeństwo ustawień, kontrola i automatyczny dobór brakujących modeli) — `python tests/test_bridge_presets.py`, bez sieci i GPU |
| `dodaj_facedetailer.py` | dopisuje detal twarzy (`FaceDetailer` z Impact Packu) do `workflow_api.json`; nod buduje z `/object_info` Twojego ComfyUI, więc działa z różnymi wersjami wtyczki (`--dry-run` plan, `--remove` cofnięcie, `--test` próba generacji, `--sam`) |
| `workflow_api_simple.json` | zapasowy, minimalny workflow txt2img (checkpoint → KSampler → VAE Decode → SaveImage, 512x768, bez LoRy i upscalera); uruchom mostek z `--workflow-file workflow_api_simple.json`, gdy `sprawdz_comfy.py` zgłasza brakujące pliki albo gdy brakuje VRAM |
| `dodaj_facedetailer.py` | dopisuje detal twarzy (`FaceDetailer` z Impact Packu) do `workflow_api.json`; nod buduje z `/object_info` Twojego ComfyUI, więc działa z różnymi wersjami wtyczki (`--dry-run` plan, `--remove` cofnięcie, `--test` próba generacji, `--sam`) |
| `Dodaj_detektor_twarzy.bat` | dwuklik: wgrywa brakujący pakiet **ComfyUI-Impact-Subpack** (bez gita) i woła `instaluj_detektor_twarzy.py` |
| `instaluj_detektor_twarzy.py` | dokłada zależności `ultralytics` **zawsze `--no-deps`** (żeby nie podmienić torch/ROCm) i ściąga `face_yolov8m.pt` do `models\ultralytics\bbox` |
| `openrouter_key.txt` | *nieobowiązkowy* plik z kluczem OpenRoutera (wygodne na Windows) |
| `bridge_config.json` | *nieobowiązkowy* plik z domyślnymi ustawieniami mostka |
| `images/` | zapisane obrazy + pliki `.txt` z użytym promptem i negatywą |

## Odpalacz: `odpal.py` + `odpal.bat` (najwygodniej)

Robi za Ciebie całą sekwencję: **znajduje i uruchamia ComfyUI → czeka, aż wstanie →
uruchamia mostek → wypisuje adresy do panelu Chloe**. Ctrl+C kończy mostek i (po
potwierdzeniu) zamyka ComfyUI.

Dwuklik na `odpal.bat` albo z konsoli:

```
python odpal.py                          # ComfyUI (auto) + mostek
python odpal.py --find-comfy             # gdzie szukałem i co znalazłem
python odpal.py --comfy-dir "C:\ComfyUI"  # wskaż folder (zapamięta w odpal_config.json)
python odpal.py --no-comfy               # tylko mostek (ComfyUI już chodzi)
python odpal.py --comfy-only             # tylko ComfyUI
python odpal.py --keep-comfy --yes       # Ctrl+C nie zamyka ComfyUI, bez pytań
python odpal.py --same-window            # log ComfyUI w tym samym oknie ([comfy] ...)
python odpal.py -- --no-refine --size 832x1216   # wszystko po "--" leci do mostka
```

Jak odpalacz szuka ComfyUI (w tej kolejności): folder z `odpal_config.json` → katalog
odpalacza i jego podfoldery `ComfyUI*` → `Desktop\ComfyUI*`, `Desktop\ComfyUI_windows_portable*`,
`~/ComfyUI`, `Documents\ComfyUI`, `Downloads\ComfyUI`, `C:\ComfyUI*`, `C:\AI\ComfyUI*`.
W każdym z nich wystarczy jedno z: `run_nvidia_gpu.bat` (użyje Twojego pliku, czyli m.in.
portable Python), `ComfyUI\main.py` (portable) albo `main.py` (+ `venv\.venv` jeśli jest).

`odpal_config.json` (tworzy się sam):

```json
{
  "comfy_dir": "C:\\Users\\adamo\\Desktop\\AI.KURWA\\ComfyUI",
  "comfy_url": "http://127.0.0.1:8188",
  "comfy_args": [],
  "cors": true,
  "python": "",
  "wait_sec": 600,
  "open_browser": true,
  "keep_comfy": false
}
```

* `cors: true` dokłada do ComfyUI `--enable-cors-header "*"` (przydatne tylko dla dostawcy
  „ComfyUI (lokalny)" w panelu Obrazy — mostek gada z ComfyUI po stronie serwera). Gdyby
  Twoja wersja ComfyUI nie znała tej opcji, ustaw `false`.
* `--comfy-only` zostawia ComfyUI w oknie obok; gdy zamkniesz je ręcznie, odpalacz to zauważy.
* Skrypt kończy się kodem 2, gdy port mostka jest zajęty (mostek już działa), kodem 3, gdy
  nie znalazł ComfyUI w trybie `--comfy-only`. W trybie „oba" brak ComfyUI nie przerywa
  startu — mostek wstaje, a obrazy ruszą, gdy ComfyUI się pojawi.
* To, co widać w oknie, to log mostka (banner z adresami + każdy request). Sprawdzone
  testami w Pyodide (37/37): wykrywanie instalacji, budowa komend, kolejka startu,
  przekazywanie argumentów, zajęty port, brak ComfyUI, `--keep-comfy`.

## `Start_Comfy_i_Hermes.bat` — jednoplikowy launcher (v4.3, 24.09.2026)

Dwuklik i masz wszystko: **środowisko ROCm → ComfyUI na `:8188` → sprawdzenie modeli →
mostek na `:8443` → weryfikacja całego stosu i raport**. Plik działa i z `AI.KURWA\`,
i z `AI.KURWA\comfyui-rocm-091926\` (sam znajduje `python_env`, mostek i
`workflow_api.json`). Zastępuje poprzednie wersje (v2/v3 wołające `comfyui-rocm.bat`) oraz
osobne narzędzie diagnostyczne `diagnoza_mostka.bat` (od v4 służy do tego `--check`).

Co doszło w v4:

* tryby: `--check` (tylko diagnoza, nic nie startuje, wynik na ekran i do
  `raport_mostka.txt`), `--stop`, `--restart`, `--test` (jedno krótkie zapytanie czatu
  przez mostek — dowód, że Hermes/OpenRouter działa), `--serve`, `--simple`, `--no-comfy`;
* na końcu **weryfikacja**: `/health` mostka, `sprawdz_comfy.py --no-wait`
  (GPU + brakujące modele) i `hermes_comfy_bridge.py --selftest` (workflow, ComfyUI, klucz
  OpenRoutera) — wszystko ląduje w `raport_mostka.txt` obok mostka;
* ostrzeżenie, gdy `tailscale serve status` pokazuje port `8188` — czyli gdy ComfyUI jest
  wystawione poza ten komputer (przy Funnelu: publicznie, bez hasła);
* `chcp 65001`, więc raport jest w UTF-8 (wcześniejsze raporty mieszały kodowania i miały
  „Przepisywacz â€”" zamiast „Przepisywacz —");
* gdy ComfyUI nie odpowie w `--wait`, launcher **diagnozuje**: sprawdza, czy proces
  ComfyUI w ogóle żyje, i pokazuje ostatnie 25 linii `user\comfyui.log` (zamiast czekać w
  ciszy) — a `rocm-sdk init` zgłaszający kod błędu nie wygląda już jak awaria (dopisek, że
  to zwykle „już zainicjalizowane", + informacja, gdy `HIP_PATH` wziął się z zapasowej
  ścieżki `_rocm_sdk_devel`);
* mostek startuje w **osobnym oknie** `Mostek Hermes` (launcher zostaje jako okno raportu);
  wcześniej biegł w tym samym oknie i Ctrl+C go kończył. Teraz kończy go zamknięcie tamtego
  okna albo `--stop`.

Co doszło w v4.2:

* **`Restart_Mostka.bat`** — dwuklik zamiast wpisywania `--restart` w cmd (samo `--restart` to
  argument, nie komenda — cmd odpowie „nie jest rozpoznawane jako polecenie”);
* raport wypisuje **`Parametry ComfyUI: …`** i honoruje zmienną `CHL_COMFY_PARAMS` (patrz niżej);
* raport porównuje **wersję mostka w kodzie z wersją działającego procesu** i mówi wprost
  `UWAGA: dziala STARSZY kod mostka - uruchom Start_Comfy_i_Hermes.bat --restart`, gdy plik na
  dysku jest nowszy niż to, co odpowiada na `/health` (to była realna pułapka: podmieniony
  `hermes_comfy_bridge.py` nie działa, dopóki nie zabijesz starego procesu).

Co doszło w v4.3:

* **`--bench`** (albo dwuklik `Zmierz_tempo.bat`) — po starcie całego stosu mierzy tempo
  ComfyUI (`bench_comfy.py`) i pisze `raport_wydajnosci.txt`; `--bench-runs=N`,
  `--bench-steps=N` zmieniają parametry pomiaru;
* **`--attn=X`** — `default` / `split` / `quad` / `pytorch` / `sage`: dokłada do startu ComfyUI
  odpowiednią flagę attention (`--use-split-cross-attention` itd.), żeby dało się porównać
  ustawienia bez edycji pliku. Po starcie launcher wypisuje **jaki attention faktycznie
  wstał** (linia z `user\comfyui.log`), więc wiadomo, co się właściwie mierzy;
* **`--restart-comfy`** — zamyka działający proces ComfyUI przed startem. Potrzebne przy
  zmianie flag startowych (`--attn=...`): proces, który już działa, ma stare parametry, więc
  bez tego „nowy" attention w ogóle by się nie włączył;
* **`CHL_COMFY_EXTRA`** — dopisuje flagi na koniec listy parametrów ComfyUI (obok
  `CHL_COMFY_PARAMS`, który nadal **zastępuje** całą listę);
* rozpoznawanie `--size 512x768` także w formie z odstępem (wcześniej tylko `--size=`);
* `Restart_Mostka.bat` bez zmian — dalej robi to samo, co `--restart`.

Co robi po kolei (widać w oknie, kroki `[1/5]`…`[4/5]`):

1. `rocm-sdk.exe init`, potem `rocm-sdk.exe path --root` — wynik idzie **do pliku** i jest
   czytany przez `for /f "usebackq"` (patrz „Sprawa `rocm-sdk`" niżej — to był cały problem).
   Gdyby SDK nic nie zwrócił, `HIP_PATH` bierze się z `python_env\Lib\site-packages\_rocm_sdk_devel`.
2. Architektura GPU z **torcha** (`torch.cuda.get_device_properties(0).gcnArchName`), czyli
   z tego samego źródła, którego użyje ComfyUI; `detect_gpu.py` tylko jako zapas. Dzięki temu
   `COMFYUI_ENABLE_MIOPEN=1` oraz ścieżki `MIOPEN_SYSTEM_DB_PATH`/`ROCBLAS_TENSILE_*` naprawdę
   włączają się dla `gfx1102`.
3. Start ComfyUI w osobnym, zminimalizowanym oknie (`start /min /d <pack> cmd /k`), jeśli port
   `:8188` jeszcze nie nasłuchuje — okno dziedziczy całe środowisko ROCm z punktów 1-2.
4. `sprawdz_comfy.py` czeka na `/system_stats` i sprawdza pliki modeli z workflow.
5. Sprzątanie VRAM po `koboldcpp` (możesz usunąć te dwie linie `powershell`) i start mostka
   w tym samym oknie; `--serve` dokłada `tailscale serve --bg --https=8443 http://127.0.0.1:8443`,
   każdy inny argument leci do mostka (np. `--no-refine`).

**Pułapka `netstat` + Tailscale:** nie sprawdzaj „czy mostek działa" przez
`netstat | findstr :8443` — `tailscale serve --bg --https=8443` trzyma `100.95.18.94:8443`
w stanie `LISTENING` (PID tailscaled), więc taki test zawsze skłamie „już działa". Zarówno
launcher, jak i `diagnoza_mostka.bat` pytają zamiast tego `http://127.0.0.1:8443/health`.
Na pętli lokalnej 8443 jest wolne, bo Serve binduje tylko adres tailnetu.

**Czasy generowania (RX 7600S, 8 GB, 19.09.2026, zmierzone bezpośrednio na ComfyUI):**

tej samej workflow co `workflow_api.json` (4x NMKD + hires): baza **512x768 → 120 s**,
baza **768x768 → 389 s** (obraz pośredni po 4x upscalerze ma wtedy 3072x3072). Minimalny
workflow `workflow_api_simple.json` (512x768, bez LoRy/upscalera) → **26 s**. Dlatego launcher
domyślnie dokłada mostkowi `--size 512x768`: aplikacja Chloe nie wysyła rozmiaru, a końcowy
obraz i tak skaluje node 14 do 1024x1536 — więc niższa baza nie zmienia wyniku, tylko czas.

**Raport z 19.09.2026** (`raport_mostka.txt`): pliki i Python OK, port 8443 wolny na
`127.0.0.1`, `--selftest` mostka: workflow 14 nodów, ComfyUI 0.33.0 odpowiada, klucz
OpenRoutera przyjęty (`sk-or-v1-126...541`), 768x768 — czyli **mostek jest sprawny**, a jedyną
przeszkodą był `netstat` w launcherze, który uznał listener Tailscale'a za mostek i nie
uruchomił procesu. Naprawione w `v3`.

**Raport z 21.09.2026 20:10** (ten sam plik, zrobiony jeszcze **starą** `diagnoza_mostka.bat`,
przed poprawką): reszta zielona, ale `[9]` mówi „mostek JUZ nasluchuje na 8443", podczas gdy
`[4]` pokazuje na 8443 wyłącznie `tailscaled` (PID 5428, adres tailnetu), a `[6]` tylko jeden
proces `python.exe` (828 MB = ComfyUI). To **fałszywy alarm netstata** — mostka wtedy nie było.
Wniosek: nie ufać `[9]` ze starych raportów; nowe narzędzie pyta `/health` (`--check`).

Wszystkie zmienne mają prefiks `CHL_` (nie `ROOT`, `PORT`, `PATH`): launcher ComfyUI
dziedziczy to środowisko, więc ogólne nazwy mogłyby mu coś nadpisać i zepsuć start.
Log ComfyUI, gdy coś pójdzie nie tak: `<folder pakietu>\user\comfyui.log`.

### Parametry startu ComfyUI i jak je zmienić (dodane 21.09.2026)

Launcher odpala `python.exe main.py` z:

```
--enable-cors-header * --disable-api-nodes --disable-triton-backend
```

(na starszych GPU typu `gfx101x`/`gfx103x` dochodzi jeszcze `--use-quad-cross-attention`),
a linijkę z parametrami wypisuje w raporcie jako `Parametry ComfyUI: …`.

* `--enable-cors-header *` — nagłówki CORS dla dostawcy „custom" z panelu Chloe; mostkowi
  (Python) nie jest to potrzebne, ale nie szkodzi.
* `--disable-api-nodes` — wyłącza wbudowane node'y wołające chmurę ComfyOrg; nie ruszamy z nich,
  więc tylko czyści UI.
* `--disable-triton-backend` — wyłącza backend `triton` z `comfy-kitchen`. W logu z tego
  powodu widać `Found comfy_kitchen backend triton: … 'disabled': True` oraz
  `[aiter] Windows: CK and HIP ops are not available. Triton ops only.` — czyli akceleracja
  `aiter`/triton **jest nieaktywna**. Backend `hip` zostaje włączony, więc liczenie działa
  normalnie, ale jeśli chcesz przetestować szybszy wariant, uruchom launcher z podmienionymi
  parametrami **bez edycji pliku**:

  ```
  set CHL_COMFY_PARAMS=--enable-cors-header * --disable-api-nodes
  Start_Comfy_i_Hermes.bat --restart
  ```

  (jeśli pojawi się błąd sterownika/wybuch, wróć do domyślnych przez `set CHL_COMFY_PARAMS=`).

### Gdy brakuje plików: `workflow_api_simple.json`

`workflow_api.json` to Twój workflow z LoRą `epiCRealismHelper.safetensors` i upscalerem
`4x_NMKD-Superscale-SP_178000_G.pth` — jeśli któregoś z tych plików nie ma w `models\loras`
/ `models\upscale_models`, ComfyUI odrzuci zadanie. Wtedy możesz ruszyć od razu na zapasowym,
minimalnym workflow, który potrzebuje **tylko checkpointu**:

```
Start_Comfy_i_Hermes.bat --workflow-file workflow_api_simple.json
```

Ma te same nody promptu (dodatni `2`, ujemny `3`) i `SaveImage`, więc mostek działa bez zmian;
launcher wykrywa ten argument i sprawdza właśnie ten plik. Mniej VRAM (512x768 bez hires
i bez upscalera), więc przydaje się też, gdy ComfyUI łapie OOM na 8 GB.

### `sprawdz_comfy.py` — czy modele z workflow są na dysku

```
python sprawdz_comfy.py                       # czekaj do 300 s i sprawdź wszystko
python sprawdz_comfy.py --no-wait             # nie czekaj, sprawdź teraz
python sprawdz_comfy.py --wait 600 --workflow workflow_api.json
```

Czeka, aż ComfyUI odpowie na `/system_stats` (wypisuje wersję ComfyUI, kartę, VRAM, torch),
potem pobiera `/object_info` tylko dla typów nodów z workflow i porównuje **każde** pole
z listy wyboru: checkpoint, LoRę, model upscalu, sampler, scheduler, metodę skalowania. Przy
brakach mówi wprost co i gdzie wgrać (`models\checkpoints`, `models\loras`,
`models\upscale_models`, `models\text_encoders`, `models\vae`, `models\diffusion_models`…)
i wypisuje, co ComfyUI widzi w tym folderze. Osobno zgłasza nieznane typy nodów (brak custom
node) i brak `SaveImage`/`PreviewImage`. Kody wyjścia: `0` ok, `1` ComfyUI nie wstał,
`2` brakuje plików. Zero zależności, Python 3.8+. Sprawdzone w Pyodide: `sprawdz_modele()` na
atrapie `/object_info` (brak LoRy, pusty folder upscalerów, nieznany typ noda), `opis_comfy()`
na pustych/śmieciowych `/system_stats`, `wczytaj_workflow()` na śmieciach, `main()` na martwym
porcie.

## CFG 6.0 w `workflow_api.json` (wdrożone 24.09.2026)

W obu samplerach (`5` = baza, `10` = hires) **CFG podniesione z 5 na 6.0**. Reszta bez zmian:
baza `dpmpp_2m` / `karras` / 25 kroków / denoise 1, hires 20 kroków / denoise 0.35. Powód:
zalecenie z analizy panelu („KSampler: 5.5–6.5") i typowy zakres dla realistycznego SD1.5
(EpicRealism) — CFG 5 dawał czasem mdłe, „wyprane" twarze przy mocnej negatywie, 6.0 trzyma
prompt mocniej, a jeszcze nie przypala kolorów. `_meta.title` obu nodów mówi teraz
„… - CFG 6.0", więc widać to też w interfejsie ComfyUI.

Mostek **nie wymaga restartu** po zmianie workflow: `load_workflow()` trzyma graf w pamięci,
ale kluczem jest `mtime` pliku, więc każdy zapis `workflow_api.json` jest widziany od razu.
Sam CFG da się też nadpisać pojedynczym żądaniem: `POST /api/generate {"prompt":…, "cfg":6.5}`
(mostek wstawia `steps`/`cfg`/`sampler_name` do **wszystkich** KSamplerów w grafie).

## Detal twarzy (FaceDetailer) i Ultimate SD Upscale — sprawdzone 24.09.2026

Sprawdzone na żywo, na Twoim ComfyUI 0.33.0 (`AMD Radeon RX 7600S : native`), przez
`/object_info` i próbne zakolejkowanie grafu.

**Inwentarz — co ComfyUI widzi:**

| Element | Stan |
|---|---|
| checkpoint | `epicrealism_naturalSinRC1VAE.safetensors` (tylko ten) |
| LoRA | `epiCRealismHelper.safetensors` (tylko ta) |
| modele upscalu | `4x_NMKD-Superscale-SP_178000_G.pth`, `RealESRGAN_x2plus.pth` — **brak `4x-UltraSharp`** |
| modele SAM | `sam_vit_b_01ec64.pth` — **jest** |
| modele ControlNet | **brak jakiegokolwiek** (`control_net_name` = pusta lista) |
| `FaceDetailer` | **jest** (Impact Pack `V8.28.3`, sygnatura z polami `cycle`, `wildcard`, `noise_mask_feather`, `tiled_encode/decode`) |
| `UltralyticsDetectorProvider` | **BRAK** |
| `UltimateSDUpscale` | **BRAK** |
| całość `workflow_api.json` | wszystkie nody i wszystkie listy wyboru zgadzają się z ComfyUI (launcher nie ma czego zgłaszać) |

### FaceDetailer: nod jest, detektora nie ma — i dlaczego

`FaceDetailer` **jest częścią** Impact Packu, ale `UltralyticsDetectorProvider` (ten, który
wykrywa twarze i zwraca `BBOX_DETECTOR`) **nie** — od Impact Packu V8 jest w osobnym pakiecie
**`ComfyUI Impact Subpack`** (cytat z README Impact Packu: *„The UltralyticsDetectorProvider
node is not part of the ComfyUI-Impact-Pack… please install the ComfyUI-Impact-Subpack
separately"*, a od V8 Subpack nie instaluje się automatycznie). `bbox_detector` jest w
`FaceDetailer` polem **wymaganym**, więc bez Subpacku detal nie ruszy.

Dwie drogi naprawy (druga jest po to, żeby nie trzeba było klikać w Managerze):

1. **ComfyUI-Manager → Install Custom Nodes → „ComfyUI Impact Subpack"** (autor `ltdrdata`),
   restart ComfyUI. Manager sam uruchomi `install.py` Subpacku, który dodatkowo ściąga
   `face_yolov8m.pt`, `hand_yolov8s.pt` i `person_yolov8m-seg.pt`.
2. **Dwuklik `Dodaj_detektor_twarzy.bat`** — wgrywa Subpack z kopii na uploads (zapasowo z
   GitHuba, bez gita) i woła `instaluj_detektor_twarzy.py`, który dokłada zależności i ściąga
   sam model twarzy.

Zależności Subpacku to `matplotlib`, `ultralytics>=8.3.162`, `numpy`,
`opencv-python-headless`, `dill`. **Uwaga na ROCm:** zwykłe `pip install ultralytics` potrafi
podmienić `torch`/`torchvision` na wersję CUDA i wtedy ComfyUI przestaje widzieć kartę —
dlatego `instaluj_detektor_twarzy.py` instaluje **wyłącznie z `--no-deps`**, sam sprawdza
`find_spec` każdego brakującego modułu, a gdy import `YOLO` nadal nie działa, czyta nazwę
modułu z `ModuleNotFoundError: No module named 'X'` i dokłada tylko `X`. Skrypt wypisuje
wersję `torch` przed i po instalacji, żeby było widać, że jest ta sama (`…+rocm…`), i **nie**
dokłada `opencv-python-headless`, jeśli `cv2` już jest (dwa opakowania opencv nadpisałyby
sobie pliki).

Kiedy detektor już wstanie (launcher wypisze `[OK] UltralyticsDetectorProvider`):

```
python dodaj_facedetailer.py --dry-run     # plan: co i gdzie zostanie wpięte
python dodaj_facedetailer.py               # wpisuje detal do workflow_api.json
python dodaj_facedetailer.py --sam         # dodatkowo maska z SAM (masz sam_vit_b_01ec64.pth)
python dodaj_facedetailer.py --test        # od razu próbna generacja z raportem błędów ComfyUI
python dodaj_facedetailer.py --remove      # cofnięcie
```

Co ten skrypt ustawia (wartości z panelu: denoise 0.35–0.40, crop factor 3.0, feather 16, plus
to, co wymaga SD1.5): `denoise 0.40`, `guide_size 512` (`--guide-size 384` = szybciej),
`max_size 1024`, `feather 16`, `bbox_crop_factor 3.0`, `bbox_threshold 0.5`,
`bbox_dilation 10`, `steps` = tyle co w bazowym KSamplerze, `cfg 6.0`, `cycle 1`,
`scheduler karras`, `sampler_name dpmpp_2m`. Nowe nody dostają to samo, czym maluje się cały
kadr: `model` z LoRy, `vae` z VAE Decode, `positive`/`negative` z nodów `2`/`3` — dzięki temu
twarz nie jest „doklejona" w innym stylu, a mostek podmienia w nich prompt razem z resztą.
Detal jest wpinany **przed** `ImageUpscaleWithModel` (na 512x768 jest taniej, a drugi KSampler
i tak domalowuje detale po powiększeniu). Kopia oryginału: `workflow_api.backup-fd.json`.

Mostek v8 dokłada jedno: nody z polem `seed`, które nie są KSamplerami (czyli właśnie
`FaceDetailer`), dostają ziarno zadania + 1. Bez tego detal liczyłby zawsze ten sam szum, mimo
że baza jest losowa. Widać to w `/health` → `features` zawiera `detail_seeds`, a licznik
`detail_seeds` trafia do `last.json` i pliku `.txt` obok obrazu.

### Mostek v9: koniec wiszenia na 15 minut (24.09.2026)

v9 nie zmienia obrazu — zmienia **diagnostykę** i zachowanie przy awariach:

- **`/health` ma pole `job`** — np. `{"stage": "comfy", "prompt_id": "1a2b3c4d", "elapsed_s": 41.2}`.
  Widać, na czym mostek stoi: `start` → `refine` (przepisywanie promptu przez Hermesa) → `comfy`
  (malowanie). Strona `/` pokazuje to samo („Teraz robi: …"). Bez tego trzeba było zgadywać, czy
  mostek czeka na OpenRouter, czy na ComfyUI.
- **Odrzucony graf jest nazwany po imieniu.** ComfyUI przy walidacji zwraca `node_errors` —
  v9 zamienia to na `ComfyUI odrzucilo graf — wezel 5 (KSampler): Required input is missing: model`.
  Wcześniej leciał albo ogólnik, albo (gdy ComfyUI zwrócił 200 z `node_errors`) mostek czekał
  bezsensownie na zadanie, którego ComfyUI nigdy nie uruchomił.
- **Watchdog restartu ComfyUI.** Jeśli zadanie zniknie jednocześnie z `/queue` i z `/history`
  (`restart_misses` = 5 odpytań po `poll` = ok. 6 s), mostek przerywa z komunikatem
  `ComfyUI zrestartowalo sie w trakcie generowania …` zamiast trzymać `JOB_LOCK` i blokować
  aplikację do końca `--timeout` (domyślnie 900 s). Nowa opcja: `--restart-misses` (albo
  `restart_misses` w `bridge_config.json`).
- **Błąd wykonania noda zamiast „blad noda".** `ComfyUI przerwal generowanie — wezel 12
  (SaveImage): CUDA out of memory…` — z numerem, typem noda i `exception_message`. Osobno
  rozpoznawany jest `execution_interrupted`, czyli Cancel/Interrupt w ComfyUI.

### Mostek v10: klucz OpenRoutera także od klienta (24.09.2026)

Wykryte przy wdrożeniu Chloe 2.0: **mostek v9 miał włączone tylko własne pole `api_key`**
(`openrouter_key.txt` / `--openrouter-key` / `OPENROUTER_API_KEY`). Aplikacja Chloe wysyła
swojego klucza w nagłówku `Authorization`, ale mostek go ignorował — więc gdy mostek nie miał
własnego klucza, **każdy czat kończył się błędem OpenRoutera**:

```text
401 {"error": {"message": "No cookie auth credentials found", "code": 401}}
```

Objaw był podstępny: `/health` pokazywał `last_chat.requested` z poprawną nazwą modelu, obraz
się generował, a czat nie odpowiadał. Diagnoza w jednym miejscu: strona `http://127.0.0.1:8443/`
→ `api_key: BRAK`.

v10 to naprawia: `upstream_headers()` bierze najpierw własny klucz mostka, a gdy go nie ma —
klucz z nagłówka `Authorization` zadania (czyli ten wpisany w panelu Chloe). `/health` ma teraz
pole **`key_source`**: `wlasny (…)` | `klienta (Authorization z aplikacji Chloe)` |
`BRAK - czat zwroci 401`. Własny klucz nadal ma priorytet, więc nic nie zmienia się dla tych,
którzy wpisali klucz do pliku.

Wariant bez podmiany kodu (v9 i starsze): wklej klucz do pliku `openrouter_key.txt` obok
`hermes_comfy_bridge.py` (jedna linia, bez cudzysłowów) i uruchom `Restart_Mostka.bat`.

### Mostek v11: tryby obrazu (presety) + szybszy workflow (25.09.2026)

Zmiana jest dwuczęściowa i obie części są potrzebne razem:

1. **Nowe pliki workflow** (opis i pomiary: `NSFW_CONFIG.md`). Stary `workflow_api.json`
   liczył bazę 768x768 (mostek nadpisywał rozmiar z pliku), potem robił z tego 4x upscalerem
   3072x3072 i zmniejszał do 1024x1536 — **63,7 s na obraz**. Nowy domyślny plik to
   **768x1152 natywnie, 20 kroków (~18 s)** i wypada lepiej w ocenie jakości; tryb `fast`
   (512x768 + ESRGAN 2x) robi obraz w **~3-4 s**.
2. **Mostek v11** umie wybierać „tryb" (plik workflow + parametry + rozmiar + checkpoint):

```json
// bridge_config.json
{ "preset": "fast",
  "presets": { "moj_sdxl": { "workflow_file": "workflow_sdxl_cfg8.json",
                             "checkpoint": "lustifySDXLNSFW_endgame.safetensors" } } }
```

Presety wbudowane: `default`, `fast`, `classic`, `sdxl_fast`, `sdxl_cfg8`, `sdxl_hq`.
Tryb wybiera się też **per zadanie** polem `preset` w `/api/generate` lub
`/images/generations` (`workflow`/`tryb`/`mode`/`quality` działają jako aliasy).

Co doszło w API (nic nie zniknęło):

* pola żądania: `preset`, `size`, `steps`, `cfg`, `sampler`, `scheduler`, `denoise`, `checkpoint`;
* pola odpowiedzi: `tryb`, `workflow`, `sampling`, `ms`, **`ms_comfy`**, **`ms_refine`**
  (rozdzielony czas ComfyUI i przepisywacza — widać, co naprawdę zjada sekundy);
* `/health`: `tryb`, `tryby` (opis każdego presetu: plik, rozmiar, parametry, czy plik istnieje),
  `last_image` (ostatni tryb i czasy);
* **kontrola modeli przed kolejką**: jeśli w grafie jest checkpoint/LoRA/VAE/upscaler, którego
  ComfyUI nie widzi, mostek zwraca po polsku co i gdzie brakuje (i podpowiada podobne pliki
  z folderu) zamiast `value not in list` z ComfyUI;
* **rozmiar**: `size` z żądania > rozmiar presetu > `cfg.size` > rozmiar z pliku workflow
  (żeby o rozmiarze decydował plik, wpisz `"size": "auto"`).
  To naprawia też starą pułapkę: `cfg.size` (domyślnie `768x768`) nadpisywał rozmiar z workflow.

Przy przełączaniu modeli bazowych (realistic ↔ anime) nie trzeba już edytować JSON-a workflow —
wystarczy `"checkpoint": "plik.safetensors"` w presecie albo w żądaniu.

Pod `full hard NSFW` mostek v11 jest gotowy na SDXL; brakuje tylko samego checkpointu —
`Pobierz_modele_NSFW.bat` (LUSTIFY SDXL NSFW, CyberRealisticXL Play, WAI-NSFW-Illustrious,
Pony V6 XL, Hassaku) plus LoRA Lightning/Hyper-SD, które są już zainstalowane przez
ComfyUI-Manager. Zalecane ustawienia i taktyki promptowania: `NSFW_CONFIG.md`.

### Mostek v12: automatyczny dobór checkpointu + naprawa pobieracza (25.09.2026)

Dwie rzeczy, które sprawiają, że „pobierz model i działa" faktycznie działa:

1. **Automatyczny dobór checkpointu** (`checkpoint_autopick`). Jeśli graf wskazuje plik,
   którego nie ma na dysku, a w `models/checkpoints` leży inny model **tej samej rodziny**
   (preset ma teraz pole `family`: `sd15` dla `default`/`fast`/`classic`, `sdxl` dla
   `sdxl_*`), mostek podstawia go, loguje podmianę i zwraca ją w odpowiedzi jako
   `checkpoint_auto` (widać też w `/health` → `last_image.checkpoint_auto` i na stronie
   statusu). Efekt: po pobraniu LUSTIFY/WAI/CyberRealisticXL **nie trzeba ruszać
   `bridge_config.json`** — wystarczy wybrać tryb `sdxl_cfg8`. Świadomie NIE podmienia
   modelu z innej rodziny (SD1.5 w graf SDXL dawałby śmieci) — wtedy nadal jest czytelny
   błąd o brakującym pliku. Wyraźnie zadany `checkpoint` (preset/żądanie) jest zawsze
   honorowany i nigdy nie nadpisywany.
2. **`Pobierz_modele_NSFW.bat` naprawiony**: plik miały końce linii LF (jak w Linuksie),
   a cmd.exe przy LF gubi pozycję w pliku po `set /p` / `call :etykieta` i **zamyka okno
   bez komunikatu** — dokładnie to było widać po wybraniu opcji i naciśnięciu Enter.
   Teraz plik jest CRLF, bez `chcp` (zmiana strony kodowej psuje `set /p`), a cała praca
   idzie przez `call :main`, więc nawet błąd wraca do menu, a nie zamyka okna. Doszło:
   przeciąganie folderu ComfyUI na plik, klucz `S` = sprawdź co masz (zamiast `C`),
   potwierdzenie przy `A` (~25 GB), podpowiedź po pobraniu (jaki tryb + wpis do
   `bridge_config.json`), `--connect-timeout` w curl.exe.
3. **Pobieracz nie może już „mrugnąć"**. Zgłoszony objaw: okno cmd pojawia się na ułamek
   sekundy i znika, bez żadnego komunikatu. Nie da się tego zdiagnozować zdalnie, więc
   plik **startuje teraz sam w osobnym oknie przez `cmd /k`** (zabezpieczenie przed
   pętlą: argument `__okno` + zmienna `CHL_POB_STARTED`) — cokolwiek się stanie, okno
   zostaje otwarte i widać komunikat błędu. Dodatkowo każdy krok (start, folder ComfyUI,
   wybór, każdy plik, każdy błąd) leci do `pobieranie_log.txt` obok skryptu, więc nawet
   gdyby okno zniknęło, wiadomo, gdzie się zatrzymało. Plan B bez `.bat` w ogóle:
   `POLECENIA_curl.txt` — gotowe linijki `curl.exe` do wklejenia w zwykłe okno cmd.
4. **Prawdziwa przyczyna „mrugnięcia"** (znaleziona z `pobieranie_log.txt` 25.09.2026):
   lista stanu (`call :stan`) drukowala opisy z nawiasami — np. `epicRealism (SD1.5,
   domyslny)` — wewnątrz bloku `if exist ( ... ) else ( ... )`. cmd dokleja rozwinięcie
   `%~2` do tekstu bloku, gubi przez ten nawias jego koniec i **przerywa cały skrypt**
   (bez szansy na zobaczenie błędu). Log pokazał, że skrypt dochodzi do `ComfyUI: …` i tam
   ginie. Poprawka: opisy i ścieżki idą do echa przez zmienne opóźnione (`!OPIS!`, `!CEL!`,
   `!URL!`, `!PLIK!`) — one rozwijają się dopiero w czasie wykonania, więc nawiasy w treści
   nie mogą już rozbić bloku; `:stan` i autodetekcja folderu nie mają żadnego bloku
   nawiasowego (zamiast tego etykiety + `goto`), a w opisach nie ma nawiasów.
   **Zasada na przyszłość: `%~1`/`%VAR%` z nawiasami nigdy nie może trafić do `echo`
   wewnątrz `( ... )` w tym pliku.**
5. **Tryby SDXL zmierzone na prawdziwym modelu** (LUSTIFY SDXL endgame + `sdxl_vae`,
   RX 7600S 8 GB, `--lowvram`). Pierwszy przebieg po zmianie trybu ~70 s (wczytanie 6,9 GB
   checkpointu), ciepłe: `sdxl_cfg8` **21,8 s**, `sdxl_fast` **22,1 s**, nowy `sdxl_std`
   **42,6 s**, `sdxl_hq` **123-152 s**. Bezpośrednie A/B na tym samym seedzie: 8-krokowe
   warianty z destylacją mają „woskową" skórę, kolorowe plamki i słabszą anatomię
   (realizm 6/10, anatomia 4/10), a `sdxl_std` bez destylacji daje realizm 8,5/10 i
   anatomię 7,5/10; `sdxl_hq` bywa lepszy, ale na części seedów hires rozjeżdża anatomię,
   więc nie jest wart 3x czasu. Dlatego **`sdxl_std` to zalecany tryb jakości**, a
   `sdxl_cfg8`/`sdxl_fast` zostały jako szybkie podglądy. Pełna tabela: `NSFW_CONFIG.md`
   sekcja 5.2.

Testy: `tests/test_bridge_presets.py` mają teraz sekcję `[11]` na dobór checkpointu
(61 asercji, bez sieci i GPU).

### Pomiar tempa: `--bench` i `Zmierz_tempo.bat` (dodane 24.09.2026)

Ten sam graf potrafi iść **4 s/krok albo 26 s/krok** — na `workflow_api.json` zmierzono oba
przypadki w odstępie kilku minut, bez żadnej zmiany w workflow (identyczne komunikaty
„prepared for dynamic VRAM loading"). Ponieważ nie da się tego odróżnić po wyglądzie, jest
pomiar:

```
Zmierz_tempo.bat                                  (dwuklik = Start_Comfy_i_Hermes.bat --bench)
Zmierz_tempo.bat --attn=split --restart-comfy     (--use-split-cross-attention)
Zmierz_tempo.bat --attn=pytorch --restart-comfy   (--use-pytorch-cross-attention)
```

`--restart-comfy` jest tu ważne: ComfyUI, który już działa, ma parametry z momentu startu —
bez zamknięcia procesu nowa flaga attention nie zadziała. Sam `--bench` nie wymaga restartu
(mierzy to, co działa w tej chwili).

`bench_comfy.py` podmienia w Twoim workflow liczbę kroków KSamplerów na małą (domyślnie 3,
opcja `--bench-steps=N`), losuje ziarno, wysyła zadanie do ComfyUI i mierzy **s/krok osobno dla
base passu i dla hires** — czyli to, co realnie decyduje o czasie obrazu. Obrazów nie zapisuje
(prefix `bench/`), więc galeria zostaje czysta. Wynik leci na ekran, do `raport_wydajnosci.txt`
i do JSON-a (`--json`, gdy chcesz surowe dane).

Werdykt na końcu raportu:

| Kod wyjścia | Znaczenie |
|---|---|
| `0` | stabilnie — wszystkie przebiegi w podobnym czasie |
| `1` | błąd (brak ComfyUI, zły workflow, odrzucony graf) |
| `2` | **wolny tryb** — jeden przebieg ≥2,5x wolniejszy od najszybszego |

Jak tym sterować: `--attn=X` dokłada do startu ComfyUI flagę attention (`split`, `quad`,
`pytorch`, `sage`, `default` = bez flagi). `CHL_COMFY_PARAMS` nadal **zastępuje** całą listę
parametrów, a `CHL_COMFY_EXTRA` tylko **dopisuje** na końcu. Launcher po starcie wypisuje też,
jaki tryb attention faktycznie wstał (linia z `user\comfyui.log`), więc wiadomo, co było
mierzone.

Uwaga praktyczna: gdy w ComfyUI pasek mieli się w tempie kilkunastu–kilkudziesięciu s/it,
**Cancel i powtórka tego samego zadania** była w pomiarach 1,8–4,5x szybsza. Zanim zaczniesz
zmieniać flagi — sprawdź, czy to nie ten przypadek.

### Ultimate SD Upscale: nie polecam na tym sprzęcie (na razie)

`UltimateSDUpscale` nie jest zainstalowany i **nie ma z czego go zrobić**: brakuje trzech
rzeczy naraz — samego nodu (`ComfyUI_UltimateSDUpscale` od `ssitu`), modelu `4x-UltraSharp`
(ok. 67 MB; masz tylko NMKD i RealESRGAN), no i **jakiegokolwiek** ControlNetu (panel zakłada
„ControlNet: Tile Resampling", a `models\controlnet` jest pusty — model tile dla SD1.5 to
kolejne ~723 MB). Do tego panel podaje kafel `1024x1024`, co jest wartością dla SDXL —
przy SD1.5 daje powtórzone detale; dla EpicRealism sensowny kafel to **512–768 przy denoise
0.2–0.25** (i tak trzeba by to przestroić).

Co ważniejsze: USDU **dublowałby robotę, którą już robisz**. Twój łańcuch
`4x NMKD → ImageScale(lanczos) do 1024x1536 → KSampler(denoise 0.35)` to w praktyce hires-fix
z modelem upscalu i daje obraz 2K. USDU zamienia ten mechanizm na kafelkową dyfuzję — przewaga
jest w detailu skóry przy wyższym denoise, ale kosztem kolejnych minut na 8 GB (baza 512x768 to
~2 min, a przebieg po 1024x1536 jest kilkukrotnie droższy). Rekomendacja: **zostaw obecny
łańcuch**, a jeśli kiedyś najważniejszy będzie detal skóry — wtedy Subpack już masz, więc patrz
najpierw na `SEGSUpscaler`/`PixelTiledKSampleUpscalerProvider` z Impact Packu (nie wymagają
ControlNetu) przed dociąganiem USDU.

## Sprawa `rocm-sdk` — ROZWIĄZANA (21.09.2026)

**ROCm nigdy nie był zepsuty.** WinError 123 („Nazwa pliku, nazwa katalogu lub składnia
etykiety woluminu jest niepoprawna") nie pochodził z `rocm-sdk`, tylko z **błędu cmd**.
Launcher czytał ścieżkę SDK tak:

```
for /f "delims=" %%i in ('"%PYTHON_DIR%\Scripts\rocm-sdk.exe" path --root') do set "HIP_PATH=%%i"
```

Gdy polecenie w apostrofach zaczyna się od cudzysłowu, cmd gubi cudzysłowy, nie znajduje
programu i wypisuje właśnie ten komunikat — a `>nul 2>&1` przy `rocm-sdk init` ukrywał
wszystko, więc w oknie zostawało tylko `[WARN]`. Skutek: puste `HIP_PATH`/`ROCM_PATH` i puste
`GPU_ARCH` (drugi `for /f`, ten od `detect_gpu.py`, miał dokładnie ten sam problem), więc blok
MIOpen dla `gfx1102` był pomijany.

Dowody, że SDK i torch są zdrowe — `raport_rocm_sdk.txt` z `diagnoza_rocm.bat` (19.09.2026):

| Sprawdzenie | Wynik |
|---|---|
| `rocm-sdk init` / `rocm-sdk path --root` | kod `0`, ścieżka `…\python_env\Lib\site-packages\_rocm_sdk_devel` |
| `rocm-sdk targets` | `gfx1102` na liście |
| `hipconfig --version` | `7.16.26332-d134b7823f` |
| `detect_gpu.py` | `gfx1102` (`AMD Radeon RX 7600S`, `DEV_7480`) |
| `torch` | `2.13.0+rocm10.1.0a20260822`, `is_available()=True`, `gcnArchName=gfx1102`, 8 GB, testowa operacja OK |
| Windows | sterownik `32.0.31041.1004` z 17.08.2026, urządzenie `Status: OK` |

Podobnie `_rocm_sdk_core` / `_rocm_sdk_devel` / `_rocm_sdk_libraries` mają komplet DLL-i
(`amdhip64_7.dll`, `MIOpen.dll`, `MIOpenCKGroupedConv_gfx1102.dll`, `hipblas.dll`, `rocblas`…),
a wpisy `C:\Users\Vinay\Projects\…pdb` czy `D:\a\1\…` w plikach `.exe` to zwykłe ścieżki
z kompilacji — nie znaczą, że instalacja była przenoszona.

**ComfyUI też wstaje.** `comfyui-run.log` (uruchomienie z poprawionym czytaniem ścieżek,
17.09.2026 21:32) dochodzi do końca bez błędu:

```
[INFO] HIP_PATH: …\python_env\Lib\site-packages\_rocm_sdk_devel
[INFO] GPU arch: gfx1102          [INFO] MIOpen: 1
[INFO] Total VRAM 8176 MB, total RAM 32507 MB
[INFO] AMD arch: gfx1102          [INFO] ROCm version: (7, 16)
[INFO] Device: cuda:0 AMD Radeon RX 7600S : native
[INFO] Starting server
[INFO] To see the GUI go to: http://127.0.0.1:8188
```

Czyli **nie trzeba nic przeinstalowywać ani odświeżać ROCm/torch w `python_env`** — wystarczy
uruchamiać ComfyUI przez `Start_Comfy_i_Hermes.bat` v2 (albo samemu ustawić `HIP_PATH` ze
`rocm-sdk path --root` odczytanego **przez plik**, nie przez `for /f` z cudzysłowem).

Pliki diagnostyczne zostają w repo na wszelki wypadek: `sprawdz_comfy.bat` (raport środowiska →
`raport_comfy.txt`), `diagnoza_rocm.bat` + `diagnoza_rocm.py` (raport ROCm/SDK →
`raport_rocm_sdk.txt`), `comfyui-rocm-gfx1102.bat` (kopia Twojego launchera z tymi samymi
poprawkami — do odpalania samego ComfyUI bez mostka). Awaryjnie obrazy nadal mogą iść przez
AI Horde (`provider:"horde"`), bez GPU.

## Uruchomienie

1. Uruchom **ComfyUI** (domyślnie `http://127.0.0.1:8188`).
2. Wygeneruj klucz na <https://openrouter.ai/keys> i wpisz go do `openrouter_key.txt`
   (albo podaj `--openrouter-key sk-or-...`, albo ustaw zmienną `OPENROUTER_API_KEY`).
3. W katalogu z mostkiem:

```
python hermes_comfy_bridge.py
```

4. Najpierw sprawdź wszystko jednym poleceniem (workflow, ComfyUI, klucz):

```
python hermes_comfy_bridge.py --selftest --selftest-scene "klęczy nago na łóżku, zbliżenie"
```

Chcesz przetestować też realną generację: dodaj `--selftest-gen`.
Status mostka możesz podejrzeć w przeglądarce: <http://127.0.0.1:8443/> (widać kolejkę,
konfigurację i ostatni prompt).

## Dostęp z telefonu (HTTPS)

Panel Obrazy wymaga adresu **HTTPS**, więc wystaw mostek przez Tailscale Serve (TLS robi
Tailscale, mostek zostaje czystym HTTP na pętli lokalnej):

```
tailscale serve --bg --https=8443 http://127.0.0.1:8443
```

Telefon musi być w tym samym tailnecie. Adres do panelu to wtedy
`https://<twoj-host>.<twoj-tailnet>.ts.net:8443`.

## Co wpisać w panelu Chloe (⚙️ / `/model`)

Adres zależy od tego, skąd wchodzisz:

* **ten sam komputer** (mostek na 127.0.0.1) → `http://127.0.0.1:8443`
  Pętla lokalna jest wyjątkiem od blokady mixed-content, więc strona po HTTPS może
  wołać `http://127.0.0.1` (Chrome/Brave z Local Network Access może raz zapytać o zgodę).
* **telefon / inny komputer w tailnecie** → `https://<host>.<tailnet>.ts.net:8443`
  (Tailscale Serve z sekcji wyżej); wtedy `127.0.0.1` wskazywałby samo urządzenie.

| Gdzie | Wartość |
|---|---|
| Zakładka **model** → Base URL | `http://127.0.0.1:8443` (mostek sam doda `/v1/chat/completions`) |
| Zakładka **model** → klucz API | puste (mostek trzyma klucz OpenRoutera) **chyba że** uruchomiłeś z `--token`, wtedy token |
| Zakładka **obrazy** → dostawca „Stheno → ComfyUI" (localflow) → Base URL | `http://127.0.0.1:8443` (mostek sam doda `/api/generate`) |
| Zakładka **obrazy** → dostawca „własny endpoint" (custom) → Base URL | `http://127.0.0.1:8443` (mostek sam doda `/images/generations`) |

Czyli **jeden adres obsługuje i czat, i obrazy** — nie musisz już rozdzielać
`…ts.net/` i `…ts.net:8443`.

### Ustawienie, na którym pracuje aplikacja (stan na 15.09.2026)

Zapisane w `localStorage` przeglądarki (nie w kodzie — kod jest publiczny):

* `chloe_backend_v2`: `backend:"kobold"`, `baseUrl:"http://127.0.0.1:8443"`,
  `localFlowBaseUrl:"http://127.0.0.1:8443"`, `model:"nousresearch/hermes-3-llama-3.1-70b"`,
  `directToComfy:false` (czyli mostek dopracowuje prompt przez Hermesa — `refine:true`).
* `chloe_cloudimg_v1`: `provider:"localflow"` (ścieżka `POST /api/generate` — ma kolejkę,
  retry na 409/429/503 i podgląd promptu `/obraz prompt`), `customBaseUrl` i `comfyBaseUrl`
  ustawione na ten sam adres (przełączenie dostawcy = jedno kliknięcie), rozmiar 768x768.
  Kopia obu kluczy siedzi też w `customData.__chloeKv` postaci Chloe (fallback).

Wybór `localflow` zamiast `custom` jest celowy: `/api/generate` czeka, aż GPU będzie wolne,
a `/images/generations` przy zajętym GPU zwraca 503 i aplikacja pokazałaby błąd.
Klucz OpenRoutera w polu „klucz API" panelu jest zbędny (mostek ma własny), ale nie szkodzi.

Sprawdzone 15.09.2026 z żywej strony: `GET /health` → 200, `POST /v1/chat/completions`
(stream i nie-stream) działa, `POST /api/generate` przy wyłączonym ComfyUI zwraca czytelny
błąd „brak polaczenia z ComfyUI pod http://127.0.0.1:8188".

## Endpointy

| Metoda | Ścieżka | Do czego |
|---|---|---|
| GET | `/health` | stan + `busy` (aplikacja czeka w kolejce, gdy GPU zajęte) |
| GET | `/` | strona statusu z ostatnim promptem i obrazem |
| GET | `/last` | JSON ostatniego zadania |
| GET | `/v1/models` | lista modeli (przycisk „test" w panelu) |
| GET | `/v1/api/extra/true_max_context_length` | budżet kontekstu (131072) |
| POST | `/v1/chat/completions` | czat: przekazanie do OpenRoutera (stream i zwykły JSON) |
| POST | `/api/generate` | obrazy dla dostawcy „localflow" (aplikacja Chloe) |
| POST | `/images/generations` | obrazy dla dostawcy „custom" (zgodne z OpenAI) |
| POST | `/api/refine` | tylko przepisanie scenki na prompt (do testów) |
| GET | `/images/<plik>` | serwowanie wygenerowanych obrazów |

Uwaga o CORS: mostek przepuszcza wyłącznie origin `*.perchance.org` oraz `localhost`.
Inne originy odrzuca (można rozszerzyć `--allow-origin`).

## Najważniejsze opcje

```
--port 8443                    port (domyślnie 8443)
--host 127.0.0.1               interfejs nasłuchu
--openrouter-key sk-or-...     klucz OpenRoutera
--model <id>                   model czatu (domyślnie Hermes 3 70B)
--fallback-models a,b,c         łańcuch modeli awaryjnych (domyślnie cydonia, mistral-small-2603, deepseek-v4-flash-0731)
--no-fallbacks                 bez łańcucha awaryjnego
--no-session-cache             bez sticky sesji (i bez cache promptu)
--data-collection deny|allow   polityka providera (domyślnie deny = nie trenujący na danych)
--refine-model <id>            osobny model do przepisywania promptów obrazu
--no-refine                    nie przepisuj promptu (scenka idzie wprost)
--direct-default               domyślnie tryb „wprost"
--comfy http://127.0.0.1:8188  adres ComfyUI
--workflow-file workflow_api.json
--pos-node 2 --neg-node 3      nody promptu dodatniego i negatywy
--latent-node <id>             nod rozmiaru (domyślnie auto: EmptyLatentImage)
--size 832x1216                domyślny rozmiar
--out-dir images               katalog na wyniki
--timeout 900 --poll 1.2       limit generowania i odstęp odpytywania
--restart-misses 5             ile odpywan bez zadania w ComfyUI = jego restart (v9)
--token <token>                wymuś `Authorization: Bearer <token>` na POST-ach
--allow-origin <regex>         dodatkowe originy CORS
--config bridge_config.json    plik z domyślnymi ustawieniami
--selftest [--selftest-scene ...] [--selftest-gen]
```

## Jak to działa w środku

1. **Czat**: mostek podstawia model, jeśli aplikacja go nie podała, dodaje
   `stream_options.include_usage` przy streamingu i przekazuje odpowiedź SSE linia po linii
   (klient Chloe normalnie ją parsuje). Klucz OpenRoutera nigdy nie trafia do przeglądarki.
2. **Obraz**: `prompt` ze scenki (PL) → Hermes z systemowym promptem „prompt engineer"
   (twarde zasady: zachowaj każdy szczegół seksualny, nie ubieraj z powrotem, nie dodawaj
   osób/tekstu, jedna linia tagów) → sprzątanie wyniku (fences, wstępniaki, przecinki) →
   wstrzyknięcie w workflow → `POST /prompt` → `GET /history/{id}` → `GET /view` →
   zapis PNG + plik `.txt` z użytym promptem i negatywą.
3. **Negatywa**: negatywa z aplikacji jest scalana z wbudowanym `NEGATIVE_CORE`
   (anty-cenzura: brak mozaiki, brak ubrań na kroczu, brak zsuniętych ud, brak rąk
   zasłaniających, poprawne dłonie) i wpisywana do noda negatywy.
4. **Kolejkowanie**: `/health` raportuje stan kolejki ComfyUI, a aplikacja sama czeka, gdy
   GPU jest zajęte; dodatkowo mostek serializuje zadania zamkiem (jedno GPU = jeden job).

## Rozszerzenia OpenRoutera: fallbacki, sticky sesja, polityka danych

Mostek dokłada do każdego zadania czatu (i do przepisywacza promptu) trzy pola OpenRoutera —
wszystkie sprawdzone w dokumentacji (prompt-caching, provider-routing) 21.09.2026:

* `models[]` — **łańcuch modeli awaryjnych**. Gdy model główny zawiedzie (provider blokuje
  prompt, moderacja, rate limit, downtime, za małe okno kontekstu), OpenRouter sam próbuje
  kolejnych i liczy tylko ten, który odpowiedział. Domyślnie:
  `thedrummer/cydonia-24b-v4.1` (nieocenzurowany finetune RP) →
  `mistralai/mistral-small-2603` (najostrzejszy seks wg ludzi, 262k kontekstu) →
  `deepseek/deepseek-v4-flash-0731` (0% odmów, 1,3M kontekstu, najtańszy). Wszystkie ID
  sprawdzone w `/api/v1/models` (440 modeli, żaden nie ma `is_moderated`).
  Zmiana: `--fallback-models "id1,id2"`, wyłączenie: `--no-fallbacks`.
* `session_id` — **sticky routing**: OpenRouter przykleja rozmowę do tego samego providera,
  dzięki czemu cache promptu trafia między turami (cache read jest ~10–15× tańszy od
  zwykłego inputu, a providerzy tacy jak DeepSeek/Gemini/OpenAI cachują automatycznie).
  Identyfikator bierze się kolejno z: nagłówka `X-Session-Id`, pola `session_id` w ciele,
  odcisku rozmowy (system + pierwsza wiadomość usera + model). Wyłączenie:
  `--no-session-cache`.
* `provider.data_collection: "deny"` — **tylko providerzy, którzy nie zbierają danych**
  (domyślna wartość OpenRoutera to `allow`). Zmiana: `--data-collection allow`.

Stan widać w `/health` (`fallbacks`, `session_cache`, `data_collection`, a także `last_chat`
z `"fallback": true`, gdy odpowiedział model z łańcucha) oraz w `--selftest`, który
dodatkowo sprawdza, czy każdy model awaryjny naprawdę istnieje na OpenRouterze.

Strona aplikacji: `chloeE2Chat()` dokłada do ciała żądania `session_id`
(`chloeCacheSessionId()`, identyfikator wątku z `oc.thread.customData.__chloeSessionId`),
ale **tylko** gdy adres jest pętlą lokalną (nasz mostek) albo `openrouter.ai` — obcy serwer
OpenAI-compatible nie dostaje nieznanego pola. Mostek czyta `session_id` także z nagłówka
`X-Session-Id` (dla curl/innych klientów; nagłówek jest na liście CORS). Identyfikator jest
stały w obrębie wątku (także wtedy, gdy budżet kontekstu przytnie początek historii) i różny
między wątkami. Do testów: `window.__chloeE2.sessionId()` i `window.__chloeE2.sessionFor(url)`.

## Parametry próbkowania czatu: `min_p` i `repetition_penalty` (dodane 24.09.2026)

Analiza z „panelu technicznego" (`hermes_3_comfyui_interactive_suite.html`, przysłanego na
czacie) zaleciła dwa parametry dla modeli RP: `min_p = 0.03` (ucina tokeny poniżej 3 %
prawdopodobieństwa najlepszego — mniej halucynacji i ucieczek od sceny) oraz
`repetition_penalty = 1.05` (subtelny nacisk na bogatsze słownictwo bez psucia gramatyki).
Oba są prawdziwymi parametrami OpenRoutera (0.0–1.0 i 0.0–2.0; sprawdzone w dokumentacji
`api_reference/parameters`).

Wdrożone w mostku (**wersja 7**):

* `DEFAULT_MIN_P = 0.03` i `DEFAULT_REP_PENALTY = 1.05` — dokładane do każdego czatu
  **tylko wtedy, gdy aplikacja sama ich nie podała** (klient ma priorytet), oraz do
  przepisywacza promptu obrazu (`/api/refine`);
* zmiana/wyłączenie: `--min-p 0` i `--rep-penalty 1.0` (albo dowolne inne wartości);
* widoczne w `/health` jako `sampling` (plus funkcja `sampling_defaults`) i w `--selftest`
  jako `probkowanie: min_p … | repetition_penalty …`;
* aplikacja Chloe nie musi o niczym wiedzieć — mostek rozmawia tylko z OpenRouterem.

Reszta zaleceń z tego panelu **była już wdrożona wcześniej** (dlatego panel opisuje nasz
stan, a nie stan sprzed zmiany): kolejność promptu pod prefix-cache (statyczny blok
systemowy → historia append-only → retrieval lore/DIY na końcu → ogon `<<stan>>`; patrz
komentarz w `chloeE2BuildMessages`), limity tagów Img-Engine
(`act 22, kink 12, body 10, pose 4, cloth 3, scene 4` — zgodne co do liczby), `dpmpp_2m` +
`karras` w workflow oraz tryb bezpośredni (`directToComfy: true`).

**Do decyzji (nie wdrożone bez zgody — zmieniają czas generowania):** panel proponuje
`KSampler` 32–35 kroków i CFG 5.5–6.5 (u nas baza: 25 kroków / CFG 5, hires-fix: 20 / 5),
dodanie **FaceDetailer** (Impact Pack jest zainstalowany — trzeba sprawdzić, czy na dysku
leży detektor `face_yolov8m.pt`) oraz **Ultimate SD Upscale** (tego noda nie ma w
`custom_nodes`, wymagałby instalacji przez ComfyUI-Manager).

**Rozstrzygnięte 24.09.2026:**

* **CFG → 6.0** wdrożone w obu samplerach (`workflow_api.json`). Kroki zostawione (baza 25,
  hires 20): podniesienie ich do 32–35 wydłużyłoby generowanie o ok. 30 % bez wyraźnego zysku
  na SD1.5. Można je zmienić w nodach `5`/`10` albo nadpisać z API (`{"steps": 32}`).
* **FaceDetailer → sprawdzony i przygotowany** do wdrożenia jedną komendą
  (`python dodaj_facedetailer.py`). Blokada: brakuje pakietu **ComfyUI Impact Subpack**
  (dostarcza `UltralyticsDetectorProvider`) — do naprawy `Dodaj_detektor_twarzy.bat`.
* **Ultimate SD Upscale → sprawdzony i odradzany** na tym sprzęcie (brak nodu, brak
  `4x-UltraSharp`, brak jakiegokolwiek ControlNetu, a obecny łańcuch 4x NMKD + Lanczos +
  hires już daje 2K). Szczegóły niżej.

## Rozwiązywanie problemów

| Objaw | Przyczyna / co zrobić |
|---|---|
| `brak polaczenia z ComfyUI` | ComfyUI nie działa albo zły `--comfy`; sprawdź `--selftest` |
| Czat nie odpowiada, a w logu mostka leci `OpenRouter 401` / w odpowiedzi `{"message": "No cookie auth credentials found"}` | mostek nie ma **własnego** klucza OpenRoutera (strona `http://127.0.0.1:8443/` → `api_key: BRAK`). Do v9 klucz z panelu Chloe nie był używany. Napraw: wgraj mostek v10 (`/health` → `key_source` powie, skąd bierze klucz) albo wklej klucz do `openrouter_key.txt` obok `hermes_comfy_bridge.py` i zrestartuj mostek |
| `OpenRouter ... 401` | zły/nieaktywny klucz; `--selftest` pokaże to od razu |
| `we workflow nie ma noda o ID …` | zły `--pos-node`/`--neg-node`; w ComfyUI kliknij w node i odczytaj jego numer |
| Obraz wraca „ocenzurowany"/ubrany | sprawdź `/last` i plik `.txt` — czy prompt doszedł cały; ewentualnie `--no-refine` i wpisz prompt sam |
| Aplikacja: „Mostek musi używać HTTPS" | wystaw przez `tailscale serve` i wpisz adres `https://…` |
| `odrzucony Origin` | mostek nie przepuszcza tego originu; użyj `--allow-origin` |
| Obraz nie pojawia się, choć mostek zwraca 200 | brak noda `SaveImage` w workflow (mostek o tym mówi w `--selftest`) |
| Odpowiada inny model niż wybrany / `"fallback": true` w `/health` | OpenRouter przeskoczył na model z łańcucha awaryjnego (moderacja, rate limit, downtime providera). Sprawdź `last_chat` w `/health`; żeby to wyłączyć: `--no-fallbacks` |
| `netstat` pokazuje `100.x.x.x:8443 LISTENING`, a mostek nie działa | to **Tailscale Serve**, nie mostek — tailscaled trzyma port 8443 na adresie tailnetu. Dlatego ani launcher, ani `diagnoza_mostka.bat` nie sprawdzają mostka przez `netstat`, tylko pytają `http://127.0.0.1:8443/health` (na pętli lokalnej port jest wolny). Wniosek: brak mostka = brak procesu, nie zajęty port |
| `sprawdz_comfy.py` zgłasza `[BRAK]` przy `lora_name`/`model_name` | brakuje plików LoRy / upscalera — wgraj je do `models\loras` / `models\upscale_models` albo uruchom z `--workflow-file workflow_api_simple.json` |
| `sprawdz_comfy.py`: `[BRAK] UltralyticsDetectorProvider`, a `FaceDetailer` jest | Impact Pack V8+ **nie zawiera** już detektora twarzy — trzeba doinstalować osobny pakiet **ComfyUI Impact Subpack**. Napraw: `Dodaj_detektor_twarzy.bat` albo ComfyUI-Manager → „ComfyUI Impact Subpack" |
| Po instalacji `ultralytics` ComfyUI przestał widzieć kartę | któraś zależność podmieniła `torch` na wersję CUDA. Sprawdź `torch.__version__` — musi zawierać `+rocm…`. `instaluj_detektor_twarzy.py` temu zapobiega, bo instaluje **wyłącznie** z `--no-deps` i pokazuje wersję torch przed i po |
| Obraz z FaceDetailerem wyszedł z „obcym" detalem twarzy | detal dostał inny model/prompt — `dodaj_facedetailer.py` wpina ten sam model, LoRę, VAE i prompty co baza; jeśli edytowałeś workflow ręcznie, uruchom `--remove` i wstaw ponownie |
| W logu ComfyUI: `[DEPRECATION WARNING] … /scripts/ui.js`, `/extensions/core/clipspace.js`, `/extensions/core/groupNode.js`, `/scripts/ui/components/button.js` | **To nie błąd i nie Twoje wtyczki.** ComfyUI 0.33.0 ma wbudowany wykrywacz „starych" importów i jego *własny* frontend (`scripts/ui.js`, `extensions/core/*`) jeszcze z nich korzysta — stąd ostrzeżenia same o sobie. Tekst „custom node extension…" to szablon komunikatu, nie diagnoza. GPU/pipeline działa normalnie |
| W logu ComfyUI: `[CFZ Load] No cache files found` | komunikat wtyczki z `custom_nodes` (loader cache). Przy pierwszym uruchomieniu cache po prostu jeszcze nie istnieje — nieszkodliwe. Można usunąć, kasując katalog node'a, ale nic to nie blokuje |
| W logu ComfyUI: `[CFZ MIOpen] Startup: no saved config … miopen_config.json — skipped` | ten sam node (`custom_nodes\CFZ-Caching`) zapisuje raz znalezione konfiguracje MIOpen; przy pierwszym starcie pliku jeszcze nie ma. Po pierwszej generacji pojawi się sam |
| W logu ComfyUI: `[Impact Pack] custom_wildcards path not found: C:\Users\adamo\Desktop\AI.KURWA\…` | w `user\default\impact-pack.ini` została **stara ścieżka** z czasu, gdy pakiet leżał bezpośrednio na Pulpicie (bez `open-webui-0.11.3\`). Impact Pack sam wraca do domyślnej ścieżki, więc to kosmetyka — do poprawy tylko, gdybyś używał własnych `custom_wildcards` |
| W logu ComfyUI: `ComfyUI Revision: UNKNOWN (… not a Git repository)` | ComfyUI jest rozpakowany, nie sklonowany z gita, więc ComfyUI-Manager nie potrafi aktualizować/cofać **samego ComfyUI** (wtyczki — tak). Startowi to nie przeszkadza |
| W logu ComfyUI: `[aiter] Windows: CK and HIP ops are not available. Triton ops only.` | patrz „Parametry startu ComfyUI" — u nas backend `triton` jest wyłączony flagą, więc `aiter` nie przyspiesza; da się to przetestować przez `CHL_COMFY_PARAMS` |
| Aplikacja pokazuje „Lokalne GPU jest zajęte — czekam w kolejce… (N)" i licznik rośnie, a ComfyUI ma pustą kolejkę | mostek trzyma poprzednie zadanie (`JOB_LOCK`), bo np. ComfyUI został zrestartowany w trakcie malowania. Sprawdź `http://127.0.0.1:8443/health` → pole `job` (etap + `elapsed_s`): jeśli leci długo przy kolejce `0 / 0`, zrestartuj mostek (`Restart_Mostka.bat`). v9 sama kończy taki przypadek po ~6 s |
| `ComfyUI odrzucilo graf — wezel <id> (<Typ>): …` | ComfyUI odrzucił workflow **na walidacji** (v9 pokazuje którego noda i czego brakuje). Najczęściej: plik z listy combo zniknął (model/LoRA/upscaler), brakuje node'a z wtyczki albo zły typ wejścia. Popraw w ComfyUI i zapisz jeszcze raz przez Workflow → Export (API) |
| `ComfyUI zrestartowalo sie w trakcie generowania (zadanie zniknelo z kolejki i historii)` | zamknąłeś albo zrestartowałeś ComfyUI w trakcie obrazu — zadanie nie ma już ani w kolejce, ani w historii (v9 wykrywa to po ~6 s, wcześniej wisiało do `--timeout`). Wygeneruj obraz ponownie |
| `ComfyUI przerwal generowanie — wezel <id> (<Typ>): <powód>` | błąd wykonania noda, np. brak VRAM (`CUDA out of memory`) — w komunikacie jest `exception_message`, pełny ślad w `user\comfyui.log`. Przy OOM zmniejsz rozmiar/`--size` albo `hires` w workflow |
| `ComfyUI: generowanie przerwane … (ktos nacisnal Cancel/Interrupt w ComfyUI)` | ktoś (albo skrypt) wcisnął Cancel/Interrupt w ComfyUI — zadanie przepadło, ale to nie awaria; puść generowanie ponownie |
| W przeglądarce ComfyUI błąd typu „graph"/„Cannot read properties of …" po restarcie ComfyUI | stara karta ComfyUI trzyma martwy WebSocket do poprzedniego procesu i stary graf. Po **każdym** restarcie backendu odśwież kartę ComfyUI (Ctrl+Shift+R), zanim wpiszesz nowy prompt |
| Ten sam obraz liczy się raz ~2 min, a raz 9 min (pasek pokazuje 20+ s/it) | nie jest to wina grafu ani mostka — to zmienny koszt kroku na ROCm. Pomierzone 24.09.2026 na tym samym `workflow_api.json`: base pass 0,5–2,5 s/krok, hires (1024x1536, 20 kroków) 4,25 s/it albo 26 s/it, bez zmiany geometrii i przy identycznych komunikatach „prepared for dynamic VRAM loading". Gdy pasek w ComfyUI mieli się w tempie >15 s/it, **przerwij (Cancel) i puść zadanie ponownie** — powtórka tego samego zadania była u nas 1,8–4,5x szybsza. Zamiast zgadywać: `Zmierz_tempo.bat` (albo `Start_Comfy_i_Hermes.bat --bench`) mierzy s/krok osobno dla base i hires i pisze `raport_wydajnosci.txt`; `--attn=split\|quad\|pytorch\|sage` pozwala porównać sposoby liczenia attention |

## Bezpieczeństwo

- Domyślnie mostek słucha tylko na `127.0.0.1`; wystawienie na świat to osobna decyzja
  (Tailscale Serve = dostęp tylko w Twoim tailnecie).
- **Uwaga na Funnel na porcie `8188`.** Launcher v4 ostrzega, gdy `tailscale serve status`
  pokazuje ten port. `Funnel on` z regułą `/ → http://127.0.0.1:8188` (raport z 21.09.2026,
  sekcja `[5]`) wystawia **ComfyUI do publicznego internetu bez żadnego hasła** — ComfyUI
  potrafi zapisywać pliki i uruchamiać dowolne workflow, więc to realna dziura. Porty
  `8443`/`8444` są tylko w tailnecie (to jest OK). Wyłączenie: `tailscale funnel --https=443 off`
  (zostaw `tailscale serve --https=8443`, jeśli potrzebujesz mostka na telefonie).
- `--token` chroni POST-y, ale uwaga: dostawca „localflow" w aplikacji **nie wysyła**
  nagłówka `Authorization`, więc token działa dla czatu i dla dostawcy „custom"
  (tam wpisujesz go w polu klucza API). Jeśli mostek jest tylko w tailnecie, token nie jest
  konieczny.
- Klucz OpenRoutera trzymaj w `openrouter_key.txt` obok skryptu (a nie w `bridge_config.json`,
  który łatwiej przypadkiem wysłać dalej).
