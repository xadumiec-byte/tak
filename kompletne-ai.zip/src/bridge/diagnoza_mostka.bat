@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Diagnoza mostka Hermesa
set "OUT=%~dp0raport_mostka.txt"
set "D=%~dp0"
set "D=%D:~0,-1%"
del "%OUT%" >nul 2>&1

rem =====================================================================
rem  diagnoza_mostka.bat
rem  Jeden plik, ktory sprawdza DLACZEGO mostek nie wstaje, a na koncu sam
rem  go uruchamia w osobnym oknie. Wynik: raport_mostka.txt obok tego pliku.
rem  Poloz go obok hermes_comfy_bridge.py - czyli w AI.KURWA.
rem =====================================================================

set "PACK="
if exist "%D%\python_env\python.exe" set "PACK=%D%"
if not defined PACK if exist "%D%\comfyui-rocm-091926\python_env\python.exe" set "PACK=%D%\comfyui-rocm-091926"
set "HOME=%D%"
if not exist "%HOME%\hermes_comfy_bridge.py" if exist "%D%\..\hermes_comfy_bridge.py" set "HOME=%D%\.."

call :log "=== DIAGNOZA MOSTKA %DATE% %TIME% ==="
call :log "folder skryptu : %D%"
call :log "pack ComfyUI   : %PACK%"
call :log "folder mostka  : %HOME%"
call :blank

call :log "--- [1] pliki ---"
for %%F in (hermes_comfy_bridge.py workflow_api.json openrouter_key.txt sprawdz_comfy.py Start_Comfy_i_Hermes.bat) do (
    if exist "%HOME%\%%F" (call :log "  JEST   %HOME%\%%F") else (call :log "  BRAK   %HOME%\%%F")
)
if defined PACK (
    if exist "%PACK%\python_env\python.exe" (call :log "  JEST   %PACK%\python_env\python.exe") else (call :log "  BRAK   %PACK%\python_env\python.exe")
) else (
    call :log "  BRAK   folderu ComfyUI - nie znalazlem python_env"
)
call :log "  wersja launchera:"
findstr /C:"CHL_VER" "%HOME%\Start_Comfy_i_Hermes.bat" >>"%OUT%" 2>&1
call :log "  wersja sprawdz_comfy.py:"
findstr /C:"COMBO" "%HOME%\sprawdz_comfy.py" >>"%OUT%" 2>&1
call :blank

set "PY="
if defined PACK if exist "%PACK%\python_env\python.exe" set "PY=%PACK%\python_env\python.exe"
if not defined PY for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set "PY=%%P"
call :log "--- [2] python ---"
call :log "  uzyje: %PY%"
where python >>"%OUT%" 2>&1
where py >>"%OUT%" 2>&1
if defined PY "%PY%" -c "import sys;print(sys.version.split()[0], sys.executable)" >>"%OUT%" 2>&1
if not defined PY call :log "  BRAK Pythona - bez niego mostek nie ruszy"
call :blank

if not defined PY goto :koniec

call :log "--- [3] test bindowania portow ---"
"%PY%" -c "import socket;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',8443));s.close();print('  OK: port 8443 WOLNY')" >>"%OUT%" 2>&1
"%PY%" -c "import socket;s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind(('127.0.0.1',8453));s.close();print('  OK: port 8453 WOLNY')" >>"%OUT%" 2>&1
call :log "  gdy wyzej jest blad Windows, to port jest zajety przez inny proces"
call :blank

call :log "--- [4] co siedzi na 8443 ---"
call :log "  uwaga: wpis 100.x.x.x:8443 LISTENING to Tailscale Serve, nie mostek."
call :log "  mostek musi odpowiadac na http://127.0.0.1:8443/health - i tylko to sie liczy."
netstat -ano | findstr :8443 >>"%OUT%" 2>&1
call :blank
call :log "--- [5] tailscale serve ---"
tailscale serve status >>"%OUT%" 2>&1
call :blank
call :log "--- [6] procesy python ---"
tasklist /fi "imagename eq python.exe" >>"%OUT%" 2>&1
tasklist /fi "imagename eq pythonw.exe" >>"%OUT%" 2>&1
call :blank

call :log "--- [7] hermes_comfy_bridge.py --selftest ---"
pushd "%HOME%"
"%PY%" "hermes_comfy_bridge.py" --selftest >>"%OUT%" 2>&1
call :log "  kod wyjscia: %ERRORLEVEL%"
popd
call :blank

call :log "--- [8] sprawdz_comfy.py --no-wait ---"
if not exist "%HOME%\sprawdz_comfy.py" goto :skip_check
pushd "%HOME%"
"%PY%" "sprawdz_comfy.py" --no-wait >>"%OUT%" 2>&1
call :log "  kod wyjscia: %ERRORLEVEL%"
popd
goto :start_bridge
:skip_check
call :log "  pominiete - brak pliku sprawdz_comfy.py"

:start_bridge
call :blank
call :log "--- [9] start mostka w osobnym oknie ---"
rem UWAGA: NIE uzywamy tu netstat - Tailscale Serve trzyma 100.x.x.x:8443 i netstat
rem raportuje LISTENING, choc mostka nie ma. Pytamy wprost pod adresem petli lokalnej.
"%PY%" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8443/health',timeout=3)" >nul 2>&1
if not errorlevel 1 goto :juz_dziala
call :log "  uruchamiam: %PY% hermes_comfy_bridge.py"
start "Mostek Hermes" /min /d "%HOME%" "%ComSpec%" /k ""%PY%" "hermes_comfy_bridge.py""
call :log "  czekam 12 s na /health ..."
timeout /t 12 /nobreak >nul
"%PY%" -c "import urllib.request;print('  HEALTH: '+urllib.request.urlopen('http://127.0.0.1:8443/health',timeout=4).read().decode()[:300])" >>"%OUT%" 2>&1
goto :koniec
:juz_dziala
call :log "  mostek JUZ odpowiada na http://127.0.0.1:8443/health - nie startuje drugiego"

:koniec
call :blank
call :log "--- [10] koniec ---"
call :log "Otwieram raport. Wyslij mi plik raport_mostka.txt"
start "" notepad "%OUT%"
echo.
echo ======================================================================
echo  Gotowe. Raport: %OUT%
echo  Wyslij mi ten plik do czatu.
echo ======================================================================
echo.
pause
exit /b 0

:log
>>"%OUT%" echo %~1
exit /b 0

:blank
>>"%OUT%" echo.
exit /b 0
