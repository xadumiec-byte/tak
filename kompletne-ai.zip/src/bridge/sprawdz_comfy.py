#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sprawdz_comfy.py - czeka, az ComfyUI wstanie, i sprawdza pliki modeli z workflow.

Uruchamiany automatycznie przez Start_Comfy_i_Hermes.bat, ale mozna go wolac recznie:

    python sprawdz_comfy.py
    python sprawdz_comfy.py --wait 300 --comfy http://127.0.0.1:8188
    python sprawdz_comfy.py --workflow workflow_api.json
    python sprawdz_comfy.py --no-wait

Co robi:
  1) czeka, az ComfyUI odpowie na /system_stats, i wypisuje jego wersje oraz GPU,
  2) czyta workflow w formacie API i pyta ComfyUI o /object_info, zeby sprawdzic,
     czy KAZDY plik i KAZDA opcja z workflow istnieja u Ciebie na dysku
     - checkpoint, LoRA, model upscalu, VAE, sampler itd.,
  3) mowi wprost czego brakuje i do jakiego folderu to wgrac,
  4) sprawdza, czy sa nody SaveImage/PreviewImage, bo bez nich mostek nie ma
     czego odebrac.

Kody wyjscia:
  0  ComfyUI odpowiada i wszystko z workflow jest na dysku,
  1  ComfyUI nie odpowiedzial albo blad krytyczny,
  2  ComfyUI odpowiada, ale brakuje plikow (obrazy sie nie wygeneruja).

Zero zaleznosci - tylko biblioteka standardowa, dziala na Pythonie 3.8+.
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

WERSJA = "1.1 z 24.09.2026"

# Podpowiedz, w ktorym folderze ComfyUI szuka plikow danego pola.
FOLDER_HINT = {
    "ckpt_name": "models\\checkpoints",
    "lora_name": "models\\loras",
    "model_name": "models\\upscale_models",
    "vae_name": "models\\vae",
    "clip_name": "models\\text_encoders",
    "clip_name1": "models\\text_encoders",
    "clip_name2": "models\\text_encoders",
    "unet_name": "models\\diffusion_models",
    "control_net_name": "models\\controlnet",
    "style_model_name": "models\\style_models",
    "ipadapter_file": "models\\ipadapter",
    "pulid_file": "models\\pulid",
    "embedding_name": "models\\embeddings",
    "safety_checker": "models\\safety_checker",
}


def http_json(url, timeout=8.0):
    """GET -> (status, objekt albo None, tekst bledu). Nie rzuca wyjatkiem."""
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/json", "User-Agent": "sprawdz-comfy/" + WERSJA},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            dane = resp.read()
            return resp.status, json.loads(dane.decode("utf-8", "replace")), ""
    except urllib.error.HTTPError as exc:
        try:
            tresc = exc.read().decode("utf-8", "replace")
        except Exception:
            tresc = ""
        return exc.code, None, tresc[:400]
    except Exception as exc:
        return None, None, str(exc)


def opis_comfy(obj):
    """Wypisuje wersje ComfyUI i karty, ktore widzi torch."""
    system = obj.get("system")
    if not isinstance(system, dict):
        system = {}
    urzadzenia = obj.get("devices")
    if not isinstance(urzadzenia, list):
        urzadzenia = []
    python_ver = str(system.get("python_version") or "?").split(" ")[0]
    print("      ComfyUI " + str(system.get("comfyui_version") or "?") + "   python " + python_ver)
    for dev in urzadzenia:
        if not isinstance(dev, dict):
            continue
        vram = dev.get("vram_total")
        vram_txt = ""
        if isinstance(vram, (int, float)) and vram:
            vram_txt = "   VRAM " + str(round(vram / (1024.0 * 1024.0 * 1024.0), 1)) + " GB"
        print("      GPU: " + str(dev.get("name") or "?") + vram_txt
              + "   torch " + str(dev.get("torch_version") or "?"))
    wolne = system.get("ram_free")
    if isinstance(wolne, (int, float)) and wolne:
        print("      RAM wolny: " + str(round(wolne / (1024.0 * 1024.0 * 1024.0), 1)) + " GB")


def czekaj_na_comfy(comfy, wait_sec):
    """Czeka, az ComfyUI odpowie na /system_stats. True = wstal."""
    url = comfy.rstrip("/") + "/system_stats"
    start = time.time()
    limit = max(0.0, float(wait_sec))
    print("[..] czekam na ComfyUI: " + url + "   limit " + str(int(limit)) + " s")
    ostatni_blad = ""
    kolejny_raport = 0
    while True:
        status, obj, tekst = http_json(url, 4.0)
        if status == 200 and isinstance(obj, dict):
            print("[OK] ComfyUI odpowiada po " + str(round(time.time() - start, 1)) + " s")
            opis_comfy(obj)
            return True
        ostatni_blad = tekst or ("HTTP " + str(status))
        uplynelo = int(time.time() - start)
        if uplynelo >= kolejny_raport:
            kolejny_raport = uplynelo + 15
            print("     ... " + str(uplynelo) + " s")
            sys.stdout.flush()
        if uplynelo >= limit:
            print("[BLAD] ComfyUI nie odpowiedzial w " + str(int(limit)) + " s.")
            print("       Ostatni blad: " + str(ostatni_blad)[:200])
            print("       Zajrzyj do zminimalizowanego okna ComfyUI i do jego logu:")
            print("       <folder pakietu>\\user\\comfyui.log")
            return False
        time.sleep(2.0)


def wczytaj_workflow(sciezka):
    """Zwraca (graf, blad)."""
    if not os.path.isfile(sciezka):
        return None, "nie ma pliku " + sciezka + "  (ComfyUI: Workflow -> Export API)"
    try:
        with open(sciezka, "r", encoding="utf-8-sig") as fh:
            graf = json.load(fh)
    except Exception as exc:
        return None, "nie moge wczytac " + sciezka + ": " + str(exc)
    if not isinstance(graf, dict) or not graf:
        return None, "plik nie jest workflow w formacie API - klucz = ID noda"
    return graf, ""


def sprawdz_modele(graf, object_info):
    """Porownuje wartosci z workflow z listami dostepnymi w ComfyUI.

    Zwraca (problemy, brakujace_nody, sprawdzone_pola). Dziala ogolnie: kazde
    pole noda, ktore ComfyUI opisuje jako liste wyboru - czyli pliki, samplery,
    schedulery - jest porownywane z tym, co podaje /object_info.
    """
    problemy = []
    brakujace_nody = []
    sprawdzone = 0
    for node_id in sorted(graf.keys(), key=lambda k: str(k)):
        node = graf[node_id]
        if not isinstance(node, dict):
            continue
        cls = str(node.get("class_type") or "")
        wejscia = node.get("inputs") or {}
        if not cls:
            continue
        opis = object_info.get(cls)
        if opis is None:
            if cls not in brakujace_nody:
                brakujace_nody.append(cls)
            continue
        spec_pola = {}
        sekcje = opis.get("input") or {}
        for nazwa_sekcji in ("required", "optional"):
            for pole, spec in (sekcje.get(nazwa_sekcji) or {}).items():
                spec_pola[pole] = spec
        for pole, wartosc in wejscia.items():
            spec = spec_pola.get(pole)
            if not isinstance(spec, list) or not spec:
                continue
            # ComfyUI podaje liste wyboru w dwoch formatach:
            #   stary:  [["plik1.safetensors", "plik2.safetensors"], {"tooltip": ...}]
            #   nowszy: ["COMBO", {"options": ["plik1.safetensors", ...]}]
            wybor = None
            if isinstance(spec[0], list):
                wybor = spec[0]
            elif (isinstance(spec[0], str) and len(spec) > 1 and isinstance(spec[1], dict)
                  and isinstance(spec[1].get("options"), list)):
                wybor = spec[1]["options"]
            if wybor is None:
                continue  # pole bez listy wyboru, np. INT / STRING / MODEL
            if wybor and not isinstance(wybor[0], str):
                continue  # lista liczb itp.
            sprawdzone += 1
            opcje = [str(x) for x in wybor]
            if str(wartosc) in opcje:
                continue
            problemy.append({
                "gdzie": cls + " (nod " + str(node_id) + ")",
                "pole": pole,
                "wartosc": str(wartosc),
                "folder": FOLDER_HINT.get(pole, ""),
                "opcje": opcje,
            })
    return problemy, brakujace_nody, sprawdzone


NODY_DETALU = (
    ("FaceDetailer", "Impact Pack", "przemalowuje twarz w pelnym kadrze"),
    ("UltralyticsDetectorProvider", "Impact Subpack", "wykrywacz twarzy (YOLO)"),
    ("SAMLoader", "Impact Pack", "dokladna maska twarzy (opcjonalnie)"),
    ("UltimateSDUpscale", "Ultimate SD Upscale", "upscale kafelkowy do 2K"),
)

JAK_ZAINSTALOWAC = {
    "UltimateSDUpscale": "ComfyUI-Manager -> Install Custom Nodes -> 'Ultimate SD Upscale' (ssitu) + restart ComfyUI",
    "FaceDetailer": "ComfyUI-Manager -> Install Custom Nodes -> 'ComfyUI Impact Pack' + restart ComfyUI",
    # Od Impact Packu V8 detektor twarzy jest w OSOBNYM pakiecie - bez niego FaceDetailer
    # nie ma czym wykryc twarzy (bbox_detector jest polem wymaganym).
    "UltralyticsDetectorProvider": ("ComfyUI-Manager -> Install Custom Nodes -> 'ComfyUI Impact Subpack' "
                                    "+ restart ComfyUI   (albo Dodaj_detektor_twarzy.bat)"),
    "SAMLoader": "ComfyUI-Manager -> Install Custom Nodes -> 'ComfyUI Impact Pack' + restart ComfyUI",
}

GDZIE_TWARZ = ("   wgraj face_yolov8m.pt do <ComfyUI>\\models\\ultralytics\\bbox\\  "
               "(https://huggingface.co/Bingsu/adetailer/resolve/main/face_yolov8m.pt)")


def opcje_pola(opis, pole):
    """Lista dozwolonych wartosci pola (plikow) z opisu noda."""
    if not isinstance(opis, dict):
        return []
    sekcje = opis.get("input") or {}
    for nazwa in ("required", "optional"):
        spec = (sekcje.get(nazwa) or {}).get(pole)
        if not isinstance(spec, list) or not spec:
            continue
        pierwszy = spec[0]
        if isinstance(pierwszy, list):
            return [str(x) for x in pierwszy]
        if isinstance(pierwszy, str) and pierwszy.upper() == "COMBO":
            meta = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
            return [str(x) for x in (meta.get("options") or [])]
    return []


def wypisz_liste(nazwa, opcje, szukane=()):
    """Wypisuje liste plikow i podswietla te, ktore nas interesuja."""
    if not opcje:
        print("      " + nazwa + ": BRAK PLIKOW w tym folderze")
        return False
    trafione = [o for o in opcje if any(s.lower() in o.lower() for s in szukane)]
    skrot = opcje if len(opcje) <= 8 else opcje[:8] + ["... (" + str(len(opcje)) + " szt.)"]
    print("      " + nazwa + ": " + ", ".join(skrot))
    if szukane:
        if trafione:
            print("      -> pasuje: " + ", ".join(trafione))
            return True
        print("      -> brak wpisu z " + "/".join(szukane))
        return False
    return bool(opcje)


def sprawdz_detaling(comfy):
    """Sprawdza, czy mozna dorzucic FaceDetailer i Ultimate SD Upscale.

    Nic nie zmienia - tylko czyta /object_info. Detal nie jest wymagany, zeby
    generowac obrazy, dlatego braki tutaj nie zmieniaja kodu wyjscia.
    """
    print("")
    print("--- detailing: FaceDetailer i Ultimate SD Upscale ---")
    opis = {}
    for klasa, wtyczka, po_co in NODY_DETALU:
        stan, obj, tekst = http_json(comfy.rstrip("/") + "/object_info/" + klasa, 20.0)
        ma = stan == 200 and isinstance(obj, dict) and klasa in obj
        opis[klasa] = obj.get(klasa) if ma else None
        print(("   [OK]   " if ma else "   [BRAK] ") + klasa + "  (" + wtyczka + " - " + po_co + ")")
        if not ma:
            print("          " + JAK_ZAINSTALOWAC.get(klasa, "zainstaluj wtyczke i zrestartuj ComfyUI"))

    if opis.get("UltralyticsDetectorProvider") is not None:
        detektory = opcje_pola(opis["UltralyticsDetectorProvider"], "model_name")
        ma_twarz = wypisz_liste("wykrywacze twarzy", detektory, ("face_yolov8", "face"))
        if not ma_twarz:
            print(GDZIE_TWARZ)

    if opis.get("SAMLoader") is not None:
        wypisz_liste("modele SAM", opcje_pola(opis["SAMLoader"], "model_name"))

    stan, obj, tekst = http_json(comfy.rstrip("/") + "/object_info/UpscaleModelLoader", 20.0)
    opis_up = obj.get("UpscaleModelLoader") if stan == 200 and isinstance(obj, dict) else None
    if opis_up:
        wypisz_liste("modele upscalu", opcje_pola(opis_up, "model_name"), ("ultrasharp", "4x", "superscale"))

    if opis.get("UltimateSDUpscale") is not None:
        stan, obj, tekst = http_json(comfy.rstrip("/") + "/object_info/ControlNetLoader", 20.0)
        opis_cn = obj.get("ControlNetLoader") if stan == 200 and isinstance(obj, dict) else None
        ma_kafel = wypisz_liste("modele ControlNet",
                                opcje_pola(opis_cn, "control_net_name") if opis_cn else [],
                                ("tile",))
        if not ma_kafel:
            print("      [i] Ultimate SD Upscale dziala tez BEZ ControlNetu (bez kafelkowego podpowiadania),")
            print("          tylko z troche mniejsza ostroscia detali - mozna sprobowac tak.")

    ma_fd = opis.get("FaceDetailer") is not None
    ma_det = opis.get("UltralyticsDetectorProvider") is not None
    ma_kandydat = ma_det and any("face" in o.lower()
                                 for o in opcje_pola(opis["UltralyticsDetectorProvider"], "model_name"))
    print("")
    if ma_fd and ma_kandydat:
        print("   [FACE] gotowe do wdrozenia:  python dodaj_facedetailer.py")
        print("          (dopisze detal twarzy do workflow_api.json; --dry-run pokaze plan, --remove cofa)")
    elif ma_fd and ma_det:
        print("   [FACE] brakuje tylko pliku z detektorem twarzy (patrz wyzej) - potem:")
        print("          python dodaj_facedetailer.py")
    elif ma_fd:
        print("   [FACE] FaceDetailer JEST, ale nie ma czym wykryc twarzy: brakuje nodu")
        print("          UltralyticsDetectorProvider. Od Impact Packu V8 jest on w OSOBNYM")
        print("          pakiecie ComfyUI-Impact-Subpack (nie instaluje sie sam).")
        print("          Napraw: dwuklik Dodaj_detektor_twarzy.bat (wgrywa Subpack, dokłada")
        print("          zaleznosci bez ruszania torch i sciaga face_yolov8m.pt),")
        print("          potem restart ComfyUI i: python dodaj_facedetailer.py")
    else:
        print("   [FACE] brakuje Impact Packu - bez niego nie ma detalu twarzy.")
    if opis.get("UltimateSDUpscale") is None:
        print("   [UPSCALE] Ultimate SD Upscale nie jest zainstalowany. Masz juz upscale modelem 4x NMKD")
        print("             + resize do 1024x1536 + drugi KSampler (denoise 0.35), wiec obraz i tak")
        print("             wychodzi duzy - USDU zmienilby glownie sposob dokladania detali (kafelki).")
    else:
        print("   [UPSCALE] Ultimate SD Upscale jest zainstalowany. Dla SD1.5 (EpicRealism) ustaw")
        print("             kafel 512-768 i denoise 0.2-0.25; tile 1024 jest dla SDXL i da powtorki.")
    return


def main():
    ap = argparse.ArgumentParser(description="Czeka na ComfyUI i sprawdza pliki modeli z workflow.")
    ap.add_argument("--comfy", default=os.environ.get("COMFY_URL", "http://127.0.0.1:8188"),
                    help="adres ComfyUI, domyslnie http://127.0.0.1:8188")
    ap.add_argument("--workflow", default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                       "workflow_api.json"),
                    help="plik workflow w formacie API")
    ap.add_argument("--wait", type=float, default=300.0, help="ile sekund czekac na ComfyUI")
    ap.add_argument("--no-wait", action="store_true", help="nie czekaj, sprawdz od razu")
    ap.add_argument("--no-detaling", action="store_true",
                    help="pomin sekcje FaceDetailer / Ultimate SD Upscale")
    args = ap.parse_args()

    print("=== sprawdz_comfy.py " + WERSJA + " ===")
    print("")

    if args.no_wait:
        status, obj, tekst = http_json(args.comfy.rstrip("/") + "/system_stats", 8.0)
        if status == 200 and isinstance(obj, dict):
            print("[OK] ComfyUI odpowiada: " + args.comfy)
            opis_comfy(obj)
        else:
            print("[BLAD] ComfyUI nie odpowiada pod " + args.comfy + "  (" + str(tekst)[:200] + ")")
            return 1
    elif not czekaj_na_comfy(args.comfy, args.wait):
        return 1

    graf, blad = wczytaj_workflow(args.workflow)
    if graf is None:
        print("[BLAD] " + blad)
        return 1

    klasy = sorted({str(un.get("class_type") or "") for un in graf.values() if isinstance(un, dict)})
    klasy = [k for k in klasy if k]
    # UWAGA: /object_info/KSampler,CLIPTextEncode nie dziala (ComfyUI 0.33 zwraca wtedy {}),
    # wiec pytamy osobno o kazdy typ noda.
    object_info = {}
    bledy_pytan = []
    for klasa in klasy:
        status, odp, tekst = http_json(
            args.comfy.rstrip("/") + "/object_info/" + klasa, 30.0)
        if status == 200 and isinstance(odp, dict) and klasa in odp:
            object_info[klasa] = odp[klasa]
        else:
            bledy_pytan.append(klasa + " (" + str(status) + ")")
    if not object_info:
        print("[BLAD] ComfyUI nie zwrocil /object_info: " + " ".join(bledy_pytan))
        return 1

    problemy, brakujace_nody, sprawdzone = sprawdz_modele(graf, object_info)
    nazwa = os.path.basename(args.workflow)

    print("")
    print("--- pliki i opcje z workflow " + nazwa + " ---")
    if not problemy:
        print("[OK] Wszystkie " + str(sprawdzone) + " pol z listy wyboru zgadza sie z ComfyUI.")
    else:
        print("[BRAK] " + str(len(problemy)) + " wpis(y) nie zgadzaja sie z tym, co ma ComfyUI:")
        for prob in problemy:
            linia = "   " + prob["gdzie"] + " -> " + prob["pole"] + " = " + prob["wartosc"]
            if prob["folder"]:
                linia += "   [wgraj plik do " + prob["folder"] + "]"
            print(linia)
            opcje = prob["opcje"]
            if not opcje:
                print("      dostepne: BRAK PLIKOW - ComfyUI nie widzi nic w tym folderze")
            elif len(opcje) <= 12:
                print("      dostepne: " + ", ".join(opcje))
            else:
                print("      dostepne, " + str(len(opcje)) + " szt.: " + ", ".join(opcje[:12]) + " ...")

    if brakujace_nody:
        print("[BRAK] ComfyUI nie zna tych typow nodow - brakuje custom node / wtyczki:")
        for nod in brakujace_nody:
            print("   " + nod)

    if not any(str(un.get("class_type") or "") in ("SaveImage", "PreviewImage")
               for un in graf.values() if isinstance(un, dict)):
        print("[UWAGA] W workflow nie ma noda SaveImage ani PreviewImage - mostek nie")
        print("        mialby czego odebrac.")

    if not args.no_detaling:
        sprawdz_detaling(args.comfy)

    print("")
    if problemy or brakujace_nody:
        print("=== WYNIK: uzupelnij pliki / nody z listy wyzej, wtedy obrazy rusza ===")
        return 2
    print("=== WYNIK: ComfyUI dziala i workflow jest kompletny - mozna generowac ===")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("")
        print("przerwane")
        sys.exit(130)
