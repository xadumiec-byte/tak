#!/usr/bin/env python3
"""Pomiar szybkosci ComfyUI dla Chloe - bez restartu i bez zgadywania.

Mierzy, ile realnie trwa JEDEN KROK w Twoim workflow: osobno base pass i hires,
plus calosc zadania. Po co: ten sam graf potrafi isc 4 s/krok albo 26 s/krok
(zaleznie od tego, na jaka sciezke attention/traktowania VRAM trafil proces
ComfyUI). Wtedy zamiast zgadywac, porownujesz liczby:

    Start_Comfy_i_Hermes.bat --bench                  (domyslne ustawienia)
    Start_Comfy_i_Hermes.bat --bench --attn=split     (--use-split-cross-attention)
    Start_Comfy_i_Hermes.bat --bench --attn=pytorch   (--use-pytorch-cross-attention)

Uruchomienie recznie (ComfyUI musi dzialac):
    python bench_comfy.py                       # workflow_api.json obok skryptu, 3 przebiegi
    python bench_comfy.py --runs 2 --steps 3 --report raport_wydajnosci.txt

Co robi: bierze Twoj workflow (format API), podmienia liczbe krokow KSamplerow
na mala (domyslnie 3), losuje ziarno, wysyla do ComfyUI i mierzy. Kroki sa male
celowo - chodzi o tempo na krok, a nie o obraz. Obrazow z pomiaru nie zapisuje
(prefix `bench/`), wiec nie smieci w galerii.

Kody wyjscia: 0 = OK, 1 = blad (brak ComfyUI / zly workflow), 2 = pomiar
niestabilny (jeden przebieg ponad 2.5x wolniejszy od najszybszego - czyli
wlaczyl sie wolny tryb; to wlasnie ten przypadek, ktory chcemy zlapac).
"""

import argparse
import json
import os
import re
import secrets
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_COMFY = "http://127.0.0.1:8188"
DEFAULT_WORKFLOW = HERE / "workflow_api.json"
SAMPLERS = ("KSampler", "KSamplerAdvanced")
LATENTS = ("EmptyLatentImage", "EmptySD3LatentImage")

PROGRESS_RE = re.compile(
    r"(\d+)/(\d+)\s*\[([0-9:]+)<([0-9:]+),\s*([\d.]+)\s*(it/s|s/it)")
EXECUTED_RE = re.compile(r"Prompt executed in ([\d.]+) seconds")


def log(text):
    print("   " + str(text), flush=True)


def http_json(url, payload=None, timeout=30, method=None):
    headers = {"User-Agent": "chloe-bench/1.0"}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method or ("POST" if data else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
            status = int(getattr(resp, "status", 0) or resp.getcode())
    except urllib.error.HTTPError as exc:
        return int(exc.code), None, exc.read().decode("utf-8", "replace")
    except Exception as exc:
        return 0, None, repr(exc)
    try:
        obj = json.loads(body.decode("utf-8", "replace"))
    except Exception:
        obj = None
    return status, obj, body.decode("utf-8", "replace")


def load_workflow(path):
    file_path = Path(path)
    if not file_path.exists():
        raise RuntimeError("brak pliku workflow: " + str(file_path))
    graph = json.loads(file_path.read_text(encoding="utf-8"))
    if not isinstance(graph, dict) or not graph:
        raise RuntimeError("workflow musi byc obiektem JSON (klucz = ID noda) - to nie jest format API")
    return graph


def nodes_of_type(graph, class_type):
    return [node_id for node_id, node in graph.items()
            if isinstance(node, dict) and node.get("class_type") in class_type]


def build_graph(graph, steps, size, prefix):
    graph = json.loads(json.dumps(graph))
    samplers = nodes_of_type(graph, SAMPLERS)
    if not samplers:
        raise RuntimeError("w workflow nie ma zadnego KSamplera - nie ma czego mierzyc")
    for node_id in samplers:
        inputs = graph[node_id].setdefault("inputs", {})
        inputs["steps"] = int(steps)
        inputs["seed"] = secrets.randbelow(2 ** 31)
    if size:
        try:
            width, height = [int(part) for part in str(size).lower().split("x")]
        except Exception:
            raise RuntimeError("zly --size, ma byc np. 512x768")
        latents = nodes_of_type(graph, LATENTS)
        for node_id in latents:
            inputs = graph[node_id].setdefault("inputs", {})
            inputs["width"] = width
            inputs["height"] = height
            if "batch_size" in inputs:
                inputs["batch_size"] = 1
    for node_id in nodes_of_type(graph, ("SaveImage", "PreviewImage")):
        inputs = graph[node_id].setdefault("inputs", {})
        if "filename_prefix" in inputs:
            inputs["filename_prefix"] = prefix
    return graph, len(samplers)


def fetch_log(comfy, logfile=""):
    status, obj, _ = http_json(comfy.rstrip("/") + "/internal/logs", None, 20)
    if status == 200 and isinstance(obj, str):
        return obj
    if status == 200 and isinstance(obj, (dict, list)):
        return json.dumps(obj, ensure_ascii=False)
    if logfile and Path(logfile).exists():
        return Path(logfile).read_text(encoding="utf-8", errors="replace")
    return ""


def parse_run(text):
    """Wyciaga z logu tempo krokow ostatniego zadania (base i hires)."""
    if not text:
        return {}
    segments = text.replace("\r", "\n").split("got prompt")
    segment = segments[-1] if len(segments) > 1 else text
    matches = PROGRESS_RE.findall(segment)
    rates = []
    for _done, total, _elapsed, _left, value, unit in matches:
        value = float(value)
        per_step = value if unit == "s/it" else (1.0 / value if value else 0.0)
        if per_step <= 0:
            continue
        rates.append({"total": int(total), "s_per_step": round(per_step, 2), "shown": _shown(value, unit)})
    executed = EXECUTED_RE.search(segment)
    return {
        "passes": rates,
        "base_s_per_step": rates[0]["s_per_step"] if rates else None,
        "hires_s_per_step": rates[-1]["s_per_step"] if len(rates) > 1 else None,
        "executed_s": float(executed.group(1)) if executed else None,
    }


def _shown(value, unit):
    return (str(value) + " " + unit).strip()


def wait_for(comfy, prompt_id, timeout, poll):
    deadline = time.time() + float(timeout)
    while time.time() < deadline:
        time.sleep(float(poll))
        status, obj, _ = http_json(comfy.rstrip("/") + "/history/" + prompt_id, None, 30)
        if status != 200 or not isinstance(obj, dict):
            continue
        entry = obj.get(prompt_id)
        if not isinstance(entry, dict):
            continue
        state = str((entry.get("status") or {}).get("status_str") or "")
        if state == "error":
            return {"state": "error", "entry": entry}
        if entry.get("outputs"):
            return {"state": "success", "entry": entry}
    return {"state": "timeout", "entry": None}


def one_run(comfy, graph, steps, size, prefix, args):
    prepared, sampler_count = build_graph(graph, steps, size, prefix + "/" + secrets.token_hex(3))
    started = time.time()
    status, obj, text = http_json(comfy.rstrip("/") + "/prompt",
                                  {"prompt": prepared, "client_id": "chloe-bench-" + secrets.token_hex(4)}, 60)
    if status != 200 or not obj:
        raise RuntimeError("ComfyUI /prompt " + str(status) + ": " + str(text)[:300])
    if obj.get("node_errors"):
        raise RuntimeError("ComfyUI odrzucilo graf: " + json.dumps(obj.get("node_errors"))[:400])
    prompt_id = str(obj.get("prompt_id") or "")
    if not prompt_id:
        raise RuntimeError("ComfyUI nie zwrocilo prompt_id: " + str(text)[:300])
    result = wait_for(comfy, prompt_id, args.timeout, args.poll)
    wall = time.time() - started
    if result["state"] != "success":
        raise RuntimeError("zadanie nie doszlo do konca (" + result["state"] + ")")
    measured = parse_run(fetch_log(comfy, args.logfile))
    measured.update({"wall_s": round(wall, 1), "samplers": sampler_count})
    return measured


def main(argv=None):
    parser = argparse.ArgumentParser(description="Pomiar tempa krokow ComfyUI (dla Chloe)")
    parser.add_argument("--comfy", default=DEFAULT_COMFY, help="adres ComfyUI (domyslnie http://127.0.0.1:8188)")
    parser.add_argument("--workflow", default=str(DEFAULT_WORKFLOW), help="workflow w formacie API")
    parser.add_argument("--runs", type=int, default=3, help="ile przebiegow (domyslnie 3)")
    parser.add_argument("--steps", type=int, default=3, help="kroki w KSamplerach na czas pomiaru (domyslnie 3)")
    parser.add_argument("--size", default="", help="wymus rozmiar latentu, np. 512x768")
    parser.add_argument("--prefix", default="bench", help="prefix plikow tymczasowych (domyslnie bench)")
    parser.add_argument("--timeout", type=float, default=600, help="limit jednego przebiegu w sekundach")
    parser.add_argument("--poll", type=float, default=1.0, help="odstep odpytywania ComfyUI")
    parser.add_argument("--logfile", default="", help="sciezka do user\\comfyui.log, gdy /internal/logs nie dziala")
    parser.add_argument("--report", default="", help="zapisz raport do pliku tekstowego")
    parser.add_argument("--json", default="", help="zapisz surowe wyniki do pliku JSON")
    args = parser.parse_args(argv)

    comfy = args.comfy.rstrip("/")
    print("Pomiar ComfyUI: " + comfy)
    status, stats, text = http_json(comfy + "/system_stats", None, 10)
    if status != 200 or not isinstance(stats, dict):
        print("[BLAD] ComfyUI nie odpowiada pod " + comfy + " (" + str(text)[:120] + ")")
        return 1
    devices = stats.get("devices") or [{}]
    device = devices[0] if devices else {}
    print("   karta: " + str(device.get("name") or "?") +
          "  VRAM: " + str(round(float(device.get("vram_free") or 0) / 1024 ** 3, 2)) + " GB wolne z " +
          str(round(float(device.get("vram_total") or 0) / 1024 ** 3, 2)) + " GB")
    print("   ComfyUI: " + str((stats.get("system") or {}).get("comfyui_version") or "?"))

    try:
        graph = load_workflow(args.workflow)
    except Exception as exc:
        print("[BLAD] " + str(exc))
        return 1
    print("   workflow: " + os.path.basename(str(args.workflow)) + " (" + str(len(graph)) + " nodow), " +
          str(args.steps) + " krokow na pomiar, " + str(args.runs) + " przebiegi")
    attention = ""
    try:
        log_text = fetch_log(comfy, args.logfile)
        found = [line.strip() for line in log_text.replace("\r", "\n").split("\n")
                 if "attention" in line.lower() and "optimization" in line.lower()]
        attention = found[-1] if found else ""
    except Exception:
        pass
    if attention:
        print("   attention: " + attention.split(" - ", 1)[-1][:140])

    results = []
    try:
        for index in range(max(1, int(args.runs))):
            measured = one_run(comfy, graph, args.steps, args.size, args.prefix, args)
            results.append(measured)
            print("   przebieg " + str(index + 1) + "/" + str(args.runs) + ":  calosc " +
                  str(measured["wall_s"]) + " s  |  base " + _fmt(measured.get("base_s_per_step")) +
                  " s/krok  |  hires " + _fmt(measured.get("hires_s_per_step")) + " s/krok")
    except KeyboardInterrupt:
        print("   przerwane")
    except Exception as exc:
        print("[BLAD] " + str(exc))
        if not results:
            return 1

    if not results:
        return 1
    walls = [r["wall_s"] for r in results]
    hires = [r["hires_s_per_step"] for r in results if r.get("hires_s_per_step")]
    base = [r["base_s_per_step"] for r in results if r.get("base_s_per_step")]
    worst_ratio = (max(walls) / min(walls)) if len(walls) > 1 and min(walls) else 1.0
    verdict = "stabilnie"
    code = 0
    if worst_ratio >= 2.5:
        verdict = "NIESTABILNIE - jeden przebieg byl " + str(round(worst_ratio, 1)) + "x wolniejszy od najszybszego"
        code = 2
    lines = []
    lines.append("Pomiar ComfyUI - " + time.strftime("%Y-%m-%d %H:%M:%S"))
    lines.append("  adres: " + comfy)
    lines.append("  workflow: " + str(args.workflow) + " (" + str(args.steps) + " krokow, " + str(len(results)) + " przebiegow)")
    if attention:
        lines.append("  attention: " + attention.split(" - ", 1)[-1][:160])
    for index, measured in enumerate(results):
        lines.append("  przebieg " + str(index + 1) + ": calosc " + str(measured["wall_s"]) + " s, base " +
                     _fmt(measured.get("base_s_per_step")) + " s/krok, hires " +
                     _fmt(measured.get("hires_s_per_step")) + " s/krok")
    lines.append("  mediana: calosc " + str(round(statistics.median(walls), 1)) + " s, base " +
                 _fmt(statistics.median(base) if base else None) + " s/krok, hires " +
                 _fmt(statistics.median(hires) if hires else None) + " s/krok")
    lines.append("  werdykt: " + verdict)
    lines.append("  (im mniejszy i stabilniejszy hires s/krok, tym lepiej. Zmien ustawienia startowe i powtorz pomiar.)")
    report = "\n".join(lines)
    print("")
    print(report)
    if args.report:
        try:
            Path(args.report).write_text(report + "\n", encoding="utf-8")
            log("raport zapisany: " + str(args.report))
        except Exception as exc:
            log("nie udalo sie zapisac raportu: " + str(exc))
    if args.json:
        try:
            Path(args.json).write_text(json.dumps({"attention": attention, "steps": args.steps,
                                                   "workflow": str(args.workflow), "runs": results},
                                                  ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    return code


def _fmt(value):
    return "-" if value is None else str(value)


if __name__ == "__main__":
    sys.exit(main())
