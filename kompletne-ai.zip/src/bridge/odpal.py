#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Odpalacz dla Chloe: ComfyUI + mostek Hermes (OpenRouter) + ComfyUI.

Robi jednym poleceniem (albo dwuklikiem na odpal.bat) to, co wczesniej trzeba bylo
robic recznie w dwoch oknach:
  1) znajduje i uruchamia ComfyUI na http://127.0.0.1:8188 i czeka, az wstanie,
  2) uruchamia mostek (hermes_comfy_bridge.py) na http://127.0.0.1:8443,
  3) Ctrl+C konczy mostek i (domyslnie) zamyka ComfyUI razem z nim.

Przyklady:
  python odpal.py                          # ComfyUI (auto-wykryty) + mostek
  python odpal.py --comfy-dir "C:\\ComfyUI"  # wskaz folder ComfyUI (zapamietuje)
  python odpal.py --no-comfy               # tylko mostek (ComfyUI juz chodzi)
  python odpal.py --comfy-only             # tylko ComfyUI (mostek odpal osobno)
  python odpal.py --find-comfy             # pokaz, gdzie szukalem i co znalazlem
  python odpal.py -- --no-refine           # wszystko po "--" leci do mostka
  python odpal.py --keep-comfy --yes       # nie zamykaj ComfyUI po Ctrl+C, bez pytania

Ustawienia trwale: odpal_config.json obok tego pliku (tworzy sie sam).
Wymaga tylko biblioteki standardowej (ten sam Python co mostek).
"""

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG_FILE = ROOT / "odpal_config.json"
BRIDGE_SCRIPT = ROOT / "hermes_comfy_bridge.py"

DEFAULT_COMFY_URL = "http://127.0.0.1:8188"
DEFAULT_BRIDGE_HOST = "127.0.0.1"
DEFAULT_BRIDGE_PORT = 8443

DEFAULTS = {
    "comfy_dir": "",
    "comfy_url": DEFAULT_COMFY_URL,
    "comfy_args": [],
    "cors": True,
    "python": "",
    "wait_sec": 600,
    "open_browser": True,
    "keep_comfy": False,
}


def say(msg=""):
    try:
        print(msg, flush=True)
    except Exception:
        pass


def load_config():
    cfg = dict(DEFAULTS)
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key, value in data.items():
                    if key in cfg and value is not None:
                        cfg[key] = value
        except Exception as exc:
            say("Nie udalo sie wczytac " + str(CONFIG_FILE) + ": " + str(exc))
    return cfg


def save_config(cfg):
    try:
        CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        say("Zapisano ustawienia: " + str(CONFIG_FILE))
    except Exception as exc:
        say("Nie udalo sie zapisac " + str(CONFIG_FILE) + ": " + str(exc))


# ----------------------------------------------------------------- ComfyUI: szukanie

def _candidate_roots(cfg):
    roots = []
    if cfg.get("comfy_dir"):
        roots.append(Path(str(cfg["comfy_dir"])).expanduser())
    roots += [
        ROOT, ROOT / "ComfyUI", ROOT / "comfy", ROOT / "ComfyUI_windows_portable",
        Path.home() / "Desktop" / "ComfyUI",
        Path.home() / "Desktop" / "ComfyUI_windows_portable",
        Path.home() / "ComfyUI",
        Path.home() / "Documents" / "ComfyUI",
        Path.home() / "Downloads" / "ComfyUI",
        Path("C:/ComfyUI"),
        Path("C:/ComfyUI_windows_portable"),
        Path("C:/AI/ComfyUI"),
    ]
    # typowe nazwy folderow w pobranych/Desktopie: ComfyUI, ComfyUI-cuda, ComfyUI_v2 ...
    seen = set()
    uniq = []
    for root in roots:
        key = str(root).lower()
        if key in seen:
            continue
        seen.add(key)
        uniq.append(root)
    return uniq


def _portable_python(root):
    for name in ("python_embeded", "python_embedded"):
        for exe in ("python.exe", "python"):
            cand = root / name / exe
            if cand.exists():
                return str(cand)
    return ""


def _venv_python(root):
    for name in ("venv", ".venv", "env"):
        for sub in (Path("Scripts") / "python.exe", Path("bin") / "python"):
            cand = root / name / sub
            if cand.exists():
                return str(cand)
    return ""


def system_python():
    for name in ("python", "python3"):
        found = shutil.which(name)
        if found:
            return found
    return sys.executable or "python"


def _describe(root, meta, cfg):
    kind = meta["kind"]
    label = str(root)
    if kind in ("bat",):
        label = str(meta["bat"])
    return {
        "kind": kind,
        "root": root,
        "main": meta.get("main"),
        "bat": meta.get("bat"),
        "python": meta.get("python") or cfg.get("python") or "",
        "label": label,
    }


def _check_root(root, cfg):
    """Zwraca liste mozliwych sposobow uruchomienia ComfyUI w tym folderze."""
    found = []
    try:
        if not root.exists():
            return found
    except OSError:
        return found
    for bat in ("run_nvidia_gpu.bat", "run_nvidia_gpu_fast_fp16_accumulation.bat",
                "run_cpu.bat", "run_nvidia_gpu_lowvram.bat"):
        cand = root / bat
        if cand.exists():
            found.append(_describe(root, {"kind": "bat", "bat": cand}, cfg))
    inner = root / "ComfyUI" / "main.py"
    if inner.exists():
        found.append(_describe(root, {"kind": "portable", "main": inner,
                                      "python": _portable_python(root)}, cfg))
    if (root / "main.py").exists():
        found.append(_describe(root, {"kind": "main", "main": root / "main.py",
                                      "python": _venv_python(root)}, cfg))
    return found


def detect_comfyui(cfg, verbose=False):
    """Szuka instalacji ComfyUI. Zwraca dict albo None."""
    tried = []
    for root in _candidate_roots(cfg):
        tried.append(str(root))
        found = _check_root(root, cfg)
        if found:
            if verbose:
                for item in found:
                    say("  " + item["kind"].ljust(9) + " " + item["label"])
            return found[0]
        # jeden poziom w glab folderow o typowych nazwach
        try:
            if root.is_dir():
                for child in sorted(root.glob("ComfyUI*"))[:20]:
                    if child.is_dir():
                        tried.append(str(child))
                        found = _check_root(child, cfg)
                        if found:
                            if verbose:
                                for item in found:
                                    say("  " + item["kind"].ljust(9) + " " + item["label"])
                            return found[0]
        except Exception:
            pass
    if verbose:
        say("  (nie znalazlem - sprawdzone sciezki:)")
        for path in tried:
            say("    " + path)
    return None


# ------------------------------------------------------------------ ComfyUI: proces

def build_comfy_cmd(info, cfg):
    """Zwraca (cmd, cwd, uwaga)."""
    args = []
    note = ""
    if cfg.get("cors"):
        # ComfyUI sam dodaje naglowki CORS - potrzebne tylko, gdy przegladarka ma
        # wolac ComfyUI bezposrednio (dostawca "comfyui" w panelu Obrazy). Mostek
        # gada z ComfyUI po stronie serwera, wiec CORS nie jest mu potrzebny.
        args += ["--enable-cors-header", "*"]
    extra = cfg.get("comfy_args") or []
    if isinstance(extra, str):
        extra = extra.split()
    args += [str(item) for item in extra]

    if info["kind"] == "bat":
        cmd = ["cmd", "/c", str(info["bat"])] + args
        note = "Uruchamiam Twoj plik " + Path(str(info["bat"])).name + "."
        return cmd, str(info["root"]), note

    python = cfg.get("python") or info.get("python") or system_python()
    cmd = []
    if info["kind"] == "portable":
        cmd += [str(python), "-s", str(info["main"])]
    else:
        cmd += [str(python), str(info["main"])]
    cmd += args
    if not info.get("python") and not cfg.get("python"):
        note = "Uruchamiam '" + str(python) + "' z PATH - jesli ComfyUI ma wlasne venv, uzyj --comfy-dir."
    return cmd, str(info["root"]), note


def _creationflags():
    return getattr(subprocess, "CREATE_NEW_CONSOLE", 0) if os.name == "nt" else 0


def launch_comfy(info, cfg, same_window=False):
    cmd, cwd, note = build_comfy_cmd(info, cfg)
    say("Startuje ComfyUI:")
    say("  " + " ".join('"' + part + '"' if " " in part else part for part in cmd))
    say("  katalog: " + cwd)
    if note:
        say("  " + note)
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    try:
        if same_window:
            proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, bufsize=1, universal_newlines=True)
            _prefix_thread(proc)
        else:
            proc = subprocess.Popen(cmd, cwd=cwd, env=env, creationflags=_creationflags())
    except FileNotFoundError:
        say("Nie znaleziono programu do uruchomienia ComfyUI: " + cmd[0])
        say("Uzyj --comfy-dir z folderem instalacji albo popraw sciezke w odpal_config.json.")
        raise SystemExit(3)
    except Exception as exc:
        say("Nie udalo sie uruchomic ComfyUI: " + str(exc))
        raise SystemExit(3)
    say("  PID " + str(proc.pid))
    return proc


def _prefix_thread(proc):
    def pump():
        try:
            for line in proc.stdout:
                say("[comfy] " + str(line).rstrip())
        except Exception:
            pass
    thread = threading.Thread(target=pump)
    thread.daemon = True
    thread.start()
    return thread


def comfy_up(url, timeout=2.5):
    target = str(url).rstrip("/") + "/system_stats"
    try:
        with urllib.request.urlopen(target, timeout=timeout) as response:
            status = getattr(response, "status", 200)
            return status is None or 200 <= int(status) < 500
    except Exception:
        return False


def wait_for_comfy(url, wait_sec):
    if not wait_sec or wait_sec <= 0:
        return comfy_up(url)
    say("Czekam, az ComfyUI wstanie (" + str(url) + ", do " + str(int(wait_sec)) + " s) ")
    started = time.time()
    while time.time() - started < wait_sec:
        if comfy_up(url):
            sys.stdout.write(" gotowe po " + str(int(time.time() - started)) + " s\n")
            sys.stdout.flush()
            return True
        sys.stdout.write(".")
        sys.stdout.flush()
        time.sleep(1)
    sys.stdout.write("\n")
    sys.stdout.flush()
    return False


def stop_comfy(proc):
    if proc is None:
        return
    try:
        if proc.poll() is not None:
            return
    except Exception:
        pass
    say("Zamykam ComfyUI (PID " + str(proc.pid) + ") ...")
    try:
        if os.name == "nt":
            killer = subprocess.Popen(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            try:
                killer.wait(timeout=15)
            except Exception:
                pass
        else:
            proc.terminate()
    except Exception:
        try:
            proc.terminate()
        except Exception:
            pass


# ------------------------------------------------------------------ mostek: start

def bridge_endpoint(passthrough):
    host, port = DEFAULT_BRIDGE_HOST, DEFAULT_BRIDGE_PORT
    cfg_file = ROOT / "bridge_config.json"
    if cfg_file.exists():
        try:
            data = json.loads(cfg_file.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                host = str(data.get("host") or host)
                port = int(data.get("port") or port)
        except Exception:
            pass
    args = list(passthrough or [])
    for i, item in enumerate(args):
        if item == "--host" and i + 1 < len(args):
            host = args[i + 1]
        elif item.startswith("--host="):
            host = item.split("=", 1)[1]
        elif item == "--port" and i + 1 < len(args):
            try:
                port = int(args[i + 1])
            except ValueError:
                pass
        elif item.startswith("--port="):
            try:
                port = int(item.split("=", 1)[1])
            except ValueError:
                pass
    return host, port


def port_free(host, port):
    probe_host = host
    if probe_host in ("0.0.0.0", "::"):
        probe_host = ""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((probe_host, int(port)))
        return True
    except OSError:
        return False
    finally:
        try:
            sock.close()
        except Exception:
            pass


def start_bridge(passthrough):
    if not BRIDGE_SCRIPT.exists():
        say("Brak pliku " + str(BRIDGE_SCRIPT) + " - odpalacz musi lezec obok mostka.")
        return 4
    sys.path.insert(0, str(ROOT))
    try:
        import hermes_comfy_bridge as bridge
    except Exception as exc:
        say("Nie udalo sie wczytac mostka (hermes_comfy_bridge.py): " + str(exc))
        return 4
    return bridge.main(list(passthrough or []))


def open_status_page(url):
    """Otwiera strone statusu mostka w przegladarce (w tle, zeby nie blokowac startu)."""
    def worker():
        time.sleep(1.5)
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass
    try:
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
        return True
    except Exception:
        # np. srodowisko bez watkow - nie przewracamy odpalacza, adres i tak wypiszemy na koncu
        return False


def ask_keep(question, default_yes=True):
    try:
        answer = input(question).strip().lower()
    except Exception:
        return default_yes
    if not answer:
        return default_yes
    return answer[0] in ("t", "y", "1")


# --------------------------------------------------------------------------- main

def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Odpala ComfyUI i mostek Hermes (OpenRouter) + ComfyUI dla Chloe.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Wszystko po '--' leci do mostka, np.: python odpal.py -- --no-refine --size 832x1216",
    )
    parser.add_argument("--comfy-dir", default=None, help="folder instalacji ComfyUI (zapamietuje w odpal_config.json)")
    parser.add_argument("--comfy-url", default=None, help="adres ComfyUI (domyslnie http://127.0.0.1:8188)")
    parser.add_argument("--python", default=None, help="interpreter Pythona dla ComfyUI (domyslnie wykryty/portable)")
    parser.add_argument("--no-comfy", action="store_true", help="nie uruchamiaj ComfyUI (juz chodzi / odpalasz je inaczej)")
    parser.add_argument("--comfy-only", action="store_true", help="tylko ComfyUI, bez mostka")
    parser.add_argument("--no-cors", action="store_true", help="nie dodawaj --enable-cors-header do ComfyUI")
    parser.add_argument("--wait", type=float, default=None, help="ile sekund czekac na ComfyUI (domyslnie 600)")
    parser.add_argument("--same-window", action="store_true", help="log ComfyUI w tym samym oknie (z prefiksem [comfy])")
    parser.add_argument("--no-browser", action="store_true", help="nie otwieraj strony statusu mostka")
    parser.add_argument("--keep-comfy", action="store_true", help="nie zamykaj ComfyUI po zakonczeniu")
    parser.add_argument("--yes", action="store_true", help="nie pytaj o nic (zamyka ComfyUI bez pytania)")
    parser.add_argument("--find-comfy", action="store_true", help="pokaz, gdzie szukalem ComfyUI, i wyjdz")
    parser.add_argument("--save", action="store_true", help="zapisz biezace ustawienia do odpal_config.json i wyjdz")
    return parser.parse_known_args(argv)


def main(argv=None):
    raw = list(argv if argv is not None else sys.argv[1:])
    args, unknown = parse_args(raw)
    # Argumenty dla mostka: wszystko po "--", a bez "--" - to, co nie pasowalo do odpalacza.
    if "--" in raw:
        passthrough = raw[raw.index("--") + 1:]
    else:
        passthrough = list(unknown)

    cfg = load_config()
    if args.comfy_dir:
        cfg["comfy_dir"] = str(Path(args.comfy_dir).expanduser())
    if args.comfy_url:
        cfg["comfy_url"] = args.comfy_url
    if args.python:
        cfg["python"] = args.python
    if args.no_cors:
        cfg["cors"] = False
    if args.wait is not None:
        cfg["wait_sec"] = args.wait
    if args.no_browser:
        cfg["open_browser"] = False
    if args.keep_comfy:
        cfg["keep_comfy"] = True

    if args.save or args.comfy_dir or args.comfy_url or args.python:
        save_config(cfg)

    if args.find_comfy:
        say("Szukam ComfyUI (folder odpalacza: " + str(ROOT) + ") ...")
        info = detect_comfyui(cfg, verbose=True)
        say("")
        if info:
            cmd, cwd, note = build_comfy_cmd(info, cfg)
            say("Znalazlem: " + info["label"])
            say("Uruchomienie: " + " ".join(cmd) + "   (katalog: " + cwd + ")")
        else:
            say("Nie znalazlem ComfyUI.")
            say("Podaj folder recznie, np.:  python odpal.py --comfy-dir \"C:\\Sciezka\\Do\\ComfyUI\"")
        return 0

    comfy_proc = None
    comfy_started_by_us = False

    if not args.no_comfy:
        if comfy_up(cfg["comfy_url"]):
            say("ComfyUI juz odpowiada na " + str(cfg["comfy_url"]) + " - nie uruchamiam drugiego.")
        else:
            info = detect_comfyui(cfg)
            if not info:
                say("")
                say("Nie znalazlem ComfyUI. Uruchom go sam, albo wskaz folder:")
                say("  python odpal.py --comfy-dir \"C:\\Sciezka\\Do\\ComfyUI\"")
                say("(podglad szukania: python odpal.py --find-comfy)")
                if not args.comfy_only:
                    say("")
                    say("Uruchamiam sam mostek - obrazy nie zadzialaja, dopoki ComfyUI nie wstanie.")
                else:
                    return 3
            else:
                try:
                    comfy_proc = launch_comfy(info, cfg, same_window=args.same_window)
                    comfy_started_by_us = True
                except SystemExit as exc:
                    if args.comfy_only:
                        raise
                    say("Kontynuuje z samym mostkiem (kod " + str(exc.code) + ").")
                if comfy_started_by_us:
                    if not wait_for_comfy(cfg["comfy_url"], cfg["wait_sec"]):
                        say("ComfyUI nie odpowiedzial w " + str(int(cfg["wait_sec"])) + " s.")
                        say("Sprawdz jego okno - zwykle brakuje modeli/CLIPu albo jest blad Pythona.")
                        say("Mostek uruchamiam mimo to; obrazy rusza, gdy ComfyUI wstanie.")

    if args.comfy_only:
        say("")
        say("ComfyUI dziala. Ctrl+C zamyka go.")
        try:
            while True:
                if comfy_proc is not None and comfy_proc.poll() is not None:
                    say("ComfyUI zakonczyl sie (kod " + str(comfy_proc.returncode) + ").")
                    break
                time.sleep(1)
        except KeyboardInterrupt:
            say("")
        finally:
            if comfy_started_by_us and not cfg.get("keep_comfy"):
                if args.yes or ask_keep("Zamknac ComfyUI? [T/n] ", True):
                    stop_comfy(comfy_proc)
        return 0

    host, port = bridge_endpoint(passthrough)
    if not port_free(host, port):
        say("Port " + str(port) + " jest juz zajety - mostek chyba juz dziala w innym oknie.")
        say("Jesli to nie mostek, zmien port: python odpal.py -- --port 8444 (i taki sam w panelu Chloe).")
        if comfy_started_by_us:
            stop_comfy(comfy_proc)
        return 2

    status_url = "http://" + ("127.0.0.1" if host in ("0.0.0.0", "::", "") else host) + ":" + str(port) + "/"
    if cfg.get("open_browser"):
        open_status_page(status_url)

    code = 0
    try:
        code = start_bridge(passthrough)
    except KeyboardInterrupt:
        say("")
        code = 0
    finally:
        if comfy_started_by_us and not cfg.get("keep_comfy"):
            if args.yes or ask_keep("Zamknac ComfyUI razem z mostkiem? [T/n] ", True):
                stop_comfy(comfy_proc)
            else:
                say("ComfyUI zostaje uruchomiony.")
        say("")
        say("Gotowe. Status mostka: " + status_url)
        say("Z telefonu: tailscale serve --bg --https=" + str(port) + " http://127.0.0.1:" + str(port))
    return code


if __name__ == "__main__":
    sys.exit(main())
