@echo off
setlocal EnableExtensions
title Diagnostyka ComfyUI ROCm

rem =====================================================================
rem  sprawdz_comfy.bat - zbiera wszystko, co potrzebne do naprawy startu
rem  ComfyUI ROCm, do pliku raport_comfy.txt i otwiera go w notatniku.
rem  Niczego nie zmienia w systemie: tylko czyta i uruchamia --selftest mostka.
rem =====================================================================

set "CHL_ROOT=%~dp0"
set "CHL_CDIR=%CHL_ROOT%comfyui-rocm-091926"
set "CHL_REP=%CHL_ROOT%raport_comfy.txt"
set "CHL_PY="
where py >nul 2>&1 && set "CHL_PY=py -3"
if not defined CHL_PY (
    where python >nul 2>&1 && set "CHL_PY=python"
)

if not exist "%CHL_CDIR%\" (
    echo [BLAD] Nie ma folderu: "%CHL_CDIR%"
    echo        Popraw sciezke CHL_CDIR w tym pliku.
    pause
    exit /b 1
)

break > "%CHL_REP%"

(
    echo ==============================================================
    echo  RAPORT ComfyUI ROCm - do diagnozy startu
    echo  data:   %DATE% %TIME%
    echo  folder: %CHL_CDIR%
    echo ==============================================================
    echo.
    echo ---- 1. Pliki i katalogi w folderze ComfyUI ----
    dir "%CHL_CDIR%"
    echo.
    echo ---- 2. comfyui-rocm.bat - pelna zawartosc ----
    type "%CHL_CDIR%\comfyui-rocm.bat"
    echo.
    echo ---- 3. Inne pliki .bat .cmd .ps1 w folderze ----
    dir /b "%CHL_CDIR%\*.bat" "%CHL_CDIR%\*.cmd" "%CHL_CDIR%\*.ps1"
    echo.
    echo ---- 4. Python widziany z PATH ----
    where python
    python --version
    echo.
    echo ---- 5. Zmienne ROCm / HIP / AMD / HSA / PATH ----
    set | findstr /I "rocm hip amd hsa gfx torch path="
    echo.
    echo ---- 6. Podfoldery pierwszego poziomu ----
    dir /ad /b "%CHL_CDIR%"
    echo.
    echo ---- 7. Wszystkie .bat w podfolderach ----
    dir /s /b "%CHL_CDIR%\*.bat"
    echo.
    echo ---- 8. python.exe znalezione w folderze ----
    dir /s /b "%CHL_CDIR%\python.exe"
    echo.
    echo ---- 9. Czy cos slucha na porcie 8188 ----
    netstat -ano | findstr ":8188"
) > "%CHL_REP%" 2>&1

echo. >> "%CHL_REP%"
echo ---- 10. Mostek: --selftest - czyli klucz OpenRoutera, workflow i ComfyUI ----
if defined CHL_PY (
    %CHL_PY% "%CHL_ROOT%hermes_comfy_bridge.py" --selftest >> "%CHL_REP%" 2>&1
) else (
    echo [UWAGA] brak Pythona w PATH - pomijam test mostka >> "%CHL_REP%"
)

echo.
echo Gotowe. Raport jest tutaj:
echo   %CHL_REP%
echo.
echo Wrzuc ten plik jako zalacznik w czacie z Chloe - wtedy da sie to naprawic.
echo.
start "" notepad "%CHL_REP%"
