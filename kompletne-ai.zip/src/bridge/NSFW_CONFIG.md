# Workflow ComfyUI pod hard NSFW + szybkość — audyt i konfiguracja

Stan na 25.09.2026. Dokument opisuje, co było w `workflow_api.json`, co zmieniłem,
jakie są zmierzone czasy na tym sprzęcie (Radeon RX 7600S 8 GB, ROCm, `--lowvram`),
jakie modele warto pobrać pod „full hard NSFW" i jak przełączać tryby w mostku v11.

**Aktualizacja 25.09.2026 (mostek v12):** doszedł automatyczny dobór checkpointu, więc
pobrany model **nie wymaga już edycji `bridge_config.json`** (sekcja 5.1), oraz **nowy tryb
`sdxl_std`** — 24 kroki bez destylacji, 42,6 s, lepszy od 8-krokowych wariantów
(pomiary i werdykt: sekcja 5.2).

## 1. TL;DR

* Stary workflow marnował ~70% czasu: rysował bazę 768x768 (mostek nadpisywał rozmiar
  z pliku!), potem 4x upscaler robił z tego 3072x3072, żeby na końcu zmniejszyć do
  1024x1536 i jeszcze raz domalowywać. **63,7 s na obraz.**
* Nowy domyślny tryb: **768x1152 natywnie, 20 kroków, ~18-19 s, lepsza jakość**
  (ostrość 8/10 zamiast 5-6/10 przy upscale'ach).
* Tryb szybki: **512x768 + upscale ESRGAN 2x → 1024x1536, ~3-4 s** (ciepły model).
* Wąskie gardło na tym GPU to **dekodowanie VAE w wysokiej rozdzielczości** (~11 s przy
  1024x1536), a nie próbkowanie (SD1.5: ~0,15 s/krok przy 512x768). Dlatego nie warto
  domalowywać w wysokiej rozdzielczości — lepiej rysować natywnie w docelowym rozmiarze.
* Destylowane LoRA (Hyper-SD / Lightning) dla SD1.5 **nie opłacają się** tutaj:
  oszczędzają ~2 s próbkowania, a kosztują na jakości (wosk, gorsze dłonie). Włączam je
  dopiero dla SDXL, gdzie pojedynczy krok jest drogi.
* Pod „full hard NSFW" najlepsze jest przejście na **SDXL** (LUSTIFY SDXL NSFW /
  CyberRealisticXL Play / WAI-NSFW-Illustrious). Pobieracz: `Pobierz_modele_NSFW.bat`.

## 2. Audyt starego `workflow_api.json`

Struktura (nody): checkpoint `epicrealism_naturalSinRC1VAE` → LoRA `epiCRealismHelper`
(0.6) → KSampler(base) 25 kroków / CFG 6 / dpmpp_2m+karras → VAEDecode →
UpscaleModel 4x NMKD → ImageScale do 1024x1536 → VAEEncode → KSampler(hires) 20 kroków /
denoise 0.35 → VAEDecode → SaveImage.

Problemy:

1. **Rozmiar bazy nadpisywany przez mostek.** Plik miał 512x768, ale mostek wpisywał
   `cfg.size` (domyślnie `768x768`) do `EmptyLatentImage`. Czyli baza i tak liczyła się
   w 768x768 (o 50% drożej niż w pliku).
2. **4x upscaler na wejściu 768x768** → obraz 3072x3072, a potem `ImageScale` do
   1024x1536. To wyrzucanie ~75% wyliczonych pikseli (NMKD 4x na tak dużym wejściu to
   zwykle kilkanaście-kilkadziesiąt sekund na tej karcie).
3. **Dwa przebiegi + dwa dekodowania VAE**, w tym dekodowanie w 1024x1536 (~11 s!).
4. **45 kroków łącznie** przy CFG 6 — dużo jak na rozdzielczości, które i tak nie wnoszą
   już detalu.
5. Brak LoRA przyspieszającej, brak trybów — nie dało się wybrać „szybko/inaczej".

## 3. Pomiary (RX 7600S 8 GB, ROCm, `--lowvram`, ta sama scena/seed)

| Wariant | Ustawienia | Czas | Ocena jakości (vision) |
|---|---|---|---|
| **stary classic** | 25 st. 512x768 → NMKD 4x → hires 1024x1536 (d=0,35) | **63,7 s** | dobra (ostrość 8/10, skóra 7/10) |
| base-only | 512x768, 8 st. (Hyper-SD) | 5,0 s | za mało detalu |
| **nowy domyślny** | **768x1152 natywnie, 20 st., CFG 6, dpmpp_2m karras** | **18,4-19,4 s** | **najlepsza: skóra 8, włosy 7, koronka 7, ostrość 8, anatomia 7,5 — brak artefaktów high-res** |
| hires 1,5x | 512x768 20 st. → latent 1,5x → 6 st. (d=0,45) | 15,4 s | miękka (ostrość 5-6/10) |
| hires 1,5x | 512x768 20 st. → latent 1,5x → 12 st. | 19,2 s | miękka, „wyprana" (5-6/10) |
| hires 2x | 512x768 20 st. → latent 2x → 12 st. | 27,4 s | miękka (6/10) |
| sam upscale latentu | 512x768 20 st. → latent 2x → VAEDecode 1024x1536 (bez domalowywania) | 14,2 s | — (to pokazuje, że samo **dekodowanie VAE 1024x1536 ≈ 11 s**) |
| **nowy fast** | **512x768 20 st. → VAEDecode → ESRGAN 2x → 1024x1536** | **3,0 s** (ciepły model; ~10 s po przełączeniu workflow) | miękka/wygładzona (ostrość 5/10), ale do czatu wystarcza |
| Hyper-SD 8 st. + ESRGAN | 512x768, LoRA Hyper-SD 8st CFG | 8,1 s | — (LoRA doładowuje ~4 s narzutu, więc nie warto) |

## 4. Co z tego wynika dla tego sprzętu

* **Próbkowanie jest tanie, dekodowanie i domalowywanie w wysokiej rozdzielczości jest drogie.**
  SD1.5 przy 512x768: ~0,15 s/krok. Przy 1024x1536 krok jest ~10x droższy, a do tego
  dochodzi ~11 s na samym dekodowaniu VAE.
* Dlatego **rysuj natywnie w docelowym rozmiarze** (768x1152) i nie domalowuj.
* Upscaler ESRGAN na *zdekodowanym* obrazie jest prawie darmowy (~0,5 s) i nie wymaga
  dekodowania VAE w dużym rozmiarze → stąd 3 s dla trybu `fast`.
* **Zmiana workflow w trakcie sesji kosztuje** (przeładowanie/patche modelu i LoRA).
  Jeśli robisz serię obrazów w jednym trybie, drugi i kolejny są szybsze.
* `--lowvram` (obecnie w launcherze) na 8 GB jest bezpieczny, ale wymusza przenoszenie
  danych — warto przetestować `--normalvram`/bez flagi (patrz §9).

## 5. Nowe pliki workflow i tryby (mostek v11)

| Tryb (`preset`) | Plik | Rozmiar | Kroki | Wyjście | Czas |
|---|---|---|---|---|---|
| `default` | `workflow_api.json` | 768x1152 | 20 | 768x1152 | ~18-19 s |
| `fast` | `workflow_sd15_fast.json` | 512x768 | 20 | 1024x1536 (ESRGAN 2x) | ~3-4 s |
| `classic` | `workflow_sd15_classic.json` | 512x768 | 25+20 | 1024x1536 | ~64 s (do porównań) |
| `sdxl_fast` | `workflow_sdxl_fast.json` | 832x1216 | 8 (Lightning) | 832x1216 | ~15-30 s* |
| `sdxl_cfg8` | `workflow_sdxl_cfg8.json` | 832x1216 | 8 (Hyper-SD, CFG 5,5) | 832x1216 | ~15-30 s* |
| `sdxl_std` | `workflow_sdxl_std.json` | 832x1216 | 24 (bez destylacji) | 832x1216 | **42,6 s** (zmierzone) |
| `sdxl_hq` | `workflow_sdxl_hq.json` | 832x1216 | 28 + hires 1,5x | 1248x1824 | **123-152 s** (zmierzone) |

\* tryby SDXL wymagają checkpointu SDXL w `models/checkpoints` (pobierz przez
`Pobierz_modele_NSFW.bat`).

### 5.2 Pomiar trybów SDXL na tym sprzęcie (25.09.2026, LUSTIFY endgame, 8 GB, `--lowvram`)

Pierwsze uruchomienie danego trybu jest drogie (**~70 s**), bo checkpoint 6,9 GB leci
z dysku do VRAM; kolejne (ciepłe) przebiegi:

| Tryb | Czas ciepły | Uwagi z oceny obrazu (ten sam seed, A/B) |
|---|---|---|
| `sdxl_cfg8` / `sdxl_fast` (8 kroków, destylacja) | **21,8-22,1 s** | najszybciej, ale widać „woskową" skórę, kolorowe plamki i słabszą anatomię (destylacja nie zdąży) |
| `sdxl_std` (24 kroki, bez destylacji) | **42,6 s** | **realizm 8,5/10, anatomia 7,5/10** — czysta skóra, brak plamek; w bezpośrednim A/B wyraźnie lepszy od 8 kroków |
| `sdxl_hq` (28 kroków + hires 1,5x) | **123-152 s** | większa rozdzielczość (1248x1824), ale **na części seedów hires psuje anatomię** (np. brak głowy, rozciągnięty tors) — nie wart 3x czasu |

Wnioski:

* **Nowy domyślny tryb jakości to `sdxl_std`** (~43 s): 2x dłużej niż destylowany, ale
  obraz jest wyraźnie lepszy, a nadal 3x szybciej niż `sdxl_hq`.
* `sdxl_cfg8` zostaje jako **szybki podgląd** (21,8 s), a nie tryb „na gotowe".
* W `sdxl_hq` zmniejszyłem hires denoise **0,4 → 0,3** i zmieniłem latent upscale
  **bislerp → nearest-exact** (mniej halo i mniejsze ryzyko rozjechania anatomii), ale
  i tak jest to tryb eksperymentalny.
* Anatomia jest nadal loterią: **seed decyduje** — jak wyjdzie zniekształcona, zmień seed
  (pole `seed` w zadaniu) zamiast dokładać kroki.

### Jak przełączać tryb

1. **Na stałe** — w `bridge_config.json` obok mostka:

```json
{
  "preset": "fast",
  "presets": {
    "moj_sdxl": {
      "workflow_file": "workflow_sdxl_cfg8.json",
      "size": "832x1216",
      "checkpoint": "lustifySDXLNSFW_endgame.safetensors",
      "desc": "SDXL hard NSFW + Hyper-SD 8 krokow"
    }
  }
}
```

2. **Na jedno zadanie** — pole `preset` w żądaniu obrazu
   (`POST /api/generate` albo `/images/generations`), np.
   `{"prompt":"...","preset":"fast"}`. Aplikacja Chloe może to wysyłać, gdy
   dodamy wybór trybu w panelu (dziś domyślnie idzie tryb z konfiguracji).

3. **Inny model bazowy bez edycji workflow** — pole `checkpoint` w presecie albo w
   żądaniu. Mostek podmienia `ckpt_name` we wszystkich loaderach, np. żeby w scenie
   anime poleciał WAI-NSFW-Illustrious, a w fotorealistycznej LUSTIFY.

Pozostałe pola presetu: `steps`, `cfg`, `sampler`, `scheduler`, `denoise`,
`prompt_prefix`, `prompt_suffix`, `refine_hint`, `desc`, `workflow_file`, `size`.
Pierwszeństwo: pole z żądania > preset > wartość w pliku workflow.
Gdy brakuje pliku modelu, mostek zwraca czytelny błąd (z listą podobnych plików
w folderze) zamiast `value not in list` z ComfyUI.

### 5.1 Automatyczny dobór checkpointu (mostek v12)

Presety mają pole `family` (`sd15` dla `default`/`fast`/`classic`, `sdxl` dla `sdxl_*`).
Gdy graf wskazuje plik, którego nie ma na dysku, a w `models/checkpoints` jest model
**tej samej rodziny**, mostek go podstawia:

* log w konsoli mostka: `UWAGA: brak checkpointu X — uzywam Y (rodzina sdxl)`,
* odpowiedź `/api/generate` i `/images/generations`: pole `checkpoint_auto`
  (`{bylo, jest, rodzina, dostepne}`),
* `/health` → `last_image.checkpoint_auto`, a strona statusu pokazuje podmianę pod
  „Ostatni obraz".

Kolejność preferencji: dla SDXL `lustify… → cyberrealisticxl → wainsfw → illustrious →
pony… → cokolwiek z „sdxl"`, dla SD1.5 `epicrealism/naturalsin → hassaku → realistic`.
Modele z „obcej" rodziny (np. SD1.5 przy grafie SDXL) są odrzucane — w takiej sytuacji
zostaje czytelny błąd o brakującym pliku, bo podmiana dawałaby śmieci.

Praktyczna konsekwencja: **pobierz model z `Pobierz_modele_NSFW.bat` i od razu wybierz
tryb** — żadnego edytowania JSON-a. Wpisu w `bridge_config.json` potrzebujesz tylko
wtedy, gdy chcesz wymusić konkretny model (albo pobrałeś dwa modele tej samej rodziny
i chcesz wskazać ten drugi). Po pobraniu zrestartuj ComfyUI, żeby zobaczył nowy plik.

Pobieracz: klucz `S` = sprawdź co masz, `A` = wszystko (~25 GB), po pobraniu wypisuje
jaki tryb pasuje do modelu i gotowy wpis do `bridge_config.json`.

## 6. Modele pod hard NSFW — co pobrać i dlaczego

Ranking popularności NSFW-checkpointów SDXL (stan: Civitai API, sortowanie po liczbie
pobrań): LUSTIFY! [NSFW] ~401 tys., PornMaster ~368 tys., Copax TimeLess ~211 tys.,
Big Love ~207 tys.; z fotorealistycznych uniwersalnych: Juggernaut XL, RealVisXL V5,
epiCRealism XL, CyberRealistic XL.

### Fotoreal hard NSFW (nowy domyślny wybór dla SDXL)

* **LUSTIFY SDXL NSFW** (`lustifySDXLNSFW_endgame.safetensors`, ~6,9 GB) — model
  trenowany wprost na hard NSFW; najlepsza anatomia w scenach eksplicytnych.
  Lustro HF: `xxxpo13/LUSTIFY_SDXL` (są też `v40`, `endgameDMD2`).
* **CyberRealisticXL Play v10 FP16** (`CyberRealisticXLPlay_V10.0_FP16.safetensors`) —
  fotorealistyczny, „grzeczniejszy" look, bardzo dobre światło i skóra; do scen, gdzie
  bardziej liczy się fotografia niż akcja.
* Opcjonalnie **PornWorks Real Porn Photo v0.4** (mirror `romanfratric234/...`).

### Anime / hentai

* **WAI-NSFW-Illustrious v14** (`waiNSFWIllustrious_v14.safetensors`, ~6,9 GB) — czołowy
  hentai-checkpoint SDXL (Illustrious/NoobAI). Tagi: `masterpiece, best quality, amazing
  quality, very aesthetic, absurdres`; negatywa: `bad quality, worst quality, worst
  detail, sketch, censored`.
* **Pony Diffusion V6 XL** (`ponyDiffusionV6XL_v6StartWithThisOne.safetensors`, ~6,6 GB) —
  2.5D/anime, wymaga tagów `score_9, score_8_up, score_7_up, source_anime|source_photo`.
* **Hassaku Hentai v1.1** (SD1.5, ~2,1 GB) — najszybszy wybór 2D na tym GPU (SD1.5),
  działa z obecnym trybem 768x1152.

### LoRA przyspieszające (już zainstalowane przez ComfyUI-Manager)

* `loras/SDXL-Lightning/sdxl_lightning_8step_lora.safetensors` — oficjalna (ByteDance);
  **sampler euler + scheduler sgm_uniform, CFG 1-2, kroki = 8** (LoRA dobiera się do
  liczby kroków!).
* `loras/HyperSD/SDXL/Hyper-SDXL-8steps-CFG-lora.safetensors` — wersja „CFG-preserved":
  **CFG 5-8, kroki 8, scheduler sgm_uniform**. Producent wprost pisze, że to powinna być
  standardowa konfiguracja dla SD15 i SDXL.
* `loras/HyperSD/SD15/Hyper-SD15-8steps-CFG-lora.safetensors` — to samo dla obecnego
  epicRealism (użyteczne, gdy kiedyś dodasz drugi komputer / słabszą kartę).

### VAE

* `vae/sdxl_vae.safetensors` — jeśli kolory SDXL będą wyprane/„mleczne".
  Wtedy w workflow podmień wyjście VAE w `VAEDecode` na `VAELoader`.

Modele lądują w: `ComfyUI\models\checkpoints`, `...\loras\...`, `...\vae`,
`...\upscale_models`. Pobieracz sam znajduje folder ComfyUI (szuka `models\checkpoints`
obok siebie) i umie wznowić przerwane pobieranie oraz pokazać, co już masz (`C`).

## 7. Promptowanie pod hard NSFW (co już robi mostek)

Mostek v11 nadal robi to, co v10: przepisuje scenę przez Hermesa na tagi (`refine`),
dokleja `NEGATIVE_CORE` (anty-cenzura: `censored, mosaic, censoring bar`, ubranie na
kroczu, zsunięte uda, ręce zasłaniające krocze, przycięte kadry) i wymusza
`prompt_prefix` z presetu. Nowe: `prompt_prefix`/`prompt_suffix`/`refine_hint` per tryb,
czyli dla Pony wysyłamy `score_9, score_8_up...`, dla WAI tagi jakości anime, a dla
fotorealistycznych modeli naturalny opis.

Zasady, które realnie poprawiają hard NSFW na tych modelach:

1. **Stan ubrania opisuj wprost** („nude", „top pulled up", „no panties") — a w negatywie
   trzymaj „clothing over crotch, panties, fabric below the waist".
2. **Otwieraj kadr, nie zamykaj**: pozytywne „spread legs, open legs, legs apart",
   negatywne „closed legs, legs crossed, knees together, thighs pressed together".
3. **Ręce precz od krocza**: negatywne „hands covering pussy, hand between the legs".
4. **Nie używaj słów „tasteful/tastefully/artistic"** — w tych modelach ciągną w stronę
   aktu bez detalu.
5. **Detale anatomiczne nazywaj po angielsku i wprost** (`pussy, vulva, nipples, clitoris,
   penetration, cum` itd.) — modele są trenowane na tagach z Civitai/danbooru.
6. **Kamera**: „close-up on genitals", „pov", „full body, spread legs from above" — kadr
   mówi modelowi, co ma być widoczne, i zwykle bije to na głowę doklejanie tagów.
7. **Płyny i ekspresja**: `sweat, saliva, cum on body/skin, blushing, ahegao, tongue out`
   — działają dobrze, ale w SD1.5 potrafią rozmyć detal; na SDXL są znacznie czystsze.
8. **CFG/steps**: za niskie CFG (1-2) w zwykłych modelach = nieposłuszeństwo promptu;
   przy distylowanych LoRA (Lightning/DMD2) CFG 1-2 jest **konieczne**.

## 8. Rekomendowane samplery / CFG / kroki

| Rodzina | Kroki | CFG | Sampler | Scheduler | Uwagi |
|---|---|---|---|---|---|
| SD1.5 (epicRealism, Hassaku) | 20-25 | 6-7 | dpmpp_2m | karras | obecny domyślny tryb; 20 kroków wystarcza |
| SD1.5 + Hyper-SD 8st CFG | 8 | 5-6 | euler | **sgm_uniform** | scheduler obowiązkowo `sgm_uniform` |
| SDXL realistyczny | 25-32 | 4,5-6 | dpmpp_2m / dpmpp_2m_sde | karras | do hard NSFW niższe CFG (4,5-5) daje mniej „przypaleń" |
| SDXL + Lightning 8st | 8 | **1-2** | euler | **sgm_uniform** | LoRA musi pasować do liczby kroków |
| SDXL + Hyper-SD 8st CFG | 8 | 5-8 | euler | **sgm_uniform** | lepsze trzymanie promptu niż Lightning |
| Pony V6 XL | 22-28 | 6-7 | euler_a / dpmpp_2m | karras | wymaga `score_9, score_8_up, score_7_up` |
| Illustrious/WAI-NSFW | 20-28 | 5-7 | euler_a / dpmpp_2m_sde | karras | tagi jakości anime + negatywa `censored, bar censor` na końcu |

## 9. Dalsze przyspieszanie (do przetestowania, kolejność wg spodziewanego zysku)

1. **Zdjąć/wymienić `--lowvram`.** Przy 8 GB SD1.5 zmieści się bez offloadu, a SDXL
   często też (ComfyUI sam wyrzuca enkodery tekstu po zakodowaniu promptu). Test:
   `Zmierz_tempo.bat`, potem zmiana flagi i drugi pomiar. Jeśli zabraknie VRAM, wrócić.
   W launcherze: `CHL_COMFY_PARAMS` (patrz README mostka).
2. **Trzymać jeden tryb przez serię obrazów** — unika przeładowań modelu/LoRA.
3. **Nie domalowywać w 1024x1536** (patrz §4) — największa pojedyncza oszczędność.
4. **VAE fp16 / mniejszy VAE**, jeśli kolory są ok — dekodowanie to obecnie ~połowa czasu
   trybu domyślnego; tiled VAE nie przyspieszy, ale oszczędzi VRAM na SDXL.
5. **SDXL + Lightning/Hyper-SD** — 8 kroków zamiast 28 to ~3x szybciej przy ~10-20%
   stracie jakości; do scen w czacie to dobry kompromis.
6. **`--fast`** w ComfyUI — usuwa walidacje/optymalizuje start; zysk mały, ale darmowy.
7. **Format fp16 zamiast fp32** dla checkpointów SDXL (pobieraj `*_fp16.safetensors`,
   nie `*_FP32` — FP32 to 13 GB i nie daje nic na tej karcie).
8. **Nie uruchamiaj drugiej generacji równolegle** — mostek i tak serializuje (503/busy).
9. **Batch**: przy `n>1` każdy obraz liczony osobno (różne ziarno) — dla prędkości lepiej
   generować pojedynczo, chyba że model jest już rozgrzany.

## 10. Rollback

* Stary workflow: `workflow_sd15_classic.json` (uruchom go wpisem
  `"preset": "classic"` w `bridge_config.json` albo wskaż `workflow_file`).
* Stary mostek: kopia `hermes_comfy_bridge.py` sprzed v11 — jeśli jej nie masz,
  różnice sprowadzają się do presetów; żadne istniejące pole w API nie zniknęło
  (dodane: `preset`, `size`, `steps`, `cfg`, `sampler`, `scheduler`, `denoise`,
  `checkpoint`; odpowiedzi mają dodatkowe pola `tryb`, `workflow`, `ms_comfy`,
  `ms_refine`).
* Testy regresji: `python tests/test_bridge_presets.py` (39 asercji, bez sieci i GPU).

## 11. Źródła

* SDXL-Lightning (ByteDance, HF): oficjalny workflow ComfyUI — `euler` + `sgm_uniform`,
  CFG 1, LoRA dobrana do liczby kroków; warianty LoRA 1/2/4/8 kroków.
* Hyper-SD (ByteDance, HF, arXiv 2404.13686): „8-step CFG LoRA" — guidance 5-8,
  **scheduler musi być `sgm_uniform`**, rekomendowane jako standard dla SD15/SDXL.
* Civitai API (`/api/v1/models`, sortowanie po pobraniach, `types=Checkpoint`) — ranking
  checkpointów SDXL i NSFW.
* Karty modeli na HuggingFace: `xxxpo13/LUSTIFY_SDXL`,
  `cyberdelia/CyberRealisticXL`, `TheReprinter/WAI-NSFW-illustrious-SDXL`,
  `LyliaEngine/Pony_Diffusion_V6_XL`, `ntr-nu/hassakuHentaiModel_v11`,
  `ByteDance/SDXL-Lightning`, `ByteDance/Hyper-SD`, `stabilityai/sdxl-vae`.
* Pomiary własne: 25.09.2026, RX 7600S 8 GB, torch 2.13.0+rocm10.1,
  ComfyUI 0.33.0 z `--lowvram --use-pytorch-cross-attention`.
