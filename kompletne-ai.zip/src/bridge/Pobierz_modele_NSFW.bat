@echo off
rem ============================================================================
rem  Chloe - pobieranie modeli NSFW do ComfyUI (HuggingFace, bez konta i tokenu)
rem
rem  Ten plik uruchamia sie sam w osobnym oknie z "cmd /k", wiec okno NIE ZAMYKA
rem  sie nawet przy bledzie - zawsze zobaczysz, co sie stalo.
rem
rem  WAZNE dla wersji pliku:
rem   * konce linii musza byc CRLF (Windows). Przy LF (Linux) cmd.exe gubi
rem     pozycje w pliku po "set /p" i "call :etykieta" i zamyka okno bez sladu.
rem   * bez "chcp" (zmiana strony kodowej psuje "set /p"), tresc tylko ASCII.
rem   * ZADEN opis/argument podawany do echa w nawiasowym bloku "if ( ... )" nie
rem     moze zawierac nawiasow "(" ")" - cmd gubi wtedy koniec bloku i przerywa
rem     caly skrypt (okno mrugnie i zniknie). Dlatego opisy ida przez zmienne
rem     opoznione "!OPIS!", a nie przez "%~2" wprost.
rem
rem  Log: pobieranie_log.txt obok tego pliku.
rem ============================================================================

setlocal EnableDelayedExpansion

rem --- wlasne okno, ktore zostaje otwarte po zakonczeniu/bledzie --------------
if /I "%~1"=="__okno" goto :okno
if defined CHL_POB_STARTED goto :okno
set "CHL_POB_STARTED=1"
start "Chloe - pobieranie modeli NSFW" cmd /k ""%~f0" __okno"
exit /b 0

:okno
title Chloe - pobieranie modeli NSFW (ComfyUI)
set "LOG=%~dp0pobieranie_log.txt"
call :log "=== start %DATE% %TIME% ==="
call :main
echo.
echo Koniec. Nacisnij dowolny klawisz, aby zamknac to okno...
pause >nul
exit /b 0


:main
set "COMFY="
rem --- 1) folder, z ktorego uruchomiono skrypt (najczestszy przypadek) ---------
if exist "%~dp0models\checkpoints" set "COMFY=%~dp0"
rem --- 2) folder przeciagniety na ten plik (drag & drop) ----------------------
if not defined COMFY if not "%~1"=="" if not "%~1"=="__okno" if exist "%~f1\models\checkpoints" set "COMFY=%~f1"
rem --- 3) typowe sasiedztwo (folder nadrzedny, podfoldery ComfyUI) ------------
if not defined COMFY for %%D in ("%~dp0.." "%~dp0ComfyUI" "%~dp0comfyui" "%~dp0..\ComfyUI" "%~dp0..\comfyui" "%~dp0comfyui-rocm-091926") do call :jest_comfy "%%~fD"
rem --- 4) dowolny podfolder pierwszego poziomu --------------------------------
if not defined COMFY for /d %%D in ("%~dp0*") do call :jest_comfy "%%~fD"
if not defined COMFY (
  echo.
  echo Nie znalazlem folderu ComfyUI - szukalem katalogu "models\checkpoints".
  echo Przeciagnij folder ComfyUI na ten plik ALBO wpisz pelna sciezke i nacisnij Enter.
  echo Przyklad: C:\Users\adamo\Desktop\open-webui-0.11.3\AI.KURWA\comfyui-rocm-091926
  echo.
  set /p "COMFY=Sciezka do folderu ComfyUI: "
)
rem --- normalizacja: bez otaczajacych cudzyslowow i bez "\" na koncu ----------
for /f "tokens=* delims=" %%P in ("!COMFY!") do set "COMFY=%%~P"
set "COMFY=!COMFY:"=!"
if "!COMFY:~-1!"=="\" set "COMFY=!COMFY:~0,-1!"
if "!COMFY!"=="" (
  echo.
  echo BLAD: nie podano sciezki. Przerwane.
  call :log "BLAD: nie podano sciezki"
  pause
  exit /b 1
)
set "MDL=!COMFY!\models"
if not exist "!MDL!\checkpoints" (
  echo.
  echo BLAD: "!MDL!\checkpoints" nie istnieje.
  echo Upewnij sie, ze wskazany folder to katalog glowny ComfyUI.
  call :log "BLAD: brak !MDL!\checkpoints"
  pause
  exit /b 1
)

where curl.exe >nul 2>&1
if errorlevel 1 (
  echo.
  echo BLAD: brak curl.exe - jest w Windows 10/11 od wersji 1803. Przerwane.
  call :log "BLAD: brak curl.exe"
  pause
  exit /b 1
)

call :log "ComfyUI: !COMFY!"
echo.
echo ComfyUI : !COMFY!
echo Modele  : !MDL!
echo Log     : !LOG!
echo.
call :stan_wszystko
echo.
echo Wskazowka: duze checkpointy, 6-7 GB, pobieraja sie kilkanascie-kilkadziesiat
echo minut zaleznie od lacza. Mozesz przerwac Ctrl+C i uruchomic plik ponownie -
echo pobieranie wznowi sie od miejsca przerwania.

:menu
echo.
echo ===============================================================
echo  1  LUSTIFY SDXL NSFW "endgame"        ~6,9 GB  fotoreal hard NSFW  [POLECANE]
echo  2  LUSTIFY SDXL NSFW v40              ~6,9 GB  fotoreal, poprzednia wersja
echo  3  CyberRealisticXL Play v10 FP16     ~6,9 GB  fotoreal, lagodniejszy look
echo  4  WAI-NSFW-Illustrious v14           ~6,9 GB  anime/hentai, najlepszy wybor 2D
echo  5  Pony Diffusion V6 XL               ~6,6 GB  anime/2.5D, tagi score_9
echo  6  Hassaku Hentai v1.1 SD1.5          ~2,1 GB  anime SD1.5, najszybszy z 2D
echo  7  LoRA przyspieszajace SDXL          ~1,1 GB  Lightning 8st + Hyper-SD CFG
echo  8  LoRA Hyper-SD SD1.5 8st CFG        ~0,3 GB  przyspiesza epicRealism
echo  9  VAE SDXL fp16 fix                  ~0,3 GB  gdy kolory SDXL wyprane
echo  A  wszystko z listy bez 2 i 5         ~25 GB   dopyta o potwierdzenie
echo  S  sprawdz, co juz masz
echo  Q  koniec
echo ===============================================================
set "WYB="
set /p "WYB=Wybor, 1-9 A S Q: "
set "WYB=!WYB: =!"
if not defined WYB goto :menu
if /I "!WYB!"=="Q" exit /b 0
if /I "!WYB!"=="S" goto :sprawdz_menu
if /I "!WYB!"=="A" goto :wszystko
call :log "wybor: !WYB!"
if "!WYB!"=="1" call :p_lustify
if "!WYB!"=="2" call :p_lustify40
if "!WYB!"=="3" call :p_cyber
if "!WYB!"=="4" call :p_wai
if "!WYB!"=="5" call :p_pony
if "!WYB!"=="6" call :p_hassaku
if "!WYB!"=="7" call :p_lora_sdxl
if "!WYB!"=="8" call :p_lora_sd15
if "!WYB!"=="9" call :p_vae
echo.
pause
goto :menu


rem ===========================================================================
rem  Akcje menu (ponizej tylko etykiety - nic tu nie wpada "z gory")
rem ===========================================================================

:wszystko
echo.
echo Tryb "wszystko" pobiera ok. 25 GB: 4 checkpointy SDXL, 1 SD1.5, LoRA, VAE.
echo Kontynuowac? Wpisz T i nacisnij Enter, cokolwiek innego = powrot do menu.
set "POTW="
set /p "POTW=Potwierdzenie: "
if /I not "!POTW!"=="T" goto :menu
call :p_lustify
call :p_cyber
call :p_wai
call :p_hassaku
call :p_lora_sdxl
call :p_lora_sd15
call :p_vae
goto :sprawdz_menu

:sprawdz_menu
echo.
call :stan_wszystko
echo.
pause
goto :menu


rem --- listy stanu -----------------------------------------------------------

:stan_wszystko
echo --- co jest na dysku ---
call :stan "checkpoints\epicrealism_naturalSinRC1VAE.safetensors" "epicRealism SD1.5 domyslny"
call :stan "checkpoints\lustifySDXLNSFW_endgame.safetensors"  "LUSTIFY SDXL endgame"
call :stan "checkpoints\lustifySDXLNSFW_v40.safetensors"      "LUSTIFY SDXL v40"
call :stan "checkpoints\CyberRealisticXLPlay_V10.0_FP16.safetensors" "CyberRealisticXL Play"
call :stan "checkpoints\waiNSFWIllustrious_v14.safetensors"   "WAI-NSFW-Illustrious"
call :stan "checkpoints\ponyDiffusionV6XL_v6StartWithThisOne.safetensors" "Pony Diffusion V6 XL"
call :stan "checkpoints\hassakuHentaiModel_v11.safetensors"   "Hassaku Hentai SD1.5"
call :stan "loras\epiCRealismHelper.safetensors"              "epiCRealismHelper"
call :stan "loras\SDXL-Lightning\sdxl_lightning_8step_lora.safetensors" "Lightning SDXL 8st"
call :stan "loras\HyperSD\SDXL\Hyper-SDXL-8steps-CFG-lora.safetensors"  "Hyper-SD SDXL 8st"
call :stan "loras\HyperSD\SD15\Hyper-SD15-8steps-CFG-lora.safetensors"  "Hyper-SD SD1.5 8st"
call :stan "upscale_models\RealESRGAN_x2plus.pth"             "RealESRGAN 2x - tryb fast"
call :stan "vae\sdxl_vae.safetensors"                         "VAE SDXL"
exit /b 0

:stan
rem %1 = sciezka wzgledna w models, %2 = opis
set "PLIK=%~1"
set "OPIS=%~2"
if not exist "!MDL!\!PLIK!" goto :stan_brak
set "S="
for %%A in ("!MDL!\!PLIK!") do set "S=%%~zA"
set "SZ=!S!"
set "SZ=!SZ:~0,-6!"
if not defined SZ set "SZ=0"
echo   [JEST]  !OPIS!  ~!SZ! MB
exit /b 0

:stan_brak
echo   [BRAK]  !OPIS!
exit /b 0


rem --- checkpointy SDXL ------------------------------------------------------

:p_lustify
call :pobierz "https://huggingface.co/xxxpo13/LUSTIFY_SDXL/resolve/main/lustifySDXLNSFW_endgame.safetensors" "!MDL!\checkpoints\lustifySDXLNSFW_endgame.safetensors" "LUSTIFY SDXL NSFW endgame"
if not errorlevel 1 call :hint_checkpoint "lustifySDXLNSFW_endgame.safetensors" "sdxl_cfg8"
exit /b 0

:p_lustify40
call :pobierz "https://huggingface.co/xxxpo13/LUSTIFY_SDXL/resolve/main/lustifySDXLNSFW_v40.safetensors" "!MDL!\checkpoints\lustifySDXLNSFW_v40.safetensors" "LUSTIFY SDXL NSFW v40"
if not errorlevel 1 call :hint_checkpoint "lustifySDXLNSFW_v40.safetensors" "sdxl_cfg8"
exit /b 0

:p_cyber
call :pobierz "https://huggingface.co/cyberdelia/CyberRealisticXL/resolve/main/CyberRealisticXLPlay_V10.0_FP16.safetensors" "!MDL!\checkpoints\CyberRealisticXLPlay_V10.0_FP16.safetensors" "CyberRealisticXL Play v10 FP16"
if not errorlevel 1 call :hint_checkpoint "CyberRealisticXLPlay_V10.0_FP16.safetensors" "sdxl_cfg8"
exit /b 0

:p_wai
call :pobierz "https://huggingface.co/TheReprinter/WAI-NSFW-illustrious-SDXL/resolve/main/waiNSFWIllustrious_v14.safetensors" "!MDL!\checkpoints\waiNSFWIllustrious_v14.safetensors" "WAI-NSFW-Illustrious v14"
if not errorlevel 1 call :hint_checkpoint "waiNSFWIllustrious_v14.safetensors" "sdxl_cfg8"
exit /b 0

:p_pony
call :pobierz "https://huggingface.co/LyliaEngine/Pony_Diffusion_V6_XL/resolve/main/ponyDiffusionV6XL_v6StartWithThisOne.safetensors" "!MDL!\checkpoints\ponyDiffusionV6XL_v6StartWithThisOne.safetensors" "Pony Diffusion V6 XL"
if not errorlevel 1 call :hint_checkpoint "ponyDiffusionV6XL_v6StartWithThisOne.safetensors" "sdxl_cfg8"
exit /b 0

:p_hassaku
call :pobierz "https://huggingface.co/ntr-nu/hassakuHentaiModel_v11/resolve/main/hassakuHentaiModel_v11.safetensors" "!MDL!\checkpoints\hassakuHentaiModel_v11.safetensors" "Hassaku Hentai v1.1 SD1.5"
if not errorlevel 1 call :hint_sd15 "hassakuHentaiModel_v11.safetensors"
exit /b 0


rem --- LoRA i VAE ------------------------------------------------------------

:p_lora_sdxl
if not exist "!MDL!\loras\SDXL-Lightning" mkdir "!MDL!\loras\SDXL-Lightning"
if not exist "!MDL!\loras\HyperSD\SDXL" mkdir "!MDL!\loras\HyperSD\SDXL"
call :pobierz "https://huggingface.co/ByteDance/SDXL-Lightning/resolve/main/sdxl_lightning_8step_lora.safetensors" "!MDL!\loras\SDXL-Lightning\sdxl_lightning_8step_lora.safetensors" "LoRA SDXL-Lightning 8 krokow"
call :pobierz "https://huggingface.co/ByteDance/Hyper-SD/resolve/main/Hyper-SDXL-8steps-CFG-lora.safetensors" "!MDL!\loras\HyperSD\SDXL\Hyper-SDXL-8steps-CFG-lora.safetensors" "LoRA Hyper-SD SDXL 8 krokow CFG"
echo   Wskazowka: to sa LoRA do trybow sdxl_fast i sdxl_cfg8. Bez nich te tryby
echo              zglosza blad o brakujacym pliku.
exit /b 0

:p_lora_sd15
if not exist "!MDL!\loras\HyperSD\SD15" mkdir "!MDL!\loras\HyperSD\SD15"
call :pobierz "https://huggingface.co/ByteDance/Hyper-SD/resolve/main/Hyper-SD15-8steps-CFG-lora.safetensors" "!MDL!\loras\HyperSD\SD15\Hyper-SD15-8steps-CFG-lora.safetensors" "LoRA Hyper-SD SD1.5 8 krokow CFG"
echo   Wskazowka: LoRA SD1.5 nie jest podpieta w zadnym trybie - sluzy do wlasnych
echo              eksperymentow w ComfyUI albo we wlasnym presecie.
exit /b 0

:p_vae
if not exist "!MDL!\vae" mkdir "!MDL!\vae"
call :pobierz "https://huggingface.co/stabilityai/sdxl-vae/resolve/main/sdxl_vae.safetensors" "!MDL!\vae\sdxl_vae.safetensors" "VAE SDXL fp16 fix"
echo   Wskazowka: VAE wgrywa sie recznie w ComfyUI - node Load VAE. Domyslne
echo              workflowy SDXL uzywaja VAE z checkpointu.
exit /b 0


rem --- podpowiedzi po pobraniu ------------------------------------------------

:hint_checkpoint
rem %1 = nazwa pliku checkpointu, %2 = sugerowany tryb
echo.
echo   Zrobione. Plik: %1
echo   Tryb dla niego: mostek %2 - SDXL, 8 krokow.
echo   Mostek od wersji 12 sam podmieni brakujacy checkpoint na to, co jest na dysku,
echo   wiec zeby go uzywac, wystarczy zrestartowac ComfyUI, zeby zobaczyl nowy plik,
echo   i wybrac tryb %2 w aplikacji. Aby wymusic TEN model na stale, dopisz w
echo   bridge_config.json:
echo      "presets": { "%2": { "checkpoint": "%1" } }
call :log "pobrano checkpoint %1, sugerowany tryb %2"
exit /b 0

:hint_sd15
rem %1 = nazwa pliku checkpointu SD1.5
echo.
echo   Zrobione. Plik: %1
echo   To model SD1.5 anime - chodzi w trybie "default", 20 krokow, 768x1152.
echo   Model domyslny to epicRealism, wiec zeby uzywac tego, dopisz w bridge_config.json:
echo      "presets": { "default": { "checkpoint": "%1" } }
echo   ...albo zrob osobny preset z wlasnym prompt_prefix, np. tagi danbooru - patrz
echo   NSFW_CONFIG.md, sekcja o anime.
exit /b 0


rem --- samo pobieranie --------------------------------------------------------

:pobierz
rem %1 = url, %2 = plik docelowy, %3 = opis
set "URL=%~1"
set "CEL=%~2"
set "OPIS=%~3"
set "S1="
if exist "!CEL!" for %%A in ("!CEL!") do set "S1=%%~zA"
if defined S1 if !S1! GTR 50000000 goto :pobierz_mam
if defined S1 goto :pobierz_wznawiam
echo   [pobieram]  !OPIS!
call :log "pobieram: !OPIS!"
goto :pobierz_start

:pobierz_mam
echo   [mam]       !OPIS!
call :log "mam juz: !OPIS!"
exit /b 0

:pobierz_wznawiam
echo   [wznawiam]  !OPIS!
call :log "wznawiam: !OPIS!"
goto :pobierz_start

:pobierz_start
echo               !CEL!
curl.exe -L --fail --retry 3 --retry-delay 3 --connect-timeout 30 -C - -o "!CEL!" "!URL!"
if errorlevel 1 (
  echo   [ponawiam]  pobieranie od zera...
  call :log "curl blad - ponawiam od zera: !OPIS!"
  if exist "!CEL!" del /q "!CEL!"
  curl.exe -L --fail --retry 3 --retry-delay 3 --connect-timeout 30 -o "!CEL!" "!URL!"
)
if not exist "!CEL!" (
  echo   [BLAD]      nie pobrano: !OPIS!
  echo               sprawdz internet, miejsce na dysku i blokade antywirusa
  echo               link: !URL!
  call :log "BLAD: nie pobrano !OPIS!"
  exit /b 1
)
set "S2="
for %%A in ("!CEL!") do set "S2=%%~zA"
if not defined S2 set "S2=0"
if !S2! LSS 50000000 (
  echo   [BLAD]      plik za maly: !S2! bajtow - sprawdz miejsce na dysku
  call :log "BLAD: plik za maly !OPIS! !S2! B"
  exit /b 1
)
echo   [ok]        !OPIS!  !S2! bajtow
call :log "ok: !OPIS! !S2! B"
exit /b 0


rem --- log -------------------------------------------------------------------

:jest_comfy
rem %1 = kandydat na folder ComfyUI (bez cudzyslowow, moze byc z "\..")
if defined COMFY exit /b 0
if not exist "%~1\models\checkpoints" exit /b 0
set "COMFY=%~1"
exit /b 0

:log
>>"!LOG!" echo %~1
exit /b 0
