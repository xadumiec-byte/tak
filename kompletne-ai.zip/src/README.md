# Chloe — uncensored NSFW research assistant (for `ai-character-chat`)

This workspace IS the Perchance **ai-character-chat** application (its `main.pjs` +
`index.html`). The project's goal is a single, maximally-capable first starter
character, **Chloe**: an uncensored expert on sex/fetishes/kinks/BDSM/erotica who
also finds the best information, sites and direct NSFW video links on the internet.

## Improvement plan / status

`src/PLAN.md` holds the researched list of proposed upgrades (sources, ranking,
UI console, model/embedding, lorebook) plus a ranked recommendation. The user picks
IDs before anything is implemented. TTS was removed on request (see below).

**Status of `E2` (own model via OpenRouter): IMPLEMENTED and verified** — see
"The `E2` own-model mode" below. The recommended remainder — **`D1` (shared search
console), `D3` (result cards 2.0) and `D4` (live search progress)** — is now also
IMPLEMENTED, adapted to the OpenRouter mode (see `src/PLAN.md` and the "Search
console / cards / progress" section below).

**Status of the RP layer (`src/PLAN-RP.md`, R0–R12): IMPLEMENTED, verified end-to-end
against a real local model.** Chloe is no longer a "porn search assistant": she is a
full uncensored erotic/fetish roleplay companion (scene state + beat engine,
kink/limit profile, author's note, anti-slop, relationship progression + diary,
NPC/world, DIY/hardware knowledge, on-page scene bar, `.md` export, multi-stage
campaigns). See the "RP engine (R0–R12)" section below — it also documents the
prefix-cache prompt layout, the `fast` budget switch, and the abort/409 server
behaviour that used to make replies fall back to the Perchance model.

`src/MODELS.md` is the community research behind the model presets: RP-Bench/
PlotPoints benchmark data + EuroEval Polish + OpenRouter pricing, with a recommended
default (`mistralai/mistral-small-2603`) and alternatives (`google/gemma-4-26b-a4b-it`,
`deepseek/deepseek-v4-flash`).

**24.09.2026 — „panel techniczny" + detal twarzy:** analiza przesłanego panelu
(`hermes_3_comfyui_interactive_suite.html`) została **zaimplementowana w naszym kodzie, nie
przez podmianę `index.html`** (użytkownik wybrał opcję 3 — panel to statyczny raport, nie
kod Chloe). Z jego zaleceń brakowało tylko `min_p`/`repetition_penalty` (→ mostek **v7**) i
CFG (→ **6.0** w `workflow_api.json` i `workflow_api_simple.json`); reszta (kolejność promptu
pod prefix-cache, limity tagów Img-Engine, `dpmpp_2m`+`karras`, `directToComfy`) była już
wdrożona. Mostek podniósł się na **v8** (ziarno dla nodów detalowania, patrz sekcja o moście),
doszły `dodaj_facedetailer.py`, `Dodaj_detektor_twarzy.bat` + `instaluj_detektor_twarzy.py`,
a `sprawdz_comfy.py` ma sekcję detailingową. **Ustalenie kluczowe:** `UltralyticsDetectorProvider`
(filmowy detektor twarzy wymagany przez `FaceDetailer`) **nie jest częścią ComfyUI Impact Packu
od V8 — jest w osobnym pakiecie `ComfyUI-Impact-Subpack`**, którego użytkownik nie ma; dlatego
`FaceDetailer` jest, a detalu twarzy nie da się uruchomić, dopóki Subpack nie zostanie
doinstalowany. `UltimateSDUpscale` jest odradzany na tym sprzęcie (brak nodu, `4x-UltraSharp` i
jakiegokolwiek ControlNetu; obecny łańcuch 4x NMKD + Lanczos + hires już daje 2K).

### Chat commands (all in the custom code)

- `/panel` (aliases: `konsola`, `console`, `zrodla`, `zrodla`, `filtry`) — opens the
  shared side panel on the **search console** tab (source filters, result grid,
  history, "load more"). `⚙️ model` and `🧭 panel` shortcut buttons open the two tabs.
- `/model` — opens the same panel on the **model** tab (own-model settings).
- `/model on` / `/model off` (`wlacz`/`wylacz`) — toggle the own-model mode.
- `/model test` — sends one probe request and reports success/failure.
- `/search`, `/reddit`, `/wiki`, `/pref`, `/pomoc` — as before.

## Where Chloe lives

- `index.html` → `starterCharacters` → the object with `name: "Chloe"`.
  Key fields:
  - `roleInstruction` (~6.2 KB) — persona, expertise, absolute no-refusal rules,
    SPEECH & VOICE block, "Visual Impression" block, reply length in WORDS,
    `<search>…</search>` and `<image>…</image>` output protocols, `[[akcje]]` chips.
  - `reminderMessage` (~1.4 KB) — inline reminder (search usage, image tag, prefs,
    concrete URLs, no clichés, word-count, 2–4 `[[akcje]]` chips).
  - `shortcutButtons` — 5 buttons: 🔎 szukaj NSFW / 👽 Reddit / 📚 wiedza /
    🖼️ wygeneruj obraz / ❓ pomoc. (Przycisk 🔊 głos i całe TTS zostały usunięte.)
  - `loreBookUrls` — points at the uploaded lorebook (below).
  - `customCode` — the whole JS feature set (below).
  - an intro system message.

> Threads snapshot the character at creation, so edits to `starterCharacters`
> only affect **newly created threads**. IMPORTANT EXCEPTION: the custom-code iframe is
> built from `db.characters.get(thread.characterId).customCode` (index.html:10814) every
> time it is (re)created, so the *running* threads DO pick up new code after a reload —
> but only if you also update the saved characters in `db.characters` (the user's
> "Your Characters" copies, which are separate snapshots). Recipe from the live page:
> grab the fresh code from the live page's module `<script>`
> (`[...document.scripts].find(s => s.textContent.includes("uncensored NSFW research"))`,
> then regex `customCode:\s*"((?:[^"\\]|\\.)*)"` and `JSON.parse('"'+m[1]+'"')`), then
> `for (const id of ids) { const c = await db.characters.get(id); c.customCode = code; await db.characters.put(c); }`
> and `page_refresh`.

## The custom code (the "plugins")

All abilities are implemented in the Chloe starter's `customCode` field. It is a
single JSON-escaped JS string on one line inside `index.html`. Features:

- **Multi-source live web search**: `chloeWebSearch(query, mode, opts)` fans out to a
  registry of 18 sources (`CHLOE_SOURCES`): Redtube, porn.com, Xozilla, SunPorno,
  TNAFlix, nudevista (metasearch), Pornhub, YouPorn, Porntrex, SpankBang, RedGIFs,
  nhentai (JSON API), e-Hentai, 3Hentai, e621, Bing RSS (en+pl) and Reddit via
  **redlib.catsarch.com**. Each source can be toggled in the console (persisted),
  results are de-duped, ranked (`chloeRankItems`) and interleaved across sites
  (`chloeInterleaveVideos`); the top Reddit post's comments are scraped
  (`chloeRedlibComments`). Query expansion PL→EN uses a dictionary plus an
  **OpenRouter** model fallback (`chloeAiExpand`).
  - E-Hentai URL parsing bug (fixed): the gallery regex needed `\/?"` because real
    `e-hentai.org/g/<id>/<hash>/` URLs end with a slash; it previously matched 0 items.
- **Rich result cards (D3)**: `chloeThumbHTML(v, big)` renders a per-site gradient
  + thumbnail + **site badge** + **duration badge** (Redtube/SunPorno/TNAFlix/
  nudevista) + a `GALERIA` badge for hentai galleries; `chloeCardHTML` is the grid
  variant and `chloeBuildUser` uses the big video-row variant in chat.
- **Search console (D1) + live progress (D4)**: an `oc.window.show()` side panel with
  two tabs — **Model** (E2/OpenRouter settings) and **Wyszukiwanie** (the console).
  The console has a query box, a mode `<select>` (media/info/Reddit), grouped source
  toggles, a live progress bar + per-source chips, a paginated result grid
  ("Wczytaj wiecej") and a persisted recent-search history. The same progress bar
  renders in the chat feed during a search (in the own-model/OpenRouter path — the
  native path is awaited by the app, which blocks live message updates; see the
  E2 section).
- **Real pages for "info" mode**: Wikipedia summary + Readability-extracted pages.
- **Slash commands**: `/search`, `/reddit`, `/wiki`, `/pref`, `/pomoc`
  (aliases in `chloeParseCommand`). `/image`, `/nar`, `/ai`, `/lore` etc. are the
  app's own native commands.
- **TTS: usunięte** na życzenie użytkownika (cała obsługa `speechSynthesis`,
  `StreamingMessage` voice handler i przycisk 🔊). Nie przywracać bez prośby.
- **Action chips**: `oc.messageRenderingPipeline` turns `[[text]]` into clickable
  buttons that push a user message. Because the model emits them unreliably, a
  deterministic fallback (`chloeActionChips`) derives 3 chips from the last user
  message whenever an AI reply contains none.
- **Preferences**: `/pref …` or "zapamiętaj, że …" stores likes; injected as a
  hidden system reminder (`chloeSyncPrefMessage`).
- **Anti-refusal safety net**: `chloeStripRefusal` rewrites canned refusals and
  `chloeForceAnswer` regenerates if needed.
- **Search-tag protocol**: the AI can emit `<search>query</search>`; the handler
  runs a live search and rewrites the message with real results.

### The `E2` own-model mode (OpenRouter BYO key)

Chloe can answer with the user's **own model** (OpenRouter, or any OpenAI-compatible
`/chat/completions` endpoint) instead of Perchance's native model. When enabled:

1. The user message flow still runs the normal search-intent detection, so a
   media/info search happens first (visible results card + a hidden AI-context card).
2. `chloeE2BuildMessages()` assembles the prompt (persona is already in
   `oc.thread` history; it prepends the lorebook knowledge and the search context).
3. `chloeE2Chat(messages)` POSTs to `baseUrl + /chat/completions` with the key in the
   `Authorization` header. The request goes through **Perchance's own fetch proxy**
   (verified to forward both the body and the `Authorization` header), so the key
   never touches a third-party relay.
4. On failure it retries once, then falls back to the native Perchance model and
   shows a `⚠️` notice explaining the error.

Key implementation details:

- **Shared panel (E2 + D1)**: `chloeE2MountPanel()` builds one `oc.window.show()` panel
  with a tab bar: **Model** (`#ce2TabModel`, the settings above) and **Wyszukiwanie**
  (`#ce2TabSearch`, `chloeSearchConsoleHtml()` + `chloeSearchConsoleWire()`). Enter
  with `/panel` (search tab) or `/model` (model tab); `window.__chloeE2ShowTab` switches.
- **`customData.__chloeTyping`** messages are the in-feed spinners. `chloeE2Respond`
  uses `setPartial`/`clearTyping`/`newTyping` so the visible search-results card is
  **not** deleted with the spinner (this was a fixed bug — the old code spliced the
  spinner and the card together).
- **Truncation handling / auto-continue**: `chloeE2Chat` records `CHLOE_E2_LAST_FINISH`
  from `choices[0].finish_reason`. When it is `"length"`, `chloeE2Respond` appends up to
  **3** extra continuation calls (`messages + [ai=partial reply, user="Kontynuuj…"]`) and
  stitches them with `chloeE2JoinCont()` (overlap de-duplication), stopping at ~16 000
  chars. If the reply is *still* truncated it shows a notice telling the user to raise
  **max tokenów** in `/model`. Default `maxTokens` is now **2000** (was 1200). Test hooks:
  `window.__chloeE2.finish()` and `.joinCont()`.
- **Live progress (D4)**: `chloeWebSearch` emits `chloeProgressHtml()` snapshots via
  `window.__chloeProgressCb`. In `chloeE2Respond` the search runs *after* the handler
  returns, so the app's 100 ms data-poll keeps flushing the placeholder updates. The
  **native** path (`chloeInject`) runs inside the awaited `MessageAdded` handler, and
  the app pauses message updates while a handler is running (`currentlyProcessingMessageActionHandlers`
  in `index.html`), so there the progress is only visible in the console, not live in
  the feed. IMPORTANT: writing progress must go through the `oc.thread.messages`
  proxy (`arr[i].content = html`) — mutating your own captured message object does
  **not** set the change flag, so the update never reaches the UI.
- **Settings persistence**: the custom-code iframe is `sandbox="allow-scripts"` →
  opaque origin → its `localStorage` throws `SecurityError`. So settings are stored
  in the PARENT page's `localStorage` via a postMessage bridge (`chloeKvBridge`,
  inserted into `index.html` just before the `types = ["showWindow","hideWindow"]`
  listener; it only serves `chloe_*` keys). `chloeKvLoad`/`chloeKvSet` wrap the
  bridge with async messaging. Settings are shared by all threads in one browser.
  Same mechanism stores the enabled-source map (`chloe_sources`) and search history
  (`chloe_search_history`).
- **Diagnostic hook**: `window.__chloeE2` (inside the iframe) exposes
  `ready/get/set/active/chat/buildMessages/test/kvGet/kvSet/panel/search/expand/
  isPolish/aiExpand/loreSelect/dedup/rank/fetchRaw/src/sources/srcList/setSources/
  history/progress/sourceStats/console/finish/joinCont/family`.
  Reach it with the postMessage probe below (preferable), or
  `window.runCodeInCustomCodeIframe("return window.__chloeE2.get()")` (note that
  helper wraps code in a NON-async function, so `return somePromise`, never
  `return await …`; and it can HANG the eval if the code throws).
- The lorebook URL is hardcoded as `CHLOE_LORE_URL` in the custom code because
  `loreBookUrls` is not exposed to custom code.
- `CHLOE_E2_PRESETS` in the custom code lists the OpenRouter model presets (ids must
  match `src/MODELS.md`); the panel has a free-text field for any other model id and
  a "custom / not on list" option.

**Verified** in the live preview with an intentionally invalid key: search ran, the
results card survived, OpenRouter returned `"User not found."`, the `⚠️` notice
appeared, and the native fallback produced a reply. `/model`, `/model on|off`,
`/model test` all verified. A real generation with a valid key was NOT tested (none
available); the URL/headers/body path was confirmed by the API returning a proper
auth error rather than a network/format error.

#### Model prompt dialects (Gemma / Mistral / Qwen / DeepSeek / generic)

The same persona is sent to different model families, and they want *different
prompt shapes*. `chloeE2Family(modelId)` buckets the id into
`"gemma" | "mistral" | "qwen" | "deepseek" | "generic"`; `chloeE2BuildMessages()`
and `chloeE2Chat()` then branch on it. The detected dialect is shown live in the
panel (`#ce2Family`, e.g. `Wariant promptu: gemma`).

- **Gemma** (`google/gemma-*`): Gemma chat templates have **no `system` role** — a
  `system` message either errors or gets silently dropped. So for gemma we build a
  plain user/assistant transcript: `sysText` (= `roleInstruction` + `CHLOE_E2_RULES` +
  `CHLOE_E2_GEMMA_EXTRA` + user prefs + lorebook) is prepended as the **first `user`
  turn**, any `system` turns in the history are folded into `sysText`
  (`chloeE2FoldSystem`), the reminder is appended to the **last user** turn,
  consecutive same-role turns are merged (`chloeE2MergeSameRole`), and if the list
  doesn't end on a user turn a synthetic `user` turn is added. Request adds
  `top_p: 0.95` and merges `CHLOE_E2_GEMMA_STOPS`
  (`<end_of_turn>`, `<start_of_turn>`, `<eos>`, `</s>`) into `stop`. The reply is
  cleaned afterwards (strip stray `<end_of_turn>`/`<start_of_turn>`/`<eos>`/`</s>` and
  a leading `Chloe:`/`Assistant:`/`Model:`/`Asystent:` label).
- `CHLOE_E2_GEMMA_EXTRA` holds the Gemma-only rules that fight its habits: Polish
  only (no anglicisms), no moralizing/caveats/"jako AI", no "czy chcesz wiedzieć
  więcej?", don't echo the user, don't turn a topic into a bland handbook, be
  explicit incl. erotic scenes, keep 2–4 paragraphs (~150–250 words) and end with
  2–4 `[[akcja]]`.
- `chloeE2Role(m)` reads `m.role || m.author`, so it works both for raw history
  objects (`author`) and for the folded OpenAI-style list (`role`).
- Verified live with `google/gemma-4-26b-a4b-it`: `buildMessages` yields
  `["user","assistant",…,"user"]` (9 msgs, no `system`, first msg ≈22 k chars) and a
  real generation returned correct Polish, uncensored, ending with `[[akcje]]`
  (`__chloeE2.chat()` returns the **content string**, not an object — read
  `finish_reason` via `__chloeE2.finish()`).
- Gotcha fixed: inside the panel HTML use entities (`&mdash;`, `&lt;…&gt;`), not
  `\uXXXX` or raw `<end_of_turn>` — `innerHTML` parses a raw `<end_of_turn>` as an
  unknown element (so it vanishes from `textContent`), and a double-escaped
  `\\u2014` shows up literally as `\u2014`.

### Action chips (`[[akcja]]`) — why they need the `chloeSend` bridge

The `[[akcja]]` buttons rendered under each AI message are wired through
`window.chloeQuickAction(text)`. **A programmatic `oc.thread.messages.push(...)`
from inside the custom-code iframe does NOT fire the app's `MessageAdded` event**,
so the message is persisted but the reply handler never runs → the user clicks a
chip and nothing happens (no typing bubble, no reply, no error). The chip path
therefore goes through the parent page:

- `chloeQuickAction(text)` → `chloeParentCall({type:"chloeSend", text})` → the
  `chloeSend` postMessage listener in `index.html` (just after `chloeKvBridge`)
  sets `#messageInput.value`, dispatches `input`, and clicks `#sendButton` — the
  **normal** send path, so `MessageAdded` fires and the bot replies. It only
  serves requests whose `e.source` is a known `customCodeIframes[*].contentWindow`.
- If the bridge is unavailable (e.g. a fork of the app without our listener), the
  `{type:"chloeSend"}` reply is `{success:false}` and `chloeQuickActionFallback()`
  pushes the message directly and then calls `chloeHandleAddedMessage()` manually.
- `chloeHandleAddedMessage` is the (former anonymous) `MessageAdded` handler; it is
  registered with `oc.thread.on("MessageAdded", chloeHandleAddedMessage)`.

### Image generation (`<image>…</image>`)

Whenever a message contains `<image>prompt</image>`, index.html renders a
`.generated-image-container`, wrapping the prompt with the character's
`imagePromptPrefix` / `imagePromptSuffix` and appending `imagePromptTriggers` text when
the regex `\bChloe\b` matches the prompt. Chloe's starter has all three configured.

**The generator is now the uncensored cloud one (AI Horde) by default** — see
"Cloud image generator" below. index.html calls `chloeCloudImgElement(options)`; it
returns a cloud placeholder when the cloud generator is active, and otherwise falls
back to the app's native `text-to-image-plugin` element.

Two user paths exist:

- **`/image <opis>`** (and the `🖼️ wygeneruj obraz` shortcut, which inserts and now
  auto-sends `/image --num=N `). `/image <opis>` is converted to `<image>opis</image>`
  in a user message, so the image renders **without any AI call**; the bare
  `/image --num=N` form instead takes the native Narrator branch (see the fix note
  below). We deliberately do **not**
  let the E2 handler also reply to such a message (it used to answer with a confused
  "is this a metaphor?" text): the E2 branch returns early when the user message
  already contains `<image>`.
- **Plain text** ("wygeneruj obraz …", the `[[Wygeneruj obraz…]]` chips). A model
  rarely emits the `<image>` tag on its own, so in E2 mode the custom code handles it
  deterministically:
  `chloeWantsImage(text)` (verb+noun regex, PL + EN) → `chloeE2ImageRespond()` asks the
  E2 model for a short Polish intro **plus exactly one**
  `<image>…English prompt…</image>` line (the rule is also in `CHLOE_E2_RULES`), and if
  the reply still has no tag it appends `<image>{chloeImageFallbackPrompt()}</image>`
  itself. The result is pushed as an AI message, so the image always appears.
  When E2 is **off**, plain-text image requests are left to the native Perchance model
  (which the roleInstruction/reminderMessage already instruct to emit `<image>`).

Verified live: `/image a red apple…` renders the image with no extra reply;
"wygeneruj obraz: czerwone jabłko…" → E2 wrote a Polish intro + a long English
prompt and the image rendered.

#### Fix: „Chloe nie generuje obrazów" — urwany znacznik `<image>` (2026-09-17)

Symptom the user reported: after asking Chloe for an image, her reply showed a
**broken/empty image** and no picture was ever generated.

Root cause: `chloeE2ImageRespond()` asked the local 8B for a description with
`maxTokens: 500` and the instruction used the *literal* two-character sequence `\n`
(not a real newline). The model echoed a fragment of the instruction
(„Dokładnie jeden znak:") and then started a long Polish description but **ran out of
tokens before writing `</image>`**. The app only renders a *complete* pair
(`/<image>(.+?)<\/image>/gs` in index.html), and the browser parses a stray raw
`<image>` as a legacy `<img>` — hence the broken image element.

Three-part fix:

1. **Custom code (prevention)** — `chloeStripImageBoilerplate()`, `chloeFixImageTags()`
   and `chloeHasImageTag()` sit just above `chloeE2ImageRespond()`. `chloeFixImageTags`
   strips leaked instruction text, collapses `</image></image>` / empty tags, removes
   orphan closers, and — when opens > closes — closes the **last** unclosed `<image>`
   by wrapping everything after it as the description (dropping it only if that tail is
   shorter than 8 chars). It is a no-op when there are no image tags at all.
   `chloeE2ImageRespond` now uses real newlines (`CHLOE_NL`) in the instruction, spells
   out four tag rules („ZAWSZE zamknij `</image>`", English description, 50–80 words, no
   meta-talk), asks for `maxTokens: 900`, and runs `chloeFixImageTags` before the
   „no tag → append fallback" check. `chloeE2Respond` also runs it right after
   `chloeStripRefusal`, so reminder-driven `<image>` output is repaired too.
2. **Price-render leniency (repair)** — in index.html, just above the
   `/<image>(.+?)<\/image>/gs` replace, the same boilerplate regexes run and a dangling
   `<image>` is auto-closed. Idempotent, so it also repaired the already-broken message
   in the user's history on the next render.
3. **`🖼️ wygeneruj obraz` shortcut** — `autoSend` changed from `false` to `true`
   (character default in index.html + the per-thread snapshots). A single click now
   sends `/image --num=N` immediately, matching the app's own documented example
   (`@autoSend=yes`). Note that the *exact* `/image --num=N` form takes the native
   branch in `sendButtonClickHandler`: it calls the Narrator with
   `wrapInImageTags: 1` to describe the current scene, so it produces a `<image>` pair
   itself and never reaches the custom code.

#### Fix: zapisany obraz znikał po odświeżeniu (`[object Object]`)

`root.uploadPlugin(blob)` returns `url` as a **boxed String object** (`new String(...)`),
not a primitive. `img.src = res.url` worked at mount time (ToString), but
`chloeCloudPersist` stored that object in IndexedDB, where structured clone degrades it
to a plain object with `"0","1","2",…` keys — so on the next render the `<img src>`
became `[object Object]` (i.e. `https://perchance.org/[object%20Object]`) and the saved
image appeared broken. All four cloud return sites
(`chloeCloudToBlobUrl` ×3, the `chloeCloudTest` postMessage reply), plus
`chloeCloudImgNode` and `chloeCloudPersist`, now wrap the URL in `String(...)`.

#### Fix: „nie wkleja do czatu wygenerowanych zdjęć" — anty-slop usuwał `<image>` + obraz 0×0 (2026-09-16)

Symptom the user reported: he asks Chloe (in RP, plain text) for a photo, the local
model generates it (ComfyUI job runs), but **nothing appears in the chat**. The only
images that ever showed up were the ones made with the app's own image button
(a `Narrator` message, `characterId:-2`).

Two INDEPENDENT bugs, both on the message path — fixing only one still shows nothing:

1. **The anti-slop/normalisation pipeline deleted the tag.** `chloeRPCleanKeepLines()`
   does `.replace(/<[^>]*>/g, " ")`, which strips *every* html-like token, including
   `<\image>…</\image>`. It is the last step of `chloeRPAbsorbAI()` (the anti-slop
   wrapper called from `chloeE2Respond` and from `chloeHandleAddedMessage`), and the
   anti-slop is ON in the user's `chloe_rp_v1` (`antislop:true`). So the tag was removed
   before the app's `/<image>(.+?)<\/image>/gs` renderer ever saw it → no image job at
   all. (This was a regression from the R5 anti-slop work: images worked before it.)
   - Fix: sentinel protection. `chloeRPImageExtract(text)` replaces every complete
     `<image>…</image>` with `\x01<idx>\x02` and returns `{text, imgs}`;
     `chloeRPImageRestore(text, imgs)` puts them back — and **re-appends any tag the
     pipeline dropped** (so an anti-slop edit that cut the whole paragraph still keeps
     the image). Both `chloeRPCleanKeepLines()` and `chloeRPAbsorbAI()` are wrapped in
     extract → transform → restore. Verified live: the reply reaches the DB with
     `tag:true` and `customData.__savedImages` filled.
   - Also broadened `chloeWantsImage()` (asks like „wyślij mi zdjęcie", „pokaż się",
     „jak wyglądasz", „chcę cię zobaczyć", `send … pic`) and added a safety net in
     `chloeE2Respond` right after `chloeRPAbsorbAI(reply)`: if the user asked for an
     image and the reply has no tag, the tag is appended
     (`<image>chloeImageFallbackPrompt(userText)</image>`).
2. **The mounted image was 0×0 (invisible).** The app renders an `<image>` inside
   `<div class="generated-image-container"><div style="width:min-content; …">
   chloeCloudImgElement()</div></div>`. The wrapper (`width:min-content`) exists so the
   keep/delete buttons can be absolutely positioned over the image — but a **percentage
   `max-width` inside a `width:min-content` parent collapses to 0px** (circular sizing),
   so `chloeCloudImgNode`'s `max-width:min(450px,100%)` img rendered at 0×0: the image
   *was* generated, uploaded and persisted, and the element existed in the DOM, but it
   had zero size → invisible ("nie wkleja zdjęć"). Measured live: 0×0 before, 161×242
   after.
   - Fix: `chloeCloudUnwrap(el)` — hoists the element out of that `min-content` wrapper
     into `.generated-image-container` (the buttons stay in the container, which gets
     `position:relative`, so they keep working) — called from `chloeCloudStep()`
     (placeholder, so the spinner is visible during the ~1 min job), `chloeCloudMount()`
     and `chloeCloudFallback()`. The cloud `<img>` then sizes exactly like the app's own
     saved images (`max-width:min(450px,100%)` → shrinks to the message column).
   - The placeholder box was also sized from the settings (768 px wide → overflowed a
     161 px column); it is now fitted to ≤450 px (`width:min(Npx,100%)`) so it matches
     the eventual image's footprint.
   - `window.__chloeCloudDebug` now also exposes `node` (chloeCloudImgNode) and
     `unwrap` (chloeCloudUnwrap) so the sizing can be tested from `page_eval` without
     burning a GPU job.

**Verified end-to-end live** (local `localflow` bridge, 2026-09-16): sent „Wyślij mi
teraz zdjęcie, proszę." → placeholder visible at 161×450 („Stheno dopracowuje prompt…")
→ mounted `<img data-chloe-cloud>` 161×242 (natural 1024×1536) inside Chloe's message,
`customData.__savedImages` persisted, still visible after `page_refresh` from cache.

Reminder for any future edit of the reply pipeline: **anything that normalises the AI
reply must not touch `<image>` tags** — run extract/restore around it.

### Cloud image generator (bez cenzur) — AI Horde

The image generator shown for any `<image>` is a **cloud, uncensored** one, default
**AI Horde** (`https://aihorde.net/api/v2`, free, anonymous, NSFW allowed, works from
the browser). It lives in `index.html` (the parent page), in a
`// Chloe edit: CLOUD image generator` block right after the `chloeSend` listener,
plus the `<image>` render integration (~9578) and the `oc.textToImage` API path
(~12013).

- **Settings** (`chloeCloudSettings()`, defaults
  `{enabled:true, provider:"horde", width:768, height:768, steps:30, sampler:"k_euler_a", nsfw:true, fallbackNative:true}`)
  persist under the PARENT localStorage key **`chloe_cloudimg_v1`** (via the same
  `chloeKvBridge` mechanism as `chloe_sources`, since the iframe origin is opaque).
- **`chloeCloudImgElement(options)`** = the `<image>` render entry point. If the cloud
  is active it returns `div.chloe-cloud-img[data-chloe-cloud]` (spinner + live status);
  otherwise it returns the native `root.textToImagePlugin(options)`.
- **`chloeCloudGenerate(prompt, settings, onStatus)`**:
  - `provider:"horde"` → `chloeCloudHorde`: `POST /generate/async` (apikey
    `0000000000`, `Client-Agent: Chloe-uncensored-image:1.0:perchance`,
    `params:{prompt, nsfw:true, censor_nsfw:false, replacement_filter:false, width,
    height, steps, sampler}`, `r2:false`, `slow_workers`/`extra_slow_workers`), then
    poll `/generate/check/{id}` (status carries queue **position + ETA**) and
    `/generate/status/{id}` → `generations[0].img` (base64). Progress goes through
    `onStatus`.
  - `provider:"custom"` → any OpenAI-compatible `/images/generations` endpoint (base
    URL, optional key/model); body `{prompt, n:1, size, response_format:"b64_json"}`,
    accepts `data[0].b64_json` or `data[0].url`.
  - `provider:"localflow"` / `provider:"comfyui"` → the user's **own PC**: a local
    bridge (Stheno → ComfyUI) or a direct ComfyUI. See "Local image pipeline" below.
  - The result blob is re-hosted via `root.uploadPlugin(blob)` → a **permanent**
    `https://user.uploads.dev/file/….webp` URL (AI Horde's own status/img URLs are
    short-lived signed links).
- **Failure** → `chloeCloudFallback`: red `❌ Nie udalo sie…` + the error text; when
  `fallbackNative` is true (default) it first swaps in the native
  `text-to-image-plugin` element before showing the error.
- **Persistence** → `chloeCloudPersist` writes
  `messageObj.customData.__savedImages[corePrompt] = {dataUrl: permanentUrl, chloeCloud:true}`,
  so scrolling back shows the saved image instantly with **no regeneration**.
- **Panel tab** — the side panel now has a third tab **🖼️ Obrazy**
  (`#ce2TabBtnImages` / `#ce2TabImages`, from `chloeCloudPanelHtml()` +
  `chloeCloudPanelWire()`): enable toggle, provider, size, steps, sampler, NSFW toggle,
  a prompt field and a **Test button** (`#ce2CloudTestBtn`). The test calls
  `chloeCloudTestInParent()`, which postMessages `{type:"chloeCloudTest", prompt}` to
  the parent; the parent listener (next to the `chloeSend` listener) generates with the
  PAGE's settings and streams `{type:"chloeCloudProgress", status}` back. Also reached
  from `/model`'s `cloudGet/cloudSet/cloudTest`. Provider `localflow` additionally shows
  the **Tryb obrazu (preset mostka)** select (`#ce2CloudPreset`) with
  **↻ Odśwież tryby** (`#ce2CloudPresetBtn`, fetches `<base>/health` and rebuilds the
  list from `tryby`); stored in `chloe_cloudimg_v1.localFlowPreset`.
- **Debug hooks**: parent `window.__chloeCloudDebug = {settings, active, generate,
  element, node, unwrap, parse, comfyBase, comfyBuild, comfyGenerate, comfyTest}`
  (`node(res, options)` builds the mounted `<img>`, `unwrap(el)` hoists it out of the
  app's `width:min-content` wrapper — use both from `page_eval` to test image sizing
  without a GPU job); iframe `window.__chloeE2.cloudGet/cloudSet/cloudTest`.
- **Caveats**: the anonymous AI Horde queue can be long (observed position 131,
  ~580 s); a harmless `ClipSkipMismatch` warning is common; occasional CSAM
  false-positive on youth-related wording.

**Verified live**: end-to-end generation (a nude prompt was honored —
`censored:false`), placeholder → `<img>` mount, permanent re-host, saved-image
re-render, panel Test button (~42 s), custom-endpoint error path, native fallback
swap, and responsive fit (`max-width:min(450px,100%)` → 307 px at a 390 px viewport,
450 px cap on desktop).

### Local image pipeline: `localflow` bridge → Stheno → ComfyUI

`provider:"localflow"` (the user's current setting) does **not** talk to ComfyUI
directly. It POSTs `{prompt}` to `<localFlowBaseUrl>/api/generate`
(`chloeCloudLocalFlow`) and the user's own bridge on the PC does the rest: Stheno 8B
expands the prompt, ComfyUI renders it (observed: 512×768, `dpmpp_2m`/`karras`,
22 steps, cfg 5, then RealESRGAN_x2plus upscale → 1024×1536) and answers with
`{ok, image_url}` where `image_url` is `<base>/images/<name>.png`.

Bridge facts (verified live, Sep 2026):

- `localFlowBaseUrl` = `http://127.0.0.1:8443` since 15.09.2026 (before that a Tailscale
  Serve URL). The new bridge (`src/bridge/hermes_comfy_bridge.py`, `/health` →
  `{ok:true, service:"Hermes (OpenRouter) -> ComfyUI", busy:false, version:5}`) serves
  `/v1/chat/completions` (OpenRouter passthrough), `/api/generate` + `/images/*`
  (Hermes refine → ComfyUI) and `/health` from that one origin.
  **The generator page CAN reach `http://127.0.0.1`** (proved live: `fetch("/health")` →
  200, chat via the app's own `chloeDirectFetch` works, streaming included) — loopback is
  exempt from mixed-content blocking and Local Network Access did not step in here. A
  phone/other machine still needs the HTTPS Tailscale Serve URL, and raw ComfyUI paths
  (`/object_info`, `/system_stats`) are still not proxied, so the `comfyui` provider needs
  its own CORS-enabled exposure. ComfyUI itself only ever lives on `http://127.0.0.1:8188`.
- The `custom` (OpenAI) provider has no queue handling — `/images/generations` answers
  **503** while the GPU is busy, so `localflow` is the provider to use with the bridge.
  `/health` reports `comfy.reachable:false` when ComfyUI is not running; `/api/generate`
  then fails with "brak polaczenia z ComfyUI pod http://127.0.0.1:8188 — sprawdz, czy
  ComfyUI dziala i czy adres jest dobry".
- **The bridge processes ONE job at a time** and answers HTTP **409** `"The local GPU is
  already processing another request."` for a second concurrent request — a reply with 3
  `<image>` tags used to produce 1 image + 2 error tiles. Fixed in the parent page by:
  a module-level promise chain (`chloeCloudLocalFlowChain`) that serializes our own
  requests, `chloeCloudLocalFlowFree()` polling `/health` (`busy === false`) before
  posting (with a visible "Lokalne GPU jest zajęte — czekam w kolejce…" status), and a
  409/429/503 retry every 5 s (up to 60 attempts).
- `chloeCloudLocalFlowRun` returns `{url, permanent:false, local:true}` and
  `chloeCloudPersist` persists `local` results too, so the image is cached in
  `messageObj.customData.__savedImages[corePrompt]` and a reload/scroll-back shows it
  from cache instead of re-running the GPU.

  **Verified live**: 3 `<image>` tags in one reply → 3/3 images in 160 s with 0 errors
  (before the fix: 1 ok + 2× 409), images rendered at 1024×1536, and after a
  `page_refresh` all 3 re-rendered from cache with no new ComfyUI job.

- `chloeCloudComfy(...)` is the direct-ComfyUI provider (its own API-format workflow in
  `chloe_cloudimg_v1.comfyWorkflow` + `comfyPositiveNode`/`comfyNegativeNode`).

### Image prompt engine (R13–R15 → v7) — `src/img-engine.js`

This is the block that decides **what** goes into an image so that it matches the RP
scene and is maximally explicit. Source of truth: `src/img-engine.js` (~77 KB),
spliced onto the END of the RP engine (see the re-splice recipe below); a byte-identical
assembled copy lives inside `src/chloe-customcode.js`. It exposes `window.__chloeImg`
(`brief enrich strip markless tags hits level tr sent budget command kadr shot flatten
direct last mark neg lex groups limits recent`).

### Bridge: Hermes (OpenRouter) + ComfyUI — `src/bridge/`

`src/bridge/hermes_comfy_bridge.py` is a **local dev tool, NOT part of the shipped
generator** (kept in `src/` so it survives the session). It replaces the old
`Stheno → ComfyUI` bridge: no local LLM at all — the chat endpoint proxies to OpenRouter
(`nousresearch/hermes-3-llama-3.1-70b` by default, so the API key stays out of the browser)
and the image endpoint runs `Hermes rewrites the prompt → ComfyUI` using the workflow in
`src/bridge/workflow_api.json` (positive node `2`, negative node `3`, size into the
`EmptyLatentImage` node, seed into every `KSampler`). One base URL serves everything:

- `POST /v1/chat/completions` — chat (streamed passthrough; also `/v1/models` and
  `/v1/api/extra/true_max_context_length` = 131072, so the engine's context budget works),
- `POST /api/generate` → `{ok, image_url:"/images/<file>", prompt, negative, direct}` — the
  `localflow` provider (the app reads `prompt` back for its `/obraz prompt` preview),
- `POST /images/generations` → `{data:[{b64_json,url}]}` — the `custom` (OpenAI) provider,
- `GET /health` → `{busy}` (the app waits while the GPU is busy), `GET /` status page,
  `GET /last`, `GET /images/<file>`.

Run `python hermes_comfy_bridge.py` (Python 3.8+, stdlib only; key from
`openrouter_key.txt` / `--openrouter-key` / `OPENROUTER_API_KEY`) — or, better, run the
launcher `python odpal.py` (double-click `odpal.bat`), which finds & starts ComfyUI first,
waits for `:8188`, then starts the bridge, and offers to shut ComfyUI down on Ctrl+C
(auto-detects `run_nvidia_gpu.bat` / `ComfyUI\main.py` / `main.py`+`venv`; settings in
`odpal_config.json`; `--find-comfy` shows what it looked at). On the same PC put
`http://127.0.0.1:8443` in BOTH the model tab Base URL and the Obrazy tab (localflow);
from a phone expose it with `tailscale serve --bg --https=8443 http://127.0.0.1:8443` and
use `https://<host>:8443` instead (the Obrazy panel accepts `http://127.0.0.1` too, since
`chloeCloudComfyHttpsOnly` whitelists loopback). The app is currently wired that way — see
`src/bridge/README.md`. Verify with `--selftest [--selftest-scene "…"] [--selftest-gen]`.
CORS accepts `*.perchance.org` + localhost only. Full guide: `src/bridge/README.md`.

**Windows/ROCm, jeden klik:** `src/bridge/Start_Comfy_i_Hermes.bat` (**v4, final**) ustawia
środowisko ROCm/HIP *sam, w środku pliku* — poprzednia wersja wołała `comfyui-rocm.bat`, gdzie
`for /f "delims=" %%i in ('"…\rocm-sdk.exe" path --root')` wpadał w błąd cmd z gubieniem
cudzysłowów (komunikat „WinError 123") → puste `GPU_ARCH` → pomijany blok MIOpen dla `gfx1102`.
**To nigdy nie był zepsuty ROCm-SDK** (`raport_rocm_sdk.txt`: `rocm-sdk init` = kod 0, `targets`
zawiera `gfx1102`, `hipconfig 7.16.26332`, `torch 2.13.0+rocm10.1.0a20260822` widzi RX 7600S,
`gcnArchName=gfx1102`; a `comfyui-run.log` pokazuje ComfyUI 0.33.0 startujące bez błędu i
nasłuchujące na `:8188`) — szczegóły w `src/bridge/README.md`. Launcher startuje ComfyUI,
czeka przez `sprawdz_comfy.py` (porównuje workflow z `/object_info` i wypisuje brakujące
checkpointy/LoRy/upscalery razem z folderem docelowym), a potem podnosi mostek. **v4** stawia
mostek w osobnym oknie, na koncu robi weryfikacje calego stosu (`/health`, `sprawdz_comfy.py`,
`--selftest`) i zapisuje ja do `raport_mostka.txt` (UTF-8); `--check` to sama diagnoza,
`--stop`/`--restart` zamykaja/podnosza mostek, `--test` wysyła jedno pytanie czatu przez
mostek, a ostrzeżenie o `tailscale serve` na porcie `8188` pilnuje, żeby ComfyUI nie został
wystawiony publicznie przez Funnel.

**Fallbacki + sticky sesja (21.09.2026):** mostek dokłada do żądań OpenRoutera `models[]`
(łańcuch modeli awaryjnych: `thedrummer/cydonia-24b-v4.1` → `mistralai/mistral-small-2603`
→ `deepseek/deepseek-v4-flash-0731`), `session_id` (sticky routing → trafienia w cache
promptu) i `provider.data_collection:"deny"` (providerzy nie trenujący na danych); stan
widać w `/health` pod `fallbacks`/`session_cache`/`last_chat`. Custom code dokłada nagłówek
`X-Session-Id` z identyfikatorem wątku (`oc.thread.customData.__chloeSessionId`) przez
`chloeE2RequestHeaders()`, którą to funkcję widać też w `window.__chloeE2.headers()` do
testów. Szczegóły: `src/bridge/README.md`.

**Detal twarzy, CFG 6.0, mostek v8 (24.09.2026):** `workflow_api.json` ma teraz **CFG 6.0** w
obu samplerach (baza i hires; `_meta.title` nodów to potwierdza), kroki bez zmian (25/20).
Mostek podniósł się na **wersję 8**: obok KSamplerów ziarno zadania dostają także inne nody z
polem `seed` (np. `FaceDetailer`) — inaczej detal twarzy liczyłby zawsze ten sam szum; widać to
w `/health` (`features` zawiera `detail_seeds`), a licznik trafia do `last.json` i pliku `.txt`
obok obrazu. Nowe narzędzia w `src/bridge/`: `dodaj_facedetailer.py` (wpina detal twarzy do
workflow, budując nod z `/object_info`, więc działa z różnymi wersjami Impact Packu;
`--dry-run` / `--remove` / `--test` / `--sam`), `Dodaj_detektor_twarzy.bat` +
`instaluj_detektor_twarzy.py` (wgrywają brakujący pakiet **ComfyUI Impact Subpack** i model
`face_yolov8m.pt`; każde `pip` idzie z `--no-deps`, żeby nie podmienić torch/ROCm), a
`sprawdz_comfy.py` (v1.1) ma sekcję detailingową i sam mówi, czego brakuje. Ustalenia:
`UltralyticsDetectorProvider` (wymagany przez `FaceDetailer`) **nie jest częścią Impact Packu
od V8** — jest w Subpacku; `UltimateSDUpscale` nie jest zainstalowany i nie ma do niego ani
`4x-UltraSharp`, ani żadnego ControlNetu, a obecny łańcuch 4x NMKD + Lanczos + hires już daje
2K, więc USDU jest na tym sprzęcie odradzany. Liczby i szczegóły: `src/bridge/README.md`.

**Mostek v9 — diagnostyka zamiast wiszenia (24.09.2026):** ten sam plik `hermes_comfy_bridge.py`
podniósł się na **wersję 9**. Powód: gdy ComfyUI zostanie zrestartowany w trakcie malowania,
jego historia i kolejka są puste, a mostek (v8) odpytywał o zadanie, którego już nie ma —
trzymał `JOB_LOCK` do końca `--timeout` (900 s), więc aplikacja pokazywała „Lokalne GPU jest
zajęte — czekam w kolejce…" i nie dało się nic wygenerować. v9: (1) `/health` ma pole `job`
(`stage` = `start`/`refine`/`comfy`, skrócone `prompt_id`, `elapsed_s`), (2) watchdog restartu —
brak zadania jednocześnie w `/queue` i `/history` przez `restart_misses` odpytań (~6 s) kończy
zadanie czytelnym błędem, (3) odrzucony graf (`node_errors`) i błąd wykonania noda są nazwane
po imieniu (numer, typ, `exception_message`), (4) osobno rozpoznawany Cancel/Interrupt.
Nowa opcja `--restart-misses`. Cała logika przetestowana w Pyodide (11/11 asercji, w tym
fałszywy restart ComfyUI i OOM w nodzie). Szczegóły: `src/bridge/README.md`.

**Launcher v4.3 + pomiar tempa (24.09.2026):** `Start_Comfy_i_Hermes.bat` podniósł się na
**v4.3**. Powód: ten sam graf potrafi iść 4 s/krok albo 26 s/krok (zmierzony hires pass
1024x1536/20 kroków: 4,25 s/it w jednym przebiegu, 26,28 s/it w innym — bez zmiany workflow),
więc zamiast zgadywać ustawienia, launcher umie je **zmierzyć** i **przełączać**:
`--bench` (po starcie mierzy tempo i pisze `raport_wydajnosci.txt`), `--attn=default|split|quad|pytorch|sage`
(dokłada flagę attention do startu ComfyUI; przy zmianie trzeba dodać `--restart-comfy`, bo
działający proces ma stare parametry) oraz `CHL_COMFY_EXTRA` (dopisuje flagi bez podmiany
całej listy). Doszły też: `Zmierz_tempo.bat` (dwuklik = `--bench`) i `bench_comfy.py` (mierzy
s/krok osobno dla base i hires, wykrywa „wolny tryb", kod wyjścia 2; przetestowany w Pyodide:
13/13 asercji na prawdziwych formatach logu ComfyUI). Launcher po starcie wypisuje, jaki
attention faktycznie wstał. Szczegóły: `src/bridge/README.md`.

Flow (`/obraz` in the RP engine calls `chloeImgCommand(arg)`):

1. `chloeImageBrief(ask, {level})` builds ONE line of English prompt from the live RP
   state (`chloeRPState()`: `lok czas ubr poz pobudz faza nastroj zabawki cialo`),
   the kink/limit profile, the last chat turns and the user's own request.
   Front→back = priority, because Stheno reads left-to-right and the bridge cuts at
   4000 chars: `@@scena-obraz@@` → `Chloe` → level text (0–3) → the action sentence →
   `the user asked for exactly this:` → tag list → framing → explicit tail → scene
   state → favourite kinks → hard limits.
2. `chloeImgCommand` sends it as the app's own `/image <brief>` path, so a real
   message id exists and the image can be persisted.
3. `index.html` wraps it: `imagePromptPrefix` + brief + `imagePromptSuffix` +
   `imagePromptTriggers` (the trigger `@prepend` text lands at the FRONT, which is
   where CLIP weights most).
4. `chloeCloudParseParams` extracts `(negativePrompt:::)`, `(resolution:::)`, `(seed:::)`,
   `(steps:::)`, `(cfg:::)`, `(sampler:::)` **and `(direct:::)`** out of the text (they
   are therefore NOT sent to the model), then the bridge runs Stheno → ComfyUI.

Components:

- **Marker `@@scena-obraz@@`** — idempotency + lets `chloeImgBriefStrip()` keep our
  labels out of the model context and `chloeCloudStripMark()` keep them out of the
  prompt. It must NOT be `[[…]]`: `oc.messageRenderingPipeline` turns every `[[…]]` into
  a `<button onclick="chloeQuickAction(…)">` before the app cuts the `<image>` content,
  so raw button HTML used to reach Stheno.
- **PL→EN translator `CHLOE_IMG_TR`** — CLIP only understands English, but the scene
  state is Polish. Longest-phrase-first pairs for places, times, poses, clothes, body,
  acts; `chloeImgTrAsk()` cleans the user's request of command words.
- **Act sentence `CHLOE_IMG_ACT_SENT`** — ~20 regexes → one natural English sentence
  ("what is happening right now: Chloe is …"), which is what makes the image match the
  chat. It is followed by the anti-covering clause ("Her thighs are spread wide apart …
  nothing stands in front of her genitals …").
- **Tag lexicon `CHLOE_IMG_LEX`** — regex → comma-separated English tags, grouped
  `act|kink|body|pose|cloth|scene`; `CHLOE_IMG_GROUP_MAX = {act:22, kink:12, body:10,
  pose:4, cloth:3, scene:4}`. Tags from the scene/user request ("core") beat tags from
  the chat (only the first 2 of a matched pattern enter), and `st.obietnice` (promises)
  never produce tags.
- **Clothing rules** — `CHLOE_IMG_CLOTH_WORDS` (latex/lace/lingerie/stockings/corset =
  keep) vs `CHLOE_IMG_CLOTH_LOWER` (shorts/skirt/panties/jeans/…). At level ≥2 the
  lower-body garment is never *named*: naming "shorts" made SD draw shorts over her
  crotch (measured). The sentence says instead "nothing on her lower body: no clothes,
  no shorts, no panties, no garment of any kind reaching down to her crotch or hips".
  At level 3 the upper garment is described as "open and pushed up above her waist" —
  without that, Stheno turned the unbuttoned shirt into a top that slid down to her
  hips and covered the crotch (measured, 1 of 2 images in the v7 test).
- **Level `chloeImgLevel`** 0–3 from arousal/phase/nudity/explicit keywords, or forced
  with `/obraz poziom N` (persisted per user) / `/obraz N opis`.
- **Framing `chloeImgKadr` / `CHLOE_IMG_SHOT`** — `auto` (default) = full body from head
  to thighs with the open crotch centred and nothing draped over it, `full` = head to
  toes, `close` = close-up. `auto` only falls back to `close` when the user explicitly
  asks ("z bliska", "detal", "close-up"). `/obraz kadr auto|full|close`.
- **Budget `chloeImgBudget`** — `4000 − (prefix + suffix-without-params + trigger texts
  + 250)` clamped to 1100–2600. Parameters are excluded because they never reach the
  bridge. If the brief still overflows it drops favourites → limits → scene state →
  trailing tags, then hard-cuts on a comma.
- **Direct mode** — `chloeImgFlattenSd()` turns the brief into a clean SD prompt (no
  "what is happening right now:"/"scene state:" labels), trims to 1500 chars and appends
  `(direct:::1)`. Stheno compresses ~3.5 KB → ~1 KB, so direct mode (bridge ≥ 1.1) is the
  way to lose nothing. Toggled by the **Tryb wprost** checkbox in the panel Obrazy or
  `/obraz stheno on|off`; stored in the parent `localStorage["chloe_backend_v2"]
  .directToComfy` (read by both the page and the iframe).
- **Anti-"tasteful" tail (v7)** — levels ≥2 end with a POSITIVE assertion ("raw
  pornographic sex photo of a real woman, an obscene sex act clearly in progress …")
  because models have a strong built-in pull toward tasteful nudes and negations alone
  are weak. The trigger `@prepend` text in the character (front of the whole prompt)
  additionally carries "bare breasts completely exposed with hard nipples, nothing
  covering her chest, nothing covering her genitals, no bikini, no underwear, no shorts,
  no swimsuit, no panties, her crotch completely bare and in the clear".

**Negative prompt — the biggest single quality lever.** `chloeCloudParseParams` pulls
`(negativePrompt:::…)` out of `imagePromptSuffix` (934→1063 chars: quality, anatomy,
anti-censorship AND anti-"covered" terms: fabric/cloth/clothing over the crotch, panties,
underwear, shorts, bikini, swimsuit, towel/sheet covering, garment over crotch, clothing
over hips, fabric below the waist, top/shirt over crotch, cloth between the legs, hands
covering the pussy, hand between the legs, thighs pressed together, closed legs, knees
together, hidden/cropped genitals, cropped hips/legs/body, sfw, tasteful, modesty, child)
and sends it as the bridge's `negative` field. **The stock bridge (version 2) ignores
that field** — node "3" of the workflow keeps its weak built-in negative — so the whole
negative only takes effect after the patched bridge below is installed. `/obraz prompt`
prints the built brief, the last final prompt AND the negative, so you can see whether it
is actually being sent.

Verified live (v7, old bridge, 12 generations from the same brief): 10/12 explicit
hardcore with a fully bare, unobstructed crotch, breasts bare, thighs spread, head-to-thighs
framing, no censorship; the 2 failures were two variants of a garment on the crotch
("green" again — the character's green hair bleeds into clothing terms), which is exactly
what the negative/`direct` patch targets.

#### Patch for the PC-side bridge (`scratch/perchance_bridge.py`)

The user's `perchance_bridge.py` is not in this repo — the patched version was written here
and handed over with instructions. It adds:

- `NEGATIVE_NODE = "3"` + `NEGATIVE_CORE` (always appended) + `NEGATIVE_DEFAULT` +
  `build_negative(app_negative)` (dedupes, caps at 2000) and writes the result into
  `workflow["3"]["inputs"]["text"]` — the bridge previously ignored `negative` entirely.
- `direct` in the POST body: `true` skips Stheno and sends the app's prompt verbatim
  (`REWRITE_DIRECTIVE` is prepended in Stheno mode instead: keep every sexual detail,
  never put clothing back on, never invent a garment, never add another person).
- `/health` reports `version: 4, features: ["negative","negative_core","direct"]` — the
  check that the patch is live (stock = `version: 2`).
  Validated by running the constants under Pyodide (`ast.parse` + `exec` of the negative
  block + `build_negative` unit checks).

#### Gotchas found while wiring this up

- `db.threads` rows carry a **sealed/frozen `character` snapshot**, so per-thread tweaks
  made via `oc.thread.character` may silently not persist to the DB. Per-thread mutable
  state lives in `oc.thread.customData.__rp*` instead.
- The custom-code iframe is sandboxed (opaque origin): `iframe.contentWindow` throws
  `SecurityError`. Use `await window.runCodeInCustomCodeIframe("…")`.
- Do NOT trigger several `/obraz` at once: the bridge is single-job and the page's chain
  serializes them, so a 3-shot test occupies the user's GPU for ~10–25 min (observed).
  Each `/obraz` can also produce an extra `<image>` message (the model may echo one), so
  check `db.messages` afterwards.
- A `<image>` message with no matching `customData.__savedImages[corePrompt]` regenerates
  on EVERY page load. After testing, delete those test messages and `page_refresh`.



Measured cause: an 8B Q4_K_M model with only 20 layers on the GPU prefills at
~31.6 ms/token (~32 tok/s) in an 8192-token window. A prompt of **25 661 chars
(~8 020 tokens)** therefore needed 250–400 s of prefill, the client's 300 s timeout
always fired, the automatic retry queued a second request, nothing aborted the server,
and KoboldCpp's single slot stayed blocked → every later message timed out too
(observed: the fallback notice only at **t = 632 s**). Fixes in the custom code:

- `chloeBuildAI` is budget-aware (`CHLOE_AI_BUDGET = 5200` chars): sections are capped
  (reads 5×420, videos 10, reddit comments 5×260, reddit 8, search 6, platform links 5)
  and `chloeTrimText()` shrinks the rest.
- History/lore are char-budgeted: `CHLOE_HIST_BUDGET = 3500` (newest-first, ≤900 chars
  per message, `chloeE2History(40, CHLOE_HIST_BUDGET)`) and
  `CHLOE_LORE_E2_BUDGET = 2200` (`chloeLoreSelect(query, recent, budget)`). Older
  `__chloeSearch`/`__chloeSearchGroup` message groups are dropped from the AI history
  (they stay visible in the UI). Result: a real request went 25 661 → **14 150 chars**.
- `chloeE2ContextLimit()` reads `/api/extra/true_max_context_length`; `chloeE2Chat`
  clamps `max_tokens` to `ctx − estIn − 24` (`CHLOE_E2_CTX_CLAMPED` notice when it bites).
- **Streaming**: `payload.stream = true` + `chloeE2SseFeed()`; `chloeDirectFetch`
  forwards chunks to the iframe and the parent's reader re-arms its abort timer on every
  chunk, so a long generation is not killed while text is flowing. The typing bubble
  (`chloeE2TypingHTML`) paints streamed text live and shows "✍️ Chloe pisze… N s"
  (+ a "1–3 min" hint after 25 s).
- `chloeE2AbortServer()` only runs when the endpoint actually supports
  `/api/extra/abort` (probed once, cached) — most proxies, including the user's tunnel,
  do not (see the RP section below); `chloeE2WaitIdle()` waits for the server to stop
  being `busy` instead. The blind 2×300 s retry is gone — a timeout now falls back to
  Perchance immediately with an explanatory notice.

  **Verified live**: "Napisz jedno zdanie o kawie." → real local reply in ~204 s, no
  notice. The decisive speed fix is on the PC, not in the code: launch Stheno with far
  more GPU layers (Q4_K_M 8B + 8192 ctx ≈ 6 GB fits the RX 7600S's 8.4 GB VRAM) —
  `--gpulayers 99` instead of 20.

### RP engine (R0–R12) — the roleplay layer

The roleplay layer is ONE appended block (`src/rp-engine.js`, ~74 KB) spliced onto
the END of the base custom code; the base part is everything up to the LAST statement of
the base, `oc.thread.on("MessageAdded", chloeHandleAddedMessage);`. It only *calls* base
helpers (`chloeClean`, `chloeGet`, `chloeE2Chat`, `chloeE2Active`, `chloeKvLoad/Set`,
`chloeParseLore`, `chloeScoreEntry`, …) and exposes `window.__chloeRP`:
`ready get set state stateSet stateSummary kinks limits setKink kinkState profil world
campaign beat beatPick tail rules config prepare absorb antislop command scenes diary
diySelect diyLoad isFast budgets exportMd panel logs reset` (all primitive-returning —
never postMessage a proxy-backed object, it throws `DataCloneError`).

Commands (handled in `chloeRPCommand`, i.e. before/instead of a model call), on top of
the base `/panel`, `/model`, `/search`, …: `/scena` (5 scene proposals), `/rp`
(+ `/rphelp`, `/pomoc2`) settings panel, `/kinks`, `/stan`, `/profil`, `/swiat`, `/npc`,
`/tempo`, `/popraw`, `/szybki`, `/stop`, `/wznow`, `/pamietnik`, `/eksport`, `/kampania`,
`/reset`.

Storage split (matters when debugging "why did my setting vanish"):
- **shared settings** → PARENT-page `localStorage["chloe_rp_v1"]` (via the `chloeKvBridge`
  listener in `index.html`, ~line 11503), with a copy in
  `oc.character.customData.__chloeKv` only as a fallback. `fast` lives here.
- **per-thread data** → `oc.thread.customData.__rpState / __rpKinks / __rpLimits /
  __rpWorld / __rpProfil / __rpKampania` (+ `__rpDiary` inside `__rpProfil`).

Second lorebook (DIY/hardware knowledge, 63 entries): `src/chloe-diy-lorebook.txt`,
referenced by `RP_DIY_URL` in the engine (currently
`https://user.uploads.dev/file/bea8789efb27954847964901bb323d87.txt`). Rebuild = edit that
file, `upload_file` it, update `RP_DIY_URL`.

#### Prompt shape (prefix-cache friendly)

`chloeE2BuildMessages()` puts the stable block FIRST and everything that changes per turn
LAST, so the model server's prefix cache covers the bulk of the prompt:
`[0] system  #  roleInstruction + RULES + config + prefs  (~8.9 KB, stable)` →
`[1..N] history (append-only)` → `[N+1] system  #  LORE + DIY  (~2 KB, varies per turn)` →
`[N+2] system  #  reminder (~1.4 KB)` → `[N+3] system  #  RP tail (state/beat/author's
note)`. Retrieval (lore + DIY) used to sit inside message 0, which invalidated the cache
on every turn — moving it after the history is the main latency win.

#### Speed / robustness fixes worth keeping

- `fast` (`auto|on|off`, default `auto` = on for the `kobold` backend) shrinks the char
  budgets via `chloeRPBudgets()`: `{hist:2000, lore:1150, diy:850}` instead of
  `{3500,2200,1300}` → far shorter prefill on a local 8B model.
- **`/api/extra/abort` is NOT universal.** The user's tunnel proxy
  (`Perchance → Stheno → ComfyUI`, version 2) exposes only `/health`, `/v1/models`,
  `/v1/chat/completions`, `/api/extra/true_max_context_length` and `/api/extra/...` at the
  ROOT; `POST /api/extra/abort` 404s both at `/` and under `/v1`. So
  `chloeE2AbortServer()` probes ONCE and caches the result (`CHLOE_E2_SRV.abort`) — on this
  proxy it disables itself instead of spamming 404s.
- That proxy answers **409 "The local GPU is processing another request."** while a
  previous request is still running, which used to silently drop the reply to the
  Perchance native model. Now each turn first calls `chloeE2WaitIdle()`, which polls
  `<root>/health` (`{"busy": true|false}`, probed once, cached in `CHLOE_E2_SRV.health`)
  and waits ≤20 s (≤60 s in the error path); the 409 branch retries the local model once
  before falling back. Cache limits are probed at the ROOT (`chloeE2RootUrl()` strips a
  trailing `/v1`) while chat/models keep the `/v1` base.
- Anti-slop (`chloeRPAntiSlop`): the ~25 cliché regexes are compiled ONCE
  (`chloeRPClicheRegexes` / `RP_CLICHE_RE`) instead of ~1000 `new RegExp()` per reply, and
  it reuses `RP_TURN.tail` instead of recomputing it. It also edits text in place via
  `chloeRPSplitKeep` / `chloeRPJoinKeep` and normalises with `chloeRPCleanKeepLines()` —
  it used to rebuild sentences with `join(" ")` and finish with `chloeClean()`, which
  flattened every paragraph into a single block. RP replies are multi-paragraph by design,
  so `\n\n` MUST survive (`chloeClean` collapses `\s+` → never use it on the reply).

### Editing the custom code (re-splice recipe)

Three durable working files matter, all under `src/`:
- `src/rp-engine.js` — the RP engine block (edit this for RP work). Starts at the
  `// =====` banner containing `CHLOE RP ENGINE`.
- `src/img-engine.js` — the image-prompt engine block, spliced AFTER the RP engine
  (edit this for image/prompt work). Exposes `window.__chloeImg`.
- `src/chloe-customcode.js` — the assembled artifact = base + RP engine + image engine,
  i.e. what actually gets installed. Its tail after the marker line
  `oc.thread.on("MessageAdded", chloeHandleAddedMessage);` is re-generated on every splice,
  so the "base" (everything before that marker: the character-chat base + Chloe's prompt
  blocks/shortcuts) lives only here. Edit the base in place here; edit RP/image work in the
  two engine modules. If the two modules are ever lost, they can be re-extracted from this
  file: the region from the RP-engine banner onward IS `rp-engine.js` + `img-engine.js`.

`index.html` remains the SOURCE OF TRUTH (that is what
ships); re-embed after every edit with the snippet below, and refresh this mirror after
re-embedding. The installed code is one JSON string literal in `index.html`, on a single
line, found via `customCode: "// =====` (Chloe's entry; 5 `customCode:` fields exist in
total — the other four are other starter characters).

Splice + install (Node-less; `execute_js` tool, `fs`):

```js
const cc = await fs.readTextFile("src/chloe-customcode.js");          // base+engines
const rp = await fs.readTextFile("src/rp-engine.js");                 // fresh RP engine
const img = await fs.readTextFile("src/img-engine.js");               // fresh image engine
const marker = 'oc.thread.on("MessageAdded", chloeHandleAddedMessage);'; // appears EXACTLY once
const rebuilt = cc.slice(0, cc.indexOf(marker) + marker.length) + "\n\n\n" + rp + "\n\n" + img + "\n";
new Function(rebuilt);                                                // syntax gate
let html = await fs.readTextFile("index.html");
const re = /customCode:\s*"((?:[^"\\]|\\.)*)"/g;
let m, hit = null;
while ((m = re.exec(html))) { let d = null; try { d = JSON.parse('"' + m[1] + '"'); } catch (e) { continue; }
  if (d.indexOf("CHLOE RP ENGINE") !== -1) { hit = {s: m.index, e: m.index + m[0].length}; break; } }
html = html.slice(0, hit.s) + "customCode: " + JSON.stringify(rebuilt).replace(/<\//g, "<\\/") + html.slice(hit.e);
await fs.writeTextFile("index.html", html);
```

Truncating at the marker and re-appending the engine makes the splice idempotent (the old
engine copy is dropped). Then push to the SAVED characters (the app builds the custom-code
iframe from `db.characters.get(thread.characterId).customCode`, so `index.html` alone is
NOT enough) and reload:

```js
const up = await tools.upload_file({path: "src/chloe-customcode.js"});
await tools.page_eval({js: `const t = await fetch(${JSON.stringify(up.url)}).then(r=>r.text());
  const cs = (await db.characters.toArray()).filter(c => c.name === "Chloe");
  for (const c of cs) await db.characters.update(c.id, {customCode: t}); return cs.map(c=>c.id);`});
await tools.page_refresh({});
```

#### Testing the custom code from `page_eval`

The custom-code iframe is sandboxed (opaque origin), so `page_eval` cannot read
`iframe.contentWindow.__chloeE2` directly. Post a function message instead (inside it
only `window.__chloeE2` / `window.oc` are reachable — top-level functions are NOT
globals):

```js
const ifr = document.querySelector(`#customCodeIframeCtn iframe[data-thread-id='${activeThreadId}']`);
const id = "probe" + Math.random().toString(36).slice(2);
const res = await new Promise((resolve) => {
  const h = (e) => { if (e.data && e.data._id === id) { window.removeEventListener("message", h); resolve(e.data); } };
  window.addEventListener("message", h);
  ifr.contentWindow.postMessage({_id: id, type: "function",
    functionText: "async function(){ return window.__chloeE2.srcList(); }", functionArg: undefined}, "*");
  setTimeout(() => { window.removeEventListener("message", h); resolve({timeout: true}); }, 30000);
});
return res;
```

The app's own `#messageFeed` / `#messageInput` / `#sendButton` live in the PARENT
page, so chat-level assertions (search cards, progress text) can be checked with
plain `page_eval` DOM reads. Poll — a search takes ~12–20 s.

**Testing slash commands without the UI** (fast, no visibility gate, no hidden
waiting): call the dispatcher directly through the exposed object. `msgs` is only
used by `.pop()` (so pass `[]`), and a system message with `hiddenFrom:["ai"]` is
pushed for anything the user should see:

```js
functionText: "async function(){ return await window.__chloeRP.command('/stan', [], {author:'user'}); }"
```

Verified this way (2026-09-15): `/pomoc2 /stan /profil /kinks /swiat /granice
/tempo /szybki /popraw /wyszukiwanie /lubi /granica /ciekaw /miekkie /npc
/kampania-stop /reset` all return `true` in <1 ms and each pushes exactly one
message; `/scena` returns `true` after ~12 s (warm local model) with the scene
picker card (5 scenes parsed out of the model output); `/eksport` produces
well-formed markdown. Note the returned value must survive postMessage — wrap it
in `JSON.parse(JSON.stringify(x))` (proxy-backed objects throw DataCloneError).

**GOTCHA — the send button "hangs" when the preview is not the focused tab.**
`doBotReplyIfNeeded` (app code, `index.html` ~line 7010) contains
`while(document.visibilityState !== "visible") await delay(300);` *before* it marks
itself as replying. If the editor/browser tab is hidden, a click on `#sendButton`
leaves the button `disabled` indefinitely and no reply is ever generated. That is
the platform's "don't burn credits in the background" guard, **not** a bug in the
RP engine, and it is not caused by handling a command. Don't diagnose an
"RP command triggered a model reply / stuck button" bug from it — check
`document.visibilityState` first, and prefer the direct-`.command()` probe above.

## Lorebook (knowledge base)

- Source: `src/chloe-lorebook.txt` (~32 KB, ~150 blank-line-separated entries; each
  entry ends with a `PL: <keywords>` line).
- Uploaded (immutable): `https://user.uploads.dev/file/e2fa9281095cb8dec0b60654003b7bba.txt`
  — this URL is what the Chloe starter's `loreBookUrls` references.
- Rebuild: edit `src/chloe-lorebook.txt`, then `upload_file` it and update
  `loreBookUrls` in `index.html` if the URL changes.
- Second lorebook (RP layer, 69 entries, Polish body): `src/chloe-diy-lorebook.txt` —
  DIY / toy-building / orgasm-engineering knowledge. Uploaded to
  `https://user.uploads.dev/file/52730771a7cab6caf65ed9649331f800.txt`, which is what
  `RP_DIY_URL` in the RP engine references (retrieved per turn by
  `chloeRPDiySelect`, budget `diy` chars = 850 fast / 1300 normal, max 12 entries).
- Six of those 69 entries are the **"tryb projektanta"** block (added 22.09.2026):
  `PROJEKT NA ZAMOWIENIE` (stały format odpowiedzi), `OGRANICZNIK ZAMIAST OSTRZEŻENIA`
  (zawór upustowy / manometr / zderzak głębokości / limit czasu + wartości), `PODCISNIENIE
  I PUMPKA — WERSJA BEZPIECZNA`, `SAMOPENETRACJA I SELF-FUCK — TECHNIKA`,
  `TRZY STOPNIE KAZDEGO MECHANIZMU`, `ZAMIENNIK ZAMIAST ODMOWY`. Retrieval sam by nie
  wystarczył (budżet ~1300 znaków), dlatego te same zasady są **zawsze aktywne** w bloku
  RULES RP engine (`SPRZĘT, DIY I INŻYNIERIA ORGAZMU` → dopisany pełny format projektu),
  a `RP_DIY_HINT` dostał aliasy `pomysł / projekt / wymyśl / wynalaz / patent / mechanizm /
  self-fuck / samopenetracja / kuchn / warsztat / domow / sport`, żeby dopytania „daj mi
  pomysł…" łapały boost ×3 na retrieval DIY. Prompt wyjściowy dla Groka (poza generatorem):
  `src/prompt-xgrok-diy-toys.txt`.

## Verified research findings (why it's built this way)

Sources that work from the runtime: redlib.catsarch.com (Reddit), RedGifs API,
nhentai JSON API, e621 JSON, Wikipedia, Bing RSS, Pornhub/YouPorn/SpankBang/Porntrex
HTML, and the tube/metasearch scrapers Redtube, porn.com, Xozilla, SunPorno, TNAFlix,
nudevista, e-Hentai and 3Hentai. Sources that do NOT (blocked/bot-gated): reddit.com
JSON (403), old.reddit, DuckDuckGo, Bing HTML, xHamster (503), XVideos/XNXX, rule34.xxx,
gelbooru (needs key), hanime (POST blocked), eporner (JS), ashemaletube, xxxbunker (geo).

Roleplay-quality techniques confirmed from r/SillyTavernAI ("After Three Years of
Roleplaying…") and r/perchance tutorials, all applied to Chloe's persona:
1. A **"Visual Impression"** field (the overall feeling a character gives) matters
   more than a list of factual traits.
2. An always-on **Speech/Voice block** (style, pitch, mannerisms) preserves identity
   better than example messages.
3. Specify reply length in **WORDS, not tokens**, and restate it close to the reply
   (in the reminder), because distant system-prompt length rules lose influence.
4. Keep secrets out of context; use the app's memory/lore retrieval + auto-memories.

Other maxed-out app capabilities used: `oc.generateText`, `oc.messageRenderingPipeline`,
`MessageAdded`/`StreamingMessage` events, `oc.thread.customData`, the built-in
memory/lore/auto-summary system, and native `/image` generation.

## Notes for a future agent

- Do NOT publish the generator unless the user asks. The starter is persisted by the
  app's normal save (`window.generatorIsUnsaved`). It is currently an UNSAVED draft.
- **`db.characters` holds THREE identical `Chloe` rows: id 1, 2, 3** (stan 2026-09-21) —
  same customCode, same prompt (`roleInstruction` 4215 znaków, `reminderMessage` 1459).
  That prompt is **NOT** the Hermes-3 one from `src/chloe-hermes3-roleInstruction.txt` /
  `-reminderMessage.txt` (5035 / 1633) — those files are prepared but not installed in the
  characters. The only thread is id 2 → `characterId` 3. Every code change must be pushed to
  ALL rows that carry the Chloe customCode (`db.characters.toArray().filter(c =>
  c.customCode.includes("CHLOE RP ENGINE"))`) — `starterCharacters` in `index.html` alone only
  affects NEW threads. (An earlier note claimed a single row id 4 = `Chloe (Hermes 3)`; that
  row is gone.)
- **Never re-save a prompt through the in-app character editor** — it strips HTML, and the
  prompt needs its literal `<image>…</image>` contract. Use `db.characters.update(...)`.
- **The app auto-seeds when there are ZERO threads**: `index.html:14817-14830`
  (`if(!$("#chatThreads .thread"))`) builds a character from `starterCharacters[0]` and a
  thread with it — so wiping everything resurrects a duplicate "Chloe" (this is how the old
  duplicates appeared). Keep at least one thread alive to avoid it; to change WHAT gets
  seeded, edit `starterCharacters[0]` in `index.html`.
- The own-model preset is a GLOBAL setting (localStorage `chloe_backend_v2`), NOT
  per-character — to run id 4 on Hermes 3, pick `nousresearch/hermes-3-llama-3.1-70b` in the
  ⚙️ model panel.
- Chat commands are handled by the RP engine before any model call — test those first
  (they're instant and prove the engine loaded): send `/pomoc2` or `/stan`.
- Test by creating a NEW throwaway thread from the user's character list, never in the
  user's own threads: click `#newThreadButton`, then the first `#characterList .character`,
  then set `#messageInput.value` + dispatch an `input` event + `#sendButton.click()`.
  Wait for the send button to re-enable AND for "Chloe pisze" to disappear before reading
  the result (a real local-model turn takes 60–130 s). Stub `confirm`/`alert`/`prompt`
  first. Delete the throwaway thread (`db.messages.where("threadId").equals(id).delete()`
  + `db.threads.delete(id)`) when done.
- Next session: `src/README.md` (this file) + the durable modules
  (`src/rp-engine.js`, `src/img-engine.js`, `src/chloe-customcode.js`) + the re-splice
  recipe above are the recovery path — `scratch/` is gone. `src/PLAN-RP.md` is the R0–R12 spec.
- Verify changes with the iframe probe recipe above (`window.__chloeRP` /
  `window.__chloeE2.buildMessages`). `window.__chloeE2.buildMessages(text)` is the clean
  way to inspect the outgoing prompt without burning a model call.
- The local model's Polish is weak (8B at the user's `temperature 1.2`): expect garbled
  chips/POLISH and short replies (~600 chars vs the 220-word target). That's the model +
  the user's own sampling settings, not the engine — do not "fix" it in code.

---

## Chloe Enhanced 2.0 — co weszło (24.09.2026)

Wdrożona paczka `chloe-enhanced-modernized-2.0.zip`. Zmiany po stronie aplikacji:
`src/chloe-customcode.js` (nowy bundle, +23,6 kB), `src/rp-engine.js` (escapowanie stanu sceny
w `chloeRPStateSummaryHtml`, komendy `/pamięć` i `/kontekst`), **nowe** `src/memory-engine.js`
(Memory Engine v2, migruje v1 bez kasowania danych) i **nowe** `src/model-router.js`
(OpenRouter Auto + trasa NSFW Dolphin-Venice + kanał reasoningu). `main.pjs` i `src/img-engine.js`
są identyczne jak przed wdrożeniem — nie ruszaliśmy ich.

Build i testy (Node, opcjonalne — do składania bundle z modułów):

```text
node src/tools/build.mjs        # składa src/chloe-customcode.js i embeduje go w index.html
node src/tests/regression.mjs   # sprawdza bundle, embed, Memory Engine i Model Router
```

Po każdej zmianie modułu (`rp-engine.js`, `memory-engine.js`, `img-engine.js`, `model-router.js`,
`research-engine.js`) uruchom build, a potem **zaktualizuj wiersze postaci w `db.characters`**
(aplikacja czyta kod z bazy, nie z `index.html` — dotyczy to wierszy o `name === "Chloe"`).
Najprościej z konsoli strony: `await __chloeDeployCode()` (kopia starego kodu ląduje w `misc`,
cofnięcie: `await __chloeRestoreCode(id)`) — patrz rozdział „Wdrażanie zmian po stronie aplikacji".

**Mostek/ComfyUI zostaje nasz** (rozdział `src/bridge/`): paczka 2.0 przywiozła starszą kopię
(mostek v6, CFG 5.0, launcher v4.2, bez narzędzi FaceDetailer i bez `bench_comfy.py`), więc
świadomie NIE podmieniliśmy `src/bridge/`.

**Znalezione przy wdrożeniu — brak klucza w mostku (naprawione w mostku v10):** mostek v9 używał
tylko własnego `api_key`, a aplikacja wysyła swój w nagłówku `Authorization` — więc bez
`openrouter_key.txt` każdy czat przez mostek kończył się `401 No cookie auth credentials found`
(obraz działał, czat nie). Mostek v10 bierze klucz klienta, gdy nie ma własnego; `/health` ma
pole `key_source`. Szczegóły: `src/bridge/README.md`.

Rollback do wersji 1.0: bundle sprzed 2.0 jest w `state/characters.json` paczki
(`customCode` wierszy Chloe) — wystarczy wstawić go z powrotem do `src/chloe-customcode.js`
i do `db.characters`.

### 2.1 Obrazy: tryby pracy mostka i szybszy workflow ComfyUI (25.09.2026, mostek v11 -> v12)

Audyt starego `workflow_api.json` + pomiary na RX 7600S 8 GB + zalecenia pod hard NSFW:
**`src/bridge/NSFW_CONFIG.md`** (czytaj to pierwsze przy każdej zmianie w obrazach).

Skrót: stary układ (baza 768x768 → 4x NMKD → zmniejszenie do 1024x1536 → hires) to
**63,7 s na obraz** i marnowanie ~70% pracy; nowy domyślny plik rysuje **natywnie
768x1152 w 20 krokach (~18 s) i wychodzi ostrzej**, a tryb `fast` (512x768 + ESRGAN 2x)
robi obraz w **~3-4 s**. Na tym GPU wąskim gardłem jest dekodowanie VAE w wysokiej
rozdzielczości (~11 s przy 1024x1536), a nie próbkowanie — dlatego nie domalowujemy
w dużych rozdzielczościach.

Mostek v11 ma **tryby** (`preset`): `default`, `fast`, `classic`, `sdxl_fast`, `sdxl_cfg8`,
`sdxl_hq` — każdy to plik workflow + rozmiar + parametry (+ opcjonalnie `checkpoint`,
`prompt_prefix`, `refine_hint`). Tryb ustawia się w `bridge_config.json` (`"preset": "fast"`)
albo per zadanie polem `preset`; podręcznik i tabela ustawień: `src/bridge/NSFW_CONFIG.md`.
`index.html` (`chloeCloudLocalFlowRun`) przekazuje teraz `preset` z ustawień obrazów
(`chloe_cloudimg_v1.localFlowPreset`), a panel Obrazy wystawia **listę trybów**
(`#ce2CloudPreset`, sekcja „Stheno → ComfyUI”) z przyciskiem **↻ Odśwież tryby**, który
pyta `/health` mostka i pokazuje jego prawdziwe tryby (`tryby`, wersja, `last_image.tryb`).
Komenda równoważna: `/obraz tryb sdxl_std` (`/obraz tryb` = lista, `/obraz tryb auto` = czyść).
Starszy mostek pole `preset` zignoruje, a nieznana nazwa kończy się czytelnym błędem z listą
dostępnych trybów.

Pod „full hard NSFW" docelowo SDXL (LUSTIFY SDXL NSFW, CyberRealisticXL Play,
WAI-NSFW-Illustrious, Pony V6 XL) — pobieracz: `src/bridge/Pobierz_modele_NSFW.bat`
(z HuggingFace, bez konta, z wznawianiem). LoRA przyspieszające SDXL (Lightning 8 st.,
Hyper-SD 8 st. CFG) są już zainstalowane przez ComfyUI-Manager.

**Mostek v12 (25.09.2026)** dokłada **automatyczny dobór checkpointu**: gdy workflow
wskazuje niepobrany plik, a w `models/checkpoints` jest model tej samej rodziny
(pole `family` w presecie: `sd15` / `sdxl`), mostek podstawia go i raportuje to jako
`checkpoint_auto` — pobrany model działa więc bez edycji `bridge_config.json`.
Ta sama zmiana naprawia `Pobierz_modele_NSFW.bat`: plik miały **końce linii LF**, a przy
LF cmd.exe po `set /p`/`call :etykieta` potrafi **zamknąć okno bez komunikatu** (objaw:
„wybieram opcję, wciskam Enter i okno się zamyka"). Teraz wszystkie `.bat` w `src/bridge/`
mają CRLF (pilnuj tego przy każdej edycji!), menu działa w `call :main`, a błąd wraca do
menu zamiast zamykać okno.

**Tryby SDXL zmierzone na żywo** (po pobraniu LUSTIFY endgame + `sdxl_vae`): ciepłe czasy
to `sdxl_cfg8` **21,8 s**, `sdxl_fast` **22,1 s**, nowy **`sdxl_std` 42,6 s** (24 kroki, bez
destylacji — w A/B wyraźnie lepsza skóra i anatomia niż 8-krokowe warianty) oraz
`sdxl_hq` **123-152 s** (hires potrafi zepsuć anatomię, zmieniono denoise 0,4 → 0,3 i
latent upscale na `nearest-exact`). Rekomendacja: `sdxl_std` do jakości, `sdxl_cfg8` do
podglądów. Tabela i werdykt: `src/bridge/NSFW_CONFIG.md` sekcja 5.2.

### 2.2 Tryb głębokiego researchu (`src/research-engine.js`, 21.09.2026)

Punkt wyjścia: plugin użytkownika „Deep Sexual Research Plugin – MAX LEVEL" (224 linie,
`scratch/message-attachments/…`) — auto-aktywacja po słowach kluczowych, komendy
`/research`, trwały tryb + sticky, własna instrukcja i format odpowiedzi. Wszystkie te
zachowania są w Chloe, ale **przepisane na jej własną infrastrukturę**, bo oryginał kazał
modelowi *udawać* research (wstrzykiwał na stałe tekst „jesteś ekspertem, oprzyj się na
Redditcie…") i puchł od tego kontekst.

Co robi teraz (moduł `src/research-engine.js`, ~430 linii, doklejany na końcu bundle'a):

- **Realne rozpoznanie zamiast deklaracji.** Aktywacja odpala `chloeWebSearch` (19 źródeł:
  tube/hentai/e621/Bing PL+EN/Reddit + komentarze z redliba) i czyta strony przez
  `chloeReadPage`; z tego powstaje **dossier** z sekcjami WIEDZA / ODCZYTANE STRONY /
  REDDIT (wątek + komentarze) / STRONY / MEDIA / **LUKI** / ŹRÓDŁA (host: liczba pozycji).
  Sekcja LUKI mówi modelowi, czego nie znalazł — to główna ochrona przed wymyślaniem.
- **Zero puchnięcia kontekstu.** Doktryna + dossier jadą **tylko w bieżącym zadaniu**
  (blok `dyn` w `chloeE2BuildMessages`, na końcu promptu — prefiks-cache zostaje stabilny).
  Nic nie ląduje w historii wątku, więc tryb może być włączony na stałe. Ścieżka natywna
  (Perchance) nie ma tego haka, więc tam `chloeResearchNative()` wstrzykuje jedną wiadomość
  systemową (`hiddenFrom:["user"]`, `expectsReply:true`) i sprząta stare grupy (max 2).
- **Aktywacja punktowa.** `chloeResearchScore()` waży frazy (3 pkt: DIY, sprzęt/zabawki,
  techniki typu edging/prostate, wprost „research"; 2 pkt: poradnik, doświadczenia, fora;
  1 pkt: „najlepsze", „szukaj") i wymaga **drugiego czynnika** (pytanie / prośba /
  „najlepsze" / „pokaż"). Narracja RP (gwiazdki, cytat, `*akcja*`) dostaje karę, więc scena
  nie włącza trybu. Próg (`prog`, domyślnie 2), `auto on|off`, sticky (domyślnie 2).
- **Oszczędność sieci.** Cache zapytania na 12 minut + `CHLOE_RS_LAST`: ten sam temat
  (overlap tokenów ≥ 0,34) **nie** powtarza wyszukiwania, a krótkie dopytanie („a ile to
  kosztuje?") dostaje zapytanie **doprecyzowane** poprzednim tematem. Druga runda
  wyszukiwania odpala się tylko, gdy pierwsza dała mało danych; twardy budżet czasu
  (45 s / 75 s w trybie `gleboko`) i `strony` = ile stron czytać (0–6).
- **Doktryna** (`CHLOE_RS_DOCTRINE`, ~2 k chars) wymusza markery dowodów `[konsensus]` /
  `[pojedyncze]` / `[sporne]`, oddzielenie relacji ludzi od wiedzy medycznej, poziom ryzyka
  1–5 przy DIY, pełne linki z danych i format: Podsumowanie / Techniki / DIY / Szalone
  pomysły / Konsensus vs wyjątki / Źródła + pytanie o pogłębienie.
- **Panel**: konsola wyszukiwania (`/panel`) ma teraz sekcję **🔬 Głęboki research**
  (`chloeResearchPanelHtml`/`Wire` w `#ce2TabSearch`): przełącznik trybu w wątku, auto,
  próg/sticky/strony/głębia i przycisk **Research teraz** (pokazuje statystyki i odczytane
  strony). Komendy: `/research`, `on`, `off`, `status`, `teraz <temat>`, `auto on|off`,
  `prog N`, `sticky N`, `strony N`, `glebia szybko|auto|gleboko`, `pomoc`.

Ustawienia globalne: kv `chloe_research_v1` (`auto`, `sticky`, `prog`, `strony`, `glebia`,
`pokazuj`, `debug`). Stan per-wątek: `oc.thread.customData.__chloeResearch`
(`on`, `sticky`, `queries`). Wpisy researchu idą też do historii wyszukiwania
(`chloeHistoryAdd(q, "research")`).

**Zweryfikowane w podglądzie:** scoring 7 przypadków (DIY/edging/„opowiedz o technikach" =
aktywne; narracja `*…*`, „lubię twoje piersi", powitanie, „masz filmy?" = brak aktywacji),
refinement dopytań, cache (drugie wywołanie = 0 zapytań sieciowych), doktryna 2 062 znaki
z wszystkimi sekcjami, komendy, panel (DOM + przełączniki + przycisk) i dispatch w
`chloeHandleAddedMessage` (lokalny backend → `plan.research`, natywny → komunikat z
doktryną, zwykła rozmowa bez zmian).

## Modernization 2.0 build and regression checks

The root `package.json` now provides a deterministic, dependency-free build. Run
`npm run verify` to splice `rp-engine.js`, `memory-engine.js`, `img-engine.js`,
`model-router.js` and `research-engine.js` into `chloe-customcode.js`, embed the exact bundle
in `index.html`, check JavaScript syntax and execute the regression suite. Memory Engine v2
migrates v1 data in place and preserves all existing per-thread memories.

`src/MODELS.md` is the community research behind the model presets: RP-Bench/
PlotPoints benchmark data + EuroEval Polish + OpenRouter pricing, with a recommended
default (`mistralai/mistral-small-2603`) and alternatives (`google/gemma-4-26b-a4b-it`,
`deepseek/deepseek-v4-flash`).

### Wdrażanie zmian po stronie aplikacji (WAŻNE)

Sama podmiana bundla w `index.html` **nie zmienia kodu, który wykonuje otwarty wątek**:
ai-character-chat trzyma `customCode` w IndexedDB (`db.characters`), a `starterCharacters`
w `index.html` to tylko dane startowe dla *nowo dodawanej* postaci. Zmiany dotrą do
istniejących „Chloe” tylko po przepisaniu wierszy postaci. `index.html` wystawia do tego
dwie funkcje (obok `__chloeCloudDebug`):

```js
await __chloeDeployCode({dryRun:true}); // co by się zmieniło
await __chloeDeployCode();              // przepisz wszystkie wiersze z kodem Chloe
await __chloeRestoreCode(4);            // przywróć poprzedni kod postaci #4
```

Przed nadpisaniem stary kod trafia do magazynu `misc` jako `chloe_code_backup_<id>_<czas>`,
więc operacja jest odwracalna. Sprawdzenie po wdrożeniu:
`document.querySelector('iframe[sandbox="allow-scripts"]').getAttribute("srcdoc")` zawiera
nowe znaczniki (np. `ce2CloudPreset`), a `__chloeDeployCode({dryRun:true})` pokazuje
`already:true` dla wszystkich wierszy. **Uwaga:** w profilu tej przeglądarki żyła także
równoległa odmiana kodu (postać „Chloe 3.2”) z własnym licznikiem `chloe_e2_usage_v2`
i logiem `chloe_e2_telemetry_v1` (provider, TTFT, tokeny/s) — nie pochodzi z tego
repozytorium i została nadpisana razem z resztą; dane telemetryczne w `localStorage`
pozostały nietknięte.

## Model router (OpenRouter Auto + fallbacks + Jev)

Kanoniczne zrodlo: `src/model-router.js`. Jest doklejany na KONCU
`src/chloe-customcode.js` (znacznik `// CHLOE MODEL ROUTER`), a caly
bundle laduje jako `customCode` w `index.html` (pierwsze wystapienie) oraz
do zapisanych postaci Chloe w `db.characters`. Reczny re-splice:

1. Edytuj `src/model-router.js` (lub baze).
2. W `src/chloe-customcode.js` wytnij wszystko od znacznika routera do konca
   pliku i wklej nowa tresc `src/model-router.js`.
3. Podmien pierwszy blok `customCode: "..."` w `index.html` na
   `JSON.stringify(bundle)`.
4. Po przeladowaniu podgladu zaktualizuj zapisane Chloe:
   `fetch("src/chloe-customcode.js")` -> `db.characters.put()` dla
   `name === "Chloe"` -> przeladuj ponownie (iframe buduje sie z DB).
5. Weryfikacja w konsoli: `chloeModelRouter.status()`,
   `chloeModelRouter.preview("tekst")`.

Warstwy: main = `openrouter/auto` (plugin `auto-router`, allow-lista,
cost_tier, pasmo `models[]`) | jawne NSFW i retry po odmowie wprost do
uncensored Dolphin | utility = sztywno tani model bez reasoningu |
klasyfikator: domyslnie regex, opcjonalnie Jev (`classifier:"jev"`,
Decisions API, przy kazdym bledzie spada do regexa).
Wazne: baza wysyla `plugins`/`models` TYLKO do endpointow
OpenRouter/mostek/lokalnych (gate w `chloeE2Chat`), zeby nie popsuc
KoboldCpp. Faktyczny model z odpowiedzi laduje w `__chloeE2.model()`
i w `chloeModelRouter.status().lastRoute.actualModel`.
