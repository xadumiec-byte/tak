# AGENT-BRIEF — kontrakt integracji Chloe (Perchance ai-character-chat)

Ten plik jest przeznaczony dla ZEWNĘTRZNEGO agenta (Gemini/AI Studio/CLI), któremu
zlecamy pracę nad Chloe. Ma zastąpić zgadywanie architektury twardymi faktami.
Wszystkie ścieżki i numery linii odnoszą się do `src/chloe-customcode.js`.

## 0. Co agent ma prawo zwrócić (i tylko to)

Przyjmujemy WYŁĄCZNIE pliki **treści** (prompty), nie kod silnika:

| Plik | Zawartość |
|---|---|
| `roleInstruction.txt` | pełny string roli postaci, surowy tekst, **bez** JSON-escapowania, bez bloków kodu, w UTF-8 |
| `reminderMessage.txt` | pełny string przypomnienia, surowy tekst |
| `CHANGES.md` | co zmieniono i dlaczego + jak to wpływa na model Hermes 3 |

Opcjonalnie: `suggested-code-changes.md` z propozycjami zmian w kodzie (opis + uzasadnienie) —
ale NIE jako gotowy plik do wgrania.

ZAKAZANE deliverables: własny „engine", pliki z `window.addEventListener('message', …)`,
pliki `character_config.json` w obcym schemacie, pliki z JSON-em całej postaci (ryzyko
skasowania `customCode`), jakikolwiek plik wykonywalny.

## 1. Platforma i przepływ (jak to faktycznie działa)

- Generator to fork generatora Perchance `ai-character-chat` (nie OpenCharacters, nie Open WebUI).
- Kod custom-code to JEDEN **klasyczny** skrypt (nie moduł!): zero `import`/`export`,
  zero top-level `await`, zero Node, zero build-stepu, zero nowych zależności.
- Uruchamia się w sandboxowanym `iframe` o obcej origin. Widoczne globalne:
  `oc`, `window.__chloeE2`, `window.__chloeRP`, `window.__chloeImg` oraz funkcje tego skryptu.
- Warstwy:
  - `src/chloe-customcode.js` = **baza** (character-chat + konfiguracja Chloe) + `src/rp-engine.js` + `src/memory-engine.js` + `src/img-engine.js` + `src/model-router.js` + `src/research-engine.js`
  - ta całość jest osadzona w `index.html` jako JSON-owy string `customCode: "// ===== …` (jedna linia)
  - i wgrywana do tabeli `db.characters` (Dexie) — wiersze o `name === "Chloe"`;
    `index.html` ma dodatkowo `starterCharacters` (dotyczy tylko NOWYCH wątków).
    Wdrożenie: `await __chloeDeployCode()` / cofnięcie `await __chloeRestoreCode(id)`;
    build: `node src/tools/build.mjs`, testy: `node src/tests/regression.mjs`. UWAGA: kod w
    `db.characters` może pochodzić z innej linii niż to repo (spotkaliśmy wariant z
    `chloe_e2_usage_v2` + `chloe_e2_telemetry_v1`) — `__chloeDeployCode` robi kopię przed
    nadpisaniem, ale warto najpierw sprawdzić rozmiar/markery wiersza.
- Tryb głębokiego researchu (`src/research-engine.js`, 2.2 w `src/README.md`): `chloeResearchDecide`
  (punktowa ocena + drugi czynnik) → `chloeResearchRun` (dossier z prawdziwych źródeł, cache 12 min)
  → `chloeResearchDirective()` wstrzykiwana transientnie do `dyn` w `chloeE2BuildMessages`
  (lokalny backend) albo jako wiadomość systemowa z `chloeResearchNative` (Perchance).
- Nie edytuje się „ręcznie" zainstalowanego kodu: robi się re-splice modułów
  (`src/rp-engine.js` / `src/img-engine.js`) i re-embed (przepis w `src/README.md`).

## 2. Warstwy promptu widzianego przez model

Kolejność sklejania (ok. linii 2141–2170):

1. `oc.character.roleInstruction` (z `db.characters`, substytucja `{{char}}`/`{{user}}`)
2. `CHLOE_E2_RULES` (:1583) — twarde reguły silnika (odmowy, język, znaczniki)
3. `chloeRPRulesText()` (:3728) — reguły RP
4. `chloeRPConfigText()` — konfiguracja trybu pracy/narracji
5. `oc.character.reminderMessage` (:2166) — przypomnienie na koniec

Ścieżka RP (:4326) używa `roleInstruction` + `chloeRPRulesText()`. Dlatego prompt z postaci
NIE jest jedynym źródłem instrukcji — agent ma go dopasować do reszty, nie duplikować reguł
z `CHLOE_E2_RULES` ani z `chloeRPRulesText()` i nie stać im w sprzeczności.

## 3. Kontrakt znaczników w odpowiedzi modelu (NIE zmieniać)

- `<image>ANGIELSKI OPIS OBRAZU</image>` — DOKŁADNIE jeden znacznik na odpowiedź; opis po
  angielsku, 70–120 słów, maksymalnie wprost. Ochrona treści: :1470, reguła: :1589,
  przypomnienie z zasadami: :2559.
- `<search>zapytanie</search>` (aliasy: `websearch`, `wyszukaj`, `szukaj`; regex `CHLOE_TAG_G` :10,
  użycie :3509) — dodatkowe wyszukiwanie w tle.
- `<<stan {...}>>` — jedna linia stanu sceny na końcu odpowiedzi.
- `[[krótka akcja]]` — 3–4 klikalne propozycje dalszych akcji (ochrona przed zamianą: :1467).
- Domyślna długość: 3–5 akapitów, ok. 220 słów.

## 4. Ustawienia (gdzie żyją, jak się nazywają)

- Własny model — `chloeE2Defaults()` (:1803): `backend` (`perchance`|`kobold`), `apiKey`,
  `baseUrl`, `model`, `temperature` (domyślnie 0.9), `maxTokens` (2000), `timeoutSec` (300),
  `injectLore`, `localFlowBaseUrl`, `directToComfy`. Persystencja: klucz `chloe_backend_v2`.
- Lista modeli: `CHLOE_E2_PRESETS` (:1550) + ceny `CHLOE_E2_PRICES` (:1566); UI listy: :3109.
  `nousresearch/hermes-3-llama-3.1-70b` jest już na liście (wpis #6).
- Endpoint modelu: OpenAI-compatible, `POST {baseUrl}/chat/completions`
  (`oc.getChatCompletion` w trybie natywnym Perchance). Zawartość wiadomości = czysty tekst:
  **żadnych tokenów ChatML `<|im_start|>`** (role ustawia API samo).
- Obrazy — `chloeCloudDefaults()` (~:1900): `provider` (`horde`|`custom`|`comfy`), `width`,
  `height`, `steps`, `cfg`, `sampler`, `nsfw`, `customBaseUrl`, `customKey`, `customModel`,
  `customSize`, `comfyBaseUrl`, `comfyWorkflow`, `comfyPositiveNode`, `comfyNegativeNode`,
  `localFlowPreset`, `fallbackNative`. Persystencja: klucz `chloe_cloudimg_v1`.
  `localFlowPreset` = tryb obrazu mostka (`default`/`fast`/`classic`/`sdxl_fast`/`sdxl_cfg8`/
  `sdxl_std`/`sdxl_hq`, puste = auto); UI: select `#ce2CloudPreset` + `#ce2CloudPresetBtn`
  (↻ Odśwież tryby → `GET <base>/health` → `tryby`), komenda `/obraz tryb <nazwa>`.
- Mostek lokalny: podajemy **bazowy** adres, kod dokłada `/api/generate`; `directToComfy: true`
  pomija Stheno (LLM dopracowujący prompt) i wysyła prompt prosto do ComfyUI.

## 5. API `oc` i mostek do strony-rodzica

- `oc.thread.on("MessageAdded", fn)` (:3557), `oc.thread.messages` (`push`/`splice`),
  `oc.thread.customData`, `oc.thread.shortcutButtons`, `oc.character.*`
  (`roleInstruction`, `reminderMessage`, `name`, `customData`, `imagePrompt*`),
  `oc.userCharacter`, `oc.getChatCompletion({messages, temperature, maxTokens, stopSequences})`,
  `oc.generateText`, `oc.messageRenderingPipeline.push`, `oc.window.show`.
- Wyjście do UI: `chloeParentCall({ type: "chloeSend", text })` (:1442) — strona-rodzic
  renderuje obrazy z `<image>` i robi resztę UI. Ustawienia backendu:
  `chloeParentCall({ type: "chloeBackendStore", op: "get"|"set", key, value })`.
  **Nie** wysyłamy surowych `window.postMessage` — to inny protokół.

## 6. Format postaci (import/export) — jeśli kiedyś potrzebny

`{ "character": { ... }, "lore": { "0": {...}, "1": {...}, ... } }`

Pola `character`: `name`, `roleInstruction`, `reminderMessage`, `initialMessages`
(`{author, content, hiddenFrom}`), `shortcutButtons` (`{name, message, insertionType, autoSend,
clearAfterSend, type}`), `avatar` (`{url, size, shape}`), `loreBookUrls` (tablica URL-i do .txt),
`temperature`, `maxTokensPerMessage`, `modelName`, `streamingResponse`, `customCode`,
`generalWritingInstructions`, `imagePromptTriggers` / `imagePromptPrefix` / `imagePromptSuffix`,
`scene`, `userCharacter`, `systemCharacter`, `customData`, `uuid`, `id`.

## 7. Antywzorce (to NIE zadziała u nas — z odrzuconej paczki „hermes3_v7_pack")

- `window.addEventListener("message", …)` + `event.data.type === "messageadded"` → u nas `oc.thread.on("MessageAdded", …)`.
- `window.postMessage({ type: "chloeSend", … })` → u nas `chloeParentCall({ type: "chloeSend", text })`.
- `http://127.0.0.1:5000/generate` + `{prompt, width, height, negative_prompt}` → u nas bazowy
  URL + `/api/generate`, pełny workflow ComfyUI (`comfyWorkflow` + `comfyPositiveNode`/`comfyNegativeNode`).
- `[IMAGE_GEN: …]` → u nas `<image>…</image>` (obsługiwane end-to-end).
- Tokeny ChatML (`<|im_start|>`) w treści wiadomości → psują prompt.
- Płaski schemat postaci (`samplingParameters`, `openRouterModel`, `avatar.url` jako string)
  → nie jest schematem Perchance.
- Zmyślone URL-e (np. `i.imgur.com/v7_chloe_avatar.png` — nie istnieje).
- Nowe zależności / CDN / moduły ES / build-step → zakazane.
